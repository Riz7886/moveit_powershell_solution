# SCRIPT 1: AUDIT NAMING ISSUES ONLY
# Shows what needs to be fixed - makes NO changes

Clear-Host
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  AZURE NAMING AUDIT REPORT" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Force fresh Azure login
Write-Host "Logging into Azure..." -ForegroundColor Yellow
Disconnect-AzAccount -ErrorAction SilentlyContinue | Out-Null
$null = Connect-AzAccount

$sub = Get-AzContext
if (-not $sub) {
    Write-Host "ERROR: Not connected to Azure" -ForegroundColor Red
    exit
}

Write-Host "Subscription: $($sub.Subscription.Name)" -ForegroundColor Green
Write-Host ""

# Get all resource groups
Write-Host "Scanning resource groups..." -ForegroundColor Yellow
$rgs = Get-AzResourceGroup
Write-Host "Found: $($rgs.Count) resource groups" -ForegroundColor Green
Write-Host ""

# Find naming issues
$issues = @()

foreach ($rg in $rgs) {
    Write-Host "  Checking: $($rg.ResourceGroupName)" -ForegroundColor Gray
    
    $res = Get-AzResource -ResourceGroupName $rg.ResourceGroupName -ErrorAction SilentlyContinue
    $dbWS = $res | Where-Object {$_.ResourceType -eq "Microsoft.Databricks/workspaces"}
    
    $env = "Unknown"
    if ($rg.ResourceGroupName -match "prod" -and $rg.ResourceGroupName -notmatch "preprod") { $env = "Production" }
    elseif ($rg.ResourceGroupName -match "preprod|pre-prod") { $env = "PreProd" }
    elseif ($rg.ResourceGroupName -match "poc") { $env = "POC" }
    elseif ($rg.ResourceGroupName -match "dev") { $env = "Dev" }
    elseif ($rg.ResourceGroupName -match "test|qa") { $env = "Test" }
    
    $problems = @()
    
    # Check POC with prod resources
    if ($env -eq "POC") {
        foreach ($r in $res) {
            if ($r.Name -match "prod" -and $r.Name -notmatch "preprod") {
                $problems += "Contains production resource: $($r.Name)"
            }
        }
    }
    
    # Check PreProd with prod resources
    if ($env -eq "PreProd") {
        foreach ($r in $res) {
            if ($r.Name -match "-prod$|prod-") {
                $problems += "Contains prod-named resource: $($r.Name)"
            }
        }
    }
    
    if ($problems.Count -gt 0) {
        $issues += [PSCustomObject]@{
            RG = $rg.ResourceGroupName
            Env = $env
            Location = $rg.Location
            Count = $res.Count
            Databricks = if ($dbWS) { ($dbWS.Name -join ", ") } else { "None" }
            Issues = ($problems -join " | ")
        }
    }
}

# Generate HTML
$rows = ""
foreach ($i in $issues) {
    $rows += "<tr><td><b>$($i.RG)</b></td><td>$($i.Env)</td><td>$($i.Count)</td><td>$($i.Databricks)</td><td style='color:red'>$($i.Issues)</td></tr>"
}

$file = "Naming-Issues-$(Get-Date -Format 'yyyyMMdd-HHmmss').html"

$html = @"
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Azure Naming Issues</title>
<style>
body{font-family:Arial;margin:20px;background:#f5f5f5}
.box{max-width:1600px;margin:0 auto;background:white;padding:30px;border-radius:8px}
h1{color:#FF3621;font-size:28px}
table{width:100%;border-collapse:collapse;margin:20px 0}
th{background:#1B3139;color:white;padding:12px;text-align:left}
td{padding:10px;border-bottom:1px solid #ddd}
tr:hover{background:#f5f5f5}
.warn{background:#fff3cd;padding:15px;border-left:4px solid #ffc107;margin:15px 0}
</style>
</head>
<body>
<div class="box">
<h1>Azure Environment Naming Issues</h1>
<p><b>Date:</b> $(Get-Date -Format 'yyyy-MM-dd HH:mm')</p>
<p><b>Subscription:</b> $($sub.Subscription.Name)</p>
<div class="warn">
<h3>Issues Found: $($issues.Count)</h3>
<p>Resource groups with naming mismatches detected.</p>
</div>
<table>
<tr>
<th>Resource Group</th>
<th>Environment</th>
<th>Resources</th>
<th>Databricks</th>
<th>Issues</th>
</tr>
$rows
</table>
<h2>Next Steps</h2>
<ol>
<li>Review with Brian/Team to verify true environments</li>
<li>Run SCRIPT 2 to rename resource groups</li>
<li>Update documentation after changes</li>
</ol>
</div>
</body>
</html>
"@

$html | Out-File $file -Encoding UTF8

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  COMPLETE" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Issues Found: $($issues.Count)" -ForegroundColor $(if ($issues.Count -gt 0) {"Red"} else {"Green"})
Write-Host "Report: $file" -ForegroundColor Green
Write-Host ""

Start-Process $file
Write-Host "Done!" -ForegroundColor Green
