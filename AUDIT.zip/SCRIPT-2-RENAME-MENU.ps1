# SCRIPT 2: RENAME RESOURCE GROUPS - INTERACTIVE MENU
# Lets you choose what to rename

Clear-Host
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  AZURE RESOURCE GROUP RENAME TOOL" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Force fresh login
Write-Host "Logging into Azure..." -ForegroundColor Yellow
Disconnect-AzAccount -ErrorAction SilentlyContinue | Out-Null
$null = Connect-AzAccount

$sub = Get-AzContext
if (-not $sub) {
    Write-Host "ERROR: Not connected" -ForegroundColor Red
    exit
}

Write-Host "Subscription: $($sub.Subscription.Name)" -ForegroundColor Green
Write-Host ""

# Get resource groups
Write-Host "Loading resource groups..." -ForegroundColor Yellow
$rgs = Get-AzResourceGroup
Write-Host "Found: $($rgs.Count) resource groups" -ForegroundColor Green
Write-Host ""

# Find ones with issues
$problems = @()

foreach ($rg in $rgs) {
    $res = Get-AzResource -ResourceGroupName $rg.ResourceGroupName -ErrorAction SilentlyContinue
    
    $env = "Unknown"
    if ($rg.ResourceGroupName -match "prod" -and $rg.ResourceGroupName -notmatch "preprod") { $env = "Production" }
    elseif ($rg.ResourceGroupName -match "preprod|pre-prod") { $env = "PreProd" }
    elseif ($rg.ResourceGroupName -match "poc") { $env = "POC" }
    
    $hasIssue = $false
    
    if ($env -eq "POC") {
        foreach ($r in $res) {
            if ($r.Name -match "prod" -and $r.Name -notmatch "preprod") {
                $hasIssue = $true
                break
            }
        }
    }
    
    if ($env -eq "PreProd") {
        foreach ($r in $res) {
            if ($r.Name -match "-prod$|prod-") {
                $hasIssue = $true
                break
            }
        }
    }
    
    if ($hasIssue) {
        $problems += [PSCustomObject]@{
            Current = $rg.ResourceGroupName
            Env = $env
            Location = $rg.Location
            Count = $res.Count
        }
    }
}

if ($problems.Count -eq 0) {
    Write-Host "No naming issues found!" -ForegroundColor Green
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit
}

# Show menu
while ($true) {
    Clear-Host
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  RESOURCE GROUP RENAME MENU" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Found $($problems.Count) resource groups with naming issues:" -ForegroundColor Yellow
    Write-Host ""
    
    for ($i = 0; $i -lt $problems.Count; $i++) {
        Write-Host "  [$($i+1)] $($problems[$i].Current)" -ForegroundColor White
        Write-Host "      Environment: $($problems[$i].Env) | Location: $($problems[$i].Location)" -ForegroundColor Gray
        Write-Host ""
    }
    
    Write-Host ""
    Write-Host "OPTIONS:" -ForegroundColor Cyan
    Write-Host "  [A] Show ALL mislabeled resource groups" -ForegroundColor White
    Write-Host "  [R] Rename a specific resource group" -ForegroundColor White
    Write-Host "  [L] List suggested new names" -ForegroundColor White
    Write-Host "  [X] Exit" -ForegroundColor White
    Write-Host ""
    
    $choice = Read-Host "Select option"
    
    if ($choice -eq "X" -or $choice -eq "x") {
        Write-Host "Exiting..." -ForegroundColor Yellow
        break
    }
    
    if ($choice -eq "A" -or $choice -eq "a") {
        Write-Host ""
        Write-Host "All Mislabeled Resource Groups:" -ForegroundColor Cyan
        foreach ($p in $problems) {
            Write-Host "  - $($p.Current) [$($p.Env)]" -ForegroundColor Yellow
        }
        Write-Host ""
        Read-Host "Press Enter to continue"
        continue
    }
    
    if ($choice -eq "L" -or $choice -eq "l") {
        Write-Host ""
        Write-Host "Suggested Naming Convention:" -ForegroundColor Cyan
        Write-Host "  Format: Company-Project-Environment-Region" -ForegroundColor White
        Write-Host ""
        Write-Host "Examples:" -ForegroundColor Yellow
        Write-Host "  Pyx-Warehouse-Prod-EastUS" -ForegroundColor White
        Write-Host "  Pyx-Warehouse-PreProd-EastUS" -ForegroundColor White
        Write-Host "  Pyx-Analytics-Dev-EastUS" -ForegroundColor White
        Write-Host ""
        Write-Host "Current Resource Groups:" -ForegroundColor Cyan
        foreach ($p in $problems) {
            $suggested = $p.Current -replace "POC", "Prod" -replace "preprod", "PreProd"
            Write-Host "  OLD: $($p.Current)" -ForegroundColor Red
            Write-Host "  NEW: $suggested (suggested)" -ForegroundColor Green
            Write-Host ""
        }
        Read-Host "Press Enter to continue"
        continue
    }
    
    if ($choice -eq "R" -or $choice -eq "r") {
        Write-Host ""
        $oldName = Read-Host "Enter CURRENT resource group name"
        $newName = Read-Host "Enter NEW resource group name"
        
        if (-not $oldName -or -not $newName) {
            Write-Host "ERROR: Both names required" -ForegroundColor Red
            Start-Sleep -Seconds 2
            continue
        }
        
        Write-Host ""
        Write-Host "WARNING: Azure does not support direct RG renaming!" -ForegroundColor Yellow
        Write-Host "You must:" -ForegroundColor Yellow
        Write-Host "  1. Create new RG with new name" -ForegroundColor White
        Write-Host "  2. Move resources to new RG" -ForegroundColor White
        Write-Host "  3. Delete old RG" -ForegroundColor White
        Write-Host ""
        Write-Host "Commands to execute:" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "  # Create new RG" -ForegroundColor Gray
        Write-Host "  New-AzResourceGroup -Name '$newName' -Location 'EastUS'" -ForegroundColor White
        Write-Host ""
        Write-Host "  # Move resources (do for each resource)" -ForegroundColor Gray
        Write-Host "  Move-AzResource -ResourceId '/subscriptions/.../resourceGroups/$oldName/...' -DestinationResourceGroupName '$newName'" -ForegroundColor White
        Write-Host ""
        Write-Host "  # Delete old RG (after all moved)" -ForegroundColor Gray
        Write-Host "  Remove-AzResourceGroup -Name '$oldName' -Force" -ForegroundColor White
        Write-Host ""
        
        $confirm = Read-Host "Copy commands to clipboard? (Y/N)"
        if ($confirm -eq "Y" -or $confirm -eq "y") {
            $commands = @"
# Rename $oldName to $newName
New-AzResourceGroup -Name '$newName' -Location 'EastUS'
# Move resources (update ResourceId for each resource)
# Move-AzResource -ResourceId '/subscriptions/.../resourceGroups/$oldName/...' -DestinationResourceGroupName '$newName'
Remove-AzResourceGroup -Name '$oldName' -Force
"@
            $commands | Set-Clipboard
            Write-Host "Commands copied to clipboard!" -ForegroundColor Green
        }
        
        Write-Host ""
        Read-Host "Press Enter to continue"
        continue
    }
    
    Write-Host "Invalid option" -ForegroundColor Red
    Start-Sleep -Seconds 1
}

Write-Host "Done!" -ForegroundColor Green
