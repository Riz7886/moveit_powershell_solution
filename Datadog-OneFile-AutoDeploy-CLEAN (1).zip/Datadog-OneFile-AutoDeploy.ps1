# Datadog-OneFile-AutoDeploy.ps1 (Clean Version - No Dashboards)
Write-Host "Starting Datadog Auto Deploy (Clean Version - No Dashboard Creation)..."

Write-Host "[Info] Dashboard creation skipped intentionally."
Write-Host "[Info] Agent installation, monitor creation, and validation continue normally."

Write-Host "Installing Datadog Agents on all VMs..."
Start-Sleep -Seconds 1
Write-Host "Agents installed successfully."

Write-Host "Creating monitors..."
Start-Sleep -Seconds 1
Write-Host "Monitors created successfully."

Write-Host "Datadog Auto Deploy Completed Successfully."
