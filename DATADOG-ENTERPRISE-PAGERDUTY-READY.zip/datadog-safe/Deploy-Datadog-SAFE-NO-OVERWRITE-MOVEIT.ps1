#Requires -Version 5.1
<#
.SYNOPSIS
    Datadog SAFE Deployment - NO OVERWRITES + MOVEIT MONITORING
    
.DESCRIPTION
    100% SAFE:
    - PREVIEW MODE: See what will be created BEFORE creating
    - Checks for existing monitors (no duplicates)
    - ONLY ADDS new monitors, never modifies existing
    - MOVEIT SERVER monitoring included
    - Can run on LIVE production without risk
    
.NOTES
    Safety: Preview first, then deploy
    MOVEit: Dedicated monitoring for MOVEit Transfer servers
#>

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# CONFIGURATION
$Script:Config = @{
    DatadogAPIKey = '14fe5ae3-6459-40a4-8f3b-b3c8c97e520e'
    DatadogAppKey = '195558c2-6170-4af6-ba4f-4267b05e4017'
    DatadogSite = 'us3.datadoghq.com'
    DatadogAPIURL = 'https://api.us3.datadoghq.com/api/v1'
    
    # SECURITY: Emails from config file
    AlertEmails = @()
    
    PagerDuty = '@pagerduty-pyxhealth-oncall'
    SlackProd = '@slack-alerts-prod'
}

$Script:DeploymentLog = @()
$Script:ExistingMonitors = @()
$Script:PreviewMode = $false

# ==============================================================================
# LOGGING
# ==============================================================================

function Write-Log {
    param([string]$Message, [string]$Level = 'Info')
    
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $logEntry = "[$timestamp] [$Level] $Message"
    $Script:DeploymentLog += $logEntry
    
    $color = switch ($Level) {
        'Info' { 'Cyan' }
        'Success' { 'Green' }
        'Warning' { 'Yellow' }
        'Error' { 'Red' }
    }
    
    Write-Host $Message -ForegroundColor $color
}

function Show-Banner {
    param([string]$Title)
    
    Clear-Host
    Write-Host ""
    Write-Host "=====================================================================" -ForegroundColor Cyan
    Write-Host "  DATADOG SAFE DEPLOYMENT - NO OVERWRITES" -ForegroundColor White
    Write-Host "=====================================================================" -ForegroundColor Cyan
    if ($Title) {
        Write-Host "  $Title" -ForegroundColor Yellow
    }
    Write-Host ""
}

# ==============================================================================
# SECURE EMAIL CONFIGURATION
# ==============================================================================

function Initialize-SecureConfig {
    Show-Banner -Title "LOADING SECURE CONFIGURATION"
    
    Write-Log "Loading team email configuration..." "Info"
    
    $configFile = Join-Path $PSScriptRoot "team-emails-config.txt"
    
    if (Test-Path $configFile) {
        $Script:Config.AlertEmails = Get-Content $configFile | Where-Object { $_ -match '@' }
        Write-Log "Loaded $($Script:Config.AlertEmails.Count) email addresses" "Success"
    }
    else {
        Write-Log "No config file found. Creating template..." "Warning"
        Write-Host ""
        Write-Host "SECURITY: Enter team member emails for alerts" -ForegroundColor Yellow
        Write-Host "Enter one email per line. Press Enter twice when done." -ForegroundColor White
        Write-Host ""
        
        $emails = @()
        do {
            $email = Read-Host "Email address (or press Enter to finish)"
            if ($email -and $email -match '@') {
                $emails += $email
                Write-Host "  Added: $email" -ForegroundColor Green
            }
        } while ($email)
        
        if ($emails.Count -gt 0) {
            $Script:Config.AlertEmails = $emails
            $emails | Out-File $configFile
            Write-Log "Saved $($emails.Count) emails to secure config file" "Success"
        }
    }
    
    Write-Host ""
}

# ==============================================================================
# SAFETY: CHECK EXISTING MONITORS
# ==============================================================================

function Get-ExistingMonitors {
    Show-Banner -Title "SAFETY CHECK: GETTING EXISTING MONITORS"
    
    Write-Log "Checking existing Datadog monitors..." "Info"
    Write-Log "This ensures we don't create duplicates" "Info"
    Write-Host ""
    
    try {
        $headers = @{
            'DD-API-KEY' = $Script:Config.DatadogAPIKey
            'DD-APPLICATION-KEY' = $Script:Config.DatadogAppKey
        }
        
        $response = Invoke-RestMethod -Uri "$($Script:Config.DatadogAPIURL)/monitor" -Method Get -Headers $headers
        $Script:ExistingMonitors = $response
        
        Write-Host ""
        Write-Host "EXISTING MONITORS FOUND:" -ForegroundColor Yellow
        Write-Host "  Total monitors: $($Script:ExistingMonitors.Count)" -ForegroundColor White
        Write-Host ""
        
        # Group by tag
        $prodMonitors = $Script:ExistingMonitors | Where-Object { $_.tags -contains 'env:production' }
        $managedMonitors = $Script:ExistingMonitors | Where-Object { $_.tags -contains 'managed:automation' }
        
        Write-Host "  Production monitors: $($prodMonitors.Count)" -ForegroundColor Cyan
        Write-Host "  Automation-managed: $($managedMonitors.Count)" -ForegroundColor Cyan
        Write-Host ""
        
        Write-Log "Safety check complete" "Success"
        Write-Host ""
        
        return $true
    }
    catch {
        Write-Log "Could not retrieve existing monitors: $($_.Exception.Message)" "Warning"
        return $false
    }
}

function Test-MonitorExists {
    param([string]$MonitorName)
    
    foreach ($monitor in $Script:ExistingMonitors) {
        if ($monitor.name -eq $MonitorName) {
            return $true
        }
    }
    return $false
}

# ==============================================================================
# MONITOR CREATION
# ==============================================================================

function New-DatadogMonitor {
    param(
        [string]$Name,
        [string]$Type,
        [string]$Query,
        [string]$Message,
        [hashtable]$Options,
        [string[]]$Tags
    )
    
    # SAFETY CHECK: Does monitor already exist?
    if (Test-MonitorExists -MonitorName $Name) {
        if ($Script:PreviewMode) {
            Write-Host "  SKIP (already exists)" -ForegroundColor Yellow
        }
        else {
            Write-Host "  SKIPPED - Already exists" -ForegroundColor Yellow
        }
        return $false
    }
    
    # PREVIEW MODE: Don't actually create
    if ($Script:PreviewMode) {
        Write-Host "  WOULD CREATE (preview)" -ForegroundColor Cyan
        return $true
    }
    
    # LIVE MODE: Create the monitor
    try {
        $headers = @{
            'DD-API-KEY' = $Script:Config.DatadogAPIKey
            'DD-APPLICATION-KEY' = $Script:Config.DatadogAppKey
            'Content-Type' = 'application/json'
        }
        
        $body = @{
            name = $Name
            type = $Type
            query = $Query
            message = $Message
            tags = $Tags
            options = $Options
        } | ConvertTo-Json -Depth 10
        
        Invoke-RestMethod -Uri "$($Script:Config.DatadogAPIURL)/monitor" -Method Post -Headers $headers -Body $body -ErrorAction Stop | Out-Null
        Write-Host "  CREATED" -ForegroundColor Green
        return $true
    }
    catch {
        Write-Host "  FAILED: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# ==============================================================================
# AZURE CONNECTION
# ==============================================================================

function Install-AzureModules {
    Show-Banner -Title "CHECKING PREREQUISITES"
    
    $requiredModules = @('Az.Accounts', 'Az.Compute', 'Az.Resources')
    
    foreach ($module in $requiredModules) {
        if (-not (Get-Module -ListAvailable -Name $module)) {
            Write-Log "Installing $module..." "Warning"
            Install-Module -Name $module -Repository PSGallery -Force -AllowClobber -Scope CurrentUser -SkipPublisherCheck
        }
    }
    
    Write-Log "All modules ready" "Success"
    Write-Host ""
}

function Connect-ToAzure {
    Show-Banner -Title "CONNECTING TO AZURE"
    
    $context = Get-AzContext -ErrorAction SilentlyContinue
    
    if (-not $context) {
        Write-Log "Logging in to Azure..." "Info"
        Connect-AzAccount
    }
    else {
        Write-Log "Connected as: $($context.Account.Id)" "Success"
    }
    
    Write-Host ""
    return $true
}

function Select-Subscriptions {
    Show-Banner -Title "SELECTING SUBSCRIPTIONS"
    
    $subscriptions = Get-AzSubscription
    
    Write-Host "Available subscriptions:" -ForegroundColor Yellow
    Write-Host ""
    
    for ($i = 0; $i -lt $subscriptions.Count; $i++) {
        $sub = $subscriptions[$i]
        Write-Host "  [$($i + 1)] $($sub.Name)" -ForegroundColor White
    }
    
    Write-Host ""
    Write-Host "  [A] ALL subscriptions" -ForegroundColor Green
    Write-Host ""
    
    $selection = Read-Host "Select (1-$($subscriptions.Count) or A)"
    
    if ($selection -eq 'A' -or $selection -eq 'a') {
        return $subscriptions
    }
    
    $num = [int]$selection - 1
    return @($subscriptions[$num])
}

# ==============================================================================
# COMPREHENSIVE MONITORS INCLUDING MOVEIT
# ==============================================================================

function New-ComprehensiveMonitors {
    param([array]$Subscriptions)
    
    $mode = if ($Script:PreviewMode) { "PREVIEW MODE - NO CHANGES" } else { "LIVE DEPLOYMENT" }
    Show-Banner -Title "CREATING MONITORS - $mode"
    
    Write-Host "Creating COMPREHENSIVE monitoring for ALL 13 SUBSCRIPTIONS" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Monitoring EVERYTHING:" -ForegroundColor Yellow
    Write-Host "  - MOVEIT Transfer Servers (10 monitors)" -ForegroundColor White
    Write-Host "  - Virtual Machines" -ForegroundColor White
    Write-Host "  - App Services" -ForegroundColor White
    Write-Host "  - SQL Databases" -ForegroundColor White
    Write-Host "  - Storage Accounts" -ForegroundColor White
    Write-Host "  - Load Balancers (4 monitors)" -ForegroundColor White
    Write-Host "  - Network Security Groups NSG (4 monitors)" -ForegroundColor White
    Write-Host "  - RBAC Role Assignments (4 monitors)" -ForegroundColor White
    Write-Host "  - Azure Policy (3 monitors)" -ForegroundColor White
    Write-Host "  - Port Scanning and Security (4 monitors)" -ForegroundColor White
    Write-Host "  - Additional Security (6 monitors)" -ForegroundColor White
    Write-Host ""
    Write-Host "TOTAL: 47 monitors per subscription" -ForegroundColor Cyan
    Write-Host "For 13 subscriptions: 611 total monitors" -ForegroundColor Cyan
    Write-Host ""
    
    $emailNotifications = ($Script:Config.AlertEmails | ForEach-Object { "@$_" }) -join ' '
    
    $totalCreated = 0
    $totalSkipped = 0
    
    foreach ($sub in $Subscriptions) {
        $isProd = $sub.Name -match 'prod'
        $env = if ($isProd) { 'PRODUCTION' } else { $sub.Name }
        
        $notify = "$emailNotifications $($Script:Config.PagerDuty) $($Script:Config.SlackProd)"
        $tags = @('managed:automation', 'company:secure', "env:production", "subscription:$($sub.Id)")
        
        Write-Host "Subscription: $($sub.Name)" -ForegroundColor Yellow
        Write-Host ""
        
        # COMPREHENSIVE MONITORS - INCLUDING MOVEIT + ALL SECURITY
        $monitors = @(
            # ========== MOVEIT TRANSFER SERVERS ==========
            @{ Name = "MOVEIT [$env] Server Down"; Type = 'service check'; Query = "datadog.agent.up{service:moveit,subscription_id:$($sub.Id)}.by('host').last(2).count_by_status()"; Message = "CRITICAL: MOVEit Transfer server {{host.name}} is DOWN. $notify"; Options = @{ thresholds = @{ critical = 1 }; notify_no_data = $true; no_data_timeframe = 10 } },
            @{ Name = "MOVEIT [$env] Service Not Running"; Type = 'service check'; Query = "'MOVEit.Transfer.Service'{subscription_id:$($sub.Id)}.by('host').last(2).count_by_status()"; Message = "CRITICAL: MOVEit Transfer Service stopped on {{host.name}}. $notify"; Options = @{ thresholds = @{ critical = 1 }; notify_no_data = $true; no_data_timeframe = 10 } },
            @{ Name = "MOVEIT [$env] CPU Critical"; Type = 'metric alert'; Query = "avg(last_5m):avg:system.cpu.user{service:moveit,subscription_id:$($sub.Id)} by {host} > 90"; Message = "CRITICAL: MOVEit server {{host.name}} CPU at 90%+. $notify"; Options = @{ thresholds = @{ critical = 90; warning = 80 }; notify_no_data = $true } },
            @{ Name = "MOVEIT [$env] Memory Critical"; Type = 'metric alert'; Query = "avg(last_5m):avg:system.mem.pct_usable{service:moveit,subscription_id:$($sub.Id)} by {host} < 10"; Message = "CRITICAL: MOVEit server {{host.name}} memory at 90%+. $notify"; Options = @{ thresholds = @{ critical = 10; warning = 20 }; notify_no_data = $true } },
            @{ Name = "MOVEIT [$env] Disk Space Critical"; Type = 'metric alert'; Query = "avg(last_5m):avg:system.disk.in_use{service:moveit,subscription_id:$($sub.Id)} by {host,device} > 0.90"; Message = "CRITICAL: MOVEit server {{host.name}} disk at 90%+. File transfers may fail. $notify"; Options = @{ thresholds = @{ critical = 0.90; warning = 0.80 }; notify_no_data = $true } },
            @{ Name = "MOVEIT [$env] Web Interface Down"; Type = 'metric alert'; Query = "avg(last_10m):avg:http.can_connect{service:moveit,subscription_id:$($sub.Id)} by {host} < 1"; Message = "CRITICAL: MOVEit web interface unreachable on {{host.name}}. $notify"; Options = @{ thresholds = @{ critical = 1 }; notify_no_data = $true; no_data_timeframe = 15 } },
            @{ Name = "MOVEIT [$env] Failed Login Attempts"; Type = 'log alert'; Query = "logs('service:moveit status:error failed login subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 10"; Message = "WARNING: Multiple failed login attempts on MOVEit. Possible security breach. $notify"; Options = @{ thresholds = @{ critical = 20; warning = 10 }; notify_no_data = $false } },
            @{ Name = "MOVEIT [$env] File Transfer Failures"; Type = 'log alert'; Query = "logs('service:moveit status:error transfer failed subscription_id:$($sub.Id)').index('*').rollup('count').last('15m') > 5"; Message = "WARNING: File transfer failures on MOVEit {{host.name}}. $notify"; Options = @{ thresholds = @{ critical = 10; warning = 5 }; notify_no_data = $false } },
            @{ Name = "MOVEIT [$env] Database Connection Lost"; Type = 'metric alert'; Query = "avg(last_5m):avg:sqlserver.database.connection_status{service:moveit,subscription_id:$($sub.Id)} < 1"; Message = "CRITICAL: MOVEit database connection lost. All transfers halted. $notify"; Options = @{ thresholds = @{ critical = 1 }; notify_no_data = $true; no_data_timeframe = 10 } },
            @{ Name = "MOVEIT [$env] License Expiring Soon"; Type = 'log alert'; Query = "logs('service:moveit license expir* subscription_id:$($sub.Id)').index('*').rollup('count').last('1d') > 0"; Message = "WARNING: MOVEit license expiring soon. Check license status. $notify"; Options = @{ thresholds = @{ warning = 0 }; notify_no_data = $false } },
            
            # ========== VIRTUAL MACHINES ==========
            @{ Name = "PROD [$env] VM CPU Critical"; Type = 'metric alert'; Query = "avg(last_5m):avg:azure.vm.percentage_cpu{subscription_id:$($sub.Id)} by {host} > 90"; Message = "CRITICAL: VM CPU 90%+ on {{host.name}}. $notify"; Options = @{ thresholds = @{ critical = 90 }; notify_no_data = $true; no_data_timeframe = 10 } },
            @{ Name = "PROD [$env] VM Down"; Type = 'metric alert'; Query = "avg(last_10m):avg:azure.vm.status{subscription_id:$($sub.Id)} by {vm_name} < 1"; Message = "CRITICAL: VM {{vm_name}} is DOWN. $notify"; Options = @{ thresholds = @{ critical = 1 }; notify_no_data = $true; no_data_timeframe = 10 } },
            @{ Name = "PROD [$env] VM Memory Critical"; Type = 'metric alert'; Query = "avg(last_5m):avg:system.mem.pct_usable{subscription_id:$($sub.Id)} by {host} < 10"; Message = "CRITICAL: Memory 90%+ on {{host.name}}. $notify"; Options = @{ thresholds = @{ critical = 10 }; notify_no_data = $true } },
            @{ Name = "PROD [$env] VM Disk Critical"; Type = 'metric alert'; Query = "avg(last_5m):avg:system.disk.in_use{subscription_id:$($sub.Id)} by {host,device} > 0.90"; Message = "CRITICAL: Disk 90%+ on {{host.name}}. $notify"; Options = @{ thresholds = @{ critical = 0.90 }; notify_no_data = $true } },
            
            # ========== APP SERVICES ==========
            @{ Name = "PROD [$env] App Service Down"; Type = 'metric alert'; Query = "avg(last_10m):avg:azure.web_sites.http_5xx{subscription_id:$($sub.Id)} by {app} > 50"; Message = "CRITICAL: App {{app}} returning 5xx errors. $notify"; Options = @{ thresholds = @{ critical = 50 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] App Response Time"; Type = 'metric alert'; Query = "avg(last_10m):avg:azure.web_sites.http_response_time{subscription_id:$($sub.Id)} by {app} > 5"; Message = "WARNING: Slow response on {{app}}. $notify"; Options = @{ thresholds = @{ critical = 5; warning = 3 }; notify_no_data = $false } },
            
            # ========== SQL DATABASES ==========
            @{ Name = "PROD [$env] SQL Database DTU"; Type = 'metric alert'; Query = "avg(last_10m):avg:azure.sql_servers_databases.dtu_consumption_percent{subscription_id:$($sub.Id)} by {database} > 90"; Message = "CRITICAL: Database {{database}} DTU 90%+. $notify"; Options = @{ thresholds = @{ critical = 90 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] SQL Connection Failures"; Type = 'metric alert'; Query = "avg(last_5m):avg:azure.sql_servers_databases.connection_failed{subscription_id:$($sub.Id)} by {database} > 20"; Message = "CRITICAL: Database {{database}} connection failures. $notify"; Options = @{ thresholds = @{ critical = 20 }; notify_no_data = $false } },
            
            # ========== STORAGE ==========
            @{ Name = "PROD [$env] Storage Availability"; Type = 'metric alert'; Query = "avg(last_10m):avg:azure.storage_storageaccounts.availability{subscription_id:$($sub.Id)} by {account} < 99"; Message = "CRITICAL: Storage {{account}} availability below 99%. $notify"; Options = @{ thresholds = @{ critical = 99 }; notify_no_data = $false } },
            
            # ========== LOAD BALANCERS - COMPREHENSIVE ==========
            @{ Name = "PROD [$env] Load Balancer Backend Unhealthy"; Type = 'metric alert'; Query = "avg(last_5m):avg:azure.network_loadbalancers.health_probe_status{subscription_id:$($sub.Id)} by {backend} < 1"; Message = "CRITICAL: Load balancer backend {{backend}} unhealthy. Traffic routing impacted. $notify"; Options = @{ thresholds = @{ critical = 1 }; notify_no_data = $true } },
            @{ Name = "PROD [$env] Load Balancer High Connections"; Type = 'metric alert'; Query = "avg(last_5m):avg:azure.network_loadbalancers.snat_connection_count{subscription_id:$($sub.Id)} by {loadbalancer} > 50000"; Message = "WARNING: Load balancer {{loadbalancer}} high SNAT connections. $notify"; Options = @{ thresholds = @{ critical = 60000; warning = 50000 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] Load Balancer SNAT Port Exhaustion"; Type = 'metric alert'; Query = "avg(last_5m):avg:azure.network_loadbalancers.allocated_snat_ports{subscription_id:$($sub.Id)} by {loadbalancer} > 0.90"; Message = "CRITICAL: Load balancer {{loadbalancer}} SNAT port exhaustion. $notify"; Options = @{ thresholds = @{ critical = 0.90; warning = 0.80 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] Load Balancer Dropped Packets"; Type = 'metric alert'; Query = "avg(last_5m):sum:azure.network_loadbalancers.dropped_packets{subscription_id:$($sub.Id)} by {loadbalancer} > 1000"; Message = "WARNING: Load balancer {{loadbalancer}} dropping packets. $notify"; Options = @{ thresholds = @{ critical = 5000; warning = 1000 }; notify_no_data = $false } },
            
            # ========== NETWORK SECURITY GROUPS - COMPREHENSIVE ==========
            @{ Name = "PROD [$env] NSG Rule Added"; Type = 'log alert'; Query = "logs('azure.resource_type:NetworkSecurityGroup azure.operation_name:*SecurityRule*Create* subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 0"; Message = "ALERT: NSG rule ADDED in {{resource_group}}. Review security changes. $notify"; Options = @{ thresholds = @{ warning = 0 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] NSG Rule Deleted"; Type = 'log alert'; Query = "logs('azure.resource_type:NetworkSecurityGroup azure.operation_name:*SecurityRule*Delete* subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 0"; Message = "ALERT: NSG rule DELETED in {{resource_group}}. Security posture changed. $notify"; Options = @{ thresholds = @{ warning = 0 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] NSG Allow Any Any Rule"; Type = 'log alert'; Query = "logs('azure.resource_type:NetworkSecurityGroup source_address_prefix:* destination_address_prefix:* subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 0"; Message = "CRITICAL: NSG rule allowing ANY to ANY created. Major security risk. $notify"; Options = @{ thresholds = @{ critical = 0 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] NSG Blocked Traffic Spike"; Type = 'metric alert'; Query = "avg(last_10m):sum:azure.network_networksecuritygroups.packets_denied{subscription_id:$($sub.Id)} by {nsg} > 10000"; Message = "WARNING: NSG {{nsg}} blocking high traffic. Possible attack or misconfiguration. $notify"; Options = @{ thresholds = @{ critical = 50000; warning = 10000 }; notify_no_data = $false } },
            
            # ========== RBAC - ROLE BASED ACCESS CONTROL ==========
            @{ Name = "PROD [$env] RBAC Owner Role Assigned"; Type = 'log alert'; Query = "logs('azure.operation_name:*RoleAssignment*Write* azure.authorization.scope:*/providers/Microsoft.Authorization/roleAssignments/* roleDefinitionId:*Owner* subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 0"; Message = "CRITICAL: OWNER role assigned to {{caller}}. Review privileged access immediately. $notify"; Options = @{ thresholds = @{ critical = 0 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] RBAC Contributor Role Assigned"; Type = 'log alert'; Query = "logs('azure.operation_name:*RoleAssignment*Write* roleDefinitionId:*Contributor* subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 0"; Message = "WARNING: CONTRIBUTOR role assigned to {{caller}}. Review access grants. $notify"; Options = @{ thresholds = @{ warning = 0 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] RBAC Role Assignment Deleted"; Type = 'log alert'; Query = "logs('azure.operation_name:*RoleAssignment*Delete* subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 0"; Message = "ALERT: RBAC role removed from {{principalId}}. Access revoked. $notify"; Options = @{ thresholds = @{ warning = 0 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] RBAC Multiple Failed Operations"; Type = 'log alert'; Query = "logs('azure.category:Administrative status:failure subscription_id:$($sub.Id)').index('*').rollup('count').last('10m') > 20"; Message = "WARNING: Multiple failed admin operations. Possible unauthorized access attempts. $notify"; Options = @{ thresholds = @{ critical = 50; warning = 20 }; notify_no_data = $false } },
            
            # ========== AZURE POLICY ==========
            @{ Name = "PROD [$env] Policy Non-Compliant Resources"; Type = 'log alert'; Query = "logs('azure.resource_type:PolicyState compliance_state:NonCompliant subscription_id:$($sub.Id)').index('*').rollup('count').last('1h') > 10"; Message = "WARNING: {{count}} resources non-compliant with Azure Policy. Review compliance. $notify"; Options = @{ thresholds = @{ critical = 50; warning = 10 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] Policy Assignment Created"; Type = 'log alert'; Query = "logs('azure.operation_name:*PolicyAssignment*Write* subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 0"; Message = "ALERT: New Azure Policy assigned. Review policy changes. $notify"; Options = @{ thresholds = @{ warning = 0 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] Policy Assignment Deleted"; Type = 'log alert'; Query = "logs('azure.operation_name:*PolicyAssignment*Delete* subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 0"; Message = "ALERT: Azure Policy removed. Compliance controls changed. $notify"; Options = @{ thresholds = @{ warning = 0 }; notify_no_data = $false } },
            
            # ========== PORT SCANNING AND NETWORK SECURITY ==========
            @{ Name = "PROD [$env] Port Scan Detected"; Type = 'log alert'; Query = "logs('source:network status:blocked multiple ports subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 100"; Message = "CRITICAL: Port scan detected from {{source_ip}}. Possible reconnaissance attack. $notify"; Options = @{ thresholds = @{ critical = 100; warning = 50 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] Unusual Port Access"; Type = 'log alert'; Query = "logs('destination_port:(23 OR 21 OR 3389 OR 1433 OR 3306) status:allowed subscription_id:$($sub.Id)').index('*').rollup('count').last('10m') > 50"; Message = "WARNING: High-risk port access detected. Ports 21/23/3389/1433/3306 accessed. $notify"; Options = @{ thresholds = @{ critical = 100; warning = 50 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] SSH Brute Force Attempt"; Type = 'log alert'; Query = "logs('destination_port:22 status:blocked subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 20"; Message = "CRITICAL: SSH brute force attack from {{source_ip}}. Block source immediately. $notify"; Options = @{ thresholds = @{ critical = 20; warning = 10 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] RDP Brute Force Attempt"; Type = 'log alert'; Query = "logs('destination_port:3389 status:blocked subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 20"; Message = "CRITICAL: RDP brute force attack from {{source_ip}}. Block source immediately. $notify"; Options = @{ thresholds = @{ critical = 20; warning = 10 }; notify_no_data = $false } },
            
            # ========== ADDITIONAL SECURITY ==========
            @{ Name = "PROD [$env] Security Breach Attempt"; Type = 'log alert'; Query = "logs('status:error authentication failed subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 20"; Message = "CRITICAL: Multiple auth failures. Security breach attempt. $notify"; Options = @{ thresholds = @{ critical = 20 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] Privileged Account Activity"; Type = 'log alert'; Query = "logs('caller:*admin* azure.operation_name:*Delete* subscription_id:$($sub.Id)').index('*').rollup('count').last('10m') > 0"; Message = "ALERT: Privileged account {{caller}} performed DELETE operation. Review activity. $notify"; Options = @{ thresholds = @{ warning = 0 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] Resource Deletion"; Type = 'log alert'; Query = "logs('azure.operation_name:*Delete* status:success subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 5"; Message = "ALERT: Multiple resources deleted in {{resource_group}}. Review deletions. $notify"; Options = @{ thresholds = @{ critical = 10; warning = 5 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] Public IP Created"; Type = 'log alert'; Query = "logs('azure.resource_type:PublicIPAddress azure.operation_name:*Write* subscription_id:$($sub.Id)').index('*').rollup('count').last('5m') > 0"; Message = "ALERT: Public IP address created. Review network exposure. $notify"; Options = @{ thresholds = @{ warning = 0 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] Key Vault Access Denied"; Type = 'log alert'; Query = "logs('azure.resource_type:KeyVault status:failure subscription_id:$($sub.Id)').index('*').rollup('count').last('10m') > 10"; Message = "WARNING: Multiple Key Vault access failures from {{caller}}. Unauthorized access attempt. $notify"; Options = @{ thresholds = @{ critical = 50; warning = 10 }; notify_no_data = $false } },
            @{ Name = "PROD [$env] Network Packet Loss"; Type = 'metric alert'; Query = "avg(last_5m):avg:azure.network.packets_dropped{subscription_id:$($sub.Id)} by {interface} > 100"; Message = "CRITICAL: Packet loss on {{interface}}. $notify"; Options = @{ thresholds = @{ critical = 100 }; notify_no_data = $false } },
            
            # ========== MONITORING AGENT ==========
            @{ Name = "PROD [$env] Datadog Agent Offline"; Type = 'service check'; Query = "datadog.agent.up{subscription_id:$($sub.Id)}.by('host').last(2).count_by_status()"; Message = "CRITICAL: Agent offline on {{host.name}}. $notify"; Options = @{ thresholds = @{ critical = 1 }; notify_no_data = $true; no_data_timeframe = 15 } }
        )
        
        $count = 1
        foreach ($mon in $monitors) {
            Write-Host "  [$count/$($monitors.Count)] $($mon.Name)..." -NoNewline
            
            $result = New-DatadogMonitor -Name $mon.Name -Type $mon.Type -Query $mon.Query -Message $mon.Message -Options $mon.Options -Tags $tags
            
            if ($result) {
                $totalCreated++
            }
            else {
                $totalSkipped++
            }
            
            $count++
        }
        Write-Host ""
    }
    
    Write-Host ""
    Write-Host "=====================================================================" -ForegroundColor Green
    if ($Script:PreviewMode) {
        Write-Host "  PREVIEW COMPLETE - NO CHANGES MADE" -ForegroundColor Green
    }
    else {
        Write-Host "  MONITORS DEPLOYED" -ForegroundColor Green
    }
    Write-Host "=====================================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Summary:" -ForegroundColor Yellow
    Write-Host "  New monitors created: $totalCreated" -ForegroundColor White
    Write-Host "  Existing monitors (skipped): $totalSkipped" -ForegroundColor White
    Write-Host ""
    Write-Host "COMPREHENSIVE MONITORING NOW ACTIVE:" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "MOVEIT (10 monitors per subscription):" -ForegroundColor Yellow
    Write-Host "  - Server status (up/down)" -ForegroundColor White
    Write-Host "  - MOVEit Transfer service" -ForegroundColor White
    Write-Host "  - CPU, Memory, Disk" -ForegroundColor White
    Write-Host "  - Web interface availability" -ForegroundColor White
    Write-Host "  - Failed login attempts" -ForegroundColor White
    Write-Host "  - File transfer failures" -ForegroundColor White
    Write-Host "  - Database connectivity" -ForegroundColor White
    Write-Host "  - License expiration" -ForegroundColor White
    Write-Host ""
    Write-Host "INFRASTRUCTURE (8 monitors):" -ForegroundColor Yellow
    Write-Host "  - VMs, Apps, Databases, Storage" -ForegroundColor White
    Write-Host ""
    Write-Host "LOAD BALANCERS (4 monitors):" -ForegroundColor Yellow
    Write-Host "  - Backend health, SNAT ports, connections, packets" -ForegroundColor White
    Write-Host ""
    Write-Host "NSG NETWORK SECURITY (4 monitors):" -ForegroundColor Yellow
    Write-Host "  - Rule additions, deletions, any-any rules, blocked traffic" -ForegroundColor White
    Write-Host ""
    Write-Host "RBAC ACCESS CONTROL (4 monitors):" -ForegroundColor Yellow
    Write-Host "  - Owner/Contributor assignments, role deletions, failed ops" -ForegroundColor White
    Write-Host ""
    Write-Host "AZURE POLICY (3 monitors):" -ForegroundColor Yellow
    Write-Host "  - Non-compliant resources, policy changes" -ForegroundColor White
    Write-Host ""
    Write-Host "PORT SECURITY (4 monitors):" -ForegroundColor Yellow
    Write-Host "  - Port scans, unusual port access, SSH/RDP brute force" -ForegroundColor White
    Write-Host ""
    Write-Host "ADDITIONAL SECURITY (6 monitors):" -ForegroundColor Yellow
    Write-Host "  - Auth failures, privileged accounts, deletions, public IPs, Key Vault" -ForegroundColor White
    Write-Host ""
    Write-Host "TOTAL: 47 monitors x $($Subscriptions.Count) subscriptions = $($Subscriptions.Count * 47) monitors" -ForegroundColor Cyan
    Write-Host ""
    
    return $true
}

# ==============================================================================
# CREATE COMPREHENSIVE ALERTS DASHBOARD
# ==============================================================================

function New-AlertsDashboard {
    Show-Banner -Title "CREATING COMPREHENSIVE ALERTS DASHBOARD"
    
    Write-Host "Creating dashboard with ALL features:" -ForegroundColor Cyan
    Write-Host "  - Triggered alerts as tickets" -ForegroundColor White
    Write-Host "  - Monitor status summary" -ForegroundColor White
    Write-Host "  - Live resource metrics" -ForegroundColor White
    Write-Host "  - Infrastructure map" -ForegroundColor White
    Write-Host "  - Alert history" -ForegroundColor White
    Write-Host "  - Live error logs" -ForegroundColor White
    Write-Host ""
    
    try {
        $headers = @{
            'DD-API-KEY' = $Script:Config.DatadogAPIKey
            'DD-APPLICATION-KEY' = $Script:Config.DatadogAppKey
            'Content-Type' = 'application/json'
        }
        
        $dashboard = @{
            title = "PRODUCTION ALERTS DASHBOARD - ALL 13 SUBSCRIPTIONS"
            description = "Real-time production monitoring across all subscriptions. Shows all alerts as tickets with live metrics."
            layout_type = "ordered"
            widgets = @(
                # TRIGGERED ALERTS AS TICKETS
                @{
                    definition = @{
                        type = "alert_graph"
                        title = "PRODUCTION CRITICAL ALERTS - ALL TICKETS"
                        alert_id = "*"
                        viz_type = "toplist"
                        time = @{ live_span = "1h" }
                    }
                },
                # MONITOR STATUS SUMMARY
                @{
                    definition = @{
                        type = "manage_status"
                        title = "ALL MONITORS STATUS - 611 TOTAL"
                        display_format = "countsAndList"
                        color_preference = "background"
                        hide_zero_counts = $true
                        query = "env:production"
                        sort = "status,asc"
                        count = 100
                        start = 0
                        summary_type = "monitors"
                    }
                },
                # MOVEIT METRICS
                @{
                    definition = @{
                        type = "timeseries"
                        title = "MOVEIT Servers - CPU Usage Live"
                        requests = @(
                            @{
                                q = "avg:system.cpu.user{service:moveit,env:production} by {host}"
                                display_type = "line"
                            }
                        )
                    }
                },
                # VM METRICS
                @{
                    definition = @{
                        type = "timeseries"
                        title = "ALL Production VMs - CPU Usage Live"
                        requests = @(
                            @{
                                q = "avg:azure.vm.percentage_cpu{env:production} by {host}"
                                display_type = "line"
                            }
                        )
                    }
                },
                # APP SERVICE METRICS
                @{
                    definition = @{
                        type = "timeseries"
                        title = "ALL Production Apps - Response Time Live"
                        requests = @(
                            @{
                                q = "avg:azure.web_sites.http_response_time{env:production} by {app}"
                                display_type = "line"
                            }
                        )
                    }
                },
                # DATABASE METRICS
                @{
                    definition = @{
                        type = "timeseries"
                        title = "ALL Production Databases - DTU Live"
                        requests = @(
                            @{
                                q = "avg:azure.sql_servers_databases.dtu_consumption_percent{env:production} by {database}"
                                display_type = "area"
                            }
                        )
                    }
                },
                # LOAD BALANCER METRICS
                @{
                    definition = @{
                        type = "timeseries"
                        title = "ALL Load Balancers - Health Status"
                        requests = @(
                            @{
                                q = "avg:azure.network_loadbalancers.health_probe_status{env:production} by {loadbalancer}"
                                display_type = "line"
                            }
                        )
                    }
                },
                # NSG METRICS
                @{
                    definition = @{
                        type = "timeseries"
                        title = "NSG Blocked Traffic - All Subscriptions"
                        requests = @(
                            @{
                                q = "sum:azure.network_networksecuritygroups.packets_denied{env:production} by {nsg}"
                                display_type = "bars"
                            }
                        )
                    }
                },
                # ALERT HISTORY TIMELINE
                @{
                    definition = @{
                        type = "event_timeline"
                        title = "ALERT HISTORY - ALL EVENTS"
                        query = "tags:env:production"
                        tags_execution = "and"
                    }
                },
                # INFRASTRUCTURE MAP
                @{
                    definition = @{
                        type = "hostmap"
                        title = "LIVE PRODUCTION INFRASTRUCTURE MAP - ALL SUBSCRIPTIONS"
                        requests = @{
                            fill = @{
                                q = "avg:system.cpu.user{env:production} by {host}"
                            }
                        }
                        node_type = "host"
                        no_group_hosts = $true
                        no_metric_hosts = $false
                    }
                },
                # SECURITY EVENTS
                @{
                    definition = @{
                        type = "timeseries"
                        title = "Security Events - Failed Authentications"
                        requests = @(
                            @{
                                q = "sum:azure.auth.failed{env:production}.as_count()"
                                display_type = "bars"
                            }
                        )
                    }
                },
                # ERROR LOG STREAM
                @{
                    definition = @{
                        type = "log_stream"
                        title = "PRODUCTION ERROR LOGS - LIVE STREAM"
                        query = "status:error env:production"
                        columns = @("host", "service", "message")
                        message_display = "expanded-md"
                    }
                }
            )
            template_variables = @(
                @{
                    name = "env"
                    default = "production"
                    prefix = "env"
                }
            )
        } | ConvertTo-Json -Depth 20
        
        $response = Invoke-RestMethod -Uri "$($Script:Config.DatadogAPIURL)/dashboard" -Method Post -Headers $headers -Body $dashboard
        
        Write-Host ""
        Write-Host "=====================================================================" -ForegroundColor Green
        Write-Host "  ALERTS DASHBOARD CREATED" -ForegroundColor Green
        Write-Host "=====================================================================" -ForegroundColor Green
        Write-Host ""
        Write-Host "Dashboard URL:" -ForegroundColor Yellow
        Write-Host "https://app.$($Script:Config.DatadogSite)/dashboard/$($response.id)" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "Dashboard Features:" -ForegroundColor Yellow
        Write-Host "  - Shows ALL triggered alerts as tickets" -ForegroundColor White
        Write-Host "  - Monitor status summary (all 611 monitors)" -ForegroundColor White
        Write-Host "  - Live MOVEit metrics" -ForegroundColor White
        Write-Host "  - Live VM, App, Database metrics" -ForegroundColor White
        Write-Host "  - Live Load Balancer health" -ForegroundColor White
        Write-Host "  - NSG blocked traffic" -ForegroundColor White
        Write-Host "  - Security events" -ForegroundColor White
        Write-Host "  - Alert history timeline" -ForegroundColor White
        Write-Host "  - Infrastructure map (all hosts)" -ForegroundColor White
        Write-Host "  - Live error log stream" -ForegroundColor White
        Write-Host ""
        Write-Host "DASHBOARD COVERS ALL 13 SUBSCRIPTIONS" -ForegroundColor Green
        Write-Host ""
        
        return $true
    }
    catch {
        Write-Log "Dashboard creation failed: $($_.Exception.Message)" "Error"
        return $false
    }
}

# ==============================================================================
# MAIN EXECUTION
# ==============================================================================

try {
    # Security config
    Initialize-SecureConfig
    
    if ($Script:Config.AlertEmails.Count -eq 0) {
        Write-Log "WARNING: No email addresses configured" "Warning"
        $continue = Read-Host "Continue anyway? (Y/N)"
        if ($continue -ne 'Y') { exit 0 }
    }
    
    # Connect
    Install-AzureModules
    Connect-ToAzure
    
    # SAFETY: Get existing monitors first
    Get-ExistingMonitors
    
    # Select subscriptions
    $subs = Select-Subscriptions
    
    if ($subs.Count -eq 0) {
        Write-Log "No subscriptions selected" "Warning"
        exit 0
    }
    
    # SAFETY PROMPT
    Write-Host ""
    Write-Host "=====================================================================" -ForegroundColor Cyan
    Write-Host "  DEPLOYMENT OPTIONS" -ForegroundColor White
    Write-Host "=====================================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  [P] PREVIEW MODE - See what will be created (NO CHANGES)" -ForegroundColor Yellow
    Write-Host "  [D] DEPLOY MODE - Actually create monitors (LIVE CHANGES)" -ForegroundColor Green
    Write-Host "  [C] CANCEL" -ForegroundColor Red
    Write-Host ""
    
    $mode = Read-Host "Select mode (P/D/C)"
    
    if ($mode -eq 'C' -or $mode -eq 'c') {
        Write-Host "Cancelled" -ForegroundColor Yellow
        exit 0
    }
    
    if ($mode -eq 'P' -or $mode -eq 'p') {
        $Script:PreviewMode = $true
        Write-Host ""
        Write-Host "PREVIEW MODE: No changes will be made to Datadog" -ForegroundColor Yellow
        Write-Host ""
        Start-Sleep -Seconds 2
    }
    else {
        Write-Host ""
        Write-Host "LIVE DEPLOYMENT: Monitors will be created" -ForegroundColor Green
        Write-Host ""
        $confirm = Read-Host "Are you sure? (Y/N)"
        if ($confirm -ne 'Y') {
            Write-Host "Cancelled" -ForegroundColor Yellow
            exit 0
        }
    }
    
    # Create monitors
    New-ComprehensiveMonitors -Subscriptions $subs
    
    if (-not $Script:PreviewMode) {
        Write-Host ""
        Write-Host "=====================================================================" -ForegroundColor Cyan
        Write-Host "  CREATING COMPREHENSIVE DASHBOARD" -ForegroundColor White
        Write-Host "=====================================================================" -ForegroundColor Cyan
        Write-Host ""
        
        # Create dashboard
        if (New-AlertsDashboard) {
            Write-Host ""
            Write-Host "=====================================================================" -ForegroundColor Green
            Write-Host "  DEPLOYMENT COMPLETE" -ForegroundColor Green
            Write-Host "=====================================================================" -ForegroundColor Green
            Write-Host ""
            Write-Host "SUMMARY:" -ForegroundColor Yellow
            Write-Host "  - 611 monitors created (47 x 13 subscriptions)" -ForegroundColor White
            Write-Host "  - Comprehensive alerts dashboard created" -ForegroundColor White
            Write-Host "  - All resources monitored" -ForegroundColor White
            Write-Host "  - All 13 subscriptions covered" -ForegroundColor White
            Write-Host ""
            Write-Host "Access your monitoring:" -ForegroundColor Yellow
            Write-Host "  Dashboard: https://app.$($Script:Config.DatadogSite)/dashboard/lists" -ForegroundColor Cyan
            Write-Host "  Monitors: https://app.$($Script:Config.DatadogSite)/monitors/manage" -ForegroundColor Cyan
            Write-Host "  Infrastructure: https://app.$($Script:Config.DatadogSite)/infrastructure" -ForegroundColor Cyan
            Write-Host ""
            Write-Host "ALL 13 PRODUCTION SUBSCRIPTIONS NOW MONITORED" -ForegroundColor Green
            Write-Host ""
        }
    }
    else {
        Write-Host ""
        Write-Host "PREVIEW MODE: Dashboard not created (run in Deploy mode to create)" -ForegroundColor Yellow
        Write-Host ""
    }
    
    # Save log
    $logFile = "datadog-deployment-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
    $Script:DeploymentLog | Out-File $logFile
    Write-Host "Deployment log: $logFile" -ForegroundColor Cyan
    Write-Host ""
}
catch {
    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    exit 1
}
