param(
    [Parameter(Mandatory=$true)][string]$DatadogApiKey,
    [Parameter(Mandatory=$true)][string]$DatadogAppKey,
    [string]$Region = "us3",
    [string]$CsvReport = ".\Datadog-Validation-Report.csv"
)

$ErrorActionPreference = "Stop"
$Report = @()

function Log {
    param($Check,$Status,$Details)
    $Report += [pscustomobject]@{
        Timestamp = (Get-Date)
        Check     = $Check
        Status    = $Status
        Details   = $Details
    }
}

Write-Host "`n=== Datadog Validation Script Started ==="

$Site = switch($Region) {
    "us1" { "datadoghq.com" }
    "us3" { "us3.datadoghq.com" }
    "us5" { "us5.datadoghq.com" }
    "eu"  { "datadoghq.eu" }
    "ap1" { "ap1.datadoghq.com" }
    default { "datadoghq.com" }
}

$Headers = @{
    "DD-API-KEY"        = $DatadogApiKey
    "DD-APPLICATION-KEY" = $DatadogAppKey
}

try {
    $resp = Invoke-RestMethod -Uri "https://api.$Region.datadoghq.com/api/v1/validate" -Headers $Headers -Method Get
    if ($resp.valid -eq $true) {
        Log "API Key Validation" "PASS" "API Key accepted by Datadog"
    } else {
        Log "API Key Validation" "FAIL" "Invalid API Key"
    }
}
catch {
    Log "API Key Validation" "FAIL" $_.Exception.Message
}

$MetricsToCheck = @(
    "datadog.agent.up",
    "azure.vm.status",
    "azure.compute.virtualmachine.percentage_cpu",
    "system.mem.pct_usable",
    "system.disk.in_use",
    "azure.network.latency"
)

foreach ($metric in $MetricsToCheck) {
    try {
        $metricUrl = "https://api.$Region.datadoghq.com/api/v1/query?from=$( (Get-Date).AddMinutes(-10).ToFileTimeUtc() )&to=$( (Get-Date).ToFileTimeUtc() )&query=$metric"
        $metricResp = Invoke-RestMethod -Uri $metricUrl -Headers $Headers -Method Get

        if ($metricResp.series.Count -gt 0) {
            Log "Metric: $metric" "PASS" "Data present"
        } else {
            Log "Metric: $metric" "FAIL" "No series returned"
        }
    }
    catch {
        Log "Metric: $metric" "ERROR" $_.Exception.Message
    }
}

$vms = Get-AzVM -Status
foreach ($vm in $vms) {
    $vmName = $vm.Name
    try {
        $agentMetric = "datadog.agent.up{host:$vmName}"
        $url ="https://api.$Region.datadoghq.com/api/v1/query?from=$( (Get-Date).AddMinutes(-10).ToFileTimeUtc() )&to=$( (Get-Date).ToFileTimeUtc() )&query=$agentMetric"
        $metricResp = Invoke-RestMethod -Uri $url -Headers $Headers -Method Get

        if ($metricResp.series.Count -gt 0) {
            Log "Agent Heartbeat ($vmName)" "PASS" "Agent reporting to Datadog"
        }
        else {
            Log "Agent Heartbeat ($vmName)" "FAIL" "No agent heartbeat received"
        }
    }
    catch {
        Log "Agent Heartbeat ($vmName)" "ERROR" $_.Exception.Message
    }
}

$Report | Export-Csv -Path $CsvReport -NoTypeInformation
Write-Host "`nValidation Complete. Report Saved to: $CsvReport"
