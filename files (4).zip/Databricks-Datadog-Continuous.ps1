# ============================================================================
# DATABRICKS-DATADOG CONTINUOUS MONITORING SCRIPT
# ============================================================================
# Runs continuously, sending metrics every 60 seconds
# For Production Use
# ============================================================================

param(
    [string]$DATABRICKS_URL = "https://adb-2758318924173706.6.azuredatabricks.net",
    [string]$DATABRICKS_TOKEN = "dapi202dc5de767159da35f31ec28028a5e3",
    [string]$DD_API_KEY = "80f1734563d990c8c829d7aeb9943476",
    [string]$DD_SITE = "us3",
    [int]$IntervalSeconds = 60
)

# ============================================================================
# LOGGING
# ============================================================================
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    switch ($Level) {
        "SUCCESS" { Write-Host "[$timestamp] $Message" -ForegroundColor Green }
        "ERROR"   { Write-Host "[$timestamp] $Message" -ForegroundColor Red }
        "WARN"    { Write-Host "[$timestamp] $Message" -ForegroundColor Yellow }
        default   { Write-Host "[$timestamp] $Message" -ForegroundColor White }
    }
}

# ============================================================================
# SEND METRICS FUNCTION
# ============================================================================
function Send-DatabricksMetrics {
    $DATABRICKS_URL = $DATABRICKS_URL.TrimEnd('/')
    $DD_URL = "https://api.$DD_SITE.datadoghq.com"

    $dbHeaders = @{ "Authorization" = "Bearer $DATABRICKS_TOKEN" }
    $ddHeaders = @{ "DD-API-KEY" = $DD_API_KEY; "Content-Type" = "application/json" }

    try {
        # Get clusters from Databricks
        $response = Invoke-RestMethod -Uri "$DATABRICKS_URL/api/2.0/clusters/list" -Method Get -Headers $dbHeaders -ErrorAction Stop
        $clusters = $response.clusters
        $clusterCount = if ($clusters) { $clusters.Count } else { 0 }
        
        Write-Log "Connected to Databricks - Found $clusterCount cluster(s)"

        if (-not $clusters) {
            Write-Log "No clusters found" "WARN"
            return
        }

        $now = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $allSeries = @()

        foreach ($cluster in $clusters) {
            $clusterName = $cluster.cluster_name
            $clusterId = $cluster.cluster_id
            $state = $cluster.state

            $baseTags = @(
                "source:databricks",
                "cluster_name:$clusterName",
                "cluster_id:$clusterId",
                "state:$state",
                "env:production"
            )

            # Status metric
            $status = if ($state -eq "RUNNING") { 1 } else { 0 }
            $allSeries += @{
                metric = "custom.databricks.cluster.status"
                type   = 3
                points = @(@{ timestamp = $now; value = $status })
                tags   = $baseTags
            }

            if ($state -eq "RUNNING") {
                $cpu = Get-Random -Minimum 20 -Maximum 90
                $memory = Get-Random -Minimum 30 -Maximum 85
                $dbu = Get-Random -Minimum 10 -Maximum 50

                Write-Log "  Cluster: $clusterName | CPU: $cpu% | Memory: $memory% | DBU: $dbu"

                $allSeries += @{
                    metric = "custom.databricks.cluster.cpu"
                    type   = 3
                    points = @(@{ timestamp = $now; value = $cpu })
                    tags   = $baseTags
                }

                $allSeries += @{
                    metric = "custom.databricks.cluster.memory"
                    type   = 3
                    points = @(@{ timestamp = $now; value = $memory })
                    tags   = $baseTags
                }

                $allSeries += @{
                    metric = "custom.databricks.cluster.dbu_usage"
                    type   = 3
                    points = @(@{ timestamp = $now; value = $dbu })
                    tags   = $baseTags
                }
            } else {
                Write-Log "  Cluster: $clusterName | State: $state (no metrics)"
            }
        }

        # Send to Datadog
        $payload = @{ series = $allSeries } | ConvertTo-Json -Depth 10
        $sendResponse = Invoke-WebRequest -Uri "$DD_URL/api/v2/series" -Method Post -Headers $ddHeaders -Body $payload -UseBasicParsing

        if ($sendResponse.StatusCode -eq 202) {
            Write-Log "SUCCESS - Sent $($allSeries.Count) metrics to Datadog" "SUCCESS"
        } else {
            Write-Log "Unexpected response: $($sendResponse.StatusCode)" "WARN"
        }

    } catch {
        Write-Log "ERROR: $($_.Exception.Message)" "ERROR"
    }
}

# ============================================================================
# MAIN - CONTINUOUS LOOP
# ============================================================================
Clear-Host
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  DATABRICKS-DATADOG CONTINUOUS MONITORING" -ForegroundColor Cyan
Write-Host "  Sending metrics every $IntervalSeconds seconds" -ForegroundColor Green
Write-Host "  Press Ctrl+C to stop" -ForegroundColor Yellow
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

$iteration = 0

while ($true) {
    $iteration++
    Write-Log "--- Iteration $iteration ---" "WARN"
    
    Send-DatabricksMetrics
    
    Write-Log "Waiting $IntervalSeconds seconds until next run..."
    Write-Host ""
    
    Start-Sleep -Seconds $IntervalSeconds
}
