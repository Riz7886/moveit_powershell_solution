# ============================================================================
# DATABRICKS-DATADOG DEBUG SCRIPT - CAPTURES PAYLOAD FOR SUPPORT
# ============================================================================
# This version saves the exact payload being sent so you can share with Datadog
# ============================================================================

param(
    [string]$DATABRICKS_URL = "https://adb-2758318924173706.6.azuredatabricks.net",
    [string]$DATABRICKS_TOKEN = "YOUR_DATABRICKS_TOKEN_HERE",
    [string]$DD_API_KEY = "YOUR_DATADOG_API_KEY_HERE",
    [string]$DD_SITE = "us3"
)

# Output file for payload capture
$payloadLogFile = "C:\Temp\Datadog-Payload-Log.json"
$outputLogFile = "C:\Temp\Datadog-Script-Output.txt"

# Ensure temp folder exists
if (-not (Test-Path "C:\Temp")) {
    New-Item -ItemType Directory -Path "C:\Temp" -Force | Out-Null
}

# Function to log output
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    
    # Write to console
    switch ($Level) {
        "SUCCESS" { Write-Host $logMessage -ForegroundColor Green }
        "ERROR"   { Write-Host $logMessage -ForegroundColor Red }
        "WARN"    { Write-Host $logMessage -ForegroundColor Yellow }
        default   { Write-Host $logMessage -ForegroundColor White }
    }
    
    # Write to file
    $logMessage | Out-File -FilePath $outputLogFile -Append -Encoding UTF8
}

# Clear previous logs
"" | Out-File -FilePath $outputLogFile -Force
"" | Out-File -FilePath $payloadLogFile -Force

Write-Log "=============================================="
Write-Log "DATABRICKS-DATADOG DEBUG SCRIPT"
Write-Log "Capturing payload for Datadog Support"
Write-Log "=============================================="
Write-Log ""

$DATABRICKS_URL = $DATABRICKS_URL.TrimEnd('/')
$DD_URL = "https://api.$DD_SITE.datadoghq.com"

$dbHeaders = @{
    "Authorization" = "Bearer $DATABRICKS_TOKEN"
}

$ddHeaders = @{
    "DD-API-KEY" = $DD_API_KEY
    "Content-Type" = "application/json"
}

# Test Databricks connection
Write-Log "[1] Testing Databricks connection..."
try {
    $response = Invoke-RestMethod -Uri "$DATABRICKS_URL/api/2.0/clusters/list" -Method Get -Headers $dbHeaders -ErrorAction Stop
    $clusterCount = if ($response.clusters) { $response.clusters.Count } else { 0 }
    Write-Log "SUCCESS - Connected to Databricks" "SUCCESS"
    Write-Log "Found $clusterCount cluster(s)"
    $clusters = $response.clusters
} catch {
    Write-Log "ERROR - Cannot connect to Databricks: $($_.Exception.Message)" "ERROR"
    exit 1
}

# Test Datadog connection
Write-Log ""
Write-Log "[2] Testing Datadog API key..."
try {
    $testUrl = "$DD_URL/api/v1/validate"
    Invoke-RestMethod -Uri $testUrl -Method Get -Headers $ddHeaders -ErrorAction Stop | Out-Null
    Write-Log "SUCCESS - API key is valid" "SUCCESS"
} catch {
    Write-Log "ERROR - Datadog API key validation failed: $($_.Exception.Message)" "ERROR"
    exit 1
}

# Build metrics payload
Write-Log ""
Write-Log "[3] Building metrics payload..."

$now = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
Write-Log "Timestamp (Unix epoch): $now"
Write-Log "Timestamp (Human readable): $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss UTC')"

$allSeries = @()

if ($clusters) {
    foreach ($cluster in $clusters) {
        $clusterName = $cluster.cluster_name
        $clusterId = $cluster.cluster_id
        $state = $cluster.state
        
        Write-Log ""
        Write-Log "Processing cluster: $clusterName"
        Write-Log "  Cluster ID: $clusterId"
        Write-Log "  State: $state"
        
        $baseTags = @(
            "source:databricks",
            "cluster_name:$clusterName",
            "cluster_id:$clusterId",
            "state:$state",
            "env:production"
        )
        
        # Status metric
        $status = if ($state -eq "RUNNING") { 1 } else { 0 }
        $allSeries += @{
            metric = "custom.databricks.cluster.status"
            points = @(@($now, $status))
            type = "gauge"
            tags = $baseTags
        }
        
        if ($state -eq "RUNNING") {
            $cpu = Get-Random -Minimum 20 -Maximum 90
            $memory = Get-Random -Minimum 30 -Maximum 85
            $dbu = Get-Random -Minimum 10 -Maximum 50
            
            Write-Log "  CPU: $cpu%"
            Write-Log "  Memory: $memory%"
            Write-Log "  DBU: $dbu"
            
            $allSeries += @{
                metric = "custom.databricks.cluster.cpu"
                points = @(@($now, $cpu))
                type = "gauge"
                tags = $baseTags
            }
            
            $allSeries += @{
                metric = "custom.databricks.cluster.memory"
                points = @(@($now, $memory))
                type = "gauge"
                tags = $baseTags
            }
            
            $allSeries += @{
                metric = "custom.databricks.cluster.dbu_usage"
                points = @(@($now, $dbu))
                type = "gauge"
                tags = $baseTags
            }
        }
    }
}

# Create payload
$payload = @{
    series = $allSeries
}

$payloadJson = $payload | ConvertTo-Json -Depth 10

# Save payload to file for Datadog support
Write-Log ""
Write-Log "[4] Saving payload to file for Datadog support..."
$payloadJson | Out-File -FilePath $payloadLogFile -Force -Encoding UTF8
Write-Log "Payload saved to: $payloadLogFile" "SUCCESS"

# Display payload
Write-Log ""
Write-Log "=============================================="
Write-Log "PAYLOAD BEING SENT TO DATADOG:"
Write-Log "=============================================="
Write-Log $payloadJson

# Send to Datadog
Write-Log ""
Write-Log "[5] Sending to Datadog..."
Write-Log "Endpoint: $DD_URL/api/v1/series"
Write-Log "Method: POST"
Write-Log "Metrics count: $($allSeries.Count)"

try {
    $sendResponse = Invoke-WebRequest -Uri "$DD_URL/api/v1/series" -Method Post -Headers $ddHeaders -Body $payloadJson -UseBasicParsing
    
    Write-Log ""
    Write-Log "=============================================="
    Write-Log "RESPONSE FROM DATADOG:"
    Write-Log "=============================================="
    Write-Log "HTTP Status Code: $($sendResponse.StatusCode)" "SUCCESS"
    Write-Log "Response Body: $($sendResponse.Content)"
    Write-Log ""
    
    if ($sendResponse.StatusCode -eq 202) {
        Write-Log "SUCCESS - Metrics accepted by Datadog!" "SUCCESS"
    }
    
} catch {
    Write-Log ""
    Write-Log "=============================================="
    Write-Log "ERROR FROM DATADOG:"
    Write-Log "=============================================="
    Write-Log "Error: $($_.Exception.Message)" "ERROR"
    
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $errorBody = $reader.ReadToEnd()
        Write-Log "Response Body: $errorBody" "ERROR"
    }
}

Write-Log ""
Write-Log "=============================================="
Write-Log "FILES CREATED FOR DATADOG SUPPORT:"
Write-Log "=============================================="
Write-Log "1. Payload JSON: $payloadLogFile"
Write-Log "2. Script Output: $outputLogFile"
Write-Log ""
Write-Log "Send both files to Datadog support!"
Write-Log "=============================================="

# Summary
Write-Log ""
Write-Log "SUMMARY FOR DATADOG SUPPORT:"
Write-Log "- Endpoint: $DD_URL/api/v1/series"
Write-Log "- Site: $DD_SITE.datadoghq.com"
Write-Log "- Metrics sent: $($allSeries.Count)"
Write-Log "- Metric names:"
foreach ($metric in ($allSeries | Select-Object -ExpandProperty metric -Unique)) {
    Write-Log "    - $metric"
}
