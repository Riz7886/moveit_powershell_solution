# ============================================================================
# SETUP WINDOWS SCHEDULED TASK FOR DATABRICKS-DATADOG MONITORING
# ============================================================================
# Run this script ONCE as Administrator to create the scheduled task
# The task will run the monitoring script every 1 minute
# ============================================================================

#Requires -RunAsAdministrator

$ErrorActionPreference = "Stop"

# Configuration
$TaskName = "Databricks-Datadog-Monitoring"
$ScriptPath = "C:\Scripts\Databricks-Datadog-ScheduledTask.ps1"
$ScriptFolder = "C:\Scripts"
$LogFolder = "C:\Logs"

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  DATABRICKS-DATADOG SCHEDULED TASK SETUP" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Step 1: Create folders
Write-Host "[1/5] Creating folders..." -ForegroundColor Yellow
if (-not (Test-Path $ScriptFolder)) {
    New-Item -ItemType Directory -Path $ScriptFolder -Force | Out-Null
    Write-Host "  Created: $ScriptFolder" -ForegroundColor Green
} else {
    Write-Host "  Exists: $ScriptFolder" -ForegroundColor Green
}

if (-not (Test-Path $LogFolder)) {
    New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null
    Write-Host "  Created: $LogFolder" -ForegroundColor Green
} else {
    Write-Host "  Exists: $LogFolder" -ForegroundColor Green
}

# Step 2: Check if script exists
Write-Host ""
Write-Host "[2/5] Checking for script..." -ForegroundColor Yellow
if (-not (Test-Path $ScriptPath)) {
    Write-Host "  ERROR: Script not found at $ScriptPath" -ForegroundColor Red
    Write-Host "  Please copy 'Databricks-Datadog-ScheduledTask.ps1' to $ScriptFolder" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Expected location: $ScriptPath" -ForegroundColor White
    exit 1
} else {
    Write-Host "  Found: $ScriptPath" -ForegroundColor Green
}

# Step 3: Remove existing task if exists
Write-Host ""
Write-Host "[3/5] Checking for existing task..." -ForegroundColor Yellow
$existingTask = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existingTask) {
    Write-Host "  Removing existing task..." -ForegroundColor Yellow
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "  Removed existing task" -ForegroundColor Green
} else {
    Write-Host "  No existing task found" -ForegroundColor Green
}

# Step 4: Create the scheduled task
Write-Host ""
Write-Host "[4/5] Creating scheduled task..." -ForegroundColor Yellow

# Action - Run PowerShell with the script
$Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ScriptPath`""

# Trigger - Every 1 minute (using repetition)
$Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration (New-TimeSpan -Days 9999)

# Settings
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RunOnlyIfNetworkAvailable -MultipleInstances IgnoreNew

# Principal - Run as SYSTEM (no password needed)
$Principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

# Register the task
Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Settings $Settings -Principal $Principal -Description "Sends Databricks metrics to Datadog every 60 seconds"

Write-Host "  Created task: $TaskName" -ForegroundColor Green

# Step 5: Start the task
Write-Host ""
Write-Host "[5/5] Starting the task..." -ForegroundColor Yellow
Start-ScheduledTask -TaskName $TaskName
Write-Host "  Task started!" -ForegroundColor Green

# Summary
Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  SETUP COMPLETE!" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Task Name:    $TaskName" -ForegroundColor White
Write-Host "  Script:       $ScriptPath" -ForegroundColor White
Write-Host "  Frequency:    Every 1 minute" -ForegroundColor White
Write-Host "  Log File:     $LogFolder\Databricks-Datadog.log" -ForegroundColor White
Write-Host "  Runs As:      SYSTEM" -ForegroundColor White
Write-Host ""
Write-Host "  COMMANDS:" -ForegroundColor Yellow
Write-Host "  - Check status:  Get-ScheduledTask -TaskName '$TaskName'" -ForegroundColor Gray
Write-Host "  - View log:      Get-Content '$LogFolder\Databricks-Datadog.log' -Tail 50" -ForegroundColor Gray
Write-Host "  - Stop task:     Stop-ScheduledTask -TaskName '$TaskName'" -ForegroundColor Gray
Write-Host "  - Remove task:   Unregister-ScheduledTask -TaskName '$TaskName'" -ForegroundColor Gray
Write-Host ""
