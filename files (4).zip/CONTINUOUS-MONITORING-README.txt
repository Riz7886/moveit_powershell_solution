================================================================================
DATABRICKS-DATADOG CONTINUOUS MONITORING - SETUP GUIDE
================================================================================

You have 2 OPTIONS to run the script continuously:

================================================================================
OPTION 1: CONTINUOUS LOOP (Quick Test / Dev)
================================================================================

Use: Databricks-Datadog-Continuous.ps1

This script runs in a loop forever, sending metrics every 60 seconds.
Good for testing. Must keep PowerShell window open.

HOW TO RUN:
-----------
1. Open PowerShell as Administrator
2. Run:
   .\Databricks-Datadog-Continuous.ps1

3. Leave it running (Ctrl+C to stop)

OUTPUT:
-------
[2026-01-02 08:30:00] --- Iteration 1 ---
[2026-01-02 08:30:01] Connected to Databricks - Found 2 cluster(s)
[2026-01-02 08:30:01]   Cluster: analytics | CPU: 45% | Memory: 62% | DBU: 23
[2026-01-02 08:30:02] SUCCESS - Sent 5 metrics to Datadog
[2026-01-02 08:30:02] Waiting 60 seconds until next run...


================================================================================
OPTION 2: WINDOWS SCHEDULED TASK (Production)
================================================================================

Use: Databricks-Datadog-ScheduledTask.ps1 + Setup-ScheduledTask.ps1

This sets up a Windows Scheduled Task that runs every 1 minute.
Runs in background, survives reboots, no window needed.

HOW TO SET UP:
--------------
1. Copy these files to C:\Scripts\
   - Databricks-Datadog-ScheduledTask.ps1

2. Open PowerShell as Administrator

3. Run the setup script:
   .\Setup-ScheduledTask.ps1

4. DONE! Task will run every 60 seconds automatically.

VERIFY IT'S RUNNING:
--------------------
# Check task status
Get-ScheduledTask -TaskName "Databricks-Datadog-Monitoring"

# View recent log entries
Get-Content "C:\Logs\Databricks-Datadog.log" -Tail 20

MANAGE THE TASK:
----------------
# Stop the task
Stop-ScheduledTask -TaskName "Databricks-Datadog-Monitoring"

# Start the task
Start-ScheduledTask -TaskName "Databricks-Datadog-Monitoring"

# Remove the task completely
Unregister-ScheduledTask -TaskName "Databricks-Datadog-Monitoring"


================================================================================
WHICH OPTION TO CHOOSE?
================================================================================

| Scenario                    | Use Option |
|-----------------------------|------------|
| Quick test / debugging      | Option 1   |
| Production / permanent      | Option 2   |
| Need to see output live     | Option 1   |
| Must survive reboot         | Option 2   |
| Run on server unattended    | Option 2   |


================================================================================
REPLY TO PATRYK (DATADOG)
================================================================================

Hi Patryk,

I've now configured the script to run continuously every 60 seconds using 
Windows Task Scheduler. You should start seeing metrics at that frequency.

Please confirm once you see the regular 60-second intervals.

Thanks,
Syed

================================================================================
