output "resource_group_name" {
  value = azurerm_resource_group.font_intune.name
}
output "storage_account_name" {
  value = azurerm_storage_account.font_storage.name
}
