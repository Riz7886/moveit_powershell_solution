variable "subscription_id" {
  type = string
}
variable "tenant_id" {
  type = string
}
variable "environment" {
  type = string
}
variable "location" {
  type    = string
  default = "eastus"
}
variable "project_name" {
  type    = string
  default = "fontintune"
}
variable "tags" {
  type    = map(string)
  default = {}
}
