# ============================================================================
# DEVELOPMENT ENVIRONMENT - FONT INTUNE DEPLOYMENT
# ============================================================================

subscription_id = "YOUR-DEV-SUBSCRIPTION-ID-HERE"
tenant_id       = "YOUR-TENANT-ID-HERE"

environment  = "dev"
location     = "eastus"
project_name = "intune-fonts"
cost_center  = "IT-Development"
owner        = "devops-team@company.com"

font_source_folder = "./fonts"
auto_deploy        = true
enable_monitoring  = true

tags = {
  Application        = "FontDeployment"
  BusinessUnit       = "IT"
  CriticalityTier    = "Tier3"
  DataClassification = "Internal"
}
