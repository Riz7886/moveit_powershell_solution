# ============================================================================
# TEST ENVIRONMENT - FONT INTUNE DEPLOYMENT
# ============================================================================

subscription_id = "YOUR-TEST-SUBSCRIPTION-ID-HERE"
tenant_id       = "YOUR-TENANT-ID-HERE"

environment  = "test"
location     = "eastus"
project_name = "intune-fonts"
cost_center  = "IT-Test"
owner        = "devops-team@company.com"

font_source_folder = "./fonts"
auto_deploy        = false
enable_monitoring  = false

tags = {
  Application        = "FontDeployment"
  BusinessUnit       = "IT"
  CriticalityTier    = "Tier4"
  DataClassification = "Internal"
}
