# Font Intune Deployment - Terraform
terraform {
  required_version = ">= 1.5.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.80.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.5.0"
    }
  }
  backend "azurerm" {
    resource_group_name  = "rg-terraform-state"
    storage_account_name = "stterraformstate"
    container_name       = "tfstate"
    key                  = "font-intune.terraform.tfstate"
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
}

locals {
  common_tags = merge(var.tags, {
    Environment = var.environment
    ManagedBy   = "Terraform"
    Project     = "FontIntune"
  })
  
  # Storage account name must be 3-24 chars, lowercase, no hyphens
  storage_name = lower("stfont${var.environment}${random_string.unique.result}")
}

resource "random_string" "unique" {
  length  = 6
  special = false
  upper   = false
}

resource "azurerm_resource_group" "font_intune" {
  name     = "rg-${var.project_name}-${var.environment}-font-intune"
  location = var.location
  tags     = local.common_tags
}

resource "azurerm_storage_account" "font_storage" {
  name                     = local.storage_name
  resource_group_name      = azurerm_resource_group.font_intune.name
  location                 = azurerm_resource_group.font_intune.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  tags                     = local.common_tags
}

resource "azurerm_storage_container" "fonts" {
  name                  = "fonts"
  storage_account_name  = azurerm_storage_account.font_storage.name
  container_access_type = "private"
}
