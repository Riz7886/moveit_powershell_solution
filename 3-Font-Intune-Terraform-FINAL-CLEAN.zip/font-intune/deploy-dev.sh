#!/bin/bash
# ============================================================================
# FONT INTUNE DEPLOYMENT - DEVELOPMENT
# ============================================================================

set -e
ENV="dev"
terraform init -upgrade -reconfigure -backend-config="key=font-intune-${ENV}.terraform.tfstate"
terraform validate
terraform plan -var-file="environments/terraform-${ENV}.tfvars" -out="tfplan-${ENV}"
terraform apply -auto-approve "tfplan-${ENV}"
terraform output
rm -f "tfplan-${ENV}"
echo "DEV DEPLOYMENT COMPLETE"
