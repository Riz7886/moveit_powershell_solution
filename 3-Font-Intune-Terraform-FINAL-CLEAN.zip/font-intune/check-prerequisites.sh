#!/bin/bash
# ============================================================================
# PREREQUISITE CHECKER AND AUTO-INSTALLER
# ============================================================================
# Checks and auto-installs:
# - Azure CLI
# - Terraform
# - Required tools
# ============================================================================

set -e

echo "============================================"
echo "CHECKING PREREQUISITES"
echo "============================================"
echo ""

# Detect OS
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS="linux"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    OS="mac"
else
    echo "ERROR: Unsupported operating system"
    exit 1
fi

echo "Detected OS: $OS"
echo ""

# Check Azure CLI
echo "Checking Azure CLI..."
if ! command -v az &> /dev/null; then
    echo "Azure CLI not found. Installing..."
    
    if [ "$OS" == "linux" ]; then
        curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
    elif [ "$OS" == "mac" ]; then
        brew install azure-cli
    fi
    
    echo "Azure CLI installed"
else
    echo "Azure CLI found: $(az version --query '\"azure-cli\"' -o tsv)"
fi
echo ""

# Check Terraform
echo "Checking Terraform..."
if ! command -v terraform &> /dev/null; then
    echo "Terraform not found. Installing..."
    
    TERRAFORM_VERSION="1.6.6"
    
    if [ "$OS" == "linux" ]; then
        wget https://releases.hashicorp.com/terraform/${TERRAFORM_VERSION}/terraform_${TERRAFORM_VERSION}_linux_amd64.zip
        unzip terraform_${TERRAFORM_VERSION}_linux_amd64.zip
        sudo mv terraform /usr/local/bin/
        rm terraform_${TERRAFORM_VERSION}_linux_amd64.zip
    elif [ "$OS" == "mac" ]; then
        brew install terraform
    fi
    
    echo "Terraform installed"
else
    CURRENT_VERSION=$(terraform version -json | grep -o '"version":"[^"]*' | cut -d'"' -f4)
    echo "Terraform found: $CURRENT_VERSION"
    
    # Check if version is sufficient
    if [ "$(printf '%s\n' "1.5.0" "$CURRENT_VERSION" | sort -V | head -n1)" != "1.5.0" ]; then
        echo "WARNING: Terraform version is less than 1.5.0"
        echo "Upgrading..."
        
        if [ "$OS" == "linux" ]; then
            TERRAFORM_VERSION="1.6.6"
            wget https://releases.hashicorp.com/terraform/${TERRAFORM_VERSION}/terraform_${TERRAFORM_VERSION}_linux_amd64.zip
            unzip terraform_${TERRAFORM_VERSION}_linux_amd64.zip
            sudo mv terraform /usr/local/bin/
            rm terraform_${TERRAFORM_VERSION}_linux_amd64.zip
        elif [ "$OS" == "mac" ]; then
            brew upgrade terraform
        fi
    fi
fi
echo ""

# Check required tools
echo "Checking required tools..."

tools=("jq" "curl" "unzip")
for tool in "${tools[@]}"; do
    if ! command -v $tool &> /dev/null; then
        echo "Installing $tool..."
        if [ "$OS" == "linux" ]; then
            sudo apt-get update && sudo apt-get install -y $tool
        elif [ "$OS" == "mac" ]; then
            brew install $tool
        fi
    else
        echo "$tool: installed"
    fi
done
echo ""

# Login to Azure
echo "Checking Azure login..."
if ! az account show &> /dev/null; then
    echo "Not logged in. Please login to Azure..."
    az login
else
    echo "Already logged in to Azure"
    ACCOUNT=$(az account show --query name -o tsv)
    echo "Current subscription: $ACCOUNT"
fi
echo ""

echo "============================================"
echo "ALL PREREQUISITES READY"
echo "============================================"
echo ""
echo "You can now run deployment scripts:"
echo "  ./scripts/deploy-dev.sh"
echo "  ./scripts/deploy-prod.sh"
echo ""
