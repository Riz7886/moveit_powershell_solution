# Font Intune Deployment - Terraform

## Overview
Deploy font deployment infrastructure for Microsoft Intune using Terraform.

## Files
- `main.tf` - Main configuration
- `variables.tf` - Variable definitions
- `outputs.tf` - Output values
- `environments/` - Environment configs

## Quick Start

### 1. Update Configuration
Edit `environments/terraform-prod.tfvars`:
```hcl
subscription_id = "your-subscription-id"
tenant_id       = "your-tenant-id"
```

### 2. Deploy
```bash
terraform init
terraform plan -var-file=environments/terraform-prod.tfvars
terraform apply -var-file=environments/terraform-prod.tfvars
```

## Resources Created
- Resource Group
- Storage Account (for font files)
- Storage Container (private)

## Outputs
- `resource_group_name` - Resource group name
- `storage_account_name` - Storage account name

## Important Notes
- Storage account names must be globally unique
- Storage account names must be 3-24 characters, lowercase only
- If deployment fails due to name conflict, change `project_name` variable

## Troubleshooting
See `TROUBLESHOOTING.md` for solutions.

## Requirements
- Terraform >= 1.5.0
- Azure CLI
- Azure subscription
