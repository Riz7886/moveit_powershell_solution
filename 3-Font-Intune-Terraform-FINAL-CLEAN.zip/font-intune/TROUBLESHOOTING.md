# TERRAFORM TROUBLESHOOTING GUIDE - ALL PROJECTS

## COMMON TERRAFORM COMMANDS

### INITIALIZATION
```bash
# Initialize Terraform
terraform init

# Re-initialize with backend reconfiguration
terraform init -reconfigure

# Upgrade provider versions
terraform init -upgrade

# Initialize without backend
terraform init -backend=false
```

### VALIDATION
```bash
# Validate configuration
terraform validate

# Format all files
terraform fmt -recursive

# Check formatting
terraform fmt -check -recursive
```

### PLANNING & APPLYING
```bash
# Create plan for prod
terraform plan -var-file=environments/terraform-prod.tfvars

# Create plan for dev
terraform plan -var-file=environments/terraform-dev.tfvars

# Apply plan
terraform apply -var-file=environments/terraform-prod.tfvars

# Apply with auto-approve (DANGEROUS!)
terraform apply -auto-approve -var-file=environments/terraform-prod.tfvars

# Apply targeting specific resource
terraform apply -target=azurerm_resource_group.main -var-file=environments/terraform-prod.tfvars
```

### STATE MANAGEMENT
```bash
# List all resources
terraform state list

# Show specific resource
terraform state show azurerm_resource_group.main

# Remove resource from state (doesn't delete in Azure)
terraform state rm azurerm_resource_group.main

# Import existing resource
terraform import azurerm_resource_group.main /subscriptions/SUB_ID/resourceGroups/RG_NAME

# Pull state
terraform state pull > backup.tfstate

# Push state (BE CAREFUL!)
terraform state push backup.tfstate

# Refresh state
terraform refresh -var-file=environments/terraform-prod.tfvars
```

### OUTPUTS
```bash
# Show all outputs
terraform output

# Show specific output
terraform output resource_group_name

# Show output in JSON
terraform output -json

# Show sensitive output
terraform output -raw sensitive_value
```

### DESTROY
```bash
# Destroy all resources
terraform destroy -var-file=environments/terraform-prod.tfvars

# Destroy specific resource
terraform destroy -target=azurerm_resource_group.main -var-file=environments/terraform-prod.tfvars
```

## COMMON ERROR FIXES

### ERROR: Backend initialization failed
```bash
terraform init -reconfigure -backend-config="key=PROJECT-ENV.tfstate"
```

### ERROR: State locked
```bash
# Get lock ID from error message, then:
terraform force-unlock LOCK_ID
```

### ERROR: Provider authentication failed
```bash
az login
az account show
az account set --subscription "SUBSCRIPTION_ID"
```

### ERROR: Resource already exists
```bash
# Import the existing resource
terraform import azurerm_resource_group.main /subscriptions/SUB_ID/resourceGroups/RG_NAME
```

### ERROR: Storage account name invalid (font-intune project)
```bash
# This is fixed - storage account name now uses random string
# Name format: stfontprod123abc (always valid)
```

### ERROR: Variables not defined
```bash
# Make sure tfvars file exists and is specified
terraform plan -var-file=environments/terraform-prod.tfvars

# Or set via environment
export TF_VAR_subscription_id="YOUR-SUB-ID"
```

### ERROR: Cycle dependency
```bash
# Check for circular dependencies in code
terraform graph | dot -Tsvg > graph.svg
```

## DEBUGGING

### Enable Debug Logging
```bash
export TF_LOG=DEBUG
export TF_LOG_PATH=terraform.log
terraform apply -var-file=environments/terraform-prod.tfvars
```

### Enable Trace Logging (most verbose)
```bash
export TF_LOG=TRACE
terraform apply -var-file=environments/terraform-prod.tfvars
```

### Disable Logging
```bash
unset TF_LOG
unset TF_LOG_PATH
```

## PROJECT-SPECIFIC FIXES

### MOVEIT PROJECT

**Issue: NSG rules not working**
```bash
# Verify NSG is attached to subnet
az network vnet subnet show --resource-group RG_NAME --vnet-name VNET_NAME --name SUBNET_NAME
```

### AVD PROJECT

**Issue: Session hosts not registering**
```bash
# Check registration token hasn't expired (48 hours)
terraform output host_pool_registration_token

# Recreate registration token
terraform taint azurerm_virtual_desktop_host_pool_registration_info.main
terraform apply -var-file=environments/terraform-prod.tfvars
```

**Issue: Domain join failing**
```bash
# Verify domain_join_password is correct
# Check ou_path format: "OU=AVD,DC=contoso,DC=com"
# Verify domain_join_username doesn't include domain (use "admin" not "DOMAIN\admin")
```

**Issue: VM extension failures**
```bash
# Check VM extension status in Azure Portal
# View extension logs in VM under Extensions blade
# Re-apply if needed:
terraform taint azurerm_virtual_machine_extension.avd_dsc[0]
terraform apply -var-file=environments/terraform-prod.tfvars
```

### FONT-INTUNE PROJECT

**Issue: Storage account name too long**
```bash
# FIXED in latest version - uses random string
# Old: stfontintuneprodfo... (TOO LONG)
# New: stfontprod123abc (ALWAYS VALID)
```

## AZURE CLI VERIFICATION

### Verify Deployment
```bash
# List resource groups
az group list --output table

# Show specific resource group
az group show --name RG_NAME

# List VMs
az vm list --resource-group RG_NAME --output table

# List virtual networks
az network vnet list --resource-group RG_NAME --output table

# Check AVD host pool
az desktopvirtualization hostpool show --resource-group RG_NAME --name HP_NAME
```

## CLEANUP COMMANDS

### Clean Local Files
```bash
# Remove all terraform files
rm -rf .terraform .terraform.lock.hcl terraform.tfstate* tfplan*

# Then reinitialize
terraform init
```

### Complete Reset
```bash
# 1. Backup state
terraform state pull > state-backup-$(date +%Y%m%d-%H%M%S).json

# 2. Clean local
rm -rf .terraform .terraform.lock.hcl terraform.tfstate*

# 3. Reinitialize
terraform init -reconfigure

# 4. Import resources if needed
terraform import azurerm_resource_group.main /subscriptions/SUB/resourceGroups/RG
```

## VALIDATION CHECKLIST

Before deploying to production:

- [ ] Run `terraform validate`
- [ ] Run `terraform fmt -check -recursive`
- [ ] Review `terraform plan` output carefully
- [ ] Verify subscription_id and tenant_id are correct
- [ ] Check all resource names follow naming convention
- [ ] Verify tags are correct
- [ ] Test in dev environment first
- [ ] Have rollback plan ready
- [ ] Ensure proper RBAC permissions
- [ ] Document any manual steps required

## EMERGENCY ROLLBACK

### If deployment fails:
```bash
# 1. Identify last good state
terraform state pull > current-state.json

# 2. Get previous commit
git log --oneline
git checkout PREVIOUS_COMMIT

# 3. Apply previous version
terraform apply -var-file=environments/terraform-prod.tfvars

# 4. Or destroy and redeploy
terraform destroy -var-file=environments/terraform-prod.tfvars
# Fix issue, then redeploy
terraform apply -var-file=environments/terraform-prod.tfvars
```

## GETTING HELP

### Check Terraform Version
```bash
terraform version
```

### Check Provider Versions
```bash
terraform providers
```

### View Detailed Plan
```bash
terraform plan -var-file=environments/terraform-prod.tfvars -out=tfplan
terraform show tfplan
```

### Generate Dependency Graph
```bash
terraform graph | dot -Tsvg > graph.svg
```

## BEST PRACTICES

1. Always run `terraform plan` before `apply`
2. Use `-var-file` to specify environment
3. Never commit `.tfstate` files to git
4. Use remote backend for team collaboration
5. Tag all resources properly
6. Use workspaces for multiple environments
7. Keep modules small and focused
8. Document all manual steps
9. Test in dev before prod
10. Have rollback plan ready

## SUPPORT

For issues:
1. Check this troubleshooting guide first
2. Review Terraform error messages carefully
3. Check Azure Portal for resource status
4. Review diagnostic logs
5. Contact DevOps team if needed
