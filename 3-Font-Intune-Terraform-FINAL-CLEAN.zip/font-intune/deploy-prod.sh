#!/bin/bash
# ============================================================================
# FONT INTUNE DEPLOYMENT - PRODUCTION
# ============================================================================

set -e

echo "============================================================================"
echo "FONT INTUNE DEPLOYMENT - PRODUCTION"
echo "============================================================================"

ENV="prod"
TFVARS_FILE="environments/terraform-${ENV}.tfvars"
STATE_KEY="font-intune-${ENV}.terraform.tfstate"

terraform version
az account show --output table
terraform init -upgrade -reconfigure -backend-config="key=${STATE_KEY}"
terraform validate
terraform plan -var-file="$TFVARS_FILE" -out="tfplan-${ENV}"

read -p "Apply to PRODUCTION? (yes/no): " approval
if [ "$approval" != "yes" ]; then
    echo "Cancelled"
    exit 0
fi

terraform apply "tfplan-${ENV}"
terraform output
rm -f "tfplan-${ENV}"

echo "============================================================================"
echo "INFRASTRUCTURE DEPLOYED"
echo "To deploy fonts, run the PowerShell script manually or use:"
terraform output -raw deployment_command
echo "============================================================================"
