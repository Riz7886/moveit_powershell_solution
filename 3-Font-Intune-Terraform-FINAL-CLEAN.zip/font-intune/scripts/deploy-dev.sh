#!/bin/bash
set -e
echo "font-intune - DEV DEPLOYMENT"
./scripts/setup-backend.sh
terraform init -reconfigure -backend-config="key=font-intune-dev.tfstate"
terraform validate
terraform plan -var-file="environments/terraform-dev.tfvars" -out="tfplan-dev"
terraform apply -auto-approve "tfplan-dev"
terraform output
rm -f "tfplan-dev"
echo "DEV DEPLOYMENT COMPLETE"
