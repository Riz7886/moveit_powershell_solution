#!/bin/bash
set -e
echo "font-intune - PRODUCTION DEPLOYMENT"
./scripts/setup-backend.sh
terraform init -reconfigure -backend-config="key=font-intune-prod.tfstate"
terraform validate
terraform plan -var-file="environments/terraform-prod.tfvars" -out="tfplan-prod"
read -p "Deploy to PRODUCTION? (yes/no): " approval
if [ "$approval" != "yes" ]; then exit 0; fi
terraform apply "tfplan-prod"
terraform output
rm -f "tfplan-prod"
echo "PRODUCTION DEPLOYMENT COMPLETE"
