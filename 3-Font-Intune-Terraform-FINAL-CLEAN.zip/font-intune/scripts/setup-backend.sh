#!/bin/bash
# ============================================================================
# BACKEND SETUP SCRIPT - MOVEIT
# ============================================================================
# Creates backend storage if it doesn't exist
# Run this before terraform init
# ============================================================================

set -e

echo "============================================"
echo "BACKEND STORAGE SETUP"
echo "============================================"
echo ""

# Configuration
RESOURCE_GROUP="rg-terraform-state"
STORAGE_ACCOUNT="stterraformstate$(date +%s | tail -c 5)"
CONTAINER_NAME="tfstate"
LOCATION="eastus"

# Check if logged in to Azure
echo "Checking Azure login..."
if ! az account show &> /dev/null; then
    echo "Not logged in. Logging in to Azure..."
    az login
fi

echo "Logged in to Azure"
echo ""

# Get current subscription
SUBSCRIPTION_ID=$(az account show --query id -o tsv)
echo "Using subscription: $SUBSCRIPTION_ID"
echo ""

# Check if resource group exists
echo "Checking if resource group exists..."
if ! az group show --name $RESOURCE_GROUP &> /dev/null; then
    echo "Creating resource group: $RESOURCE_GROUP"
    az group create --name $RESOURCE_GROUP --location $LOCATION
    echo "Resource group created"
else
    echo "Resource group already exists"
fi
echo ""

# Check if storage account exists
echo "Checking if storage account exists..."
EXISTING_STORAGE=$(az storage account list --resource-group $RESOURCE_GROUP --query "[?starts_with(name, 'stterraformstate')].name" -o tsv | head -1)

if [ -z "$EXISTING_STORAGE" ]; then
    echo "Creating storage account: $STORAGE_ACCOUNT"
    az storage account create \
        --name $STORAGE_ACCOUNT \
        --resource-group $RESOURCE_GROUP \
        --location $LOCATION \
        --sku Standard_LRS \
        --encryption-services blob
    
    echo "Storage account created"
    STORAGE_ACCOUNT_NAME=$STORAGE_ACCOUNT
else
    echo "Storage account already exists: $EXISTING_STORAGE"
    STORAGE_ACCOUNT_NAME=$EXISTING_STORAGE
fi
echo ""

# Get storage account key
ACCOUNT_KEY=$(az storage account keys list --resource-group $RESOURCE_GROUP --account-name $STORAGE_ACCOUNT_NAME --query '[0].value' -o tsv)

# Check if container exists
echo "Checking if container exists..."
if ! az storage container show --name $CONTAINER_NAME --account-name $STORAGE_ACCOUNT_NAME --account-key $ACCOUNT_KEY &> /dev/null; then
    echo "Creating container: $CONTAINER_NAME"
    az storage container create \
        --name $CONTAINER_NAME \
        --account-name $STORAGE_ACCOUNT_NAME \
        --account-key $ACCOUNT_KEY
    echo "Container created"
else
    echo "Container already exists"
fi
echo ""

# Update backend config in main.tf
echo "Updating backend configuration in main.tf..."
sed -i "s/storage_account_name = \"stterraformstate\"/storage_account_name = \"$STORAGE_ACCOUNT_NAME\"/" main.tf

echo ""
echo "============================================"
echo "BACKEND SETUP COMPLETE"
echo "============================================"
echo ""
echo "Resource Group: $RESOURCE_GROUP"
echo "Storage Account: $STORAGE_ACCOUNT_NAME"
echo "Container: $CONTAINER_NAME"
echo ""
echo "You can now run terraform init"
echo ""
