# ================================================================
# AZURE VPN GATEWAY - BULLETPROOF DEPLOYMENT
# Point-to-Site VPN for Remote Access
# Deployment Time: 30-40 minutes
# ================================================================

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  AZURE VPN GATEWAY - BULLETPROOF DEPLOY" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

function Write-Log {
    param([string]$Message, [string]$Color = "White")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] $Message" -ForegroundColor $Color
}

# ----------------------------------------------------------------
# CONFIGURATION
# ----------------------------------------------------------------
$global:config = @{
    Location = "westus"
    DeploymentResourceGroup = "rg-vpn"
    VPNGatewayName = "vpngw-corporate"
    VPNPublicIPName = "pip-vpngw"
    GatewaySubnetPrefix = "10.100.255.0/27"
    VPNClientAddressPool = "172.16.0.0/16"
    VPNGatewaySKU = "VpnGw2"
}

# ----------------------------------------------------------------
# STEP 1: CHECK AZURE CLI
# ----------------------------------------------------------------
Write-Log "Checking Azure CLI..." "Yellow"
try {
    $azVersion = az version --output json 2>$null | ConvertFrom-Json
    Write-Log "Azure CLI version: $($azVersion.'azure-cli')" "Green"
} catch {
    Write-Log "ERROR: Azure CLI not found!" "Red"
    Write-Log "Install from: https://aka.ms/installazurecliwindows" "Yellow"
    exit 1
}

# ----------------------------------------------------------------
# STEP 2: LOGIN
# ----------------------------------------------------------------
Write-Log "Checking Azure login..." "Yellow"
$loginCheck = az account show 2>$null
if (-not $loginCheck) {
    Write-Log "Not logged in. Starting login..." "Yellow"
    az login --use-device-code
} else {
    Write-Log "Already logged in" "Green"
}

# ----------------------------------------------------------------
# STEP 3: SELECT SUBSCRIPTION
# ----------------------------------------------------------------
Write-Host ""
Write-Log "============================================" "Cyan"
Write-Log "AVAILABLE SUBSCRIPTIONS" "Cyan"
Write-Log "============================================" "Cyan"

$subscriptions = az account list --output json | ConvertFrom-Json

for ($i = 0; $i -lt $subscriptions.Count; $i++) {
    $sub = $subscriptions[$i]
    $stateColor = if ($sub.state -eq "Enabled") { "Green" } else { "Yellow" }
    Write-Host "[$($i + 1)] " -NoNewline -ForegroundColor Cyan
    Write-Host "$($sub.name) " -NoNewline -ForegroundColor White
    Write-Host "($($sub.state))" -ForegroundColor $stateColor
}

Write-Host ""
$selection = Read-Host "Select subscription number"
$selectedSubscription = $subscriptions[[int]$selection - 1]
az account set --subscription $selectedSubscription.id
Write-Log "Active subscription: $($selectedSubscription.name)" "Green"
Write-Host ""

# ----------------------------------------------------------------
# STEP 4: NETWORK DISCOVERY OR CREATE NEW
# ----------------------------------------------------------------
Write-Host ""
Write-Log "============================================" "Cyan"
Write-Log "NETWORK CONFIGURATION" "Cyan"
Write-Log "============================================" "Cyan"
Write-Host ""

Write-Host "Do you want to:" -ForegroundColor Yellow
Write-Host "  1. Use existing VNet (will auto-discover)" -ForegroundColor White
Write-Host "  2. Create new VNet" -ForegroundColor White
Write-Host ""
$networkChoice = Read-Host "Enter choice (1 or 2)"

if ($networkChoice -eq "1") {
    # AUTO-DISCOVER EXISTING NETWORK
    Write-Log "Looking for existing networks..." "Yellow"
    
    # Find network resource group
    $allRGs = az group list --output json | ConvertFrom-Json
    $networkRG = $null
    
    Write-Log "Looking for resource group with 'network' in name..." "Yellow"
    foreach ($rg in $allRGs) {
        if ($rg.name -like "*network*") {
            $networkRG = $rg.name
            Write-Log "FOUND: $networkRG" "Green"
            break
        }
    }
    
    if (-not $networkRG) {
        Write-Log "No 'network' RG found. Showing all resource groups:" "Yellow"
        for ($i = 0; $i -lt $allRGs.Count; $i++) {
            Write-Host "[$($i + 1)] $($allRGs[$i].name)" -ForegroundColor Cyan
        }
        Write-Host ""
        $rgSelection = Read-Host "Select resource group number"
        $networkRG = $allRGs[[int]$rgSelection - 1].name
        Write-Log "Selected: $networkRG" "Green"
    }
    
    $global:config.NetworkResourceGroup = $networkRG
    
    # Find VNet
    Write-Log "Looking for VNets in $networkRG..." "Yellow"
    $allVNets = az network vnet list --resource-group $networkRG --output json 2>$null | ConvertFrom-Json
    
    if (-not $allVNets -or $allVNets.Count -eq 0) {
        Write-Log "ERROR: No VNets found in $networkRG!" "Red"
        exit 1
    }
    
    Write-Log "FOUND VNets:" "Green"
    for ($i = 0; $i -lt $allVNets.Count; $i++) {
        Write-Host "[$($i + 1)] $($allVNets[$i].name) ($($allVNets[$i].addressSpace.addressPrefixes -join ', '))" -ForegroundColor Cyan
    }
    
    if ($allVNets.Count -eq 1) {
        $selectedVNet = $allVNets[0].name
        Write-Log "Auto-selected: $selectedVNet" "Green"
    } else {
        Write-Host ""
        $vnetSelection = Read-Host "Select VNet number"
        $selectedVNet = $allVNets[[int]$vnetSelection - 1].name
        Write-Log "Selected: $selectedVNet" "Green"
    }
    
    $global:config.VNetName = $selectedVNet
    $global:config.CreateNew = $false
    
} else {
    # CREATE NEW NETWORK
    Write-Log "Creating new VNet configuration..." "Yellow"
    
    $vnetName = Read-Host "Enter VNet name (default: vnet-vpn)"
    if ([string]::IsNullOrWhiteSpace($vnetName)) {
        $vnetName = "vnet-vpn"
    }
    
    $vnetPrefix = Read-Host "Enter VNet address space (default: 10.100.0.0/16)"
    if ([string]::IsNullOrWhiteSpace($vnetPrefix)) {
        $vnetPrefix = "10.100.0.0/16"
    }
    
    $global:config.VNetName = $vnetName
    $global:config.VNetAddressPrefix = $vnetPrefix
    $global:config.NetworkResourceGroup = $global:config.DeploymentResourceGroup
    $global:config.CreateNew = $true
}

Write-Host ""
Write-Log "============================================" "Cyan"
Write-Log "CONFIGURATION SUMMARY" "Cyan"
Write-Log "============================================" "Cyan"
Write-Host ""
Write-Host "Network RG: $($global:config.NetworkResourceGroup)" -ForegroundColor White
Write-Host "VNet: $($global:config.VNetName)" -ForegroundColor White
if ($global:config.CreateNew) {
    Write-Host "VNet Prefix: $($global:config.VNetAddressPrefix)" -ForegroundColor White
    Write-Host "Mode: Create New Network" -ForegroundColor Yellow
} else {
    Write-Host "Mode: Use Existing Network" -ForegroundColor Yellow
}
Write-Host "Gateway Subnet: $($global:config.GatewaySubnetPrefix)" -ForegroundColor White
Write-Host "VPN Client Pool: $($global:config.VPNClientAddressPool)" -ForegroundColor White
Write-Host "VPN Gateway SKU: $($global:config.VPNGatewaySKU)" -ForegroundColor White
Write-Host "Deployment RG: $($global:config.DeploymentResourceGroup)" -ForegroundColor White
Write-Host ""
Write-Host "Press ENTER to start deployment..." -ForegroundColor Yellow
Read-Host

# ----------------------------------------------------------------
# STEP 5: CREATE RESOURCE GROUP
# ----------------------------------------------------------------
Write-Host ""
Write-Log "============================================" "Cyan"
Write-Log "CREATING RESOURCE GROUPS" "Cyan"
Write-Log "============================================" "Cyan"
Write-Host ""

Write-Log "Creating deployment resource group..." "Yellow"
$rgExists = az group show --name $global:config.DeploymentResourceGroup 2>$null
if (-not $rgExists) {
    az group create --name $global:config.DeploymentResourceGroup --location $global:config.Location --output none
    Write-Log "Created: $($global:config.DeploymentResourceGroup)" "Green"
} else {
    Write-Log "Already exists: $($global:config.DeploymentResourceGroup)" "Yellow"
}

# ----------------------------------------------------------------
# STEP 6: CREATE OR VALIDATE VNET
# ----------------------------------------------------------------
if ($global:config.CreateNew) {
    Write-Host ""
    Write-Log "Creating new VNet..." "Yellow"
    
    az network vnet create `
        --resource-group $global:config.DeploymentResourceGroup `
        --name $global:config.VNetName `
        --address-prefix $global:config.VNetAddressPrefix `
        --location $global:config.Location `
        --output none
    
    Write-Log "VNet created: $($global:config.VNetName)" "Green"
}

# ----------------------------------------------------------------
# STEP 7: CREATE GATEWAY SUBNET
# ----------------------------------------------------------------
Write-Host ""
Write-Log "Creating Gateway Subnet..." "Yellow"

$gatewaySubnetExists = az network vnet subnet show `
    --resource-group $global:config.NetworkResourceGroup `
    --vnet-name $global:config.VNetName `
    --name "GatewaySubnet" 2>$null

if (-not $gatewaySubnetExists) {
    az network vnet subnet create `
        --resource-group $global:config.NetworkResourceGroup `
        --vnet-name $global:config.VNetName `
        --name "GatewaySubnet" `
        --address-prefix $global:config.GatewaySubnetPrefix `
        --output none
    
    Write-Log "Gateway Subnet created" "Green"
} else {
    Write-Log "Gateway Subnet already exists" "Yellow"
}

# ----------------------------------------------------------------
# STEP 8: CREATE PUBLIC IP FOR VPN GATEWAY
# ----------------------------------------------------------------
Write-Host ""
Write-Log "Creating public IP for VPN Gateway..." "Yellow"
Write-Log "This will take 2-3 minutes..." "Gray"

$pipExists = az network public-ip show --resource-group $global:config.DeploymentResourceGroup --name $global:config.VPNPublicIPName 2>$null
if (-not $pipExists) {
    az network public-ip create `
        --resource-group $global:config.DeploymentResourceGroup `
        --name $global:config.VPNPublicIPName `
        --location $global:config.Location `
        --sku Standard `
        --allocation-method Static `
        --output none
    
    Write-Log "Public IP created" "Green"
} else {
    Write-Log "Public IP already exists" "Yellow"
}

# ----------------------------------------------------------------
# STEP 9: CREATE VPN GATEWAY (THIS TAKES 30-40 MINUTES!)
# ----------------------------------------------------------------
Write-Host ""
Write-Log "============================================" "Yellow"
Write-Log "CREATING VPN GATEWAY" "Yellow"
Write-Log "============================================" "Yellow"
Write-Host ""
Write-Log "This will take 30-40 minutes. Please be patient..." "Yellow"
Write-Log "Started at: $(Get-Date -Format 'HH:mm:ss')" "Cyan"
Write-Host ""

$gwExists = az network vnet-gateway show --resource-group $global:config.DeploymentResourceGroup --name $global:config.VPNGatewayName 2>$null
if (-not $gwExists) {
    az network vnet-gateway create `
        --resource-group $global:config.DeploymentResourceGroup `
        --name $global:config.VPNGatewayName `
        --public-ip-address $global:config.VPNPublicIPName `
        --vnet $global:config.VNetName `
        --gateway-type Vpn `
        --sku $global:config.VPNGatewaySKU `
        --vpn-type RouteBased `
        --location $global:config.Location `
        --client-protocol IkeV2 OpenVPN `
        --address-prefixes $global:config.VPNClientAddressPool `
        --output none
    
    Write-Log "VPN Gateway created!" "Green"
} else {
    Write-Log "VPN Gateway already exists" "Yellow"
}

Write-Log "Completed at: $(Get-Date -Format 'HH:mm:ss')" "Cyan"

# ----------------------------------------------------------------
# STEP 10: GET GATEWAY DETAILS
# ----------------------------------------------------------------
Write-Host ""
Write-Log "Getting VPN Gateway details..." "Yellow"

$publicIP = az network public-ip show --resource-group $global:config.DeploymentResourceGroup --name $global:config.VPNPublicIPName --query ipAddress --output tsv

# ----------------------------------------------------------------
# STEP 11: CREATE SUMMARY FILE
# ----------------------------------------------------------------
$summaryFile = "$env:USERPROFILE\Desktop\VPN-Gateway-Summary.txt"
@"
========================================
AZURE VPN GATEWAY DEPLOYMENT SUMMARY
========================================
Deployment Date: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")

CONNECTION INFORMATION:
VPN Gateway Public IP: $publicIP
VPN Client Address Pool: $($global:config.VPNClientAddressPool)

INFRASTRUCTURE:
Resource Group: $($global:config.DeploymentResourceGroup)
Network RG: $($global:config.NetworkResourceGroup)
VNet: $($global:config.VNetName)
Gateway Subnet: $($global:config.GatewaySubnetPrefix)
VPN Gateway Name: $($global:config.VPNGatewayName)
VPN Gateway SKU: $($global:config.VPNGatewaySKU)

SUPPORTED PROTOCOLS:
- IKEv2 (Windows, macOS, iOS)
- OpenVPN (All platforms)

NEXT STEPS:
1. Generate root and client certificates
2. Upload root certificate to VPN Gateway
3. Download VPN client configuration
4. Distribute to users

CERTIFICATE GENERATION (PowerShell):
# Generate root certificate
`$rootCert = New-SelfSignedCertificate -Type Custom -KeySpec Signature ``
    -Subject "CN=VPN-Root-Certificate" -KeyExportPolicy Exportable ``
    -HashAlgorithm sha256 -KeyLength 2048 ``
    -CertStoreLocation "Cert:\CurrentUser\My" ``
    -KeyUsageProperty Sign -KeyUsage CertSign

# Generate client certificate
`$clientCert = New-SelfSignedCertificate -Type Custom -KeySpec Signature ``
    -Subject "CN=VPN-Client-Certificate" -KeyExportPolicy Exportable ``
    -HashAlgorithm sha256 -KeyLength 2048 ``
    -CertStoreLocation "Cert:\CurrentUser\My" ``
    -Signer `$rootCert -TextExtension @("2.5.29.37={text}1.3.6.1.5.5.7.3.2")

# Export root certificate public key
`$rootCertData = [System.Convert]::ToBase64String(`$rootCert.Export('Cert'))

# Upload to Azure
az network vnet-gateway root-cert create ``
    --resource-group $($global:config.DeploymentResourceGroup) ``
    --gateway-name $($global:config.VPNGatewayName) ``
    --name "VPN-Root-Certificate" ``
    --public-cert-data `$rootCertData

DOWNLOAD VPN CLIENT:
az network vnet-gateway vpn-client generate ``
    --resource-group $($global:config.DeploymentResourceGroup) ``
    --name $($global:config.VPNGatewayName) ``
    --processor-architecture Amd64 ``
    --output tsv

USER INSTRUCTIONS:
1. Install client certificate on user machine
2. Download and install VPN client
3. Connect to VPN Gateway
4. Access corporate resources

MONTHLY COST: ~`$140/month (VpnGw2)

========================================
"@ | Out-File -FilePath $summaryFile -Encoding UTF8

Write-Host ""
Write-Log "============================================" "Green"
Write-Log "DEPLOYMENT COMPLETE!" "Green"
Write-Log "============================================" "Green"
Write-Host ""
Write-Host "VPN GATEWAY DEPLOYED:" -ForegroundColor Cyan
Write-Host "  Public IP: $publicIP" -ForegroundColor Green
Write-Host "  SKU: $($global:config.VPNGatewaySKU)" -ForegroundColor White
Write-Host "  Client Pool: $($global:config.VPNClientAddressPool)" -ForegroundColor White
Write-Host "  Protocols: IKEv2, OpenVPN" -ForegroundColor White
Write-Host ""
Write-Host "NEXT STEPS:" -ForegroundColor Cyan
Write-Host "  1. Generate certificates (see summary file)" -ForegroundColor Yellow
Write-Host "  2. Upload root certificate to gateway" -ForegroundColor Yellow
Write-Host "  3. Download VPN client configuration" -ForegroundColor Yellow
Write-Host "  4. Distribute to users" -ForegroundColor Yellow
Write-Host ""
Write-Host "Summary saved to: $summaryFile" -ForegroundColor Gray
Write-Host ""
Write-Host "Press any key to exit..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
