[CmdletBinding()]
param(
    [switch]$DryRun,
    [ValidateSet("all", "foundation", "networking", "shared-services", "container-apps", "devops", "migrate")]
    [string]$Phase = "all"
)

$Config = @{
    CompanyName          = "PYX"
    CompanyFullName      = "PYX Health"
    TenantId             = "<your-tenant-id>"
    Subscriptions        = @{
        Management       = "<management-subscription-id>"
        Connectivity     = "<connectivity-subscription-id>"
        Identity         = "<identity-subscription-id>"
        Production       = "<production-subscription-id>"
        NonProduction    = "<nonprod-subscription-id>"
        Sandbox          = "<sandbox-subscription-id>"
        AIML             = "<aiml-subscription-id>"
    }
    PrimaryRegion        = "eastus2"
    SecondaryRegion      = "westus2"
    Networking           = @{
        HubVNetCidr          = "10.0.0.0/16"
        GatewaySubnetCidr    = "10.0.0.0/27"
        FirewallSubnetCidr   = "10.0.1.0/26"
        BastionSubnetCidr    = "10.0.2.0/27"
        SharedSubnetCidr     = "10.0.3.0/24"
        SpokeVNets           = @{
            Production   = @{ Cidr = "10.1.0.0/16"; CaeSubnet = "10.1.1.0/24"; AppSubnet = "10.1.2.0/24"; DbSubnet = "10.1.3.0/24" }
            NonProduction= @{ Cidr = "10.2.0.0/16"; CaeSubnet = "10.2.1.0/24"; AppSubnet = "10.2.2.0/24"; DbSubnet = "10.2.3.0/24" }
            AIML         = @{ Cidr = "10.3.0.0/16"; CaeSubnet = "10.3.1.0/24"; DatabricksPublic = "10.3.2.0/24"; DatabricksPrivate = "10.3.3.0/24" }
        }
    }
    DevOps               = @{
        OrganizationName     = "pyx-enterprise"
        OrganizationUrl      = "https://dev.azure.com/pyx-enterprise"
        PAT                  = "<your-pat-token>"
        Projects             = @(
            @{ Name = "Infrastructure"; Description = "Landing Zones and Terraform modules" }
            @{ Name = "Platform";       Description = "Container platforms and shared services" }
            @{ Name = "Applications";   Description = "Application workloads" }
            @{ Name = "AI-ML";          Description = "AI and ML workloads" }
            @{ Name = "Security";       Description = "Security and compliance" }
        )
        Environments         = @{
            sandbox = @{ Approvers = @(); Timeout = 0 }
            dev = @{ Approvers = @("team-lead@pyxhealth.com"); Timeout = 24 }
            staging = @{ Approvers = @("team-lead@pyxhealth.com", "qa-lead@pyxhealth.com"); Timeout = 48 }
            production = @{ Approvers = @("release-manager@pyxhealth.com", "director@pyxhealth.com"); Timeout = 72; RequireChangeTicket = $true }
        }
    }
    OldDevOps            = @{
        OrganizationUrl      = "https://dev.azure.com/techmodgroup"
        Project              = "Pyx.DriversHealth"
        Pipelines            = @("hi pyx API")
    }
    OldGitHub            = @{
        Organization         = "TechModGroup"
        Repositories         = @(
            "PyxWeb"
            "drivers-health-api"
            "drivers-health-ai"
            "TargetPopulationIntegration"
            "fra-netsuite-scripts"
            "fra-order-portal"
            "Internal-automation-tools"
        )
    }
    ContainerRegistry    = @{
        NonProd = @{ Name = "acrpyxnonprod"; Sku = "Standard"; ResourceGroup = "rg-pyx-shared-nonprod" }
        Prod    = @{ Name = "acrpyxprod";    Sku = "Premium";  ResourceGroup = "rg-pyx-shared-prod" }
    }
    KeyVaults            = @{
        Dev     = @{ Name = "kv-pyx-dev"; ResourceGroup = "rg-pyx-shared-nonprod" }
        Staging = @{ Name = "kv-pyx-staging"; ResourceGroup = "rg-pyx-shared-nonprod" }
        Prod    = @{ Name = "kv-pyx-prod"; ResourceGroup = "rg-pyx-shared-prod" }
    }
    Tags                 = @{
        Required = @("Environment", "CostCenter", "Owner", "Application", "ManagedBy")
        Defaults = @{
            CostCenter = "Engineering"
            Owner      = "platform-team@pyxhealth.com"
            ManagedBy  = "Terraform"
        }
    }
}

$Timestamp         = Get-Date -Format "yyyyMMdd-HHmmss"
$LogFile           = Join-Path $PSScriptRoot "deploy-enterprise-$Timestamp.log"
$script:Errors     = 0
$script:Warnings   = 0

function Write-Log {
    param([string]$Level, [string]$Message)
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $entry = "$ts [$Level] $Message"
    Add-Content -Path $LogFile -Value $entry -ErrorAction SilentlyContinue
    switch ($Level) {
        "INFO"    { Write-Host $entry -ForegroundColor Cyan }
        "SUCCESS" { Write-Host $entry -ForegroundColor Green }
        "WARN"    { Write-Host $entry -ForegroundColor Yellow; $script:Warnings++ }
        "ERROR"   { Write-Host $entry -ForegroundColor Red; $script:Errors++ }
        "SECTION" { Write-Host "`n$Message`n" -ForegroundColor Magenta }
    }
}

function Invoke-AzCli {
    param([string]$Description, [string[]]$Arguments)
    
    if ($DryRun) {
        Write-Log "WARN" "[DRY-RUN] Would execute: az $($Arguments -join ' ')"
        return $null
    }
    
    Write-Log "INFO" $Description
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    
    try {
        $output = & az @Arguments 2>&1
        $exitCode = $LASTEXITCODE
        $stdout = ($output | Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] }) -join "`n"
        
        if ($exitCode -ne 0) {
            Write-Log "ERROR" "$Description - FAILED (exit code: $exitCode)"
            $script:Errors++
            return $null
        }
        
        Write-Log "SUCCESS" "$Description - Done"
        return $stdout
    }
    catch {
        Write-Log "ERROR" "$Description - EXCEPTION: $($_.Exception.Message)"
        $script:Errors++
        return $null
    }
    finally {
        $ErrorActionPreference = $prevEAP
    }
}

function Get-AzCliOutput {
    param([string[]]$Arguments)
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        $result = & az @Arguments 2>$null
        if ($LASTEXITCODE -eq 0) { return ($result | Out-String).Trim() }
        return $null
    }
    catch { return $null }
    finally { $ErrorActionPreference = $prevEAP }
}

function Test-ShouldRunPhase {
    param([string]$PhaseName)
    return ($Phase -eq "all" -or $Phase -eq $PhaseName)
}

function Get-Tags {
    param([string]$Environment, [string]$Application = "Platform")
    return @(
        "Environment=$Environment",
        "CostCenter=$($Config.Tags.Defaults.CostCenter)",
        "Owner=$($Config.Tags.Defaults.Owner)",
        "Application=$Application",
        "ManagedBy=$($Config.Tags.Defaults.ManagedBy)"
    )
}

function Test-Configuration {
    Write-Log "SECTION" "Validating Configuration"
    
    $hasError = $false
    
    foreach ($subKey in $Config.Subscriptions.Keys) {
        if ($Config.Subscriptions[$subKey] -match "^<") {
            Write-Log "ERROR" "Subscription '$subKey' is not configured"
            $hasError = $true
        }
    }
    
    if ($Config.TenantId -match "^<") {
        Write-Log "ERROR" "TenantId is not configured"
        $hasError = $true
    }
    
    if ($Config.DevOps.PAT -match "^<") {
        Write-Log "WARN" "DevOps PAT is not configured - DevOps phases will be skipped"
    }
    
    if ($hasError) {
        Write-Log "ERROR" "Configuration validation failed"
        exit 1
    }
    
    Write-Log "SUCCESS" "Configuration validated"
}

function Invoke-PreflightChecks {
    Write-Log "SECTION" "Preflight Checks"
    
    $azCmd = Get-Command az -ErrorAction SilentlyContinue
    if (-not $azCmd) {
        Write-Log "ERROR" "Azure CLI not found"
        exit 1
    }
    Write-Log "SUCCESS" "Azure CLI found"
    
    $account = Get-AzCliOutput -Arguments @("account", "show", "--query", "user.name", "-o", "tsv")
    if (-not $account) {
        Write-Log "ERROR" "Not logged in - Run az login first"
        exit 1
    }
    Write-Log "SUCCESS" "Logged in as: $account"
    
    $extensions = @("azure-devops", "containerapp")
    foreach ($ext in $extensions) {
        $installed = Get-AzCliOutput -Arguments @("extension", "show", "--name", $ext, "--query", "name", "-o", "tsv")
        if (-not $installed) {
            Write-Log "INFO" "Installing extension: $ext"
            & az extension add --name $ext --yes 2>$null
        }
    }
    Write-Log "SUCCESS" "Required extensions installed"
    
    $providers = @(
        "Microsoft.ContainerRegistry",
        "Microsoft.App",
        "Microsoft.KeyVault",
        "Microsoft.Network",
        "Microsoft.OperationalInsights",
        "Microsoft.ManagedIdentity"
    )
    foreach ($provider in $providers) {
        Invoke-AzCli -Description "Registering provider: $provider" -Arguments @(
            "provider", "register", "--namespace", $provider, "--wait"
        )
    }
}

function Deploy-Foundation {
    if (-not (Test-ShouldRunPhase "foundation")) { return }
    
    Write-Log "SECTION" "Phase 1: Foundation"
    
    Invoke-AzCli -Description "Setting context to Management subscription" -Arguments @(
        "account", "set", "--subscription", $Config.Subscriptions.Management
    )
    
    $resourceGroups = @{
        Management = @(
            "rg-pyx-management-$($Config.PrimaryRegion)",
            "rg-pyx-logging-$($Config.PrimaryRegion)"
        )
        Connectivity = @(
            "rg-pyx-connectivity-$($Config.PrimaryRegion)",
            "rg-pyx-dns-$($Config.PrimaryRegion)"
        )
        Production = @(
            "rg-pyx-shared-prod",
            "rg-pyx-apps-prod-$($Config.PrimaryRegion)"
        )
        NonProduction = @(
            "rg-pyx-shared-nonprod",
            "rg-pyx-apps-dev-$($Config.PrimaryRegion)",
            "rg-pyx-apps-staging-$($Config.PrimaryRegion)"
        )
        AIML = @(
            "rg-pyx-aiml-platform-$($Config.PrimaryRegion)",
            "rg-pyx-aiml-compute-$($Config.PrimaryRegion)"
        )
    }
    
    foreach ($subKey in $resourceGroups.Keys) {
        if ($Config.Subscriptions[$subKey] -match "^<") { continue }
        
        Invoke-AzCli -Description "Setting subscription: $subKey" -Arguments @(
            "account", "set", "--subscription", $Config.Subscriptions[$subKey]
        )
        
        foreach ($rg in $resourceGroups[$subKey]) {
            $env = if ($rg -match "prod") { "Production" } elseif ($rg -match "nonprod|dev|staging") { "NonProduction" } else { "Shared" }
            $tags = Get-Tags -Environment $env
            
            Invoke-AzCli -Description "Creating resource group: $rg" -Arguments @(
                "group", "create",
                "--name", $rg,
                "--location", $Config.PrimaryRegion,
                "--tags", $tags[0], $tags[1], $tags[2], $tags[3], $tags[4]
            )
        }
    }
}

function Deploy-Networking {
    if (-not (Test-ShouldRunPhase "networking")) { return }
    
    Write-Log "SECTION" "Phase 2: Networking"
    
    Invoke-AzCli -Description "Setting context to Connectivity subscription" -Arguments @(
        "account", "set", "--subscription", $Config.Subscriptions.Connectivity
    )
    
    $tags = Get-Tags -Environment "Shared" -Application "Networking"
    
    Invoke-AzCli -Description "Creating Hub VNet" -Arguments @(
        "network", "vnet", "create",
        "--name", "vnet-hub-$($Config.PrimaryRegion)",
        "--resource-group", "rg-pyx-connectivity-$($Config.PrimaryRegion)",
        "--location", $Config.PrimaryRegion,
        "--address-prefixes", $Config.Networking.HubVNetCidr,
        "--tags", $tags[0], $tags[1], $tags[2], $tags[3], $tags[4]
    )
    
    $hubSubnets = @{
        "GatewaySubnet"       = $Config.Networking.GatewaySubnetCidr
        "AzureFirewallSubnet" = $Config.Networking.FirewallSubnetCidr
        "AzureBastionSubnet"  = $Config.Networking.BastionSubnetCidr
        "snet-shared"         = $Config.Networking.SharedSubnetCidr
    }
    
    foreach ($subnet in $hubSubnets.Keys) {
        Invoke-AzCli -Description "Creating subnet: $subnet" -Arguments @(
            "network", "vnet", "subnet", "create",
            "--name", $subnet,
            "--vnet-name", "vnet-hub-$($Config.PrimaryRegion)",
            "--resource-group", "rg-pyx-connectivity-$($Config.PrimaryRegion)",
            "--address-prefixes", $hubSubnets[$subnet]
        )
    }
    
    foreach ($spokeName in $Config.Networking.SpokeVNets.Keys) {
        $spoke = $Config.Networking.SpokeVNets[$spokeName]
        $subId = $Config.Subscriptions[$spokeName]
        if ($subId -match "^<") { continue }
        
        $rgName = switch ($spokeName) {
            "Production"    { "rg-pyx-shared-prod" }
            "NonProduction" { "rg-pyx-shared-nonprod" }
            "AIML"          { "rg-pyx-aiml-platform-$($Config.PrimaryRegion)" }
        }
        
        Invoke-AzCli -Description "Setting subscription: $spokeName" -Arguments @(
            "account", "set", "--subscription", $subId
        )
        
        $spokeTags = Get-Tags -Environment $spokeName -Application "Networking"
        
        Invoke-AzCli -Description "Creating Spoke VNet: $spokeName" -Arguments @(
            "network", "vnet", "create",
            "--name", "vnet-spoke-$($spokeName.ToLower())-$($Config.PrimaryRegion)",
            "--resource-group", $rgName,
            "--location", $Config.PrimaryRegion,
            "--address-prefixes", $spoke.Cidr,
            "--tags", $spokeTags[0], $spokeTags[1], $spokeTags[2], $spokeTags[3], $spokeTags[4]
        )
        
        Invoke-AzCli -Description "Creating Container Apps subnet" -Arguments @(
            "network", "vnet", "subnet", "create",
            "--name", "snet-containerapp",
            "--vnet-name", "vnet-spoke-$($spokeName.ToLower())-$($Config.PrimaryRegion)",
            "--resource-group", $rgName,
            "--address-prefixes", $spoke.CaeSubnet,
            "--delegations", "Microsoft.App/environments"
        )
    }
}

function Deploy-SharedServices {
    if (-not (Test-ShouldRunPhase "shared-services")) { return }
    
    Write-Log "SECTION" "Phase 3: Shared Services"
    
    Invoke-AzCli -Description "Setting context to NonProduction subscription" -Arguments @(
        "account", "set", "--subscription", $Config.Subscriptions.NonProduction
    )
    
    $tagsNonProd = Get-Tags -Environment "NonProduction" -Application "SharedServices"
    
    Invoke-AzCli -Description "Creating NonProd Container Registry" -Arguments @(
        "acr", "create",
        "--name", $Config.ContainerRegistry.NonProd.Name,
        "--resource-group", $Config.ContainerRegistry.NonProd.ResourceGroup,
        "--location", $Config.PrimaryRegion,
        "--sku", $Config.ContainerRegistry.NonProd.Sku,
        "--admin-enabled", "false",
        "--tags", $tagsNonProd[0], $tagsNonProd[1], $tagsNonProd[2], $tagsNonProd[3], $tagsNonProd[4]
    )
    
    Invoke-AzCli -Description "Creating Dev Key Vault" -Arguments @(
        "keyvault", "create",
        "--name", $Config.KeyVaults.Dev.Name,
        "--resource-group", $Config.KeyVaults.Dev.ResourceGroup,
        "--location", $Config.PrimaryRegion,
        "--sku", "standard",
        "--enable-rbac-authorization", "true",
        "--enable-soft-delete", "true",
        "--retention-days", "90",
        "--tags", $tagsNonProd[0], $tagsNonProd[1], $tagsNonProd[2], $tagsNonProd[3], $tagsNonProd[4]
    )
    
    Invoke-AzCli -Description "Creating Staging Key Vault" -Arguments @(
        "keyvault", "create",
        "--name", $Config.KeyVaults.Staging.Name,
        "--resource-group", $Config.KeyVaults.Staging.ResourceGroup,
        "--location", $Config.PrimaryRegion,
        "--sku", "standard",
        "--enable-rbac-authorization", "true",
        "--enable-soft-delete", "true",
        "--retention-days", "90",
        "--tags", $tagsNonProd[0], $tagsNonProd[1], $tagsNonProd[2], $tagsNonProd[3], $tagsNonProd[4]
    )
    
    Invoke-AzCli -Description "Setting context to Production subscription" -Arguments @(
        "account", "set", "--subscription", $Config.Subscriptions.Production
    )
    
    $tagsProd = Get-Tags -Environment "Production" -Application "SharedServices"
    
    Invoke-AzCli -Description "Creating Prod Container Registry" -Arguments @(
        "acr", "create",
        "--name", $Config.ContainerRegistry.Prod.Name,
        "--resource-group", $Config.ContainerRegistry.Prod.ResourceGroup,
        "--location", $Config.PrimaryRegion,
        "--sku", $Config.ContainerRegistry.Prod.Sku,
        "--admin-enabled", "false",
        "--tags", $tagsProd[0], $tagsProd[1], $tagsProd[2], $tagsProd[3], $tagsProd[4]
    )
    
    Invoke-AzCli -Description "Creating Prod Key Vault" -Arguments @(
        "keyvault", "create",
        "--name", $Config.KeyVaults.Prod.Name,
        "--resource-group", $Config.KeyVaults.Prod.ResourceGroup,
        "--location", $Config.PrimaryRegion,
        "--sku", "standard",
        "--enable-rbac-authorization", "true",
        "--enable-soft-delete", "true",
        "--retention-days", "90",
        "--enable-purge-protection", "true",
        "--tags", $tagsProd[0], $tagsProd[1], $tagsProd[2], $tagsProd[3], $tagsProd[4]
    )
    
    Invoke-AzCli -Description "Setting context to Management subscription" -Arguments @(
        "account", "set", "--subscription", $Config.Subscriptions.Management
    )
    
    $tagsMgmt = Get-Tags -Environment "Shared" -Application "Monitoring"
    
    Invoke-AzCli -Description "Creating Log Analytics workspace" -Arguments @(
        "monitor", "log-analytics", "workspace", "create",
        "--workspace-name", "la-pyx-platform-$($Config.PrimaryRegion)",
        "--resource-group", "rg-pyx-logging-$($Config.PrimaryRegion)",
        "--location", $Config.PrimaryRegion,
        "--retention-time", "90",
        "--sku", "PerGB2018",
        "--tags", $tagsMgmt[0], $tagsMgmt[1], $tagsMgmt[2], $tagsMgmt[3], $tagsMgmt[4]
    )
}

function Deploy-ContainerAppEnvironments {
    if (-not (Test-ShouldRunPhase "container-apps")) { return }
    
    Write-Log "SECTION" "Phase 4: Container App Environments"
    
    Invoke-AzCli -Description "Setting context to Management subscription" -Arguments @(
        "account", "set", "--subscription", $Config.Subscriptions.Management
    )
    
    $laWorkspaceId = Get-AzCliOutput -Arguments @(
        "monitor", "log-analytics", "workspace", "show",
        "--workspace-name", "la-pyx-platform-$($Config.PrimaryRegion)",
        "--resource-group", "rg-pyx-logging-$($Config.PrimaryRegion)",
        "--query", "customerId", "-o", "tsv"
    )
    
    $laWorkspaceKey = Get-AzCliOutput -Arguments @(
        "monitor", "log-analytics", "workspace", "get-shared-keys",
        "--workspace-name", "la-pyx-platform-$($Config.PrimaryRegion)",
        "--resource-group", "rg-pyx-logging-$($Config.PrimaryRegion)",
        "--query", "primarySharedKey", "-o", "tsv"
    )
    
    Invoke-AzCli -Description "Setting context to NonProduction subscription" -Arguments @(
        "account", "set", "--subscription", $Config.Subscriptions.NonProduction
    )
    
    $tagsNonProd = Get-Tags -Environment "NonProduction" -Application "ContainerApps"
    
    Invoke-AzCli -Description "Creating Dev Container App Environment" -Arguments @(
        "containerapp", "env", "create",
        "--name", "cae-pyx-dev-$($Config.PrimaryRegion)",
        "--resource-group", "rg-pyx-shared-nonprod",
        "--location", $Config.PrimaryRegion,
        "--logs-workspace-id", $laWorkspaceId,
        "--logs-workspace-key", $laWorkspaceKey,
        "--tags", $tagsNonProd[0], $tagsNonProd[1], $tagsNonProd[2], $tagsNonProd[3], $tagsNonProd[4]
    )
    
    Invoke-AzCli -Description "Creating Staging Container App Environment" -Arguments @(
        "containerapp", "env", "create",
        "--name", "cae-pyx-staging-$($Config.PrimaryRegion)",
        "--resource-group", "rg-pyx-shared-nonprod",
        "--location", $Config.PrimaryRegion,
        "--logs-workspace-id", $laWorkspaceId,
        "--logs-workspace-key", $laWorkspaceKey,
        "--tags", $tagsNonProd[0], $tagsNonProd[1], $tagsNonProd[2], $tagsNonProd[3], $tagsNonProd[4]
    )
    
    Invoke-AzCli -Description "Setting context to Production subscription" -Arguments @(
        "account", "set", "--subscription", $Config.Subscriptions.Production
    )
    
    $tagsProd = Get-Tags -Environment "Production" -Application "ContainerApps"
    
    Invoke-AzCli -Description "Creating Production Container App Environment" -Arguments @(
        "containerapp", "env", "create",
        "--name", "cae-pyx-prod-$($Config.PrimaryRegion)",
        "--resource-group", "rg-pyx-shared-prod",
        "--location", $Config.PrimaryRegion,
        "--logs-workspace-id", $laWorkspaceId,
        "--logs-workspace-key", $laWorkspaceKey,
        "--internal-only", "true",
        "--tags", $tagsProd[0], $tagsProd[1], $tagsProd[2], $tagsProd[3], $tagsProd[4]
    )
}

function Deploy-AzureDevOps {
    if (-not (Test-ShouldRunPhase "devops")) { return }
    if ($Config.DevOps.PAT -match "^<") {
        Write-Log "WARN" "Skipping DevOps setup - PAT not configured"
        return
    }
    
    Write-Log "SECTION" "Phase 5: Azure DevOps"
    
    $env:AZURE_DEVOPS_EXT_PAT = $Config.DevOps.PAT
    
    Invoke-AzCli -Description "Configuring Azure DevOps defaults" -Arguments @(
        "devops", "configure", "--defaults",
        "organization=$($Config.DevOps.OrganizationUrl)"
    )
    
    foreach ($project in $Config.DevOps.Projects) {
        Invoke-AzCli -Description "Creating project: $($project.Name)" -Arguments @(
            "devops", "project", "create",
            "--name", $project.Name,
            "--description", $project.Description,
            "--visibility", "private",
            "--source-control", "git",
            "--process", "Agile"
        )
    }
}

function Start-Migration {
    if (-not (Test-ShouldRunPhase "migrate")) { return }
    
    Write-Log "SECTION" "Phase 6: Migration"
    
    Write-Host ""
    Write-Host "GitHub Repositories to migrate:" -ForegroundColor White
    foreach ($repo in $Config.OldGitHub.Repositories) {
        Write-Host "  - $repo" -ForegroundColor Cyan
    }
    Write-Host ""
    Write-Host "Azure DevOps Pipelines to migrate:" -ForegroundColor White
    foreach ($pipeline in $Config.OldDevOps.Pipelines) {
        Write-Host "  - $pipeline" -ForegroundColor Cyan
    }
    Write-Host ""
    
    $migrationScript = @"
#!/bin/bash
GITHUB_ORG="TechModGroup"
REPOS=(
$(foreach ($repo in $Config.OldGitHub.Repositories) { "    `"$repo`"" } | Out-String)
)
DEVOPS_ORG="$($Config.DevOps.OrganizationUrl)"

for repo in "`${REPOS[@]}"; do
    echo "Migrating `$repo..."
    git clone "https://github.com/`$GITHUB_ORG/`$repo.git"
    cd "`$repo"
    git remote add azure "`$DEVOPS_ORG/Applications/_git/`$repo"
    git push azure --all
    git push azure --tags
    cd ..
    echo "`$repo migration complete"
done
echo "All repositories migrated"
"@
    
    $migrationScriptPath = Join-Path $PSScriptRoot "migrate-repos.sh"
    $migrationScript | Out-File -FilePath $migrationScriptPath -Encoding UTF8 -Force
    Write-Log "SUCCESS" "Migration script generated: $migrationScriptPath"
}

function Write-Summary {
    Write-Log "SECTION" "Deployment Summary"
    
    Write-Host ""
    Write-Host "Company:        $($Config.CompanyFullName)" -ForegroundColor Cyan
    Write-Host "Phase:          $Phase" -ForegroundColor Cyan
    Write-Host "Dry Run:        $DryRun" -ForegroundColor Cyan
    Write-Host "Region:         $($Config.PrimaryRegion)" -ForegroundColor Cyan
    Write-Host "Errors:         $($script:Errors)" -ForegroundColor $(if ($script:Errors -gt 0) { "Red" } else { "Green" })
    Write-Host "Warnings:       $($script:Warnings)" -ForegroundColor Yellow
    Write-Host "Log File:       $LogFile" -ForegroundColor Cyan
    Write-Host ""
}

Write-Host ""
Write-Host "Enterprise Azure DevOps Deployment" -ForegroundColor Green
Write-Host "Client: $($Config.CompanyFullName)" -ForegroundColor Green
Write-Host ""

if ($DryRun) { Write-Log "WARN" "DRY-RUN mode enabled - no changes will be made" }

Test-Configuration
Invoke-PreflightChecks
Deploy-Foundation
Deploy-Networking
Deploy-SharedServices
Deploy-ContainerAppEnvironments
Deploy-AzureDevOps
Start-Migration
Write-Summary

if ($script:Errors -gt 0) {
    Write-Log "WARN" "Deployment completed with $($script:Errors) error(s)"
    exit 1
}
else {
    Write-Log "SUCCESS" "Deployment completed successfully"
    exit 0
}
