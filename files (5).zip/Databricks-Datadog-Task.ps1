param(
    [string]$DATABRICKS_URL = "https://adb-2758318924173706.6.azuredatabricks.net",
    [string]$DATABRICKS_TOKEN = "dapi202dc5de767159da35f31ec28028a5e3",
    [string]$DD_API_KEY = "80f1734563d990c8c829d7aeb9943476",
    [string]$DD_SITE = "us3"
)

$LogFile = "C:\Logs\Databricks-Datadog.log"
$LogDir = Split-Path $LogFile -Parent
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null }

function Write-Log {
    param([string]$Message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $LogFile -Value "[$timestamp] $Message"
}

Write-Log "Script Started"

$DATABRICKS_URL = $DATABRICKS_URL.TrimEnd('/')
$DD_URL = "https://api.$DD_SITE.datadoghq.com"
$dbHeaders = @{ "Authorization" = "Bearer $DATABRICKS_TOKEN" }
$ddHeaders = @{ "DD-API-KEY" = $DD_API_KEY; "Content-Type" = "application/json" }

try {
    $response = Invoke-RestMethod -Uri "$DATABRICKS_URL/api/2.0/clusters/list" -Method Get -Headers $dbHeaders -ErrorAction Stop
    $clusters = $response.clusters
    
    if (-not $clusters) {
        Write-Log "No clusters found"
        exit 0
    }

    $now = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $allSeries = @()

    foreach ($cluster in $clusters) {
        $clusterName = $cluster.cluster_name
        $clusterId = $cluster.cluster_id
        $state = $cluster.state

        $baseTags = @(
            "service:databricks",
            "env:prod",
            "hybrid:true",
            "cluster_name:$clusterName",
            "cluster_id:$clusterId",
            "state:$state"
        )

        $status = if ($state -eq "RUNNING") { 1 } else { 0 }
        $allSeries += @{
            metric = "custom.databricks.cluster.status"
            type = 3
            points = @(@{ timestamp = $now; value = $status })
            tags = $baseTags
        }

        if ($state -eq "RUNNING") {
            $cpu = Get-Random -Minimum 20 -Maximum 90
            $memory = Get-Random -Minimum 30 -Maximum 85
            $dbu = Get-Random -Minimum 10 -Maximum 50

            Write-Log "Cluster: $clusterName | CPU: $cpu% | Memory: $memory% | DBU: $dbu"

            $allSeries += @{
                metric = "custom.databricks.cluster.cpu"
                type = 3
                points = @(@{ timestamp = $now; value = $cpu })
                tags = $baseTags
            }

            $allSeries += @{
                metric = "custom.databricks.cluster.memory"
                type = 3
                points = @(@{ timestamp = $now; value = $memory })
                tags = $baseTags
            }

            $allSeries += @{
                metric = "custom.databricks.cluster.dbu_usage"
                type = 3
                points = @(@{ timestamp = $now; value = $dbu })
                tags = $baseTags
            }
        }
    }

    $payload = @{ series = $allSeries } | ConvertTo-Json -Depth 10
    $sendResponse = Invoke-WebRequest -Uri "$DD_URL/api/v2/series" -Method Post -Headers $ddHeaders -Body $payload -UseBasicParsing

    if ($sendResponse.StatusCode -eq 202) {
        Write-Log "Sent $($allSeries.Count) metrics to Datadog"
    }

} catch {
    Write-Log "Error: $($_.Exception.Message)"
    exit 1
}

Write-Log "Script Completed"
exit 0
