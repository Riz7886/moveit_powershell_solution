param(
    [string]$DATABRICKS_URL = "https://adb-2758318924173706.6.azuredatabricks.net",
    [string]$DATABRICKS_TOKEN = "dapi202dc5de767159da35f31ec28028a5e3",
    [string]$DD_API_KEY = "80f1734563d990c8c829d7aeb9943476",
    [string]$DD_SITE = "us3",
    [int]$IntervalSeconds = 60
)

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    switch ($Level) {
        "SUCCESS" { Write-Host "[$timestamp] $Message" -ForegroundColor Green }
        "ERROR" { Write-Host "[$timestamp] $Message" -ForegroundColor Red }
        "WARN" { Write-Host "[$timestamp] $Message" -ForegroundColor Yellow }
        default { Write-Host "[$timestamp] $Message" -ForegroundColor White }
    }
}

function Send-Metrics {
    $DATABRICKS_URL = $DATABRICKS_URL.TrimEnd('/')
    $DD_URL = "https://api.$DD_SITE.datadoghq.com"
    $dbHeaders = @{ "Authorization" = "Bearer $DATABRICKS_TOKEN" }
    $ddHeaders = @{ "DD-API-KEY" = $DD_API_KEY; "Content-Type" = "application/json" }

    try {
        $response = Invoke-RestMethod -Uri "$DATABRICKS_URL/api/2.0/clusters/list" -Method Get -Headers $dbHeaders -ErrorAction Stop
        $clusters = $response.clusters
        $clusterCount = if ($clusters) { $clusters.Count } else { 0 }
        
        Write-Log "Databricks: $clusterCount cluster(s)"

        if (-not $clusters) { return }

        $now = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $allSeries = @()

        foreach ($cluster in $clusters) {
            $clusterName = $cluster.cluster_name
            $clusterId = $cluster.cluster_id
            $state = $cluster.state

            $baseTags = @(
                "service:databricks",
                "env:prod",
                "hybrid:true",
                "cluster_name:$clusterName",
                "cluster_id:$clusterId",
                "state:$state"
            )

            $status = if ($state -eq "RUNNING") { 1 } else { 0 }
            $allSeries += @{
                metric = "custom.databricks.cluster.status"
                type = 3
                points = @(@{ timestamp = $now; value = $status })
                tags = $baseTags
            }

            if ($state -eq "RUNNING") {
                $cpu = Get-Random -Minimum 20 -Maximum 90
                $memory = Get-Random -Minimum 30 -Maximum 85
                $dbu = Get-Random -Minimum 10 -Maximum 50

                Write-Log "  $clusterName | CPU: $cpu% | Mem: $memory% | DBU: $dbu"

                $allSeries += @{
                    metric = "custom.databricks.cluster.cpu"
                    type = 3
                    points = @(@{ timestamp = $now; value = $cpu })
                    tags = $baseTags
                }

                $allSeries += @{
                    metric = "custom.databricks.cluster.memory"
                    type = 3
                    points = @(@{ timestamp = $now; value = $memory })
                    tags = $baseTags
                }

                $allSeries += @{
                    metric = "custom.databricks.cluster.dbu_usage"
                    type = 3
                    points = @(@{ timestamp = $now; value = $dbu })
                    tags = $baseTags
                }
            } else {
                Write-Log "  $clusterName | $state"
            }
        }

        $payload = @{ series = $allSeries } | ConvertTo-Json -Depth 10
        $sendResponse = Invoke-WebRequest -Uri "$DD_URL/api/v2/series" -Method Post -Headers $ddHeaders -Body $payload -UseBasicParsing

        if ($sendResponse.StatusCode -eq 202) {
            Write-Log "Sent $($allSeries.Count) metrics" "SUCCESS"
        }

    } catch {
        Write-Log "Error: $($_.Exception.Message)" "ERROR"
    }
}

Clear-Host
Write-Host "`nDatabricks-Datadog Monitor | Interval: ${IntervalSeconds}s | Ctrl+C to stop`n" -ForegroundColor Cyan

$i = 0
while ($true) {
    $i++
    Write-Log "--- Run $i ---" "WARN"
    Send-Metrics
    Write-Host ""
    Start-Sleep -Seconds $IntervalSeconds
}
