# Azure Infrastructure Deployment Script

**Author:** Syed Rizvi

## What This Script Deploys

This single script provisions the entire Azure infrastructure in one shot:

| # | Resource | Details |
|---|----------|---------|
| 1 | **Resource Groups** | `rg-aics-dev`, `rg-aics-staging`, `rg-aics-prod`, `rg-shared-nonprod`, `rg-shared-prod` |
| 2 | **Log Analytics** | `la-aics-nonprod`, `la-aics-prod` (90-day retention) |
| 3 | **Container Registries** | `acraicsnonprod` (dev+staging), `acraicsprod` (prod only) |
| 4 | **Key Vaults** | `kv-aics-dev`, `kv-aics-staging`, `kv-aics-prod` — RBAC mode, soft-delete, purge protection |
| 5 | **Container App Environments** | One per environment, connected to Log Analytics |
| 6 | **Container Apps** | With system-assigned managed identity enabled |
| 7 | **RBAC Assignments** | AcrPull + Key Vault Secrets User per Container App |
| 8 | **Azure Policies** | Require HTTPS, require tags, deny public IPs (prod), allowed locations |
| 9 | **Key Vault References** | Placeholder secrets linked to Container Apps |

## Prerequisites

```bash
# 1. Install Azure CLI
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

# 2. Login
az login

# 3. Verify access
az account list -o table
```

## Configuration

Open the script and update the **CONFIGURATION** section at the top:

```bash
SUB_SANDBOX_ID="<your-sandbox-subscription-id>"
SUB_NONPROD_ID="<your-nonprod-subscription-id>"
SUB_PROD_ID="<your-prod-subscription-id>"
```

## Usage

```bash
# Make executable
chmod +x deploy-azure-infrastructure.sh

# Dry run first (no changes made, just shows what would happen)
./deploy-azure-infrastructure.sh --dry-run

# Deploy everything
./deploy-azure-infrastructure.sh

# Deploy only dev environment
./deploy-azure-infrastructure.sh --env dev

# Deploy only prod
./deploy-azure-infrastructure.sh --env prod
```

## Post-Deployment Steps

1. **Update Key Vault secrets** with real connection strings and API keys
2. **Push container images** to ACR: `az acr build --registry acraicsnonprod --image aics-api:dev-v1.0 .`
3. **Update Container App** to use your image: `az containerapp update --name aics-api-app-dev --image acraicsnonprod.azurecr.io/aics-api:dev-v1.0`
4. **Set up CI/CD** with GitHub Actions
5. **Import images to prod ACR**: `az acr import --name acraicsprod --source acraicsnonprod.azurecr.io/aics-api:v1.0`

## Architecture Diagram

```
sub-nonprod/
├── rg-aics-dev/
│   ├── Container App Environment (aics-env-dev)
│   ├── Container App (aics-api-app-dev) ← managed identity
│   └── Key Vault (kv-aics-dev)
├── rg-aics-staging/
│   ├── Container App Environment (aics-env-staging)
│   ├── Container App (aics-api-app-staging) ← managed identity
│   └── Key Vault (kv-aics-staging)
└── rg-shared-nonprod/
    ├── ACR (acraicsnonprod)
    └── Log Analytics (la-aics-nonprod)

sub-prod/
├── rg-aics-prod/
│   ├── Container App Environment (aics-env-prod)
│   ├── Container App (aics-api-app-prod) ← managed identity
│   └── Key Vault (kv-aics-prod)
└── rg-shared-prod/
    ├── ACR (acraicsprod)
    └── Log Analytics (la-aics-prod)
```
