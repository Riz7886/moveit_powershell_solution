# Enterprise Azure DevOps Platform
## Complete Deployment Package

Date: February 2026
Version: 1.0

---

## Package Contents

```
devops-enterprise/
    Enterprise-DevOps-Governance-Policy.md   Complete governance documentation
    Deploy-Enterprise-DevOps.ps1             Main deployment automation
    container-app-deploy.yml                 CI CD pipeline template
    README.md                                This file
```

---

## What This Package Delivers

### 1. Governance and Policy Documentation
- Resource Group scope policies
- Container Registry scope decision per environment
- Key Vault management strategy per environment single source of truth
- Infrastructure planning structure
- Approval workflows with timeout policies
- Change ticket requirements for production
- Business hours deployment windows
- Complete RBAC matrix

### 2. Deployment Automation
Fully automated deployment of:
- Management Groups and Subscriptions
- Hub Spoke networking with Azure Firewall
- Container Registries NonProd and Prod
- Key Vaults Dev Staging Prod
- Log Analytics workspace
- Container App Environments Dev Staging Prod
- Azure DevOps organization projects and environments

### 3. CI CD Pipeline Templates
- Multi environment deployment Dev to Staging to Production
- Security scanning Trivy Gitleaks
- Blue green deployments with automatic rollback
- Change ticket validation for production
- Approval gates at each stage

---

## Quick Start

### Step 1: Configure

Edit Deploy-Enterprise-DevOps.ps1 and update:

```powershell
$Config = @{
    TenantId             = "<your-tenant-id>"
    Subscriptions        = @{
        Management       = "<management-subscription-id>"
        Connectivity     = "<connectivity-subscription-id>"
        Production       = "<production-subscription-id>"
        NonProduction    = "<nonprod-subscription-id>"
    }
    DevOps = @{
        PAT              = "<your-pat-token>"
    }
}
```

### Step 2: Deploy

```powershell
# Preview no changes
.\Deploy-Enterprise-DevOps.ps1 -DryRun

# Deploy everything
.\Deploy-Enterprise-DevOps.ps1 -Phase all

# Deploy in phases
.\Deploy-Enterprise-DevOps.ps1 -Phase foundation       # Resource groups
.\Deploy-Enterprise-DevOps.ps1 -Phase networking       # Hub Spoke VNets
.\Deploy-Enterprise-DevOps.ps1 -Phase shared-services  # ACR Key Vault Log Analytics
.\Deploy-Enterprise-DevOps.ps1 -Phase container-apps   # Container App Environments
.\Deploy-Enterprise-DevOps.ps1 -Phase devops           # Azure DevOps setup
.\Deploy-Enterprise-DevOps.ps1 -Phase migrate          # Migration helper
```

### Step 3: Configure Approvals

After deployment configure environment approvals in Azure DevOps:

1. Navigate to Project Settings then Pipelines then Environments
2. Select each environment dev staging production
3. Click Approvals and checks
4. Add approvers per the governance document

---

## Key Decision Points

### 1. Resource Group Scope
Decision: Environment based naming with rg-{app}-{env}-{region} pattern
- Enables policy targeting by environment
- Clear cost allocation
- Resource isolation

### 2. Container Registry Scope
Decision: One ACR per environment NonProd and Prod
- acrpyxnonprod for Dev Staging
- acrpyxprod for Production only
- Image promotion via az acr import

### 3. Key Vault Scope
Decision: One Key Vault per environment as single source of truth
- kv-pyx-dev for Dev secrets
- kv-pyx-staging for Staging secrets
- kv-pyx-prod for Production secrets with purge protection enabled

### 4. Permissions: Managed Identity vs Service Principal
Decision: Workload Identity Federation Managed Identity
- No secrets to manage
- Automatic rotation
- Native Azure AD integration
- Zero credential rotation maintenance

---

## Approval Matrix

| Environment | Approvers | Timeout | Change Ticket |
|-------------|-----------|---------|---------------|
| Sandbox | Auto approve | n/a | No |
| Dev | Team Lead | 24h | No |
| Staging | Team Lead and QA | 48h | No |
| Production | Release Manager and Director | 72h | YES |

---

## Production Deployment Windows

| Day | Window | Notes |
|-----|--------|-------|
| Monday to Thursday | 6 AM to 10 PM CST | Standard |
| Friday | 6 AM to 4 PM CST | Early cutoff |
| Saturday to Sunday | BLOCKED | No deployments |

---

## CI CD Pipeline Usage

### Use the Template

```yaml
# azure-pipelines.yml
trigger:
  - main

extends:
  template: templates/container-app-deploy.yml@Infrastructure
  parameters:
    appName: pyx-api
    dockerfilePath: src/Dockerfile
    runTests: true
    deployToProd: true
    changeTicket: CHG012345
```

---

## Architecture Overview

Azure DevOps Organization
  Infrastructure Project
  Platform Project
  Apps Project
  AI-ML Project
  Security Project

Service Connections using Workload Identity Federation No Secrets

NonProd Subscription
  ACR nonprod
  KV Dev
  KV Staging
  CAE Dev
  CAE Staging

Prod Subscription
  ACR prod
  KV Prod
  CAE Prod internal only

Connectivity Subscription
  Hub VNet
  Firewall
  Bastion

---

## Document History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | Feb 2026 | Initial release |
