# Enterprise Azure DevOps Platform
# Governance Policies and Deployment Guide

Document Version: 1.0
Classification: Confidential
Date: February 2026

---

# Table of Contents

1. Executive Summary
2. Current State Assessment
3. Target Architecture
4. Subscription and Management Group Strategy
5. Azure DevOps Organization Design
6. Identity and Access Management
7. Security Policies and Compliance
8. Pipeline Governance and Approval Workflows
9. Change Management Process
10. Network Security and Connectivity
11. Monitoring and Logging
12. Migration Plan
13. AI ML Workload Migration
14. Resource Group Scope Policies
15. Container Registry Scope Decision
16. Key Vault Management Strategy
17. Container Apps CI CD Pipeline

---

# 1. Executive Summary

## 1.1 Purpose

This document provides the complete blueprint for building a new enterprise grade Azure DevOps environment with locked down security from day one, governance policies enforced at every level, approval workflows for all deployments, change management procedures aligned with ITIL best practices, and migration path from existing TechModGroup environment without breaking current workloads.

## 1.2 Key Decisions

| Decision Area | Recommendation | Rationale |
|---------------|----------------|-----------|
| Identity for Pipelines | Workload Identity Federation using Managed Identity | No secrets to manage and automatic rotation |
| Service Principal vs Managed Identity | Managed Identity with Federated Credentials | More secure than service principal with secret |
| Terraform State | Azure Storage Account with RBAC | State encryption and locking with audit trail |
| Approval Gates | Azure DevOps Environments with ServiceNow | Multi stage approvals with ITSM integration |
| Policy Enforcement | Azure Policy with DevOps Branch Policies | Shift left security to prevent non compliant deployments |

## 1.3 Scope

In Scope:
- New Azure subscriptions and management groups
- New Azure DevOps organization with projects
- Landing Zone deployment with Hub Spoke networking
- CI CD pipeline templates with security controls
- Migration of existing pipelines from TechModGroup
- AI ML workload migration for drivers health ai
- Governance policies and procedures

Out of Scope:
- Application code refactoring
- Database schema changes
- Third party tool licensing

---

# 2. Current State Assessment

## 2.1 Existing Environment TechModGroup

GitHub Repositories in TechModGroup Organization:

| Repository | Purpose | Status |
|------------|---------|--------|
| PyxWeb | Web application | Active |
| drivers-health-api | API backend | Active |
| drivers-health-ai | AI ML workloads | Active and needs migration |
| TargetPopulationIntegration | Integration services | Active |
| fra-netsuite-scripts | NetSuite automation | Active |
| fra-order-portal | Order management | Active |
| Internal-automation-tools | Internal tooling | Active |

Azure DevOps in techmodgroup Pyx.DriversHealth:

| Pipeline | Stages | Status |
|----------|--------|--------|
| hi pyx API | Sandbox to Staging to Prod | Active |

## 2.2 Issues with Current State

| Issue | Risk Level | Impact |
|-------|------------|--------|
| No formal approval process | HIGH | Unauthorized deployments possible |
| Service connections use secrets | MEDIUM | Secret rotation required and leak risk |
| No change ticket requirement | HIGH | No audit trail for changes |
| Single DevOps organization | MEDIUM | No separation of concerns |
| Terraform commented out | HIGH | Manual infrastructure drift |
| No branch protection | HIGH | Direct commits to main possible |

---

# 3. Target Architecture

## 3.1 Management Group Structure

Root Management Group Tenant Root
  mg-pyx-platform Platform
    mg-pyx-management leads to Management Subscription
    mg-pyx-connectivity leads to Connectivity Subscription
    mg-pyx-identity leads to Identity Subscription
  mg-pyx-landing-zones Workloads
    mg-pyx-production leads to Production Subscriptions
    mg-pyx-non-production leads to Dev Test Subscriptions
    mg-pyx-sandbox leads to Sandbox Subscriptions
  mg-pyx-decommissioned for Retired resources

## 3.2 Network Architecture Hub Spoke

Connectivity Subscription contains Hub VNet 10.0.0.0/16 with:
- GatewaySubnet 10.0.0.0/27 for ExpressRoute or VPN Gateway
- AzureFirewallSubnet 10.0.1.0/26 for Azure Firewall
- AzureBastionSubnet 10.0.2.0/27 for Azure Bastion
- SharedServicesSubnet 10.0.3.0/24 for Jump boxes and DNS

Production Spoke 10.1.0.0/16 with AKS Subnet, App Subnet, DB Subnet, Private Endpoints
NonProd Spoke 10.2.0.0/16 with AKS Subnet, App Subnet, DB Subnet, Private Endpoints
AI ML Spoke 10.3.0.0/16 with Databricks subnets, AML Compute, Private Endpoints

All spokes connect to Hub via VNet Peering

---

# 4. Subscription and Management Group Strategy

## 4.1 Subscription Design

| Subscription | Purpose | Management Group | Budget |
|--------------|---------|------------------|--------|
| sub-pyx-management | Log Analytics and Automation and Monitoring | mg-pyx-management | 5000 per month |
| sub-pyx-identity | Azure AD DS and Key Vaults for identity | mg-pyx-identity | 2000 per month |
| sub-pyx-connectivity | Hub VNet and Firewall and Gateways | mg-pyx-connectivity | 8000 per month |
| sub-pyx-prod-01 | Production workloads | mg-pyx-production | 25000 per month |
| sub-pyx-nonprod-01 | Dev and Staging and QA | mg-pyx-non-production | 10000 per month |
| sub-pyx-sandbox-01 | Experimentation | mg-pyx-sandbox | 3000 per month |
| sub-pyx-aiml-01 | AI ML workloads | mg-pyx-production | 15000 per month |

## 4.2 Tagging Strategy Required on ALL Resources

| Tag Name | Required | Purpose | Example Values |
|----------|----------|---------|----------------|
| Environment | Yes | Identify environment | Production or Staging or Development or Sandbox |
| CostCenter | Yes | Cost allocation | Engineering or Operations or Security |
| Owner | Yes | Responsible party | team email address |
| Application | Yes | Application name | drivers-health-api or pyx-web |
| DataClassification | Yes | Data sensitivity | Public or Internal or Confidential or Restricted |
| CreatedBy | Yes | Creator identity | Terraform or Manual or Pipeline |
| ChangeTicket | Conditional | ITSM ticket number | CHG0012345 |

---

# 5. Azure DevOps Organization Design

## 5.1 Organization Structure

Organization: pyx-enterprise NEW

Project: Infrastructure
  Repo: terraform-modules for shared modules
  Repo: landing-zone-deployment
  Repo: policy-definitions
  Pipelines: deploy-management-subscription, deploy-connectivity-subscription, deploy-landing-zone, apply-azure-policies

Project: Platform
  Repo: aks-platform
  Repo: container-apps-platform
  Repo: avs-platform
  Pipelines: deploy-aks-cluster, deploy-container-apps, deploy-avs

Project: Applications
  Repo: drivers-health-api migrated
  Repo: pyx-web migrated
  Repo: order-portal migrated
  Pipelines: ci-drivers-health-api, cd-drivers-health-api, ci-cd-pyx-web

Project: AI-ML
  Repo: drivers-health-ai migrated
  Repo: ml-pipelines
  Pipelines: train-ml-model, deploy-ml-endpoint, databricks-jobs

Project: Security
  Repo: security-scanning
  Repo: compliance-policies
  Pipelines: security-scan-all-repos, compliance-audit, secret-rotation

## 5.2 Project Permissions Matrix

| Role | Infrastructure | Platform | Applications | AI-ML | Security |
|------|---------------|----------|--------------|-------|----------|
| Platform Admins | Contributor | Contributor | Reader | Reader | Contributor |
| Developers | Reader | Reader | Contributor | Contributor | Reader |
| QA Engineers | Reader | Reader | Contributor | Reader | Reader |
| Security Team | Reader | Reader | Reader | Reader | Contributor |
| Release Managers | Reader | Contributor | Contributor | Contributor | Reader |

---

# 6. Identity and Access Management

## 6.1 Managed Identity vs Service Principal Decision

RECOMMENDED: Workload Identity Federation using Managed Identity

| Aspect | Managed Identity | Service Principal with Secret |
|--------|-----------------|---------------------------|
| Secret Management | None required | Must rotate secrets |
| Security Risk | Lower | Higher due to secret exposure |
| Audit Trail | Automatic | Manual tracking needed |
| Azure AD Integration | Native | Requires app registration |
| Pipeline Configuration | OIDC federation | Client ID plus Secret |
| Maintenance | Zero | Regular rotation required |

## 6.2 Service Connection Configuration

| Service Connection | Type | Scope | Used By |
|--------------------|------|-------|---------|
| sc-pyx-management | Workload Identity | sub-pyx-management | Infrastructure project |
| sc-pyx-connectivity | Workload Identity | sub-pyx-connectivity | Infrastructure project |
| sc-pyx-prod | Workload Identity | sub-pyx-prod-01 | Applications project |
| sc-pyx-nonprod | Workload Identity | sub-pyx-nonprod-01 | Applications project |
| sc-pyx-aiml | Workload Identity | sub-pyx-aiml-01 | AI-ML project |

## 6.3 RBAC Assignments

| Identity | Scope | Role | Purpose |
|----------|-------|------|---------|
| mi-devops-infra | mg-pyx-platform | Contributor | Deploy platform resources |
| mi-devops-infra | mg-pyx-platform | User Access Administrator | Manage RBAC |
| mi-devops-apps | sub-pyx-prod-01 | Contributor | Deploy applications |
| mi-devops-apps | sub-pyx-prod-01 | AcrPush | Push container images |
| mi-devops-aiml | sub-pyx-aiml-01 | Contributor | Deploy AI ML resources |
| mi-devops-aiml | sub-pyx-aiml-01 | Databricks Contributor | Manage Databricks |

---

# 7. Security Policies and Compliance

## 7.1 Azure Policy Assignments

Subscription Level Policies Required:

| Policy | Effect | Scope | Purpose |
|--------|--------|-------|---------|
| Require tag on resources | Deny | All subscriptions | Enforce tagging |
| Allowed locations | Deny | All subscriptions | Limit to approved regions |
| Require HTTPS on storage | Deny | All subscriptions | Encryption in transit |
| Audit VMs without managed disks | Audit | All subscriptions | Security compliance |
| Deploy Defender for Cloud | DeployIfNotExists | All subscriptions | Threat protection |
| Require NSG on subnets | Deny | All subscriptions | Network security |

Production Specific Policies:

| Policy | Effect | Scope | Purpose |
|--------|--------|-------|---------|
| Deny public IP | Deny | mg-pyx-production | No public exposure |
| Require private endpoints | Deny | mg-pyx-production | Secure connectivity |
| Deny Basic SKU load balancers | Deny | mg-pyx-production | Force Standard SKU |
| Require TLS 1.2 minimum | Deny | mg-pyx-production | Secure protocols |
| Require diagnostic settings | DeployIfNotExists | mg-pyx-production | Logging compliance |

## 7.2 Azure DevOps Policies

Branch Policies Enforced on ALL Repos:

| Policy | Setting | Purpose |
|--------|---------|---------|
| Require pull request | Enabled | No direct commits to main or master |
| Minimum reviewers | 2 | Peer review requirement |
| Build validation | Required | CI must pass before merge |
| Linked work items | Required | Traceability |
| Comment resolution | Required | All comments addressed |
| Merge strategy | Squash | Clean commit history |

Pipeline Policies:

| Policy | Setting | Purpose |
|--------|---------|---------|
| Require approval | Enabled | Human gate before deployment |
| Approval timeout | 72 hours | Prevent stale approvals |
| Exclusive lock | Enabled | One deployment at a time |
| Environment checks | Required | Validate before deploy |

---

# 8. Pipeline Governance and Approval Workflows

## 8.1 Environment Definitions

| Environment | Approvers | Approval Timeout | Business Hours Only |
|-------------|-----------|------------------|---------------------|
| Sandbox | Auto approve | Not applicable | No |
| Development | Team Lead 1 person | 24 hours | No |
| Staging | Team Lead plus QA 2 people | 48 hours | No |
| Production | Release Manager plus Director 2 people | 72 hours | Yes see section 8.4 |

## 8.2 Approval Matrix

DEPLOYMENT APPROVAL MATRIX

Code Change Type and corresponding approvals:

Bug Fix Minor:
- Sandbox: Auto
- Dev: Team Lead
- Staging: Team Lead plus QA
- Production: Release Manager plus Change Ticket

Feature Standard:
- Sandbox: Auto
- Dev: Team Lead
- Staging: Team Lead plus QA
- Production: Release Manager plus Director plus Ticket

Infrastructure Change:
- Sandbox: Team Lead
- Dev: Team Lead
- Staging: Team Lead plus Security
- Production: Release Manager plus Director plus CAB

Security Patch:
- Sandbox: Auto
- Dev: Team Lead
- Staging: Team Lead plus Security
- Production: Release Manager plus Security plus Emergency

Database Migration:
- Sandbox: Team Lead
- Dev: Team Lead
- Staging: Team Lead plus DBA
- Production: Release Manager plus DBA plus Director plus CAB

AI ML Model Update:
- Sandbox: Auto
- Dev: Team Lead
- Staging: Team Lead plus Data Scientist
- Production: Release Manager plus Data Scientist plus Director plus Ticket

Legend:
- TL means Team Lead
- RM means Release Manager
- QA means QA Engineer
- Sec means Security Team
- Dir means Director
- DBA means Database Administrator
- DS means Data Scientist
- CAB means Change Advisory Board
- Ticket means Change Ticket Required

## 8.4 Business Hours Deployment Policy

Production Deployment Windows:

| Day | Allowed Window | Timezone | Notes |
|-----|---------------|----------|-------|
| Monday | 6:00 AM to 10:00 PM | CST | Standard window |
| Tuesday | 6:00 AM to 10:00 PM | CST | Standard window |
| Wednesday | 6:00 AM to 10:00 PM | CST | Standard window |
| Thursday | 6:00 AM to 10:00 PM | CST | Standard window |
| Friday | 6:00 AM to 4:00 PM | CST | Early cutoff |
| Saturday | BLOCKED | n/a | No deployments |
| Sunday | BLOCKED | n/a | No deployments |

Exceptions for Emergency Changes:
1. Security patches require Security Director approval
2. Critical bug fixes require VP approval plus post mortem
3. Compliance deadlines require CAB approval 24 hours in advance

---

# 9. Change Management Process

## 9.1 Change Types

| Change Type | Risk Level | Approval | Lead Time | Rollback Plan |
|-------------|------------|----------|-----------|---------------|
| Standard | Low | Pre approved | 24 hours | Required |
| Normal | Medium | CAB | 5 business days | Required |
| Emergency | High | Emergency CAB | Immediate | Required |
| Major | Critical | Executive plus CAB | 10 business days | Required plus DR Test |

## 9.2 Change Ticket Requirements

Every production deployment MUST have:

| Field | Required | Description |
|-------|----------|-------------|
| Change ID | Yes | Auto generated CHG followed by 6 digits |
| Title | Yes | Brief description of change |
| Description | Yes | Detailed change description |
| Business Justification | Yes | Why this change is needed |
| Risk Assessment | Yes | Low or Medium or High plus explanation |
| Test Plan | Yes | How the change was tested |
| Rollback Plan | Yes | Steps to revert if failed |
| Deployment Steps | Yes | Exact steps to implement |
| Affected Systems | Yes | List of impacted systems |
| Scheduled Window | Yes | Start and end time |
| Change Owner | Yes | Person responsible |
| Approvers | Yes | List of approvers |
| Communication Plan | Yes | Who to notify |

---

# 14. Resource Group Scope Policies

## 14.1 Decision: Environment Based Resource Group Strategy

RECOMMENDED PATTERN: rg-{application}-{environment}-{region}

Example Structure:
- rg-pyx-api-dev-eastus2
- rg-pyx-api-staging-eastus2
- rg-pyx-api-prod-eastus2
- rg-pyx-web-dev-eastus2
- rg-pyx-web-staging-eastus2
- rg-pyx-web-prod-eastus2

SHARED RESOURCES per environment:
- rg-pyx-shared-dev-eastus2 contains shared ACR and shared Key Vault
- rg-pyx-shared-staging-eastus2
- rg-pyx-shared-prod-eastus2

## 14.2 Resource Group Policies

| Policy | Scope | Effect | Purpose |
|--------|-------|--------|---------|
| Enforce naming convention | All RGs | Deny | Consistent naming |
| Require Environment tag | All RGs | Deny | Cost allocation and policy targeting |
| Require Owner tag | All RGs | Deny | Accountability |
| Require Application tag | All RGs | Deny | Resource grouping |
| Lock production RGs | Prod RGs | CanNotDelete | Prevent accidental deletion |
| Restrict resource types | Sandbox RGs | Deny | Cost control |

---

# 15. Container Registry Scope Decision

## 15.1 RECOMMENDED: One ACR Per Environment NOT Per Resource Group

| Option | Pros | Cons | Recommendation |
|--------|------|------|----------------|
| Per Resource Group | Isolation | Duplication and complex image sharing and higher cost | Not Recommended |
| Per Environment | Simplified sharing and cost efficient and single source | Cross app access needed | Recommended |
| Per Subscription | Maximum sharing | Too broad and security concerns | Not Recommended |

## 15.2 Container Registry Architecture

NON-PRODUCTION for Sandbox plus Dev plus Staging:
  acrpyxnonprod.azurecr.io
    pyx-api:dev-v1.0.0
    pyx-api:staging-v1.0.0
    pyx-web:dev-v1.0.0
    pyx-web:staging-v1.0.0
    drivers-health-ai:dev-v1.0.0
  SKU: Standard
  Geo replication: No
  Retention: 30 days for untagged

PRODUCTION:
  acrpyxprod.azurecr.io
    pyx-api:v1.0.0
    pyx-api:v1.0.1
    pyx-web:v1.0.0
    drivers-health-ai:v1.0.0
  SKU: Premium
  Geo replication: Yes for DR region
  Retention: 90 days for untagged
  Private Endpoint: Required

IMAGE PROMOTION FLOW:
nonprod ACR imports to prod ACR using az acr import command

## 15.3 ACR Access Control

| Identity | NonProd ACR | Prod ACR | Role |
|----------|-------------|----------|------|
| DevOps Pipeline NonProd | AcrPush | AcrPull | Build and push to nonprod and pull from prod |
| DevOps Pipeline Prod | AcrPull | AcrPush | Pull from nonprod and push to prod |
| Container Apps Dev | n/a | n/a | AcrPull via Managed Identity |
| Container Apps Staging | n/a | n/a | AcrPull via Managed Identity |
| Container Apps Prod | n/a | AcrPull | AcrPull via Managed Identity |
| Developers | AcrPull | None | Pull for local testing only |

---

# 16. Key Vault Management Strategy

## 16.1 RECOMMENDED: One Key Vault Per Environment as Single Source of Truth

OPTION A Per Application is Not Recommended:
- kv-pyx-api-dev
- kv-pyx-api-staging
- kv-pyx-api-prod
- kv-pyx-web-dev
- kv-pyx-web-staging
- kv-pyx-web-prod
Problems: Secret duplication and complex rotation and no single source of truth

OPTION B Per Environment is RECOMMENDED:
- kv-pyx-dev-eastus2 contains All dev secrets
    sql-connection-string
    redis-connection-string
    storage-account-key
    api-key-external-service
    ml-model-endpoint-key
- kv-pyx-staging-eastus2 contains All staging secrets with same structure
- kv-pyx-prod-eastus2 contains All prod secrets with same structure
    Soft delete: Enabled for 90 days
    Purge protection: Enabled
    Private Endpoint: Required

## 16.2 Key Vault as Source of Truth

| Principle | Implementation |
|-----------|----------------|
| Single source of truth | All secrets stored in environment Key Vault and never in code or pipelines |
| No secret duplication | Each secret exists in exactly one Key Vault per environment |
| Environment isolation | Dev cannot access staging or prod secrets |
| Audit trail | All access logged to Log Analytics |
| Rotation policy | Automated rotation for supported secret types |

## 16.3 Key Vault Access Control

| Identity | Dev KV | Staging KV | Prod KV | Role |
|----------|--------|------------|---------|------|
| DevOps Pipeline Infra | Get and List and Set | Get and List and Set | Get and List | Manage secrets |
| Container Apps Dev | Get | n/a | n/a | Read secrets at runtime |
| Container Apps Staging | n/a | Get | n/a | Read secrets at runtime |
| Container Apps Prod | n/a | n/a | Get | Read secrets at runtime |
| Developers | Get and List | Get and List | n/a | Debug access with no prod |
| Security Team | Get and List and Set | Get and List and Set | Get and List and Set | Rotation and audit |

---

# 17. Container Apps CI CD Pipeline

## 17.1 Container Apps Architecture

DEV ENVIRONMENT cae-pyx-dev-eastus2:
  VNet Integration: snet-cae-dev 10.2.1.0/24
  Container Apps: ca-pyx-api and ca-pyx-web and ca-drivers and ca-ai-ml
  Scaling: 0 to 5 replicas
  CPU: 0.5 cores
  Memory: 1Gi

STAGING ENVIRONMENT cae-pyx-staging-eastus2:
  Same structure as Dev
  Scaling: 1 to 5 replicas with always at least 1
  CPU: 0.5 cores
  Memory: 1Gi

PRODUCTION ENVIRONMENT cae-pyx-prod-eastus2:
  VNet Integration: snet-cae-prod 10.1.1.0/24
  Internal only: true with no public endpoint
  Container Apps: ca-pyx-api and ca-pyx-web and ca-drivers and ca-ai-ml
  Scaling: 2 to 10 replicas with min 2 for HA
  CPU: 1.0 cores
  Memory: 2Gi
  Revisions: Multiple active for blue green

Azure Front Door Premium:
  WAF Policy OWASP 3.2
  DDoS Protection
  Custom Domain plus TLS

---

# Document Control

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | Feb 2026 | Initial release |

END OF DOCUMENT
