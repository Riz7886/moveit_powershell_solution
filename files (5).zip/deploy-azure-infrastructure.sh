#!/bin/bash
###############################################################################
# Azure Infrastructure Deployment Script
# Author: Syed Rizvi
# Description: Automates full Azure infrastructure provisioning including
#              subscriptions, resource groups, ACR, Key Vault, Container Apps,
#              Azure Policies, RBAC, and managed identities.
#
# Prerequisites:
#   - Azure CLI installed and authenticated (az login)
#   - Sufficient permissions (Owner or Contributor + User Access Admin)
#   - Bash 4+
#
# Usage:
#   chmod +x deploy-azure-infrastructure.sh
#   ./deploy-azure-infrastructure.sh [--dry-run] [--env dev|staging|prod|all]
###############################################################################

set -euo pipefail

# =============================================================================
# CONFIGURATION — UPDATE THESE VALUES FOR YOUR ENVIRONMENT
# =============================================================================
APP_NAME="aics"
LOCATION="westus2"
LOCATION_DR="eastus2"                    # DR region for Key Vault backup

# Subscription IDs — replace with your actual subscription IDs
SUB_SANDBOX_ID="<your-sandbox-subscription-id>"
SUB_NONPROD_ID="<your-nonprod-subscription-id>"
SUB_PROD_ID="<your-prod-subscription-id>"

# Tagging
COST_CENTER="Engineering"
OWNER="Syed Rizvi"
APPLICATION="${APP_NAME^^}"              # Uppercase app name

# Container Apps
CONTAINER_APP_NAME="${APP_NAME}-api-app"
CONTAINER_ENV_NAME="${APP_NAME}-env"
CONTAINER_IMAGE="${APP_NAME}-api"
CONTAINER_CPU="0.5"
CONTAINER_MEMORY="1.0Gi"

# ACR
ACR_SKU="Standard"                       # Basic | Standard | Premium
ACR_NONPROD_NAME="acr${APP_NAME}nonprod"
ACR_PROD_NAME="acr${APP_NAME}prod"

# Key Vault
KV_SKU="standard"

# Log Analytics
LOG_RETENTION_DAYS=90

# =============================================================================
# GLOBALS
# =============================================================================
DRY_RUN=false
TARGET_ENV="all"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
LOG_FILE="deploy-${TIMESTAMP}.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

log() {
    local level="$1"
    shift
    local msg="$*"
    local ts
    ts=$(date '+%Y-%m-%d %H:%M:%S')
    echo -e "${ts} [${level}] ${msg}" | tee -a "$LOG_FILE"
}

info()    { log "${BLUE}INFO${NC}" "$@"; }
success() { log "${GREEN}SUCCESS${NC}" "$@"; }
warn()    { log "${YELLOW}WARN${NC}" "$@"; }
error()   { log "${RED}ERROR${NC}" "$@"; }
section() { echo -e "\n${CYAN}========================================${NC}" | tee -a "$LOG_FILE"
            echo -e "${CYAN} $*${NC}" | tee -a "$LOG_FILE"
            echo -e "${CYAN}========================================${NC}\n" | tee -a "$LOG_FILE"; }

run_cmd() {
    local description="$1"
    shift
    if [ "$DRY_RUN" = true ]; then
        warn "[DRY-RUN] Would execute: $*"
        return 0
    fi
    info "$description"
    if eval "$@" >> "$LOG_FILE" 2>&1; then
        success "$description — Done"
    else
        error "$description — FAILED (check $LOG_FILE)"
        return 1
    fi
}

check_exists() {
    local type="$1"  # group, keyvault, acr, etc.
    local name="$2"
    case "$type" in
        group)
            az group show --name "$name" &>/dev/null 2>&1
            ;;
        keyvault)
            az keyvault show --name "$name" &>/dev/null 2>&1
            ;;
        acr)
            az acr show --name "$name" &>/dev/null 2>&1
            ;;
        containerapp-env)
            az containerapp env show --name "$name" --resource-group "$3" &>/dev/null 2>&1
            ;;
        containerapp)
            az containerapp show --name "$name" --resource-group "$3" &>/dev/null 2>&1
            ;;
        *)
            return 1
            ;;
    esac
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --dry-run)
                DRY_RUN=true
                warn "DRY-RUN mode enabled — no changes will be made"
                shift
                ;;
            --env)
                TARGET_ENV="$2"
                shift 2
                ;;
            --help|-h)
                echo "Usage: $0 [--dry-run] [--env dev|staging|prod|all]"
                exit 0
                ;;
            *)
                error "Unknown argument: $1"
                exit 1
                ;;
        esac
    done
}

# =============================================================================
# PREREQUISITE CHECKS
# =============================================================================

preflight_checks() {
    section "Preflight Checks"

    # Check Azure CLI
    if ! command -v az &>/dev/null; then
        error "Azure CLI not found. Install from https://aka.ms/installazurecli"
        exit 1
    fi
    success "Azure CLI found: $(az version --query '\"azure-cli\"' -o tsv)"

    # Check logged in
    if ! az account show &>/dev/null 2>&1; then
        error "Not logged in. Run 'az login' first."
        exit 1
    fi
    local current_user
    current_user=$(az account show --query user.name -o tsv)
    success "Logged in as: $current_user"

    # Check required extensions
    local extensions=("containerapp")
    for ext in "${extensions[@]}"; do
        if ! az extension show --name "$ext" &>/dev/null 2>&1; then
            info "Installing extension: $ext"
            az extension add --name "$ext" --yes
        fi
        success "Extension ready: $ext"
    done

    # Register required providers
    local providers=("Microsoft.App" "Microsoft.ContainerRegistry" "Microsoft.KeyVault" "Microsoft.OperationalInsights" "Microsoft.PolicyInsights")
    for provider in "${providers[@]}"; do
        run_cmd "Registering provider: $provider" \
            "az provider register --namespace $provider --wait"
    done
}

# =============================================================================
# 1. RESOURCE GROUPS
# =============================================================================

create_resource_groups() {
    section "1. Creating Resource Groups"

    local common_tags="Environment={env} CostCenter=${COST_CENTER} Owner='${OWNER}' Application=${APPLICATION}"

    declare -A rg_map
    # Nonprod
    rg_map["rg-${APP_NAME}-dev"]="dev|${SUB_NONPROD_ID}"
    rg_map["rg-${APP_NAME}-staging"]="staging|${SUB_NONPROD_ID}"
    rg_map["rg-shared-nonprod"]="nonprod|${SUB_NONPROD_ID}"
    # Prod
    rg_map["rg-${APP_NAME}-prod"]="prod|${SUB_PROD_ID}"
    rg_map["rg-shared-prod"]="prod|${SUB_PROD_ID}"

    for rg in "${!rg_map[@]}"; do
        IFS='|' read -r env sub_id <<< "${rg_map[$rg]}"

        # Skip if not targeting this environment
        if [[ "$TARGET_ENV" != "all" && "$env" != "$TARGET_ENV" && "$env" != "nonprod" ]]; then
            continue
        fi

        local tags="${common_tags//\{env\}/$env}"

        if check_exists group "$rg"; then
            warn "Resource group '$rg' already exists — skipping"
        else
            run_cmd "Creating resource group: $rg (sub: $sub_id)" \
                "az group create \
                    --subscription '$sub_id' \
                    --name '$rg' \
                    --location '$LOCATION' \
                    --tags $tags"
        fi
    done
}

# =============================================================================
# 2. LOG ANALYTICS WORKSPACES
# =============================================================================

create_log_analytics() {
    section "2. Creating Log Analytics Workspaces"

    declare -A la_map
    la_map["la-${APP_NAME}-nonprod"]="rg-shared-nonprod|${SUB_NONPROD_ID}"
    la_map["la-${APP_NAME}-prod"]="rg-shared-prod|${SUB_PROD_ID}"

    for la_name in "${!la_map[@]}"; do
        IFS='|' read -r rg sub_id <<< "${la_map[$la_name]}"

        run_cmd "Creating Log Analytics workspace: $la_name" \
            "az monitor log-analytics workspace create \
                --subscription '$sub_id' \
                --resource-group '$rg' \
                --workspace-name '$la_name' \
                --location '$LOCATION' \
                --retention-time $LOG_RETENTION_DAYS \
                --sku PerGB2018"
    done
}

# =============================================================================
# 3. AZURE CONTAINER REGISTRY
# =============================================================================

create_container_registries() {
    section "3. Creating Azure Container Registries"

    # Nonprod ACR (shared for dev + staging)
    if check_exists acr "$ACR_NONPROD_NAME"; then
        warn "ACR '$ACR_NONPROD_NAME' already exists — skipping"
    else
        run_cmd "Creating nonprod ACR: $ACR_NONPROD_NAME" \
            "az acr create \
                --subscription '$SUB_NONPROD_ID' \
                --resource-group 'rg-shared-nonprod' \
                --name '$ACR_NONPROD_NAME' \
                --sku '$ACR_SKU' \
                --location '$LOCATION' \
                --admin-enabled false \
                --tags Environment=nonprod CostCenter='${COST_CENTER}' Owner='${OWNER}' Application=${APPLICATION}"
    fi

    # Prod ACR (isolated)
    if check_exists acr "$ACR_PROD_NAME"; then
        warn "ACR '$ACR_PROD_NAME' already exists — skipping"
    else
        run_cmd "Creating prod ACR: $ACR_PROD_NAME" \
            "az acr create \
                --subscription '$SUB_PROD_ID' \
                --resource-group 'rg-shared-prod' \
                --name '$ACR_PROD_NAME' \
                --sku '$ACR_SKU' \
                --location '$LOCATION' \
                --admin-enabled false \
                --tags Environment=prod CostCenter='${COST_CENTER}' Owner='${OWNER}' Application=${APPLICATION}"
    fi
}

# =============================================================================
# 4. KEY VAULTS
# =============================================================================

create_key_vaults() {
    section "4. Creating Key Vaults"

    declare -A kv_map
    kv_map["kv-${APP_NAME}-dev"]="rg-${APP_NAME}-dev|${SUB_NONPROD_ID}|dev"
    kv_map["kv-${APP_NAME}-staging"]="rg-${APP_NAME}-staging|${SUB_NONPROD_ID}|staging"
    kv_map["kv-${APP_NAME}-prod"]="rg-${APP_NAME}-prod|${SUB_PROD_ID}|prod"

    for kv_name in "${!kv_map[@]}"; do
        IFS='|' read -r rg sub_id env <<< "${kv_map[$kv_name]}"

        if [[ "$TARGET_ENV" != "all" && "$env" != "$TARGET_ENV" ]]; then
            continue
        fi

        if check_exists keyvault "$kv_name"; then
            warn "Key Vault '$kv_name' already exists — skipping"
        else
            run_cmd "Creating Key Vault: $kv_name" \
                "az keyvault create \
                    --subscription '$sub_id' \
                    --resource-group '$rg' \
                    --name '$kv_name' \
                    --location '$LOCATION' \
                    --sku '$KV_SKU' \
                    --enable-rbac-authorization true \
                    --enable-soft-delete true \
                    --retention-days 90 \
                    --enable-purge-protection true \
                    --tags Environment=$env CostCenter='${COST_CENTER}' Owner='${OWNER}' Application=${APPLICATION}"
        fi
    done
}

# =============================================================================
# 5. CONTAINER APP ENVIRONMENTS
# =============================================================================

create_container_app_environments() {
    section "5. Creating Container App Environments"

    declare -A env_map
    env_map["dev"]="rg-${APP_NAME}-dev|${SUB_NONPROD_ID}|la-${APP_NAME}-nonprod|rg-shared-nonprod"
    env_map["staging"]="rg-${APP_NAME}-staging|${SUB_NONPROD_ID}|la-${APP_NAME}-nonprod|rg-shared-nonprod"
    env_map["prod"]="rg-${APP_NAME}-prod|${SUB_PROD_ID}|la-${APP_NAME}-prod|rg-shared-prod"

    for env in "${!env_map[@]}"; do
        if [[ "$TARGET_ENV" != "all" && "$env" != "$TARGET_ENV" ]]; then
            continue
        fi

        IFS='|' read -r rg sub_id la_name la_rg <<< "${env_map[$env]}"
        local cae_name="${CONTAINER_ENV_NAME}-${env}"

        # Get Log Analytics workspace ID and key
        local la_id la_key
        if [ "$DRY_RUN" = false ]; then
            la_id=$(az monitor log-analytics workspace show \
                --subscription "$sub_id" \
                --resource-group "$la_rg" \
                --workspace-name "$la_name" \
                --query customerId -o tsv 2>/dev/null || echo "")
            la_key=$(az monitor log-analytics workspace get-shared-keys \
                --subscription "$sub_id" \
                --resource-group "$la_rg" \
                --workspace-name "$la_name" \
                --query primarySharedKey -o tsv 2>/dev/null || echo "")
        fi

        run_cmd "Creating Container App Environment: $cae_name" \
            "az containerapp env create \
                --subscription '$sub_id' \
                --resource-group '$rg' \
                --name '$cae_name' \
                --location '$LOCATION' \
                --logs-workspace-id '${la_id:-placeholder}' \
                --logs-workspace-key '${la_key:-placeholder}' \
                --tags Environment=$env CostCenter='${COST_CENTER}' Owner='${OWNER}' Application=${APPLICATION}"
    done
}

# =============================================================================
# 6. CONTAINER APPS WITH MANAGED IDENTITY
# =============================================================================

create_container_apps() {
    section "6. Creating Container Apps with Managed Identity"

    declare -A app_map
    app_map["dev"]="rg-${APP_NAME}-dev|${SUB_NONPROD_ID}|${ACR_NONPROD_NAME}"
    app_map["staging"]="rg-${APP_NAME}-staging|${SUB_NONPROD_ID}|${ACR_NONPROD_NAME}"
    app_map["prod"]="rg-${APP_NAME}-prod|${SUB_PROD_ID}|${ACR_PROD_NAME}"

    for env in "${!app_map[@]}"; do
        if [[ "$TARGET_ENV" != "all" && "$env" != "$TARGET_ENV" ]]; then
            continue
        fi

        IFS='|' read -r rg sub_id acr_name <<< "${app_map[$env]}"
        local ca_name="${CONTAINER_APP_NAME}-${env}"
        local cae_name="${CONTAINER_ENV_NAME}-${env}"
        local image="${acr_name}.azurecr.io/${CONTAINER_IMAGE}:${env}-latest"

        run_cmd "Creating Container App: $ca_name" \
            "az containerapp create \
                --subscription '$sub_id' \
                --resource-group '$rg' \
                --name '$ca_name' \
                --environment '$cae_name' \
                --image 'mcr.microsoft.com/k8se/quickstart:latest' \
                --target-port 80 \
                --ingress external \
                --cpu '$CONTAINER_CPU' \
                --memory '$CONTAINER_MEMORY' \
                --min-replicas 1 \
                --max-replicas 3 \
                --system-assigned \
                --tags Environment=$env CostCenter='${COST_CENTER}' Owner='${OWNER}' Application=${APPLICATION}"

        success "Container App $ca_name created with system-assigned managed identity"
    done
}

# =============================================================================
# 7. RBAC ASSIGNMENTS
# =============================================================================

assign_rbac() {
    section "7. Configuring RBAC Assignments"

    declare -A app_map
    app_map["dev"]="rg-${APP_NAME}-dev|${SUB_NONPROD_ID}|${ACR_NONPROD_NAME}|kv-${APP_NAME}-dev"
    app_map["staging"]="rg-${APP_NAME}-staging|${SUB_NONPROD_ID}|${ACR_NONPROD_NAME}|kv-${APP_NAME}-staging"
    app_map["prod"]="rg-${APP_NAME}-prod|${SUB_PROD_ID}|${ACR_PROD_NAME}|kv-${APP_NAME}-prod"

    for env in "${!app_map[@]}"; do
        if [[ "$TARGET_ENV" != "all" && "$env" != "$TARGET_ENV" ]]; then
            continue
        fi

        IFS='|' read -r rg sub_id acr_name kv_name <<< "${app_map[$env]}"
        local ca_name="${CONTAINER_APP_NAME}-${env}"

        if [ "$DRY_RUN" = true ]; then
            warn "[DRY-RUN] Would assign RBAC for $ca_name"
            continue
        fi

        # Get the managed identity principal ID
        local principal_id
        principal_id=$(az containerapp show \
            --subscription "$sub_id" \
            --resource-group "$rg" \
            --name "$ca_name" \
            --query identity.principalId -o tsv 2>/dev/null || echo "")

        if [ -z "$principal_id" ]; then
            warn "Could not retrieve principal ID for $ca_name — skipping RBAC"
            continue
        fi

        info "Principal ID for $ca_name: $principal_id"

        # Grant AcrPull on Container Registry
        local acr_id
        acr_id=$(az acr show --name "$acr_name" --query id -o tsv 2>/dev/null || echo "")
        if [ -n "$acr_id" ]; then
            run_cmd "Granting AcrPull to $ca_name on $acr_name" \
                "az role assignment create \
                    --assignee '$principal_id' \
                    --role 'AcrPull' \
                    --scope '$acr_id'"
        fi

        # Grant Key Vault Secrets User on Key Vault
        local kv_id
        kv_id=$(az keyvault show --name "$kv_name" --query id -o tsv 2>/dev/null || echo "")
        if [ -n "$kv_id" ]; then
            run_cmd "Granting Key Vault Secrets User to $ca_name on $kv_name" \
                "az role assignment create \
                    --assignee '$principal_id' \
                    --role 'Key Vault Secrets User' \
                    --scope '$kv_id'"
        fi
    done
}

# =============================================================================
# 8. AZURE POLICIES
# =============================================================================

apply_policies() {
    section "8. Applying Azure Policies"

    info "Applying subscription-level policies..."

    # --- Subscription-level policies ---

    # Require HTTPS on storage accounts
    for sub_id in "$SUB_NONPROD_ID" "$SUB_PROD_ID"; do
        local sub_scope="/subscriptions/${sub_id}"

        run_cmd "Assigning 'Require HTTPS on Storage' policy to subscription $sub_id" \
            "az policy assignment create \
                --name 'require-https-storage' \
                --display-name 'Require HTTPS for Storage Accounts' \
                --policy '/providers/Microsoft.Authorization/policyDefinitions/404c3081-a854-4457-ae30-26a93ef643f9' \
                --scope '$sub_scope' \
                --enforcement-mode Default"
    done

    # Require tags on resource groups
    local required_tags=("Environment" "CostCenter" "Owner" "Application")
    for sub_id in "$SUB_NONPROD_ID" "$SUB_PROD_ID"; do
        local sub_scope="/subscriptions/${sub_id}"
        for tag in "${required_tags[@]}"; do
            run_cmd "Assigning 'Require tag: $tag' policy to subscription $sub_id" \
                "az policy assignment create \
                    --name 'require-tag-${tag,,}' \
                    --display-name 'Require tag: $tag on Resource Groups' \
                    --policy '/providers/Microsoft.Authorization/policyDefinitions/96670d01-0a4d-4649-9c89-2d3abc0a5025' \
                    --scope '$sub_scope' \
                    --params '{\"tagName\": {\"value\": \"$tag\"}}' \
                    --enforcement-mode Default"
        done
    done

    # --- Prod-specific policies ---
    info "Applying production-specific policies..."

    # Deny public IP creation in prod resource groups
    local prod_rgs=("rg-${APP_NAME}-prod" "rg-shared-prod")
    for rg in "${prod_rgs[@]}"; do
        local rg_scope="/subscriptions/${SUB_PROD_ID}/resourceGroups/${rg}"

        run_cmd "Assigning 'Deny Public IPs' policy to $rg" \
            "az policy assignment create \
                --name 'deny-public-ip-${rg}' \
                --display-name 'Deny Public IP Addresses in ${rg}' \
                --policy '/providers/Microsoft.Authorization/policyDefinitions/6c112d4e-5bc7-47ae-a041-ea2d9dccd749' \
                --scope '$rg_scope' \
                --enforcement-mode Default"
    done

    # Allowed locations policy
    run_cmd "Assigning 'Allowed Locations' policy to prod subscription" \
        "az policy assignment create \
            --name 'allowed-locations-prod' \
            --display-name 'Allowed Locations - Production' \
            --policy '/providers/Microsoft.Authorization/policyDefinitions/e56962a6-4747-49cd-b67b-bf8b01975c4c' \
            --scope '/subscriptions/${SUB_PROD_ID}' \
            --params '{\"listOfAllowedLocations\": {\"value\": [\"${LOCATION}\", \"${LOCATION_DR}\"]}}' \
            --enforcement-mode Default"
}

# =============================================================================
# 9. CONFIGURE KEY VAULT REFERENCES FOR CONTAINER APPS
# =============================================================================

configure_kv_references() {
    section "9. Configuring Key Vault References for Container Apps"

    info "Adding sample secrets to Key Vaults and linking to Container Apps..."

    declare -A env_kv_map
    env_kv_map["dev"]="kv-${APP_NAME}-dev|rg-${APP_NAME}-dev|${SUB_NONPROD_ID}"
    env_kv_map["staging"]="kv-${APP_NAME}-staging|rg-${APP_NAME}-staging|${SUB_NONPROD_ID}"
    env_kv_map["prod"]="kv-${APP_NAME}-prod|rg-${APP_NAME}-prod|${SUB_PROD_ID}"

    for env in "${!env_kv_map[@]}"; do
        if [[ "$TARGET_ENV" != "all" && "$env" != "$TARGET_ENV" ]]; then
            continue
        fi

        IFS='|' read -r kv_name rg sub_id <<< "${env_kv_map[$env]}"
        local ca_name="${CONTAINER_APP_NAME}-${env}"

        # Add placeholder secrets (replace values per environment)
        run_cmd "Adding sample secret 'db-connection-string' to $kv_name" \
            "az keyvault secret set \
                --subscription '$sub_id' \
                --vault-name '$kv_name' \
                --name 'db-connection-string' \
                --value 'REPLACE-WITH-ACTUAL-${env^^}-CONNECTION-STRING'"

        run_cmd "Adding sample secret 'api-key' to $kv_name" \
            "az keyvault secret set \
                --subscription '$sub_id' \
                --vault-name '$kv_name' \
                --name 'api-key' \
                --value 'REPLACE-WITH-ACTUAL-${env^^}-API-KEY'"

        # Get Key Vault URI
        if [ "$DRY_RUN" = false ]; then
            local kv_uri
            kv_uri=$(az keyvault show --name "$kv_name" --query properties.vaultUri -o tsv 2>/dev/null || echo "")

            if [ -n "$kv_uri" ]; then
                # Add secrets as Key Vault references to Container App
                run_cmd "Linking Key Vault secrets to Container App: $ca_name" \
                    "az containerapp secret set \
                        --subscription '$sub_id' \
                        --resource-group '$rg' \
                        --name '$ca_name' \
                        --secrets \
                            db-conn=keyvaultref:${kv_uri}secrets/db-connection-string,identityref:system \
                            api-key=keyvaultref:${kv_uri}secrets/api-key,identityref:system"
            fi
        fi
    done
}

# =============================================================================
# 10. SUMMARY & VALIDATION
# =============================================================================

print_summary() {
    section "Deployment Summary"

    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║          Azure Infrastructure Deployment Complete           ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "  ${CYAN}Application:${NC}    $APP_NAME"
    echo -e "  ${CYAN}Region:${NC}         $LOCATION"
    echo -e "  ${CYAN}DR Region:${NC}      $LOCATION_DR"
    echo -e "  ${CYAN}Target Env:${NC}     $TARGET_ENV"
    echo -e "  ${CYAN}Dry Run:${NC}        $DRY_RUN"
    echo -e "  ${CYAN}Log File:${NC}       $LOG_FILE"
    echo ""
    echo -e "  ${YELLOW}Resources Created:${NC}"
    echo -e "  ├── Resource Groups:     rg-${APP_NAME}-{dev,staging,prod}, rg-shared-{nonprod,prod}"
    echo -e "  ├── Log Analytics:       la-${APP_NAME}-{nonprod,prod}"
    echo -e "  ├── Container Registries:${ACR_NONPROD_NAME}, ${ACR_PROD_NAME}"
    echo -e "  ├── Key Vaults:          kv-${APP_NAME}-{dev,staging,prod}"
    echo -e "  ├── Container Envs:      ${CONTAINER_ENV_NAME}-{dev,staging,prod}"
    echo -e "  ├── Container Apps:      ${CONTAINER_APP_NAME}-{dev,staging,prod}"
    echo -e "  ├── RBAC:                AcrPull + KV Secrets User per app"
    echo -e "  └── Policies:            HTTPS, Tags, Public IP deny, Locations"
    echo ""
    echo -e "  ${YELLOW}Next Steps:${NC}"
    echo -e "  1. Update Key Vault secrets with actual values per environment"
    echo -e "  2. Push container images to ACR and update Container App image references"
    echo -e "  3. Configure CI/CD pipelines (GitHub Actions recommended)"
    echo -e "  4. Convert this script to Terraform/Bicep for long-term IaC"
    echo -e "  5. Set up monitoring alerts in Log Analytics"
    echo ""
}

# =============================================================================
# MAIN EXECUTION
# =============================================================================

main() {
    parse_args "$@"

    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║    Azure Infrastructure Deployment — Syed Rizvi             ║${NC}"
    echo -e "${GREEN}║    App: ${APP_NAME}  |  Region: ${LOCATION}                         ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""

    preflight_checks
    create_resource_groups
    create_log_analytics
    create_container_registries
    create_key_vaults
    create_container_app_environments
    create_container_apps
    assign_rbac
    apply_policies
    configure_kv_references
    print_summary

    success "Full deployment completed. Log: $LOG_FILE"
}

main "$@"
