$TaskName = "Databricks-Datadog-Monitoring"
$ScriptPath = "C:\Scripts\Databricks-Datadog-Task.ps1"
$ScriptFolder = "C:\Scripts"
$LogFolder = "C:\Logs"

Write-Host "`nDatabricks-Datadog Scheduled Task Setup`n" -ForegroundColor Cyan

if (-not (Test-Path $ScriptFolder)) { 
    New-Item -ItemType Directory -Path $ScriptFolder -Force | Out-Null 
    Write-Host "Created: $ScriptFolder" -ForegroundColor Green
}

if (-not (Test-Path $LogFolder)) { 
    New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null 
    Write-Host "Created: $LogFolder" -ForegroundColor Green
}

if (-not (Test-Path $ScriptPath)) {
    Write-Host "Error: Script not found at $ScriptPath" -ForegroundColor Red
    Write-Host "Copy Databricks-Datadog-Task.ps1 to $ScriptFolder first" -ForegroundColor Yellow
    exit 1
}

$existingTask = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existingTask) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "Removed existing task" -ForegroundColor Yellow
}

$Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ScriptPath`""
$Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration (New-TimeSpan -Days 9999)
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RunOnlyIfNetworkAvailable -MultipleInstances IgnoreNew
$Principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Settings $Settings -Principal $Principal -Description "Databricks metrics to Datadog - runs every 60 seconds" | Out-Null

Start-ScheduledTask -TaskName $TaskName

Write-Host "`nSetup Complete" -ForegroundColor Green
Write-Host "Task: $TaskName" -ForegroundColor White
Write-Host "Frequency: Every 60 seconds" -ForegroundColor White
Write-Host "Log: $LogFolder\Databricks-Datadog.log`n" -ForegroundColor White
