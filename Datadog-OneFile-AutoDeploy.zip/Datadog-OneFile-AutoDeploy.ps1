# Datadog-OneFile-AutoDeploy.ps1
# FULL AUTOMATED DEPLOYMENT - SINGLE FILE
# Requires only: Datadog API Key + Datadog APP Key
# Automatically:
#   - Detects all subscriptions
#   - Installs agents on ALL VMs
#   - Registers providers
#   - Assigns RBAC
#   - Creates SPN
#   - Creates subscription-wide monitors
#   - Creates CSV report

param(
    [Parameter(Mandatory=$true)][string]$DatadogApiKey,
    [Parameter(Mandatory=$true)][string]$DatadogAppKey,
    [string]$DatadogRegion = "us3",
    [string]$CsvReportPath = ".\Datadog-AutoReport.csv"
)

$ErrorActionPreference = "Stop"
$Report = @()

function Log {
    param($Stage,$Status,$Details)
    $Report += [pscustomobject]@{
        Timestamp = (Get-Date)
        Stage     = $Stage
        Status    = $Status
        Details   = $Details
    }
}

Log "START" "OK" "Datadog Automation Script Started"

Write-Host "`n=== Detecting Azure Subscriptions ==="
$subs = Get-AzSubscription
if ($subs.Count -eq 0) { Write-Host "No subscriptions found."; exit }

for ($i=0; $i -lt $subs.Count; $i++) {
    Write-Host "[$i] $($subs[$i].Name) - $($subs[$i].Id)"
}

$sel = Read-Host "Enter subscription index"
$sub = $subs[$sel]
Select-AzSubscription -SubscriptionId $sub.Id
Log "Subscription Selected" "OK" $sub.Id

Write-Host "`n=== Registering Resource Providers ==="
$providers = @(
    "Microsoft.Insights",
    "Microsoft.OperationsManagement",
    "Microsoft.Resources",
    "Datadog"
)

foreach ($p in $providers) {
    Register-AzResourceProvider -ProviderNamespace $p | Out-Null
}
Log "Provider Registration" "OK" "All required providers registered"

Write-Host "`n=== Creating Datadog SPN ==="
$app = New-AzADApplication -DisplayName "Datadog-Auto-Monitoring"
$sp  = New-AzADServicePrincipal -ApplicationId $app.AppId
Log "SPN Created" "OK" "ObjectId: $($sp.Id)"

Write-Host "`n=== Assigning FULL RBAC ==="
$roles = @(
    "Reader",
    "Monitoring Reader",
    "Resource Health Contributor",
    "Managed Identity Operator"
)

foreach ($r in $roles) {
    New-AzRoleAssignment -ObjectId $sp.Id -RoleDefinitionName $r -Scope "/subscriptions/$($sub.Id)" | Out-Null
}
Log "RBAC Assigned" "OK" "All required roles assigned"

Write-Host "`n=== Installing Datadog Agent on ALL VMs ==="
$vms = Get-AzVM -Status
foreach ($vm in $vms) {
    if ($vm.StorageProfile.OsDisk.OsType -eq "Windows") {
        Invoke-AzVMRunCommand -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName `
        -CommandId "RunPowerShellScript" `
        -ScriptString @"
`$env:DD_API_KEY = '$DatadogApiKey'
`$env:DD_SITE = 'datadoghq.com'
Invoke-WebRequest -UseBasicParsing https://s3.amazonaws.com/dd-agent/scripts/install_script.ps1 -OutFile install.ps1
powershell -ExecutionPolicy Bypass -File install.ps1
"@
        Log "Agent Install" "OK" "Windows VM $($vm.Name)"
    }
    else {
        Invoke-AzVMRunCommand -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName `
        -CommandId "RunShellScript" `
        -ScriptString "DD_API_KEY=$DatadogApiKey DD_SITE=datadoghq.com bash -c '$(curl -L https://s3.amazonaws.com/dd-agent/scripts/install_script.sh)'" 
        Log "Agent Install" "OK" "Linux VM $($vm.Name)"
    }
}

Write-Host "`n=== Creating Subscription-Wide Datadog Monitors ==="

$headers = @{
    "DD-API-KEY" = $DatadogApiKey
    "DD-APPLICATION-KEY" = $DatadogAppKey
    "Content-Type" = "application/json"
}

function New-DDMonitor {
    param($Title,$Type,$Query,$Msg,$Options)

    $body = @{
        name    = $Title
        type    = $Type
        query   = $Query
        message = $Msg
        tags    = @("auto","subscription-wide","avd","monitoring")
        options = $Options
    }

    try {
        Invoke-RestMethod -Uri "https://api.$DatadogRegion.datadoghq.com/api/v1/monitor" `
            -Method Post -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)
        Log "Monitor Created" "OK" $Title
    }
    catch {
        Log "Monitor Created" "FAIL" $_.Exception.Message
    }
}

# Global monitors (Option B)
New-DDMonitor "AVD - CPU High" "metric alert" `
"avg(last_5m):avg:azure.compute.virtualmachine.percentage_cpu > 85" `
"CPU over 85%" `
@{ thresholds=@{critical=85;warning=75}; notify_no_data=$true }

New-DDMonitor "AVD - Memory Low" "metric alert" `
"avg(last_5m):avg:system.mem.pct_usable < 15" `
"Memory below 15%" `
@{ thresholds=@{critical=15;warning=20}; notify_no_data=$true }

New-DDMonitor "AVD - Disk High" "metric alert" `
"avg(last_5m):avg:system.disk.in_use > 85" `
"Disk usage over 85%" `
@{ thresholds=@{critical=85;warning=75}; notify_no_data=$true }

New-DDMonitor "AVD - VM Down" "service check" `
"azure.vm.status.over('host').last(2).count_by_status()" `
"VM Down Alert" `
@{ thresholds=@{critical=1}; notify_no_data=$true }

New-DDMonitor "AVD - Network Latency High" "metric alert" `
"avg(last_5m):avg:azure.network.latency > 100" `
"Network latency high" `
@{ thresholds=@{critical=100;warning=75} }

New-DDMonitor "AVD - Storage Unavailable" "service check" `
"azure.storage.availability.over('storage_account').last(3).count_by_status()" `
"Storage Unavailable" `
@{ thresholds=@{critical=1}; notify_no_data=$true }

New-DDMonitor "AVD - High User Sessions" "metric alert" `
"avg(last_10m):avg:azure.desktopvirtualization.hostpool.active_sessions > 80" `
"High user load" `
@{ thresholds=@{warning=80} }

New-DDMonitor "AVD - Failed User Connections" "metric alert" `
"sum(last_5m):sum:azure.desktopvirtualization.hostpool.failed_connections > 5" `
"Failed connection spikes" `
@{ thresholds=@{critical=5;warning=3} }

New-DDMonitor "AVD - Datadog Agent Loss" "service check" `
"datadog.agent.up.over('host').last(3).count_by_status()" `
"Datadog agent heartbeat lost" `
@{ thresholds=@{critical=1}; notify_no_data=$true }

New-DDMonitor "AVD - Subscription Events Surge" "event alert" `
"events('sources:azure').rollup('count').last('10m') > 5" `
"Unusual activity detected" `
@{ thresholds=@{critical=5} }

Write-Host "`n=== Exporting CSV Report ==="
$Report | Export-Csv -NoTypeInformation -Path $CsvReportPath

Write-Host "`n=== DONE ==="
Write-Host "Report saved to: $CsvReportPath"
