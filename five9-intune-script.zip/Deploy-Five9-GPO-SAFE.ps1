param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("Test", "CreateGPO", "DeployLocal", "Full")]
    [string]$Mode = "Test",
    
    [Parameter(Mandatory=$false)]
    [string]$GPOName = "Five9 Softphone - Firewall Exception",
    
    [Parameter(Mandatory=$false)]
    [string]$TargetOU = "",
    
    [Parameter(Mandatory=$false)]
    [string]$LogPath = "C:\Temp\Five9_Deployment_Log.txt"
)

$ErrorActionPreference = "Continue"

function Write-Log {
    param($Message, $Color = "White")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] $Message"
    Write-Host $logMessage -ForegroundColor $Color
    if (Test-Path (Split-Path $LogPath -Parent)) {
        Add-Content -Path $LogPath -Value $logMessage -ErrorAction SilentlyContinue
    }
}

Write-Host ""
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  FIVE9 FIREWALL GPO - SAFE DEPLOYMENT" -ForegroundColor Yellow
Write-Host "  100% SAFE - WITH VALIDATION AND BACKUPS" -ForegroundColor Yellow
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

$logDir = Split-Path $LogPath -Parent
if (-not (Test-Path $logDir)) {
    try {
        New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        Write-Log "Created log directory: $logDir" -Color Green
    } catch {
        Write-Host "WARNING: Cannot create log directory. Logging to console only." -ForegroundColor Yellow
    }
}

Write-Log "Starting Five9 firewall deployment - Mode: $Mode" -Color Cyan

function Test-Prerequisites {
    Write-Log "=== CHECKING PREREQUISITES ===" -Color Yellow
    Write-Host ""
    
    $allGood = $true
    
    Write-Log "Checking administrator rights..." -Color White
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if ($isAdmin) {
        Write-Log "  Administrator rights: OK" -Color Green
    } else {
        Write-Log "  ERROR: Must run as Administrator!" -Color Red
        $allGood = $false
    }
    
    Write-Log "Checking Five9 installation..." -Color White
    $five9Paths = @(
        "C:\Program Files\Five9\Five9 Softphone\Five9Softphone.exe",
        "C:\Program Files (x86)\Five9\Five9 Softphone\Five9Softphone.exe"
    )
    
    $five9Found = $false
    foreach ($path in $five9Paths) {
        if (Test-Path $path) {
            Write-Log "  Five9 found at: $path" -Color Green
            $script:Five9Path = $path
            $five9Found = $true
            break
        }
    }
    
    if (-not $five9Found) {
        Write-Log "  WARNING: Five9 not found. Will use default path." -Color Yellow
        Write-Log "  This is OK if Five9 will be installed later." -Color Yellow
        $script:Five9Path = "C:\Program Files\Five9\Five9 Softphone\Five9Softphone.exe"
    }
    
    if ($Mode -eq "CreateGPO" -or $Mode -eq "Full") {
        Write-Log "Checking Group Policy module..." -Color White
        try {
            Import-Module GroupPolicy -ErrorAction Stop
            Write-Log "  Group Policy module: OK" -Color Green
        } catch {
            Write-Log "  ERROR: Group Policy module not available!" -Color Red
            Write-Log "  Install with: Add-WindowsCapability -Online -Name Rsat.GroupPolicy.Management.Tools~~~~0.0.1.0" -Color Yellow
            $allGood = $false
        }
        
        Write-Log "Checking domain connection..." -Color White
        try {
            $domain = Get-ADDomain -ErrorAction Stop
            Write-Log "  Domain: $($domain.DNSRoot)" -Color Green
            $script:DomainDN = $domain.DistinguishedName
        } catch {
            Write-Log "  ERROR: Not connected to domain!" -Color Red
            $allGood = $false
        }
    }
    
    Write-Host ""
    return $allGood
}

function Backup-ExistingRules {
    Write-Log "Creating backup of existing firewall rules..." -Color Cyan
    
    try {
        $backupPath = "C:\Temp\Five9_Firewall_Backup_$(Get-Date -Format 'yyyyMMdd_HHmmss').xml"
        
        $existingRules = Get-NetFirewallRule -DisplayName "*Five9*" -ErrorAction SilentlyContinue
        
        if ($existingRules) {
            Write-Log "Found $($existingRules.Count) existing Five9 rules" -Color White
            $existingRules | Export-Clixml -Path $backupPath
            Write-Log "Backup saved to: $backupPath" -Color Green
            return $backupPath
        } else {
            Write-Log "No existing Five9 rules found (this is normal)" -Color White
            return $null
        }
    } catch {
        Write-Log "WARNING: Could not backup rules: $($_.Exception.Message)" -Color Yellow
        return $null
    }
}

function Test-FirewallRuleCreation {
    Write-Log "=== TESTING FIREWALL RULE CREATION ===" -Color Yellow
    Write-Host ""
    
    try {
        Write-Log "Creating test firewall rule..." -Color White
        
        $testRule = New-NetFirewallRule -DisplayName "Five9-TEST-RULE-DELETE-ME" `
            -Direction Inbound `
            -Program $script:Five9Path `
            -Action Allow `
            -Profile Any `
            -Enabled False `
            -ErrorAction Stop
        
        Write-Log "  Test rule created successfully" -Color Green
        
        Write-Log "Verifying test rule..." -Color White
        $verify = Get-NetFirewallRule -DisplayName "Five9-TEST-RULE-DELETE-ME" -ErrorAction Stop
        
        if ($verify) {
            Write-Log "  Test rule verified" -Color Green
            
            Write-Log "Removing test rule..." -Color White
            Remove-NetFirewallRule -DisplayName "Five9-TEST-RULE-DELETE-ME" -ErrorAction Stop
            Write-Log "  Test rule removed" -Color Green
            
            Write-Host ""
            Write-Log "FIREWALL TEST: PASSED" -Color Green
            return $true
        } else {
            Write-Log "  ERROR: Could not verify test rule" -Color Red
            return $false
        }
    } catch {
        Write-Log "  ERROR: Firewall test failed: $($_.Exception.Message)" -Color Red
        return $false
    }
}

function Create-FirewallRules {
    Write-Log "=== CREATING FIREWALL RULES ===" -Color Yellow
    Write-Host ""
    
    $backupPath = Backup-ExistingRules
    
    try {
        $existingInbound = Get-NetFirewallRule -DisplayName "Five9 Softphone Inbound" -ErrorAction SilentlyContinue
        if ($existingInbound) {
            Write-Log "Removing existing inbound rule..." -Color White
            Remove-NetFirewallRule -DisplayName "Five9 Softphone Inbound" -ErrorAction Stop
            Write-Log "  Existing inbound rule removed" -Color Green
        }
        
        Write-Log "Creating inbound firewall rule..." -Color White
        $inboundRule = New-NetFirewallRule -DisplayName "Five9 Softphone Inbound" `
            -Description "Allow Five9 Softphone inbound connections for Salesforce integration" `
            -Direction Inbound `
            -Program $script:Five9Path `
            -Action Allow `
            -Profile Any `
            -Enabled True `
            -ErrorAction Stop
        
        Write-Log "  Inbound rule created successfully" -Color Green
        
        $existingOutbound = Get-NetFirewallRule -DisplayName "Five9 Softphone Outbound" -ErrorAction SilentlyContinue
        if ($existingOutbound) {
            Write-Log "Removing existing outbound rule..." -Color White
            Remove-NetFirewallRule -DisplayName "Five9 Softphone Outbound" -ErrorAction Stop
            Write-Log "  Existing outbound rule removed" -Color Green
        }
        
        Write-Log "Creating outbound firewall rule..." -Color White
        $outboundRule = New-NetFirewallRule -DisplayName "Five9 Softphone Outbound" `
            -Description "Allow Five9 Softphone outbound connections for Salesforce integration" `
            -Direction Outbound `
            -Program $script:Five9Path `
            -Action Allow `
            -Profile Any `
            -Enabled True `
            -ErrorAction Stop
        
        Write-Log "  Outbound rule created successfully" -Color Green
        
        Write-Log "Verifying firewall rules..." -Color White
        $verifyInbound = Get-NetFirewallRule -DisplayName "Five9 Softphone Inbound" -ErrorAction Stop
        $verifyOutbound = Get-NetFirewallRule -DisplayName "Five9 Softphone Outbound" -ErrorAction Stop
        
        if ($verifyInbound -and $verifyOutbound) {
            Write-Log "  Both rules verified and active" -Color Green
            Write-Host ""
            Write-Log "FIREWALL RULES: SUCCESS" -Color Green
            return $true
        } else {
            throw "Rules created but verification failed"
        }
        
    } catch {
        Write-Log "ERROR: Failed to create firewall rules - $($_.Exception.Message)" -Color Red
        
        if ($backupPath) {
            Write-Log "Attempting to restore from backup..." -Color Yellow
            try {
                $backup = Import-Clixml -Path $backupPath
                foreach ($rule in $backup) {
                    New-NetFirewallRule -DisplayName $rule.DisplayName `
                        -Direction $rule.Direction `
                        -Action $rule.Action `
                        -Enabled $rule.Enabled
                }
                Write-Log "Backup restored" -Color Green
            } catch {
                Write-Log "Could not restore backup" -Color Red
            }
        }
        
        return $false
    }
}

function Create-GPOPolicy {
    Write-Log "=== CREATING GROUP POLICY OBJECT ===" -Color Yellow
    Write-Host ""
    
    try {
        Import-Module GroupPolicy -ErrorAction Stop
        
        $domain = Get-ADDomain -ErrorAction Stop
        Write-Log "Domain: $($domain.DNSRoot)" -Color White
        
        $existingGPO = Get-GPO -Name $GPOName -ErrorAction SilentlyContinue
        if ($existingGPO) {
            Write-Log "WARNING: GPO '$GPOName' already exists!" -Color Yellow
            Write-Log "Do you want to DELETE the existing GPO and create new? (Y/N)" -Color Cyan
            $response = Read-Host
            
            if ($response -eq "Y" -or $response -eq "y") {
                Write-Log "Removing existing GPO..." -Color White
                Remove-GPO -Name $GPOName -ErrorAction Stop
                Write-Log "  Existing GPO removed" -Color Green
            } else {
                Write-Log "Keeping existing GPO. Skipping GPO creation." -Color Yellow
                return $true
            }
        }
        
        Write-Log "Creating new GPO: $GPOName" -Color White
        $gpo = New-GPO -Name $GPOName -Comment "Five9 Softphone firewall exceptions for Salesforce integration - Created $(Get-Date -Format 'yyyy-MM-dd')" -ErrorAction Stop
        Write-Log "  GPO created successfully" -Color Green
        Write-Log "  GPO GUID: $($gpo.Id)" -Color White
        
        Write-Log "Configuring firewall rules in GPO..." -Color White
        
        $gpoRegPath = "HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\FirewallRules"
        
        $inboundGuid = [guid]::NewGuid().ToString()
        $inboundValue = "v2.30|Action=Allow|Active=TRUE|Dir=In|Protocol=6|App=$($script:Five9Path)|Name=Five9 Softphone Inbound|Desc=Allow Five9 Softphone inbound connections for Salesforce|"
        
        Set-GPRegistryValue -Name $GPOName -Key $gpoRegPath `
            -ValueName "Five9-Inbound-{$inboundGuid}" `
            -Type String `
            -Value $inboundValue `
            -ErrorAction Stop
        
        Write-Log "  Inbound rule configured" -Color Green
        
        $outboundGuid = [guid]::NewGuid().ToString()
        $outboundValue = "v2.30|Action=Allow|Active=TRUE|Dir=Out|Protocol=6|App=$($script:Five9Path)|Name=Five9 Softphone Outbound|Desc=Allow Five9 Softphone outbound connections for Salesforce|"
        
        Set-GPRegistryValue -Name $GPOName -Key $gpoRegPath `
            -ValueName "Five9-Outbound-{$outboundGuid}" `
            -Type String `
            -Value $outboundValue `
            -ErrorAction Stop
        
        Write-Log "  Outbound rule configured" -Color Green
        
        if ($TargetOU -ne "") {
            Write-Log "Linking GPO to OU: $TargetOU" -Color White
            
            try {
                $ouTest = Get-ADOrganizationalUnit -Identity $TargetOU -ErrorAction Stop
                
                New-GPLink -Name $GPOName -Target $TargetOU -ErrorAction Stop
                Write-Log "  GPO linked successfully to $TargetOU" -Color Green
            } catch {
                Write-Log "  WARNING: Could not link GPO to OU: $($_.Exception.Message)" -Color Yellow
                Write-Log "  You will need to link manually in Group Policy Management Console" -Color Yellow
            }
        } else {
            Write-Log "No target OU specified. Link GPO manually to desired OU." -Color Yellow
        }
        
        Write-Host ""
        Write-Log "GPO CREATION: SUCCESS" -Color Green
        Write-Log "GPO Name: $GPOName" -Color White
        Write-Log "Users should run 'gpupdate /force' to apply immediately" -Color Yellow
        
        return $true
        
    } catch {
        Write-Log "ERROR: Failed to create GPO - $($_.Exception.Message)" -Color Red
        return $false
    }
}

function Show-Summary {
    Write-Host ""
    Write-Host "========================================================" -ForegroundColor Cyan
    Write-Host "  DEPLOYMENT SUMMARY" -ForegroundColor Yellow
    Write-Host "========================================================" -ForegroundColor Cyan
    Write-Host ""
    
    Write-Log "Mode: $Mode" -Color White
    Write-Log "Five9 Path: $($script:Five9Path)" -Color White
    
    if ($Mode -eq "CreateGPO" -or $Mode -eq "Full") {
        Write-Log "GPO Name: $GPOName" -Color White
        if ($TargetOU) {
            Write-Log "Target OU: $TargetOU" -Color White
        }
    }
    
    Write-Host ""
    Write-Log "WHAT WAS DONE:" -Color Yellow
    
    if ($Mode -eq "Test") {
        Write-Log "  - Prerequisites checked" -Color White
        Write-Log "  - Firewall rule creation tested" -Color White
        Write-Log "  - NO CHANGES MADE TO SYSTEM" -Color Green
    }
    
    if ($Mode -eq "DeployLocal") {
        Write-Log "  - Firewall rules added to local machine" -Color White
        Write-Log "  - Five9 Softphone allowed through firewall" -Color White
    }
    
    if ($Mode -eq "CreateGPO") {
        Write-Log "  - Group Policy Object created" -Color White
        Write-Log "  - Firewall rules configured in GPO" -Color White
        if ($TargetOU) {
            Write-Log "  - GPO linked to target OU" -Color White
        }
    }
    
    if ($Mode -eq "Full") {
        Write-Log "  - Firewall rules added to local machine" -Color White
        Write-Log "  - Group Policy Object created" -Color White
        Write-Log "  - Firewall rules configured in GPO" -Color White
        if ($TargetOU) {
            Write-Log "  - GPO linked to target OU" -Color White
        }
    }
    
    Write-Host ""
    Write-Log "NEXT STEPS:" -Color Yellow
    
    if ($Mode -eq "Test") {
        Write-Log "  1. Review test results above" -Color White
        Write-Log "  2. If all tests passed, run with -Mode DeployLocal or -Mode Full" -Color White
    } else {
        Write-Log "  1. Verify firewall rules: Get-NetFirewallRule -DisplayName 'Five9*'" -Color White
        
        if ($Mode -eq "CreateGPO" -or $Mode -eq "Full") {
            Write-Log "  2. Check GPO in Group Policy Management Console" -Color White
            Write-Log "  3. Tell users to run: gpupdate /force" -Color White
            Write-Log "  4. Users may need to restart for changes to take effect" -Color White
        }
    }
    
    Write-Host ""
}

Write-Host ""
Write-Log "Mode selected: $Mode" -Color Cyan
Write-Host ""

if ($Mode -eq "Test") {
    Write-Log "TEST MODE - No changes will be made to your system" -Color Green
    Write-Host ""
}

$prereqOK = Test-Prerequisites

if (-not $prereqOK) {
    Write-Host ""
    Write-Log "FAILED: Prerequisites not met. Cannot continue." -Color Red
    Write-Host ""
    exit 1
}

if ($Mode -eq "Test") {
    Write-Host ""
    $testOK = Test-FirewallRuleCreation
    
    if ($testOK) {
        Write-Host ""
        Write-Log "ALL TESTS PASSED!" -Color Green
        Write-Log "The script is safe to run in deployment mode." -Color Green
        Write-Host ""
        Write-Log "To deploy locally: .\script.ps1 -Mode DeployLocal" -Color Cyan
        Write-Log "To create GPO: .\script.ps1 -Mode CreateGPO -TargetOU 'OU=Workstations,DC=pyxhealth,DC=com'" -Color Cyan
        Write-Log "To do both: .\script.ps1 -Mode Full -TargetOU 'OU=Workstations,DC=pyxhealth,DC=com'" -Color Cyan
        Write-Host ""
    } else {
        Write-Host ""
        Write-Log "TEST FAILED!" -Color Red
        Write-Log "Do not run in deployment mode until issues are resolved." -Color Red
        Write-Host ""
    }
    
    Show-Summary
    exit 0
}

$success = $true

if ($Mode -eq "DeployLocal" -or $Mode -eq "Full") {
    Write-Host ""
    $localResult = Create-FirewallRules
    if (-not $localResult) {
        $success = $false
    }
}

if ($Mode -eq "CreateGPO" -or $Mode -eq "Full") {
    Write-Host ""
    $gpoResult = Create-GPOPolicy
    if (-not $gpoResult) {
        $success = $false
    }
}

Show-Summary

if ($success) {
    Write-Host ""
    Write-Host "========================================================" -ForegroundColor Green
    Write-Host "  DEPLOYMENT COMPLETED SUCCESSFULLY!" -ForegroundColor Yellow
    Write-Host "========================================================" -ForegroundColor Green
    Write-Host ""
    Write-Log "Log file: $LogPath" -Color Cyan
    Write-Host ""
    exit 0
} else {
    Write-Host ""
    Write-Host "========================================================" -ForegroundColor Red
    Write-Host "  DEPLOYMENT COMPLETED WITH ERRORS" -ForegroundColor Yellow
    Write-Host "========================================================" -ForegroundColor Red
    Write-Host ""
    Write-Log "Check log file for details: $LogPath" -Color Cyan
    Write-Host ""
    exit 1
}
