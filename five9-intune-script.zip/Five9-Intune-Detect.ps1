# Five9 Firewall Rules - Intune Detection Script
# Returns exit code 0 if rules exist, exit code 1 if they don't

$inboundRule = Get-NetFirewallRule -DisplayName "Five9 Softphone Inbound" -ErrorAction SilentlyContinue
$outboundRule = Get-NetFirewallRule -DisplayName "Five9 Softphone Outbound" -ErrorAction SilentlyContinue

if ($inboundRule -and $outboundRule) {
    Write-Output "Detected"
    exit 0
} else {
    exit 1
}
