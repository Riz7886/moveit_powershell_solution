# Five9 Firewall Rules - Intune Deployment Script
# 100% SAFE - Only ALLOWS traffic, never blocks
# Can be deployed via Intune to all Windows devices

# Detection: Check if Five9 firewall rules exist
$inboundRule = Get-NetFirewallRule -DisplayName "Five9 Softphone Inbound" -ErrorAction SilentlyContinue
$outboundRule = Get-NetFirewallRule -DisplayName "Five9 Softphone Outbound" -ErrorAction SilentlyContinue

if ($inboundRule -and $outboundRule) {
    Write-Output "Five9 firewall rules already exist"
    exit 0
}

# Find Five9 installation path
$five9Path = "C:\Program Files\Five9\Five9 Softphone\Five9Softphone.exe"
if (-not (Test-Path $five9Path)) {
    $five9Path = "C:\Program Files (x86)\Five9\Five9 Softphone\Five9Softphone.exe"
}

try {
    # Create inbound rule
    if (-not $inboundRule) {
        New-NetFirewallRule -DisplayName "Five9 Softphone Inbound" `
            -Description "Allow Five9 Softphone inbound connections for Salesforce integration" `
            -Direction Inbound `
            -Program $five9Path `
            -Action Allow `
            -Profile Any `
            -Enabled True `
            -ErrorAction Stop | Out-Null
        
        Write-Output "Inbound rule created"
    }
    
    # Create outbound rule
    if (-not $outboundRule) {
        New-NetFirewallRule -DisplayName "Five9 Softphone Outbound" `
            -Description "Allow Five9 Softphone outbound connections for Salesforce integration" `
            -Direction Outbound `
            -Program $five9Path `
            -Action Allow `
            -Profile Any `
            -Enabled True `
            -ErrorAction Stop | Out-Null
        
        Write-Output "Outbound rule created"
    }
    
    # Verify rules were created
    $verify1 = Get-NetFirewallRule -DisplayName "Five9 Softphone Inbound" -ErrorAction Stop
    $verify2 = Get-NetFirewallRule -DisplayName "Five9 Softphone Outbound" -ErrorAction Stop
    
    if ($verify1 -and $verify2) {
        Write-Output "SUCCESS: Five9 firewall rules created and verified"
        exit 0
    } else {
        Write-Output "ERROR: Rules created but verification failed"
        exit 1
    }
    
} catch {
    Write-Output "ERROR: Failed to create firewall rules - $($_.Exception.Message)"
    exit 1
}
