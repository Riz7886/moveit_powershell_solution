# MOVEit Cleanup Script
# Removes all deployed security resources

Write-Host "========================================" -ForegroundColor Yellow
Write-Host "MOVEit Security Resources Cleanup" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Yellow

Write-Host "`nThis will destroy:" -ForegroundColor Red
Write-Host "  - Load Balancer" -ForegroundColor White
Write-Host "  - Public IP" -ForegroundColor White
Write-Host "  - Azure Front Door" -ForegroundColor White
Write-Host "  - WAF Policy" -ForegroundColor White
Write-Host "  - Network Security Group" -ForegroundColor White
Write-Host "  - Resource Group" -ForegroundColor White

Write-Host "`nThis will NOT destroy:" -ForegroundColor Green
Write-Host "  - Virtual Network" -ForegroundColor White
Write-Host "  - Subnet" -ForegroundColor White
Write-Host "  - MOVEit VM" -ForegroundColor White

$confirm = Read-Host "`nAre you sure? Type 'destroy' to confirm"

if ($confirm -ne "destroy") {
    Write-Host "Cleanup cancelled" -ForegroundColor Yellow
    exit 0
}

Write-Host "`nDestroying resources..." -ForegroundColor Red
terraform destroy -auto-approve

if ($LASTEXITCODE -eq 0) {
    Write-Host "`n========================================" -ForegroundColor Green
    Write-Host "CLEANUP COMPLETE" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "All security resources removed" -ForegroundColor White
    Write-Host "Your MOVEit server and network remain intact" -ForegroundColor White
} else {
    Write-Host "`nCleanup failed - check errors above" -ForegroundColor Red
}
