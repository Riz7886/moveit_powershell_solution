# TROUBLESHOOTING GUIDE

## Common Errors and Solutions

### 1. "Azure CLI not found"

**Error:**
```
ERROR: Azure CLI not found
```

**Solution:**
```powershell
# Download and install Azure CLI
https://aka.ms/installazurecli

# Verify installation
az --version
```

### 2. "Terraform not found"

**Error:**
```
ERROR: Terraform not found
```

**Solution:**
```powershell
# Download Terraform
https://www.terraform.io/downloads

# Extract to C:\terraform
# Add to PATH

# Verify installation
terraform version
```

### 3. "No Virtual Networks found"

**Error:**
```
ERROR: No Virtual Networks found. Deploy VNet first.
```

**Solution:**
- Ensure you're logged into correct Azure subscription
- Check subscription has VNets:
```powershell
az network vnet list
```
- If no VNets, create one first in Azure Portal

### 4. "No VMs found in resource group"

**Error:**
```
ERROR: No VMs found in resource group
```

**Solution:**
- Ensure MOVEit VM exists and is running
- Check VM status:
```powershell
az vm list --resource-group <rg-name>
```
- If VM exists but not detected, check resource group name

### 5. "Terraform init failed"

**Error:**
```
ERROR: Terraform init failed
```

**Solution:**
```powershell
# Delete Terraform cache
Remove-Item -Recurse -Force .terraform
Remove-Item .terraform.lock.hcl

# Run deploy again
.\deploy-moveit.ps1
```

### 6. "Terraform plan failed"

**Error:**
```
Error: Error creating Resource Group
```

**Solution:**
- Check you have Contributor permissions in subscription
- Verify subscription ID in terraform.tfvars is correct
- Ensure resource group name doesn't already exist

### 7. "Error creating Load Balancer"

**Error:**
```
Error: creating Load Balancer: resources.LoadBalancersClient#CreateOrUpdate
```

**Solution:**
- Check Azure quota limits
- Verify location supports Standard Load Balancer
- Ensure no conflicting Load Balancer exists with same name

### 8. "Error creating Front Door"

**Error:**
```
Error: creating Front Door Profile
```

**Solution:**
- Front Door names must be globally unique
- Try different project_name in terraform.tfvars
- Check Azure Front Door quota

### 9. "Public IP not accessible"

**Problem:**
Cannot connect to FTPS via public IP

**Solution:**
1. Verify Load Balancer health probe is healthy:
   - Azure Portal > Load Balancer > Backend pools
   - Should show "1 of 1 healthy"

2. Check NSG rules:
   - Azure Portal > Network Security Groups
   - Verify ports 990, 989 are allowed

3. Check MOVEit server firewall:
   - Ensure Windows Firewall allows ports 990, 989
   - Verify MOVEit Transfer service is running

4. Test from Load Balancer directly:
```powershell
Test-NetConnection -ComputerName <public-ip> -Port 990
```

### 10. "Front Door URL not accessible"

**Problem:**
Cannot access MOVEit web interface via Front Door URL

**Solution:**
1. Wait 5-10 minutes for Front Door to provision

2. Check origin health:
   - Azure Portal > Front Door > Origin groups
   - Should show "Healthy"

3. Test origin directly:
```powershell
Test-NetConnection -ComputerName <moveit-private-ip> -Port 443
```

4. Check WAF logs:
   - Azure Portal > Front Door > Logs
   - Look for blocked requests

5. Temporarily set WAF to Detection mode:
```hcl
# In terraform.tfvars
waf_mode = "Detection"
```
```powershell
terraform apply
```

### 11. "WAF blocking legitimate traffic"

**Problem:**
WAF blocks valid requests

**Solution:**
1. Check WAF logs:
   - Azure Portal > Front Door > Firewall Policy > Logs

2. Create exclusion rule:
   - Identify rule causing block
   - Add exclusion in WAF policy

3. Temporarily disable WAF:
```hcl
# In terraform.tfvars
enable_waf = false
```
```powershell
terraform apply
```

### 12. "Permission denied errors"

**Error:**
```
Error: authorization.RoleAssignmentsClient#Create: Failure responding
```

**Solution:**
- Ensure you have Owner or User Access Administrator role
- Check you can create role assignments:
```powershell
az role assignment list --assignee <your-email>
```

### 13. "Subnet association failed"

**Error:**
```
Error: updating Subnet Association with Network Security Group
```

**Solution:**
- Check no other NSG is associated with subnet
- Remove existing NSG association first:
```powershell
az network vnet subnet update \
  --resource-group <rg> \
  --vnet-name <vnet> \
  --name <subnet> \
  --network-security-group ""
```

### 14. "Terraform state locked"

**Error:**
```
Error: Error acquiring the state lock
```

**Solution:**
```powershell
# Force unlock (use with caution)
terraform force-unlock <lock-id>

# Or delete state lock file
Remove-Item .terraform.tfstate.lock.info
```

### 15. "Backend address pool empty"

**Problem:**
Load Balancer shows 0 of 1 healthy

**Solution:**
1. Verify MOVEit VM IP is correct:
```powershell
az vm nic list --resource-group <rg> --vm-name <vm-name>
az network nic show --ids <nic-id>
```

2. Check backend pool configuration:
   - Azure Portal > Load Balancer > Backend pools
   - Should show MOVEit server IP

3. Verify health probe:
   - Ensure MOVEit responds on port 443
```powershell
Test-NetConnection -ComputerName <moveit-ip> -Port 443
```

## Script-Specific Issues

### "Script has encoding errors"

**Problem:**
PowerShell shows weird characters or script won't run

**Solution:**
```powershell
# Save script with UTF-8 encoding
Get-Content .\deploy-moveit.ps1 | Out-File -Encoding UTF8 .\deploy-moveit-fixed.ps1

# Run fixed version
.\deploy-moveit-fixed.ps1
```

### "ExecutionPolicy restriction"

**Error:**
```
File cannot be loaded because running scripts is disabled
```

**Solution:**
```powershell
# Set execution policy (run as Administrator)
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser

# Or run with bypass
powershell -ExecutionPolicy Bypass -File .\deploy-moveit.ps1
```

## Terraform State Issues

### Reset Terraform completely

```powershell
# Remove all Terraform files
Remove-Item -Recurse -Force .terraform
Remove-Item terraform.tfstate*
Remove-Item .terraform.lock.hcl
Remove-Item tfplan

# Run deploy again
.\deploy-moveit.ps1
```

### Manually apply Terraform

```powershell
# Skip script, run Terraform manually
terraform init
terraform plan
terraform apply
```

## Verification Commands

### Check deployed resources

```powershell
# List all resources in security RG
az resource list --resource-group rg-moveit-security

# Check Load Balancer
az network lb show --name lb-moveit-prod --resource-group rg-moveit-security

# Check Front Door
az afd profile show --profile-name afd-moveit-prod --resource-group rg-moveit-security

# Check NSG
az network nsg show --name nsg-moveit-prod --resource-group rg-moveit-security
```

### Test connectivity

```powershell
# Test FTPS port
Test-NetConnection -ComputerName <public-ip> -Port 990

# Test HTTPS
Invoke-WebRequest -Uri https://<frontdoor-url>.azurefd.net
```

### View Terraform outputs

```powershell
terraform output
terraform output deployment_summary
terraform output public_ip_address
terraform output frontdoor_endpoint_url
```

## Getting Help

### View Terraform logs

```powershell
# Enable debug logging
$env:TF_LOG="DEBUG"
terraform apply
```

### Azure activity logs

```powershell
az monitor activity-log list --resource-group rg-moveit-security
```

### Check Azure service health

https://portal.azure.com/#blade/Microsoft_Azure_Health/AzureHealthBrowseBlade/serviceIssues

## Clean Slate

If all else fails, start fresh:

```powershell
# 1. Destroy everything
terraform destroy -auto-approve

# 2. Remove Terraform files
Remove-Item -Recurse -Force .terraform
Remove-Item terraform.tfstate*
Remove-Item .terraform.lock.hcl
Remove-Item terraform.tfvars
Remove-Item tfplan

# 3. Run deploy again
.\deploy-moveit.ps1
```

## Still Having Issues?

1. Check prerequisites are met:
   - Azure CLI installed
   - Terraform installed
   - MOVEit VM exists and is running
   - You have Contributor permissions

2. Verify manual Terraform works:
   - Create terraform.tfvars manually
   - Run `terraform init`
   - Run `terraform plan`
   - Check for errors

3. Check Azure Portal:
   - Verify resources exist
   - Check resource health
   - Review activity logs
