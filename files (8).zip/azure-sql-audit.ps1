param(
    [int]$DaysToAnalyze = 14,
    [string]$OutputPath = ".\AzureSQLAuditReport_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv",
    [int]$LowUsageThresholdPercent = 25,
    [int]$IdleDaysThreshold = 7
)

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) {
        "ERROR" { "Red" }
        "WARNING" { "Yellow" }
        "SUCCESS" { "Green" }
        default { "White" }
    }
    Write-Host "[$timestamp] [$Level] $Message" -ForegroundColor $color
}

function Get-DTUPricing {
    return @{
        "Basic" = @{ DTU = 5; Price = 4.99 }
        "S0" = @{ DTU = 10; Price = 15.03 }
        "S1" = @{ DTU = 20; Price = 30.05 }
        "S2" = @{ DTU = 50; Price = 75.13 }
        "S3" = @{ DTU = 100; Price = 150.26 }
        "S4" = @{ DTU = 200; Price = 300.52 }
        "S6" = @{ DTU = 400; Price = 601.03 }
        "S7" = @{ DTU = 800; Price = 1202.06 }
        "S9" = @{ DTU = 1600; Price = 2404.13 }
        "S12" = @{ DTU = 3000; Price = 4507.74 }
        "P1" = @{ DTU = 125; Price = 465.00 }
        "P2" = @{ DTU = 250; Price = 930.00 }
        "P4" = @{ DTU = 500; Price = 1860.00 }
        "P6" = @{ DTU = 1000; Price = 3720.00 }
        "P11" = @{ DTU = 1750; Price = 6510.75 }
        "P15" = @{ DTU = 4000; Price = 14880.00 }
    }
}

function Get-RecommendedTier {
    param(
        [double]$AvgDTUPercent,
        [double]$MaxDTUPercent,
        [int]$CurrentDTU
    )
    
    $pricing = Get-DTUPricing
    $neededDTU = [math]::Ceiling(($MaxDTUPercent / 100) * $CurrentDTU * 1.2)
    $sortedTiers = $pricing.GetEnumerator() | Sort-Object { $_.Value.DTU }
    
    foreach ($tier in $sortedTiers) {
        if ($tier.Value.DTU -ge $neededDTU) {
            return @{
                Tier = $tier.Key
                DTU = $tier.Value.DTU
                Price = $tier.Value.Price
            }
        }
    }
    
    return $sortedTiers[-1].Value
}

function Get-CurrentTierPrice {
    param([string]$ServiceObjective)
    
    $pricing = Get-DTUPricing
    
    if ($pricing.ContainsKey($ServiceObjective)) {
        return $pricing[$ServiceObjective].Price
    }
    
    if ($ServiceObjective -match "GP_Gen5_(\d+)") {
        $cores = [int]$Matches[1]
        return $cores * 145
    }
    
    return 0
}

Write-Log "Azure SQL Database Cost Optimization Audit" "INFO"
Write-Log "Analysis Period: Last $DaysToAnalyze days" "INFO"
Write-Log "Low Usage Threshold: $LowUsageThresholdPercent percent" "INFO"
Write-Log "Idle Days Threshold: $IdleDaysThreshold days" "INFO"

if (-not (Get-Module -ListAvailable -Name Az.Sql)) {
    Write-Log "Az.Sql module not found. Installing..." "WARNING"
    Install-Module -Name Az.Sql -Scope CurrentUser -Force
}

try {
    $context = Get-AzContext
    if (-not $context) {
        Write-Log "Not connected to Azure. Initiating login..." "WARNING"
        Connect-AzAccount
    } else {
        Write-Log "Connected as: $($context.Account.Id)" "SUCCESS"
    }
} catch {
    Write-Log "Failed to connect to Azure: $_" "ERROR"
    exit 1
}

$subscriptions = Get-AzSubscription | Where-Object { $_.State -eq "Enabled" }
Write-Log "Found $($subscriptions.Count) enabled subscriptions" "INFO"

$allResults = @()
$totalCurrentSpend = 0
$totalPotentialSavings = 0
$endTime = Get-Date
$startTime = $endTime.AddDays(-$DaysToAnalyze)

foreach ($subscription in $subscriptions) {
    Write-Log "Processing subscription: $($subscription.Name)" "INFO"
    
    try {
        Set-AzContext -SubscriptionId $subscription.Id -ErrorAction Stop | Out-Null
    } catch {
        Write-Log "Failed to set context for subscription $($subscription.Name): $_" "ERROR"
        continue
    }
    
    $sqlServers = Get-AzSqlServer -ErrorAction SilentlyContinue
    
    if (-not $sqlServers) {
        Write-Log "No SQL servers found in this subscription" "INFO"
        continue
    }
    
    Write-Log "Found $($sqlServers.Count) SQL servers" "INFO"
    
    foreach ($server in $sqlServers) {
        Write-Log "Processing server: $($server.ServerName)" "INFO"
        
        $databases = Get-AzSqlDatabase -ServerName $server.ServerName -ResourceGroupName $server.ResourceGroupName | 
                     Where-Object { $_.DatabaseName -ne "master" }
        
        foreach ($db in $databases) {
            Write-Log "Analyzing database: $($db.DatabaseName)" "INFO"
            
            $dbResult = [PSCustomObject]@{
                SubscriptionName = $subscription.Name
                SubscriptionId = $subscription.Id
                ResourceGroup = $server.ResourceGroupName
                ServerName = $server.ServerName
                DatabaseName = $db.DatabaseName
                Location = $db.Location
                Edition = $db.Edition
                ServiceObjective = $db.CurrentServiceObjectiveName
                MaxSizeGB = [math]::Round($db.MaxSizeBytes / 1GB, 2)
                CurrentDTU = 0
                Status = $db.Status
                CreationDate = $db.CreationDate
                EarliestRestoreDate = $db.EarliestRestoreDate
                AvgDTUPercent = 0
                MaxDTUPercent = 0
                AvgCPUPercent = 0
                MaxCPUPercent = 0
                AvgDataIOPercent = 0
                AvgLogIOPercent = 0
                ConnectionCount = 0
                FailedConnections = 0
                DeadlockCount = 0
                StorageUsedGB = 0
                StoragePercent = 0
                LastActivityDate = $null
                DaysSinceActivity = $null
                CurrentMonthlyCost = 0
                RecommendedTier = ""
                RecommendedDTU = 0
                RecommendedCost = 0
                PotentialSavings = 0
                SavingsPercent = 0
                StatusFlag = "Normal"
                Recommendation = ""
            }
            
            $pricing = Get-DTUPricing
            if ($pricing.ContainsKey($db.CurrentServiceObjectiveName)) {
                $dbResult.CurrentDTU = $pricing[$db.CurrentServiceObjectiveName].DTU
            }
            
            $dbResult.CurrentMonthlyCost = Get-CurrentTierPrice -ServiceObjective $db.CurrentServiceObjectiveName
            
            try {
                $dtuMetrics = Get-AzMetric -ResourceId $db.ResourceId `
                    -MetricName "dtu_consumption_percent" `
                    -StartTime $startTime `
                    -EndTime $endTime `
                    -AggregationType Average `
                    -TimeGrain 01:00:00 `
                    -ErrorAction SilentlyContinue
                
                if ($dtuMetrics.Data) {
                    $dtuValues = $dtuMetrics.Data | Where-Object { $null -ne $_.Average }
                    if ($dtuValues) {
                        $dbResult.AvgDTUPercent = [math]::Round(($dtuValues | Measure-Object -Property Average -Average).Average, 2)
                        $dbResult.MaxDTUPercent = [math]::Round(($dtuValues | Measure-Object -Property Average -Maximum).Maximum, 2)
                    }
                }
                
                $cpuMetrics = Get-AzMetric -ResourceId $db.ResourceId `
                    -MetricName "cpu_percent" `
                    -StartTime $startTime `
                    -EndTime $endTime `
                    -AggregationType Average `
                    -TimeGrain 01:00:00 `
                    -ErrorAction SilentlyContinue
                
                if ($cpuMetrics.Data) {
                    $cpuValues = $cpuMetrics.Data | Where-Object { $null -ne $_.Average }
                    if ($cpuValues) {
                        $dbResult.AvgCPUPercent = [math]::Round(($cpuValues | Measure-Object -Property Average -Average).Average, 2)
                        $dbResult.MaxCPUPercent = [math]::Round(($cpuValues | Measure-Object -Property Average -Maximum).Maximum, 2)
                    }
                }
                
                $connMetrics = Get-AzMetric -ResourceId $db.ResourceId `
                    -MetricName "connection_successful" `
                    -StartTime $startTime `
                    -EndTime $endTime `
                    -AggregationType Total `
                    -TimeGrain 1.00:00:00 `
                    -ErrorAction SilentlyContinue
                
                if ($connMetrics.Data) {
                    $connValues = $connMetrics.Data | Where-Object { $null -ne $_.Total }
                    if ($connValues) {
                        $dbResult.ConnectionCount = ($connValues | Measure-Object -Property Total -Sum).Sum
                        
                        $lastActivity = $connValues | Where-Object { $_.Total -gt 0 } | 
                                       Sort-Object TimeStamp -Descending | 
                                       Select-Object -First 1
                        if ($lastActivity) {
                            $dbResult.LastActivityDate = $lastActivity.TimeStamp
                            $dbResult.DaysSinceActivity = [math]::Round(($endTime - $lastActivity.TimeStamp).TotalDays, 0)
                        }
                    }
                }
                
                $failedMetrics = Get-AzMetric -ResourceId $db.ResourceId `
                    -MetricName "connection_failed" `
                    -StartTime $startTime `
                    -EndTime $endTime `
                    -AggregationType Total `
                    -TimeGrain 01:00:00 `
                    -ErrorAction SilentlyContinue
                
                if ($failedMetrics.Data) {
                    $failedValues = $failedMetrics.Data | Where-Object { $null -ne $_.Total }
                    if ($failedValues) {
                        $dbResult.FailedConnections = ($failedValues | Measure-Object -Property Total -Sum).Sum
                    }
                }
                
                $storageMetrics = Get-AzMetric -ResourceId $db.ResourceId `
                    -MetricName "storage_percent" `
                    -StartTime $startTime `
                    -EndTime $endTime `
                    -AggregationType Average `
                    -TimeGrain 01:00:00 `
                    -ErrorAction SilentlyContinue
                
                if ($storageMetrics.Data) {
                    $storageValues = $storageMetrics.Data | Where-Object { $null -ne $_.Average }
                    if ($storageValues) {
                        $dbResult.StoragePercent = [math]::Round(($storageValues | Measure-Object -Property Average -Average).Average, 2)
                        $dbResult.StorageUsedGB = [math]::Round(($dbResult.StoragePercent / 100) * $dbResult.MaxSizeGB, 2)
                    }
                }
                
            } catch {
                Write-Log "Error getting metrics for $($db.DatabaseName): $_" "WARNING"
            }
            
            if ($dbResult.CurrentDTU -gt 0 -and $dbResult.MaxDTUPercent -gt 0) {
                $recommended = Get-RecommendedTier -AvgDTUPercent $dbResult.AvgDTUPercent `
                                                   -MaxDTUPercent $dbResult.MaxDTUPercent `
                                                   -CurrentDTU $dbResult.CurrentDTU
                
                $dbResult.RecommendedTier = $recommended.Tier
                $dbResult.RecommendedDTU = $recommended.DTU
                $dbResult.RecommendedCost = $recommended.Price
                $dbResult.PotentialSavings = [math]::Round($dbResult.CurrentMonthlyCost - $recommended.Price, 2)
                
                if ($dbResult.CurrentMonthlyCost -gt 0) {
                    $dbResult.SavingsPercent = [math]::Round(($dbResult.PotentialSavings / $dbResult.CurrentMonthlyCost) * 100, 0)
                }
            }
            
            if ($null -ne $dbResult.DaysSinceActivity -and $dbResult.DaysSinceActivity -ge $IdleDaysThreshold) {
                $dbResult.StatusFlag = "IDLE"
                $dbResult.Recommendation = "Database has no connections for $($dbResult.DaysSinceActivity) days. Consider decommissioning or pausing."
            } elseif ($dbResult.AvgDTUPercent -lt $LowUsageThresholdPercent -and $dbResult.MaxDTUPercent -lt 50) {
                $dbResult.StatusFlag = "UNDERUTILIZED"
                $dbResult.Recommendation = "Avg DTU: $($dbResult.AvgDTUPercent) percent, Max: $($dbResult.MaxDTUPercent) percent. Consider downgrading to $($dbResult.RecommendedTier)."
            } elseif ($dbResult.ConnectionCount -eq 0) {
                $dbResult.StatusFlag = "NO CONNECTIONS"
                $dbResult.Recommendation = "Zero connections in analysis period. Verify if database is needed."
            } elseif ($dbResult.PotentialSavings -gt 100) {
                $dbResult.StatusFlag = "OVERSIZED"
                $dbResult.Recommendation = "Can save $($dbResult.PotentialSavings) per month by moving to $($dbResult.RecommendedTier)."
            } else {
                $dbResult.StatusFlag = "OK"
                $dbResult.Recommendation = "Database is appropriately sized."
            }
            
            $allResults += $dbResult
            $totalCurrentSpend += $dbResult.CurrentMonthlyCost
            if ($dbResult.PotentialSavings -gt 0) {
                $totalPotentialSavings += $dbResult.PotentialSavings
            }
        }
    }
}

Write-Log "AUDIT COMPLETE" "SUCCESS"
Write-Log "Total Databases Analyzed: $($allResults.Count)" "INFO"
Write-Log "Total Current Monthly Spend: $([math]::Round($totalCurrentSpend, 2))" "INFO"
Write-Log "Total Potential Monthly Savings: $([math]::Round($totalPotentialSavings, 2))" "SUCCESS"
Write-Log "Potential Annual Savings: $([math]::Round($totalPotentialSavings * 12, 2))" "SUCCESS"

$statusSummary = $allResults | Group-Object StatusFlag
Write-Log "Summary by Status:" "INFO"
foreach ($status in $statusSummary) {
    Write-Log "$($status.Name): $($status.Count) databases" "INFO"
}

$allResults | Export-Csv -Path $OutputPath -NoTypeInformation
Write-Log "Detailed report exported to: $OutputPath" "SUCCESS"

$topSavings = $allResults | Where-Object { $_.PotentialSavings -gt 0 } | 
              Sort-Object PotentialSavings -Descending | 
              Select-Object -First 10

if ($topSavings) {
    Write-Log "Top 10 Savings Opportunities:" "INFO"
    
    foreach ($db in $topSavings) {
        Write-Log "$($db.ServerName)/$($db.DatabaseName)" "WARNING"
        Write-Log "Current: $($db.ServiceObjective) ($($db.CurrentMonthlyCost) per month) Avg DTU: $($db.AvgDTUPercent) percent Max DTU: $($db.MaxDTUPercent) percent" "INFO"
        Write-Log "Recommended: $($db.RecommendedTier) ($($db.RecommendedCost) per month)" "INFO"
        Write-Log "Potential Savings: $($db.PotentialSavings) per month ($([math]::Round($db.PotentialSavings * 12, 2)) per year)" "SUCCESS"
    }
}

$idleDbs = $allResults | Where-Object { $_.StatusFlag -eq "IDLE" }
if ($idleDbs) {
    Write-Log "Idle Databases (No Activity in $IdleDaysThreshold or more days):" "WARNING"
    foreach ($db in $idleDbs) {
        Write-Log "$($db.ServerName)/$($db.DatabaseName) - Last activity: $($db.DaysSinceActivity) days ago - Cost: $($db.CurrentMonthlyCost) per month" "WARNING"
    }
}

$noConnDbs = $allResults | Where-Object { $_.StatusFlag -eq "NO CONNECTIONS" }
if ($noConnDbs) {
    Write-Log "Databases with Zero Connections:" "WARNING"
    foreach ($db in $noConnDbs) {
        Write-Log "$($db.ServerName)/$($db.DatabaseName) - Cost: $($db.CurrentMonthlyCost) per month" "WARNING"
    }
}

Write-Log "Script completed successfully" "SUCCESS"

return $allResults
