# Azure SQL Database Cost Optimization Audit

Audit all Azure SQL databases across subscriptions and identify cost-saving opportunities.

## What This Does

- Scans all subscriptions for Azure SQL databases
- Analyzes DTU and CPU utilization over the past 14 days
- Identifies underutilized databases (candidates for tier reduction)
- Flags idle databases with no connections
- Calculates potential savings with recommendations
- Generates detailed reports (CSV and HTML dashboard)

## Quick Start

### PowerShell (Windows)

```powershell
Connect-AzAccount
.\azure-sql-audit.ps1
.\Generate-SQLAuditReport.ps1 -CsvPath ".\AzureSQLAuditReport_YYYYMMDD.csv"
```

### Azure CLI (Linux/Mac/Windows)

```bash
az login
chmod +x azure-sql-audit-cli.sh
./azure-sql-audit-cli.sh
```

## Parameters

### PowerShell Script

| Parameter | Default | Description |
|-----------|---------|-------------|
| DaysToAnalyze | 14 | Number of days of metrics to analyze |
| LowUsageThresholdPercent | 25 | Flag DBs using less than this percent of DTU |
| IdleDaysThreshold | 7 | Flag DBs with no connections for X days |
| OutputPath | Auto-generated | Custom output CSV path |

Example with custom parameters:

```powershell
.\azure-sql-audit.ps1 -DaysToAnalyze 30 -LowUsageThresholdPercent 20
```

## Output

### CSV Report Columns

| Column | Description |
|--------|-------------|
| SubscriptionName | Azure subscription name |
| ServerName | SQL Server name |
| DatabaseName | Database name |
| ServiceObjective | Current tier (S0, S7, P1, etc.) |
| CurrentDTU | DTUs allocated |
| AvgDTUPercent | Average DTU usage percent |
| MaxDTUPercent | Peak DTU usage percent |
| ConnectionCount | Total connections in period |
| CurrentMonthlyCost | Estimated monthly cost |
| RecommendedTier | Suggested tier |
| PotentialSavings | Monthly savings if optimized |
| StatusFlag | OK, UNDERUTILIZED, IDLE, NO CONNECTIONS |
| Recommendation | Actionable suggestion |

## Status Flags

| Flag | Meaning | Action |
|------|---------|--------|
| OK | Database is appropriately sized | No action needed |
| UNDERUTILIZED | Avg DTU below 25 percent, Max below 50 percent | Consider downgrading tier |
| IDLE | No connections for 7 or more days | Review if needed, consider pausing |
| NO CONNECTIONS | Zero connections in analysis period | May be candidate for removal |
| OVERSIZED | Can save 100 or more per month | Strong candidate for tier reduction |

## Sample Savings

| Downgrade | Monthly Savings |
|-----------|-----------------|
| S7 (800 DTU) to S6 (400 DTU) | 600 per month |
| S9 (1600 DTU) to S7 (800 DTU) | 1200 per month |
| P6 (1000 DTU) to P4 (500 DTU) | 1860 per month |

## Prerequisites

### PowerShell

```powershell
Install-Module -Name Az -Scope CurrentUser -Force
```

### Azure CLI

```bash
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
sudo apt-get install jq
```

## Schedule Regular Audits

### Windows Task Scheduler

```powershell
$action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-File C:\Scripts\azure-sql-audit.ps1"
$trigger = New-ScheduledTaskTrigger -Monthly -At 9am
Register-ScheduledTask -TaskName "AzureSQLAudit" -Action $action -Trigger $trigger
```

### Linux Cron

```bash
0 9 1 * * /path/to/azure-sql-audit-cli.sh >> /var/log/sql-audit.log 2>&1
```
