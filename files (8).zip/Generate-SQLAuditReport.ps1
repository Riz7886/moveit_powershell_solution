param(
    [Parameter(Mandatory=$true)]
    [string]$CsvPath,
    [string]$OutputPath = ".\AzureSQLAuditReport.html"
)

$data = Import-Csv -Path $CsvPath

$totalDatabases = $data.Count
$totalCurrentSpend = ($data | Measure-Object -Property CurrentMonthlyCost -Sum).Sum
$totalPotentialSavings = ($data | Where-Object { [double]$_.PotentialSavings -gt 0 } | Measure-Object -Property PotentialSavings -Sum).Sum
$underutilizedCount = ($data | Where-Object { $_.StatusFlag -eq "UNDERUTILIZED" }).Count
$idleCount = ($data | Where-Object { $_.StatusFlag -eq "IDLE" }).Count
$noConnCount = ($data | Where-Object { $_.StatusFlag -eq "NO CONNECTIONS" }).Count
$okCount = ($data | Where-Object { $_.StatusFlag -eq "OK" }).Count

$topSavings = $data | Where-Object { [double]$_.PotentialSavings -gt 0 } | 
              Sort-Object { [double]$_.PotentialSavings } -Descending | 
              Select-Object -First 10

$html = @"
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Azure SQL Database Cost Optimization Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Segoe UI, Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 20px; }
        .container { max-width: 1600px; margin: 0 auto; }
        .header { background: white; border-radius: 15px; padding: 30px; margin-bottom: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); }
        .header h1 { color: #333; font-size: 2.5em; margin-bottom: 10px; }
        .header p { color: #666; font-size: 1.1em; }
        .summary-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 20px; }
        .card { background: white; border-radius: 15px; padding: 25px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); transition: transform 0.3s ease; }
        .card:hover { transform: translateY(-5px); }
        .card h3 { color: #888; font-size: 0.9em; text-transform: uppercase; margin-bottom: 10px; }
        .card .value { font-size: 2.5em; font-weight: bold; color: #333; }
        .card.savings .value { color: #10b981; }
        .card.warning .value { color: #f59e0b; }
        .card.danger .value { color: #ef4444; }
        .card .subtext { color: #888; font-size: 0.9em; margin-top: 5px; }
        .charts-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; margin-bottom: 20px; }
        .chart-card { background: white; border-radius: 15px; padding: 25px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); }
        .chart-card h2 { color: #333; margin-bottom: 20px; font-size: 1.3em; }
        .table-card { background: white; border-radius: 15px; padding: 25px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); margin-bottom: 20px; overflow-x: auto; }
        .table-card h2 { color: #333; margin-bottom: 20px; font-size: 1.3em; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f9fa; font-weight: 600; color: #555; position: sticky; top: 0; }
        tr:hover { background: #f8f9fa; }
        .status-badge { padding: 5px 12px; border-radius: 20px; font-size: 0.85em; font-weight: 500; }
        .status-ok { background: #d1fae5; color: #065f46; }
        .status-warning { background: #fef3c7; color: #92400e; }
        .status-danger { background: #fee2e2; color: #991b1b; }
        .savings-amount { color: #10b981; font-weight: bold; }
        .location-badge { background: #e0e7ff; color: #3730a3; padding: 4px 10px; border-radius: 12px; font-size: 0.85em; }
        .progress-bar { background: #e5e7eb; border-radius: 10px; height: 8px; overflow: hidden; }
        .progress-fill { height: 100%; border-radius: 10px; transition: width 0.3s ease; }
        .progress-low { background: #10b981; }
        .progress-medium { background: #f59e0b; }
        .progress-high { background: #ef4444; }
        .footer { text-align: center; color: white; padding: 20px; opacity: 0.8; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Azure SQL Database Cost Optimization Report</h1>
            <p>Generated on $(Get-Date -Format "MMMM dd, yyyy 'at' HH:mm") - Analysis Period: Last 14 days</p>
        </div>

        <div class="summary-cards">
            <div class="card">
                <h3>Total Databases</h3>
                <div class="value">$totalDatabases</div>
                <div class="subtext">Across all subscriptions</div>
            </div>
            <div class="card">
                <h3>Current Monthly Spend</h3>
                <div class="value">`$$([math]::Round($totalCurrentSpend, 0).ToString("N0"))</div>
                <div class="subtext">Estimated from DTU pricing</div>
            </div>
            <div class="card savings">
                <h3>Potential Monthly Savings</h3>
                <div class="value">`$$([math]::Round($totalPotentialSavings, 0).ToString("N0"))</div>
                <div class="subtext">`$$([math]::Round($totalPotentialSavings * 12, 0).ToString("N0")) per year</div>
            </div>
            <div class="card warning">
                <h3>Underutilized</h3>
                <div class="value">$underutilizedCount</div>
                <div class="subtext">Low DTU usage</div>
            </div>
            <div class="card danger">
                <h3>Idle or No Connections</h3>
                <div class="value">$($idleCount + $noConnCount)</div>
                <div class="subtext">May be candidates for removal</div>
            </div>
        </div>

        <div class="charts-row">
            <div class="chart-card">
                <h2>Database Status Distribution</h2>
                <canvas id="statusChart"></canvas>
            </div>
            <div class="chart-card">
                <h2>Current Spend vs Potential Savings</h2>
                <canvas id="savingsChart"></canvas>
            </div>
        </div>

        <div class="table-card">
            <h2>Top 10 Cost Savings Opportunities</h2>
            <table>
                <thead>
                    <tr>
                        <th>Database</th>
                        <th>Server</th>
                        <th>Location</th>
                        <th>Current Tier</th>
                        <th>Recommended</th>
                        <th>Avg DTU</th>
                        <th>Max DTU</th>
                        <th>Current Cost</th>
                        <th>Potential Savings</th>
                    </tr>
                </thead>
                <tbody>
"@

foreach ($db in $topSavings) {
    $dtuClass = if ([double]$db.AvgDTUPercent -lt 10) { "progress-low" } elseif ([double]$db.AvgDTUPercent -lt 25) { "progress-medium" } else { "progress-high" }
    $html += @"
                    <tr>
                        <td><strong>$($db.DatabaseName)</strong></td>
                        <td>$($db.ServerName)</td>
                        <td><span class="location-badge">$($db.Location)</span></td>
                        <td>$($db.ServiceObjective) ($($db.CurrentDTU) DTU)</td>
                        <td>$($db.RecommendedTier) ($($db.RecommendedDTU) DTU)</td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div class="progress-bar" style="width: 60px;">
                                    <div class="progress-fill $dtuClass" style="width: $([math]::Min([double]$db.AvgDTUPercent, 100))%;"></div>
                                </div>
                                $($db.AvgDTUPercent) percent
                            </div>
                        </td>
                        <td>$($db.MaxDTUPercent) percent</td>
                        <td>`$$([math]::Round([double]$db.CurrentMonthlyCost, 0)) per month</td>
                        <td class="savings-amount">`$$([math]::Round([double]$db.PotentialSavings, 0)) per month</td>
                    </tr>
"@
}

$html += @"
                </tbody>
            </table>
        </div>

        <div class="table-card">
            <h2>All Databases</h2>
            <table>
                <thead>
                    <tr>
                        <th>Subscription</th>
                        <th>Server</th>
                        <th>Database</th>
                        <th>Location</th>
                        <th>Tier</th>
                        <th>Avg DTU</th>
                        <th>Connections</th>
                        <th>Status</th>
                        <th>Monthly Cost</th>
                        <th>Recommendation</th>
                    </tr>
                </thead>
                <tbody>
"@

foreach ($db in ($data | Sort-Object { [double]$_.PotentialSavings } -Descending)) {
    $statusClass = switch ($db.StatusFlag) {
        "OK" { "status-ok" }
        "UNDERUTILIZED" { "status-warning" }
        "OVERSIZED" { "status-warning" }
        default { "status-danger" }
    }
    $html += @"
                    <tr>
                        <td>$($db.SubscriptionName)</td>
                        <td>$($db.ServerName)</td>
                        <td><strong>$($db.DatabaseName)</strong></td>
                        <td><span class="location-badge">$($db.Location)</span></td>
                        <td>$($db.ServiceObjective)</td>
                        <td>$($db.AvgDTUPercent) percent</td>
                        <td>$($db.ConnectionCount)</td>
                        <td><span class="status-badge $statusClass">$($db.StatusFlag)</span></td>
                        <td>`$$([math]::Round([double]$db.CurrentMonthlyCost, 0))</td>
                        <td><small>$($db.Recommendation)</small></td>
                    </tr>
"@
}

$html += @"
                </tbody>
            </table>
        </div>

        <div class="footer">
            <p>Azure SQL Cost Optimization Audit</p>
        </div>
    </div>

    <script>
        new Chart(document.getElementById('statusChart'), {
            type: 'doughnut',
            data: {
                labels: ['OK', 'Underutilized', 'Idle', 'No Connections'],
                datasets: [{
                    data: [$okCount, $underutilizedCount, $idleCount, $noConnCount],
                    backgroundColor: ['#10b981', '#f59e0b', '#ef4444', '#8b5cf6'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        new Chart(document.getElementById('savingsChart'), {
            type: 'bar',
            data: {
                labels: ['Current Spend', 'After Optimization'],
                datasets: [{
                    label: 'Monthly Cost',
                    data: [$([math]::Round($totalCurrentSpend, 0)), $([math]::Round($totalCurrentSpend - $totalPotentialSavings, 0))],
                    backgroundColor: ['#ef4444', '#10b981'],
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
"@

$html | Out-File -FilePath $OutputPath -Encoding UTF8
Write-Host "HTML Report generated: $OutputPath" -ForegroundColor Green
