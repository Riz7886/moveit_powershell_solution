#!/bin/bash

DAYS_TO_ANALYZE=${1:-14}
OUTPUT_FILE=${2:-"azure_sql_audit_$(date +%Y%m%d_%H%M%S).csv"}
LOW_USAGE_THRESHOLD=25
IDLE_DAYS_THRESHOLD=7

declare -A DTU_PRICING
DTU_PRICING["Basic"]="5:4.99"
DTU_PRICING["S0"]="10:15.03"
DTU_PRICING["S1"]="20:30.05"
DTU_PRICING["S2"]="50:75.13"
DTU_PRICING["S3"]="100:150.26"
DTU_PRICING["S4"]="200:300.52"
DTU_PRICING["S6"]="400:601.03"
DTU_PRICING["S7"]="800:1202.06"
DTU_PRICING["S9"]="1600:2404.13"
DTU_PRICING["S12"]="3000:4507.74"
DTU_PRICING["P1"]="125:465.00"
DTU_PRICING["P2"]="250:930.00"
DTU_PRICING["P4"]="500:1860.00"
DTU_PRICING["P6"]="1000:3720.00"
DTU_PRICING["P11"]="1750:6510.75"
DTU_PRICING["P15"]="4000:14880.00"

log() {
    local level=$1
    local message=$2
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] [$level] $message"
}

get_price_for_tier() {
    local tier=$1
    local pricing=${DTU_PRICING[$tier]}
    if [[ -n "$pricing" ]]; then
        echo "$pricing" | cut -d: -f2
    else
        echo "0"
    fi
}

get_dtu_for_tier() {
    local tier=$1
    local pricing=${DTU_PRICING[$tier]}
    if [[ -n "$pricing" ]]; then
        echo "$pricing" | cut -d: -f1
    else
        echo "0"
    fi
}

check_prerequisites() {
    if ! command -v az &> /dev/null; then
        log "ERROR" "Azure CLI is not installed. Please install it first."
        exit 1
    fi
    
    if ! command -v jq &> /dev/null; then
        log "ERROR" "jq is not installed. Please install it: sudo apt-get install jq"
        exit 1
    fi
    
    if ! az account show &> /dev/null; then
        log "WARNING" "Not logged in to Azure. Running az login..."
        az login
    fi
}

log "INFO" "Azure SQL Database Cost Optimization Audit"
log "INFO" "Analysis Period: Last $DAYS_TO_ANALYZE days"
log "INFO" "Output File: $OUTPUT_FILE"

check_prerequisites

ACCOUNT_INFO=$(az account show)
log "SUCCESS" "Logged in as: $(echo $ACCOUNT_INFO | jq -r '.user.name')"

END_TIME=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
START_TIME=$(date -u -d "$DAYS_TO_ANALYZE days ago" +"%Y-%m-%dT%H:%M:%SZ")

echo "SubscriptionName,SubscriptionId,ResourceGroup,ServerName,DatabaseName,Location,Edition,ServiceObjective,MaxSizeGB,CurrentDTU,Status,AvgDTUPercent,MaxDTUPercent,AvgCPUPercent,ConnectionCount,StoragePercent,CurrentMonthlyCost,RecommendedTier,PotentialSavings,StatusFlag,Recommendation" > "$OUTPUT_FILE"

SUBSCRIPTIONS=$(az account list --query "[?state=='Enabled']" -o json)
SUB_COUNT=$(echo "$SUBSCRIPTIONS" | jq length)
log "INFO" "Found $SUB_COUNT enabled subscriptions"

echo "$SUBSCRIPTIONS" | jq -c '.[]' | while read -r sub; do
    SUB_NAME=$(echo "$sub" | jq -r '.name')
    SUB_ID=$(echo "$sub" | jq -r '.id')
    
    log "INFO" "Processing subscription: $SUB_NAME"
    az account set --subscription "$SUB_ID"
    
    SERVERS=$(az sql server list -o json 2>/dev/null || echo "[]")
    SERVER_COUNT=$(echo "$SERVERS" | jq length)
    
    if [[ "$SERVER_COUNT" -eq 0 ]]; then
        log "INFO" "No SQL servers found in this subscription"
        continue
    fi
    
    log "INFO" "Found $SERVER_COUNT SQL servers"
    
    echo "$SERVERS" | jq -c '.[]' | while read -r server; do
        SERVER_NAME=$(echo "$server" | jq -r '.name')
        SERVER_RG=$(echo "$server" | jq -r '.resourceGroup')
        
        log "INFO" "Processing server: $SERVER_NAME"
        
        DATABASES=$(az sql db list --server "$SERVER_NAME" --resource-group "$SERVER_RG" -o json 2>/dev/null || echo "[]")
        
        echo "$DATABASES" | jq -c '.[] | select(.name != "master")' | while read -r db; do
            DB_NAME=$(echo "$db" | jq -r '.name')
            DB_LOCATION=$(echo "$db" | jq -r '.location')
            DB_EDITION=$(echo "$db" | jq -r '.edition // "Unknown"')
            DB_SKU=$(echo "$db" | jq -r '.currentServiceObjectiveName // "Unknown"')
            DB_STATUS=$(echo "$db" | jq -r '.status')
            DB_MAX_SIZE=$(echo "$db" | jq -r '.maxSizeBytes // 0')
            DB_MAX_SIZE_GB=$(echo "scale=2; $DB_MAX_SIZE / 1073741824" | bc)
            DB_RESOURCE_ID=$(echo "$db" | jq -r '.id')
            
            log "INFO" "Analyzing database: $DB_NAME"
            
            CURRENT_DTU=$(get_dtu_for_tier "$DB_SKU")
            CURRENT_COST=$(get_price_for_tier "$DB_SKU")
            
            AVG_DTU=0
            MAX_DTU=0
            if [[ "$DB_STATUS" == "Online" ]]; then
                DTU_METRICS=$(az monitor metrics list \
                    --resource "$DB_RESOURCE_ID" \
                    --metric "dtu_consumption_percent" \
                    --start-time "$START_TIME" \
                    --end-time "$END_TIME" \
                    --interval PT1H \
                    --aggregation Average \
                    -o json 2>/dev/null || echo "{}")
                
                if [[ -n "$DTU_METRICS" ]] && [[ "$DTU_METRICS" != "{}" ]]; then
                    AVG_DTU=$(echo "$DTU_METRICS" | jq '[.value[0].timeseries[0].data[].average // 0] | add / length' 2>/dev/null || echo "0")
                    MAX_DTU=$(echo "$DTU_METRICS" | jq '[.value[0].timeseries[0].data[].average // 0] | max' 2>/dev/null || echo "0")
                fi
            fi
            
            AVG_CPU=0
            if [[ "$DB_STATUS" == "Online" ]]; then
                CPU_METRICS=$(az monitor metrics list \
                    --resource "$DB_RESOURCE_ID" \
                    --metric "cpu_percent" \
                    --start-time "$START_TIME" \
                    --end-time "$END_TIME" \
                    --interval PT1H \
                    --aggregation Average \
                    -o json 2>/dev/null || echo "{}")
                
                if [[ -n "$CPU_METRICS" ]] && [[ "$CPU_METRICS" != "{}" ]]; then
                    AVG_CPU=$(echo "$CPU_METRICS" | jq '[.value[0].timeseries[0].data[].average // 0] | add / length' 2>/dev/null || echo "0")
                fi
            fi
            
            CONN_COUNT=0
            if [[ "$DB_STATUS" == "Online" ]]; then
                CONN_METRICS=$(az monitor metrics list \
                    --resource "$DB_RESOURCE_ID" \
                    --metric "connection_successful" \
                    --start-time "$START_TIME" \
                    --end-time "$END_TIME" \
                    --interval P1D \
                    --aggregation Total \
                    -o json 2>/dev/null || echo "{}")
                
                if [[ -n "$CONN_METRICS" ]] && [[ "$CONN_METRICS" != "{}" ]]; then
                    CONN_COUNT=$(echo "$CONN_METRICS" | jq '[.value[0].timeseries[0].data[].total // 0] | add' 2>/dev/null || echo "0")
                fi
            fi
            
            STORAGE_PCT=0
            if [[ "$DB_STATUS" == "Online" ]]; then
                STORAGE_METRICS=$(az monitor metrics list \
                    --resource "$DB_RESOURCE_ID" \
                    --metric "storage_percent" \
                    --start-time "$START_TIME" \
                    --end-time "$END_TIME" \
                    --interval PT1H \
                    --aggregation Average \
                    -o json 2>/dev/null || echo "{}")
                
                if [[ -n "$STORAGE_METRICS" ]] && [[ "$STORAGE_METRICS" != "{}" ]]; then
                    STORAGE_PCT=$(echo "$STORAGE_METRICS" | jq '[.value[0].timeseries[0].data[].average // 0] | add / length' 2>/dev/null || echo "0")
                fi
            fi
            
            AVG_DTU=$(printf "%.2f" "${AVG_DTU:-0}")
            MAX_DTU=$(printf "%.2f" "${MAX_DTU:-0}")
            AVG_CPU=$(printf "%.2f" "${AVG_CPU:-0}")
            STORAGE_PCT=$(printf "%.2f" "${STORAGE_PCT:-0}")
            CONN_COUNT=$(printf "%.0f" "${CONN_COUNT:-0}")
            
            RECOMMENDED_TIER="$DB_SKU"
            POTENTIAL_SAVINGS=0
            STATUS_FLAG="OK"
            RECOMMENDATION="Database is appropriately sized"
            
            if (( $(echo "$AVG_DTU < $LOW_USAGE_THRESHOLD" | bc -l) )) && (( $(echo "$MAX_DTU < 50" | bc -l) )); then
                STATUS_FLAG="UNDERUTILIZED"
                RECOMMENDATION="Avg DTU ${AVG_DTU} percent Max ${MAX_DTU} percent. Consider downgrading."
                
                for tier in "Basic" "S0" "S1" "S2" "S3" "S4" "S6" "S7"; do
                    tier_dtu=$(get_dtu_for_tier "$tier")
                    needed_dtu=$(echo "scale=0; $MAX_DTU * $CURRENT_DTU * 1.2 / 100" | bc)
                    if (( tier_dtu >= needed_dtu )); then
                        RECOMMENDED_TIER="$tier"
                        break
                    fi
                done
                
                REC_COST=$(get_price_for_tier "$RECOMMENDED_TIER")
                POTENTIAL_SAVINGS=$(echo "scale=2; $CURRENT_COST - $REC_COST" | bc)
            fi
            
            if [[ "$CONN_COUNT" -eq 0 ]]; then
                STATUS_FLAG="NO CONNECTIONS"
                RECOMMENDATION="Zero connections in analysis period. Verify if database is needed."
                POTENTIAL_SAVINGS="$CURRENT_COST"
            fi
            
            echo "\"$SUB_NAME\",\"$SUB_ID\",\"$SERVER_RG\",\"$SERVER_NAME\",\"$DB_NAME\",\"$DB_LOCATION\",\"$DB_EDITION\",\"$DB_SKU\",\"$DB_MAX_SIZE_GB\",\"$CURRENT_DTU\",\"$DB_STATUS\",\"$AVG_DTU\",\"$MAX_DTU\",\"$AVG_CPU\",\"$CONN_COUNT\",\"$STORAGE_PCT\",\"$CURRENT_COST\",\"$RECOMMENDED_TIER\",\"$POTENTIAL_SAVINGS\",\"$STATUS_FLAG\",\"$RECOMMENDATION\"" >> "$OUTPUT_FILE"
            
        done
    done
done

log "SUCCESS" "Audit Complete"
log "INFO" "Results exported to: $OUTPUT_FILE"

TOTAL_DBS=$(tail -n +2 "$OUTPUT_FILE" | wc -l)
UNDERUTILIZED=$(grep -c "UNDERUTILIZED" "$OUTPUT_FILE" || echo "0")
NO_CONN=$(grep -c "NO CONNECTIONS" "$OUTPUT_FILE" || echo "0")

log "INFO" "Total Databases Analyzed: $TOTAL_DBS"
log "WARNING" "Underutilized Databases: $UNDERUTILIZED"
log "WARNING" "Databases with No Connections: $NO_CONN"

if command -v awk &> /dev/null; then
    TOTAL_SAVINGS=$(tail -n +2 "$OUTPUT_FILE" | awk -F',' '{sum += $19} END {printf "%.2f", sum}')
    log "SUCCESS" "Total Potential Monthly Savings: $TOTAL_SAVINGS"
    log "SUCCESS" "Total Potential Annual Savings: $(echo "scale=2; $TOTAL_SAVINGS * 12" | bc)"
fi

log "INFO" "Script completed successfully"
