# ================================================================
# BROWSER NUCLEAR CLEANUP - DELETE EVERYTHING
# Removes ALL traces: History, Bookmarks, Downloads, Cache, Cookies
# Works on: Chrome, Edge, Firefox
# ================================================================

Write-Host ""
Write-Host "================================================================" -ForegroundColor Red
Write-Host "  BROWSER NUCLEAR CLEANUP - DELETE EVERYTHING" -ForegroundColor Red
Write-Host "================================================================" -ForegroundColor Red
Write-Host ""
Write-Host "WARNING: This will DELETE:" -ForegroundColor Yellow
Write-Host "  - All browser history" -ForegroundColor Yellow
Write-Host "  - All bookmarks" -ForegroundColor Yellow
Write-Host "  - All downloads history" -ForegroundColor Yellow
Write-Host "  - All cache files" -ForegroundColor Yellow
Write-Host "  - All cookies" -ForegroundColor Yellow
Write-Host "  - All saved passwords" -ForegroundColor Yellow
Write-Host "  - All form data" -ForegroundColor Yellow
Write-Host "  - Recent files list" -ForegroundColor Yellow
Write-Host "  - Temp files" -ForegroundColor Yellow
Write-Host "  - Clipboard" -ForegroundColor Yellow
Write-Host "  - Windows recent items" -ForegroundColor Yellow
Write-Host ""

$confirm = Read-Host "Type YES to confirm deletion of EVERYTHING"
if ($confirm -ne "YES") {
    Write-Host "Cancelled" -ForegroundColor Red
    exit
}

Write-Host ""
Write-Host "Starting nuclear cleanup..." -ForegroundColor Cyan
Write-Host ""

# Close all browsers first
Write-Host "[1/12] Closing all browsers..." -ForegroundColor Yellow
Stop-Process -Name "chrome" -Force -ErrorAction SilentlyContinue
Stop-Process -Name "msedge" -Force -ErrorAction SilentlyContinue
Stop-Process -Name "firefox" -Force -ErrorAction SilentlyContinue
Stop-Process -Name "iexplore" -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
Write-Host "  Browsers closed" -ForegroundColor Green

# ----------------------------------------------------------------
# CHROME CLEANUP
# ----------------------------------------------------------------
Write-Host "[2/12] Deleting Chrome data..." -ForegroundColor Yellow
$chromePath = "$env:LOCALAPPDATA\Google\Chrome\User Data"
if (Test-Path $chromePath) {
    # Delete all profiles
    Get-ChildItem -Path $chromePath -Directory | Where-Object { $_.Name -like "Profile*" -or $_.Name -eq "Default" } | ForEach-Object {
        # History
        Remove-Item "$($_.FullName)\History" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\History-journal" -Force -ErrorAction SilentlyContinue
        # Bookmarks
        Remove-Item "$($_.FullName)\Bookmarks" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Bookmarks.bak" -Force -ErrorAction SilentlyContinue
        # Downloads
        Remove-Item "$($_.FullName)\History" -Force -ErrorAction SilentlyContinue
        # Cache
        Remove-Item "$($_.FullName)\Cache\*" -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Code Cache\*" -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\GPUCache\*" -Recurse -Force -ErrorAction SilentlyContinue
        # Cookies
        Remove-Item "$($_.FullName)\Cookies" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Cookies-journal" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Network\Cookies" -Force -ErrorAction SilentlyContinue
        # Sessions
        Remove-Item "$($_.FullName)\Sessions\*" -Recurse -Force -ErrorAction SilentlyContinue
        # Web Data (form data)
        Remove-Item "$($_.FullName)\Web Data" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Web Data-journal" -Force -ErrorAction SilentlyContinue
        # Login Data (passwords)
        Remove-Item "$($_.FullName)\Login Data" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Login Data-journal" -Force -ErrorAction SilentlyContinue
        # Favicons
        Remove-Item "$($_.FullName)\Favicons" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Favicons-journal" -Force -ErrorAction SilentlyContinue
        # Top Sites
        Remove-Item "$($_.FullName)\Top Sites" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Top Sites-journal" -Force -ErrorAction SilentlyContinue
    }
    Write-Host "  Chrome cleaned" -ForegroundColor Green
} else {
    Write-Host "  Chrome not found" -ForegroundColor Gray
}

# ----------------------------------------------------------------
# EDGE CLEANUP
# ----------------------------------------------------------------
Write-Host "[3/12] Deleting Edge data..." -ForegroundColor Yellow
$edgePath = "$env:LOCALAPPDATA\Microsoft\Edge\User Data"
if (Test-Path $edgePath) {
    Get-ChildItem -Path $edgePath -Directory | Where-Object { $_.Name -like "Profile*" -or $_.Name -eq "Default" } | ForEach-Object {
        Remove-Item "$($_.FullName)\History" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\History-journal" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Bookmarks" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Bookmarks.bak" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Cache\*" -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Code Cache\*" -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\GPUCache\*" -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Cookies" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Cookies-journal" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Sessions\*" -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Web Data" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Web Data-journal" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Login Data" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Login Data-journal" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Favicons" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\Top Sites" -Force -ErrorAction SilentlyContinue
    }
    Write-Host "  Edge cleaned" -ForegroundColor Green
} else {
    Write-Host "  Edge not found" -ForegroundColor Gray
}

# ----------------------------------------------------------------
# FIREFOX CLEANUP
# ----------------------------------------------------------------
Write-Host "[4/12] Deleting Firefox data..." -ForegroundColor Yellow
$firefoxPath = "$env:APPDATA\Mozilla\Firefox\Profiles"
if (Test-Path $firefoxPath) {
    Get-ChildItem -Path $firefoxPath -Directory | ForEach-Object {
        # History
        Remove-Item "$($_.FullName)\places.sqlite" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\places.sqlite-shm" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\places.sqlite-wal" -Force -ErrorAction SilentlyContinue
        # Bookmarks (same file as history in Firefox)
        Remove-Item "$($_.FullName)\bookmarkbackups\*" -Recurse -Force -ErrorAction SilentlyContinue
        # Downloads
        Remove-Item "$($_.FullName)\downloads.sqlite" -Force -ErrorAction SilentlyContinue
        # Cache
        Remove-Item "$($_.FullName)\cache2\*" -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\startupCache\*" -Recurse -Force -ErrorAction SilentlyContinue
        # Cookies
        Remove-Item "$($_.FullName)\cookies.sqlite" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\cookies.sqlite-shm" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\cookies.sqlite-wal" -Force -ErrorAction SilentlyContinue
        # Sessions
        Remove-Item "$($_.FullName)\sessionstore.jsonlz4" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\sessionstore-backups\*" -Recurse -Force -ErrorAction SilentlyContinue
        # Form data
        Remove-Item "$($_.FullName)\formhistory.sqlite" -Force -ErrorAction SilentlyContinue
        # Passwords
        Remove-Item "$($_.FullName)\logins.json" -Force -ErrorAction SilentlyContinue
        Remove-Item "$($_.FullName)\key4.db" -Force -ErrorAction SilentlyContinue
        # Favicons
        Remove-Item "$($_.FullName)\favicons.sqlite" -Force -ErrorAction SilentlyContinue
    }
    Write-Host "  Firefox cleaned" -ForegroundColor Green
} else {
    Write-Host "  Firefox not found" -ForegroundColor Gray
}

# ----------------------------------------------------------------
# INTERNET EXPLORER CLEANUP
# ----------------------------------------------------------------
Write-Host "[5/12] Deleting Internet Explorer data..." -ForegroundColor Yellow
Remove-Item "$env:LOCALAPPDATA\Microsoft\Windows\INetCache\*" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:LOCALAPPDATA\Microsoft\Windows\INetCookies\*" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:LOCALAPPDATA\Microsoft\Windows\History\*" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:APPDATA\Microsoft\Windows\Cookies\*" -Recurse -Force -ErrorAction SilentlyContinue
RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 255
Write-Host "  Internet Explorer cleaned" -ForegroundColor Green

# ----------------------------------------------------------------
# WINDOWS RECENT FILES
# ----------------------------------------------------------------
Write-Host "[6/12] Deleting Windows recent files..." -ForegroundColor Yellow
Remove-Item "$env:APPDATA\Microsoft\Windows\Recent\*" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:APPDATA\Microsoft\Windows\Recent\AutomaticDestinations\*" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:APPDATA\Microsoft\Windows\Recent\CustomDestinations\*" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "  Recent files deleted" -ForegroundColor Green

# ----------------------------------------------------------------
# TEMP FILES
# ----------------------------------------------------------------
Write-Host "[7/12] Deleting temp files..." -ForegroundColor Yellow
Remove-Item "$env:TEMP\*" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "C:\Windows\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "  Temp files deleted" -ForegroundColor Green

# ----------------------------------------------------------------
# DOWNLOADS FOLDER CLEANUP (Optional but thorough)
# ----------------------------------------------------------------
Write-Host "[8/12] Checking Downloads folder..." -ForegroundColor Yellow
$downloadsPath = "$env:USERPROFILE\Downloads"
$downloadFiles = Get-ChildItem -Path $downloadsPath -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -gt (Get-Date).AddDays(-1) }
if ($downloadFiles) {
    Write-Host "  Found $($downloadFiles.Count) recent download(s)" -ForegroundColor Yellow
    Write-Host "  Files:" -ForegroundColor Yellow
    $downloadFiles | ForEach-Object { Write-Host "    - $($_.Name)" -ForegroundColor Gray }
    $deleteDownloads = Read-Host "  Delete these files? (YES/no)"
    if ($deleteDownloads -eq "YES") {
        $downloadFiles | Remove-Item -Force -ErrorAction SilentlyContinue
        Write-Host "  Downloads deleted" -ForegroundColor Green
    } else {
        Write-Host "  Downloads kept" -ForegroundColor Yellow
    }
} else {
    Write-Host "  No recent downloads found" -ForegroundColor Green
}

# ----------------------------------------------------------------
# RECYCLE BIN
# ----------------------------------------------------------------
Write-Host "[9/12] Emptying Recycle Bin..." -ForegroundColor Yellow
Clear-RecycleBin -Force -ErrorAction SilentlyContinue
Write-Host "  Recycle Bin emptied" -ForegroundColor Green

# ----------------------------------------------------------------
# CLIPBOARD
# ----------------------------------------------------------------
Write-Host "[10/12] Clearing clipboard..." -ForegroundColor Yellow
Set-Clipboard -Value $null
Write-Host "  Clipboard cleared" -ForegroundColor Green

# ----------------------------------------------------------------
# DNS CACHE
# ----------------------------------------------------------------
Write-Host "[11/12] Flushing DNS cache..." -ForegroundColor Yellow
ipconfig /flushdns | Out-Null
Write-Host "  DNS cache flushed" -ForegroundColor Green

# ----------------------------------------------------------------
# RUN DISK CLEANUP (Optional - takes longer)
# ----------------------------------------------------------------
Write-Host "[12/12] Running Windows Disk Cleanup..." -ForegroundColor Yellow
$diskClean = Read-Host "  Run full disk cleanup? This takes 2-3 minutes (YES/no)"
if ($diskClean -eq "YES") {
    Write-Host "  Starting Disk Cleanup..." -ForegroundColor Yellow
    # Set cleanup flags
    $volumeCaches = @(
        "Active Setup Temp Folders",
        "Downloaded Program Files",
        "Internet Cache Files",
        "Memory Dump Files",
        "Old ChkDsk Files",
        "Previous Installations",
        "Recycle Bin",
        "Setup Log Files",
        "System error memory dump files",
        "System error minidump files",
        "Temporary Files",
        "Temporary Setup Files",
        "Thumbnail Cache",
        "Update Cleanup",
        "Windows Error Reporting Archive Files",
        "Windows Error Reporting Queue Files",
        "Windows Error Reporting System Archive Files",
        "Windows Error Reporting System Queue Files",
        "Windows Upgrade Log Files"
    )
    
    foreach ($cache in $volumeCaches) {
        New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches\$cache" -Name StateFlags0001 -Value 2 -PropertyType DWORD -Force | Out-Null
    }
    
    Start-Process cleanmgr.exe -ArgumentList "/sagerun:1" -Wait -NoNewWindow
    Write-Host "  Disk Cleanup completed" -ForegroundColor Green
} else {
    Write-Host "  Disk Cleanup skipped" -ForegroundColor Yellow
}

# ----------------------------------------------------------------
# FINAL VERIFICATION
# ----------------------------------------------------------------
Write-Host ""
Write-Host "================================================================" -ForegroundColor Green
Write-Host "  CLEANUP COMPLETE!" -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor Green
Write-Host ""
Write-Host "Deleted:" -ForegroundColor Cyan
Write-Host "  [X] Chrome history, bookmarks, cache, cookies" -ForegroundColor Green
Write-Host "  [X] Edge history, bookmarks, cache, cookies" -ForegroundColor Green
Write-Host "  [X] Firefox history, bookmarks, cache, cookies" -ForegroundColor Green
Write-Host "  [X] Internet Explorer data" -ForegroundColor Green
Write-Host "  [X] Windows recent files" -ForegroundColor Green
Write-Host "  [X] Temp files" -ForegroundColor Green
Write-Host "  [X] Recycle Bin" -ForegroundColor Green
Write-Host "  [X] Clipboard" -ForegroundColor Green
Write-Host "  [X] DNS cache" -ForegroundColor Green
Write-Host ""
Write-Host "NO TRACES LEFT!" -ForegroundColor Green
Write-Host ""
Write-Host "You should now:" -ForegroundColor Yellow
Write-Host "  1. Restart the browser" -ForegroundColor Yellow
Write-Host "  2. Verify history is empty" -ForegroundColor Yellow
Write-Host "  3. Verify bookmarks are empty" -ForegroundColor Yellow
Write-Host ""
Write-Host "Press any key to exit..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
