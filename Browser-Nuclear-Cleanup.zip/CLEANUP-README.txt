BROWSER NUCLEAR CLEANUP SCRIPT
===============================

DELETES EVERYTHING - NO TRACES LEFT!
=====================================

This script will DELETE:
- Browser history (Chrome, Edge, Firefox)
- All bookmarks
- Downloads history
- Cache files
- Cookies
- Saved passwords
- Form data
- Recent files
- Temp files
- Clipboard
- DNS cache
- Recycle Bin

HOW TO USE:
===========

1. Close this README
2. Right-click on Browser-Nuclear-Cleanup.ps1
3. Select "Run with PowerShell"
4. Type YES when prompted
5. Wait 1-2 minutes
6. Everything deleted!

WHAT IT CLEANS:
===============

CHROME:
- History
- Bookmarks
- Downloads list
- Cache
- Cookies
- Saved passwords
- Form data

EDGE:
- History
- Bookmarks
- Downloads list
- Cache
- Cookies
- Saved passwords
- Form data

FIREFOX:
- History
- Bookmarks
- Downloads list
- Cache
- Cookies
- Saved passwords
- Form data

WINDOWS:
- Recent files list
- Temp files
- Clipboard
- DNS cache
- Recycle Bin

WHEN TO USE:
============
- After using client laptop
- Before returning laptop
- To remove all browsing traces
- To delete download history
- To clear bookmarks

SAFE TO USE:
============
- Does NOT delete your files (unless you confirm)
- Does NOT delete applications
- Does NOT delete Windows
- Only deletes browser data

AFTER RUNNING:
==============
1. Restart browser
2. History will be empty
3. Bookmarks will be empty
4. Downloads list will be empty
5. No cookies
6. No cache
7. No traces!

WARNING:
========
This PERMANENTLY DELETES data.
Cannot be undone.
Make sure you backup anything important first.

USE BEFORE LEAVING CLIENT SITE!
================================
