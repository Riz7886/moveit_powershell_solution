# ============================================================================
# AZURE VIRTUAL DESKTOP (AVD) - VARIABLES
# ============================================================================

# ============================================================================
# AZURE AUTHENTICATION
# ============================================================================

variable "subscription_id" {
  description = "Azure Subscription ID"
  type        = string
}

variable "tenant_id" {
  description = "Azure Tenant ID"
  type        = string
}

# ============================================================================
# GENERAL CONFIGURATION
# ============================================================================

variable "environment" {
  description = "Environment name (prod, dev, test)"
  type        = string
  validation {
    condition     = contains(["prod", "dev", "test"], var.environment)
    error_message = "Environment must be prod, dev, or test"
  }
}

variable "location" {
  description = "Azure region for resources"
  type        = string
  default     = "eastus"
}

variable "project_name" {
  description = "Project name for resource naming"
  type        = string
  default     = "avd"
}

variable "cost_center" {
  description = "Cost center for billing"
  type        = string
  default     = "IT"
}

variable "owner" {
  description = "Owner email or team name"
  type        = string
  default     = "devops-team"
}

# ============================================================================
# NETWORK CONFIGURATION
# ============================================================================

variable "vnet_address_space" {
  description = "Address space for the virtual network"
  type        = list(string)
  default     = ["10.0.0.0/16"]
}

variable "subnet_address_prefixes" {
  description = "Address prefixes for the AVD subnet"
  type        = list(string)
  default     = ["10.0.1.0/24"]
}

variable "allowed_rdp_source" {
  description = "Source IP range allowed for RDP (use your corporate IP)"
  type        = string
  default     = "*"
}

# ============================================================================
# HOST POOL CONFIGURATION
# ============================================================================

variable "host_pool_type" {
  description = "Host pool type (Pooled or Personal)"
  type        = string
  default     = "Pooled"
  validation {
    condition     = contains(["Pooled", "Personal"], var.host_pool_type)
    error_message = "Host pool type must be Pooled or Personal"
  }
}

variable "host_pool_load_balancer_type" {
  description = "Load balancer type (BreadthFirst or DepthFirst)"
  type        = string
  default     = "BreadthFirst"
  validation {
    condition     = contains(["BreadthFirst", "DepthFirst"], var.host_pool_load_balancer_type)
    error_message = "Load balancer type must be BreadthFirst or DepthFirst"
  }
}

variable "maximum_sessions_allowed" {
  description = "Maximum number of sessions allowed per session host"
  type        = number
  default     = 10
  validation {
    condition     = var.maximum_sessions_allowed >= 1 && var.maximum_sessions_allowed <= 999999
    error_message = "Maximum sessions must be between 1 and 999999"
  }
}

variable "start_vm_on_connect" {
  description = "Enable Start VM on Connect feature"
  type        = bool
  default     = true
}

variable "custom_rdp_properties" {
  description = "Custom RDP properties for the host pool"
  type        = string
  default     = "audiocapturemode:i:1;audiomode:i:0;targetisaadjoined:i:1;redirectclipboard:i:1"
}

# ============================================================================
# SESSION HOST CONFIGURATION
# ============================================================================

variable "session_host_count" {
  description = "Number of session hosts to create"
  type        = number
  default     = 2
  validation {
    condition     = var.session_host_count >= 1 && var.session_host_count <= 100
    error_message = "Session host count must be between 1 and 100"
  }
}

variable "vm_name_prefix" {
  description = "Prefix for session host VM names"
  type        = string
  default     = "avd-vm-"
}

variable "vm_size" {
  description = "Size of the session host VMs"
  type        = string
  default     = "Standard_D2s_v3"
}

variable "vm_storage_account_type" {
  description = "Storage account type for OS disk"
  type        = string
  default     = "Premium_LRS"
  validation {
    condition     = contains(["Premium_LRS", "StandardSSD_LRS", "Standard_LRS"], var.vm_storage_account_type)
    error_message = "Storage account type must be Premium_LRS, StandardSSD_LRS, or Standard_LRS"
  }
}

variable "vm_image_publisher" {
  description = "Publisher of the VM image"
  type        = string
  default     = "MicrosoftWindowsDesktop"
}

variable "vm_image_offer" {
  description = "Offer of the VM image"
  type        = string
  default     = "windows-11"
}

variable "vm_image_sku" {
  description = "SKU of the VM image"
  type        = string
  default     = "win11-22h2-avd"
}

variable "vm_image_version" {
  description = "Version of the VM image"
  type        = string
  default     = "latest"
}

variable "admin_username" {
  description = "Admin username for session hosts"
  type        = string
  default     = "avdadmin"
}

# ============================================================================
# DOMAIN JOIN CONFIGURATION
# ============================================================================

variable "enable_domain_join" {
  description = "Enable domain join for session hosts"
  type        = bool
  default     = false
}

variable "domain_name" {
  description = "Active Directory domain name"
  type        = string
  default     = ""
}

variable "ou_path" {
  description = "Organizational Unit path for computer objects"
  type        = string
  default     = ""
}

variable "domain_join_username" {
  description = "Username for domain join (without domain prefix)"
  type        = string
  default     = ""
  sensitive   = true
}

variable "domain_join_password" {
  description = "Password for domain join"
  type        = string
  default     = ""
  sensitive   = true
}

# ============================================================================
# MONITORING CONFIGURATION
# ============================================================================

variable "enable_diagnostics" {
  description = "Enable diagnostic settings"
  type        = bool
  default     = true
}

variable "log_analytics_workspace_id" {
  description = "Log Analytics Workspace ID for diagnostics"
  type        = string
  default     = null
}

# ============================================================================
# TAGS
# ============================================================================

variable "tags" {
  description = "Additional tags to apply to resources"
  type        = map(string)
  default     = {}
}
