# ============================================================================
# DEVELOPMENT ENVIRONMENT - AVD TERRAFORM VARIABLES
# ============================================================================
# File: terraform-dev.tfvars
# Environment: Development
# ============================================================================

# ============================================================================
# AZURE AUTHENTICATION (UPDATE THESE VALUES)
# ============================================================================

subscription_id = "YOUR-DEV-SUBSCRIPTION-ID-HERE"
tenant_id       = "YOUR-TENANT-ID-HERE"

# ============================================================================
# GENERAL CONFIGURATION
# ============================================================================

environment  = "dev"
location     = "eastus"
project_name = "avd"
cost_center  = "IT-Development"
owner        = "devops-team@company.com"

# ============================================================================
# NETWORK CONFIGURATION
# ============================================================================

vnet_address_space      = ["10.200.0.0/16"]
subnet_address_prefixes = ["10.200.1.0/24"]
allowed_rdp_source      = "*"  # Open for dev, restrict in production

# ============================================================================
# HOST POOL CONFIGURATION
# ============================================================================

host_pool_type               = "Pooled"
host_pool_load_balancer_type = "BreadthFirst"
maximum_sessions_allowed     = 5
start_vm_on_connect          = true
custom_rdp_properties        = "audiocapturemode:i:1;audiomode:i:0;targetisaadjoined:i:1;redirectclipboard:i:1"

# ============================================================================
# SESSION HOST CONFIGURATION (DEV = 2 HOSTS)
# ============================================================================

session_host_count      = 2
vm_name_prefix          = "avd-vm-"
vm_size                 = "Standard_D2s_v3"
vm_storage_account_type = "StandardSSD_LRS"
vm_image_publisher      = "MicrosoftWindowsDesktop"
vm_image_offer          = "windows-11"
vm_image_sku            = "win11-22h2-avd"
vm_image_version        = "latest"
admin_username          = "avdadmin"

# ============================================================================
# DOMAIN JOIN CONFIGURATION
# ============================================================================

enable_domain_join   = false
domain_name          = ""
ou_path              = ""
domain_join_username = ""
domain_join_password = ""

# ============================================================================
# MONITORING CONFIGURATION
# ============================================================================

enable_diagnostics         = true
log_analytics_workspace_id = "/subscriptions/YOUR-SUBSCRIPTION-ID/resourceGroups/rg-monitoring/providers/Microsoft.OperationalInsights/workspaces/law-dev"

# ============================================================================
# TAGS
# ============================================================================

tags = {
  Application        = "AVD"
  BusinessUnit       = "IT"
  CriticalityTier    = "Tier3"
  DataClassification = "Internal"
}
