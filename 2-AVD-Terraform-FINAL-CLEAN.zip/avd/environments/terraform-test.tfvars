# ============================================================================
# TEST ENVIRONMENT - AVD TERRAFORM VARIABLES
# ============================================================================
# File: terraform-test.tfvars
# Environment: Test
# ============================================================================

# ============================================================================
# AZURE AUTHENTICATION (UPDATE THESE VALUES)
# ============================================================================

subscription_id = "YOUR-TEST-SUBSCRIPTION-ID-HERE"
tenant_id       = "YOUR-TENANT-ID-HERE"

# ============================================================================
# GENERAL CONFIGURATION
# ============================================================================

environment  = "test"
location     = "eastus"
project_name = "avd"
cost_center  = "IT-Test"
owner        = "devops-team@company.com"

# ============================================================================
# NETWORK CONFIGURATION
# ============================================================================

vnet_address_space      = ["10.300.0.0/16"]
subnet_address_prefixes = ["10.300.1.0/24"]
allowed_rdp_source      = "*"

# ============================================================================
# HOST POOL CONFIGURATION
# ============================================================================

host_pool_type               = "Pooled"
host_pool_load_balancer_type = "DepthFirst"
maximum_sessions_allowed     = 3
start_vm_on_connect          = false
custom_rdp_properties        = "audiocapturemode:i:1;audiomode:i:0;targetisaadjoined:i:1;redirectclipboard:i:1"

# ============================================================================
# SESSION HOST CONFIGURATION (TEST = 1 HOST)
# ============================================================================

session_host_count      = 1
vm_name_prefix          = "avd-vm-"
vm_size                 = "Standard_D2s_v3"
vm_storage_account_type = "Standard_LRS"
vm_image_publisher      = "MicrosoftWindowsDesktop"
vm_image_offer          = "windows-11"
vm_image_sku            = "win11-22h2-avd"
vm_image_version        = "latest"
admin_username          = "avdadmin"

# ============================================================================
# DOMAIN JOIN CONFIGURATION
# ============================================================================

enable_domain_join   = false
domain_name          = ""
ou_path              = ""
domain_join_username = ""
domain_join_password = ""

# ============================================================================
# MONITORING CONFIGURATION
# ============================================================================

enable_diagnostics         = false
log_analytics_workspace_id = null

# ============================================================================
# TAGS
# ============================================================================

tags = {
  Application        = "AVD"
  BusinessUnit       = "IT"
  CriticalityTier    = "Tier4"
  DataClassification = "Internal"
}
