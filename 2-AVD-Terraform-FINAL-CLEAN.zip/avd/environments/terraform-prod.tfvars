# ============================================================================
# PRODUCTION ENVIRONMENT - AVD TERRAFORM VARIABLES
# ============================================================================
# File: terraform-prod.tfvars
# Environment: Production
# ============================================================================

# ============================================================================
# AZURE AUTHENTICATION (UPDATE THESE VALUES)
# ============================================================================

subscription_id = "YOUR-PROD-SUBSCRIPTION-ID-HERE"
tenant_id       = "YOUR-TENANT-ID-HERE"

# ============================================================================
# GENERAL CONFIGURATION
# ============================================================================

environment  = "prod"
location     = "eastus"
project_name = "avd"
cost_center  = "IT-Production"
owner        = "devops-team@company.com"

# ============================================================================
# NETWORK CONFIGURATION
# ============================================================================

vnet_address_space      = ["10.100.0.0/16"]
subnet_address_prefixes = ["10.100.1.0/24"]
allowed_rdp_source      = "YOUR-CORPORATE-IP-RANGE"  # Example: "203.0.113.0/24"

# ============================================================================
# HOST POOL CONFIGURATION
# ============================================================================

host_pool_type               = "Pooled"
host_pool_load_balancer_type = "BreadthFirst"
maximum_sessions_allowed     = 10
start_vm_on_connect          = true
custom_rdp_properties        = "audiocapturemode:i:1;audiomode:i:0;drivestoredirect:s:;redirectclipboard:i:1;redirectcomports:i:0;redirectprinters:i:1;redirectsmartcards:i:1;screen mode id:i:2;targetisaadjoined:i:1"

# ============================================================================
# SESSION HOST CONFIGURATION (PRODUCTION = 4 HOSTS)
# ============================================================================

session_host_count      = 4
vm_name_prefix          = "avd-vm-"
vm_size                 = "Standard_D4s_v3"
vm_storage_account_type = "Premium_LRS"
vm_image_publisher      = "MicrosoftWindowsDesktop"
vm_image_offer          = "windows-11"
vm_image_sku            = "win11-22h2-avd"
vm_image_version        = "latest"
admin_username          = "avdadmin"

# ============================================================================
# DOMAIN JOIN CONFIGURATION (OPTIONAL - SET TO true IF USING AD)
# ============================================================================

enable_domain_join   = false
domain_name          = ""  # Example: "contoso.com"
ou_path              = ""  # Example: "OU=AVD,DC=contoso,DC=com"
domain_join_username = ""  # Example: "domainadmin"
domain_join_password = ""  # Will be prompted or use Key Vault

# ============================================================================
# MONITORING CONFIGURATION
# ============================================================================

enable_diagnostics         = true
log_analytics_workspace_id = "/subscriptions/YOUR-SUBSCRIPTION-ID/resourceGroups/rg-monitoring/providers/Microsoft.OperationalInsights/workspaces/law-prod"

# ============================================================================
# TAGS
# ============================================================================

tags = {
  Application        = "AVD"
  BusinessUnit       = "IT"
  CriticalityTier    = "Tier1"
  DataClassification = "Confidential"
  DR                 = "Required"
  Compliance         = "SOC2"
}
