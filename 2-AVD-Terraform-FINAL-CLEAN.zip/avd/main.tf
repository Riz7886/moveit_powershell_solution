# ============================================================================
# AZURE VIRTUAL DESKTOP (AVD) - MAIN CONFIGURATION
# ============================================================================
# Purpose: Deploy complete AVD infrastructure with automation
# Version: 1.0
# Terraform: >= 1.5.0
# ============================================================================

terraform {
  required_version = ">= 1.5.0"
  
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.80.0"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 2.45.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.5.0"
    }
  }

  backend "azurerm" {
    resource_group_name  = "rg-terraform-state"
    storage_account_name = "stterraformstate"
    container_name       = "tfstate"
    key                  = "avd.terraform.tfstate"
  }
}

# ============================================================================
# PROVIDER CONFIGURATION
# ============================================================================

provider "azurerm" {
  features {
    resource_group {
      prevent_deletion_if_contains_resources = false
    }
    virtual_machine {
      delete_os_disk_on_deletion     = true
      graceful_shutdown              = false
      skip_shutdown_and_force_delete = false
    }
  }
  
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
}

provider "azuread" {
  tenant_id = var.tenant_id
}

# ============================================================================
# LOCAL VARIABLES
# ============================================================================

locals {
  common_tags = merge(
    var.tags,
    {
      Environment    = var.environment
      ManagedBy      = "Terraform"
      Project        = "AVD"
      DeploymentDate = timestamp()
      CostCenter     = var.cost_center
      Owner          = var.owner
    }
  )

  resource_prefix = "${var.project_name}-${var.environment}"
  
  # Session host naming
  vm_prefix = "${var.vm_name_prefix}${var.environment}"
}

# ============================================================================
# RANDOM STRINGS FOR UNIQUE NAMING
# ============================================================================

resource "random_string" "unique" {
  length  = 6
  special = false
  upper   = false
}

resource "random_password" "vm_password" {
  count   = var.session_host_count
  length  = 24
  special = true
}

# ============================================================================
# RESOURCE GROUPS
# ============================================================================

resource "azurerm_resource_group" "avd" {
  name     = "rg-${local.resource_prefix}-avd"
  location = var.location
  tags     = local.common_tags
}

resource "azurerm_resource_group" "network" {
  name     = "rg-${local.resource_prefix}-network"
  location = var.location
  tags     = local.common_tags
}

# ============================================================================
# VIRTUAL NETWORK
# ============================================================================

resource "azurerm_virtual_network" "avd" {
  name                = "vnet-${local.resource_prefix}-avd"
  location            = azurerm_resource_group.network.location
  resource_group_name = azurerm_resource_group.network.name
  address_space       = var.vnet_address_space
  tags                = local.common_tags
}

# ============================================================================
# SUBNET FOR SESSION HOSTS
# ============================================================================

resource "azurerm_subnet" "avd" {
  name                 = "snet-${local.resource_prefix}-avd"
  resource_group_name  = azurerm_resource_group.network.name
  virtual_network_name = azurerm_virtual_network.avd.name
  address_prefixes     = var.subnet_address_prefixes
}

# ============================================================================
# NETWORK SECURITY GROUP
# ============================================================================

resource "azurerm_network_security_group" "avd" {
  name                = "nsg-${local.resource_prefix}-avd"
  location            = azurerm_resource_group.network.location
  resource_group_name = azurerm_resource_group.network.name
  tags                = local.common_tags

  security_rule {
    name                       = "Allow-RDP-Inbound"
    priority                   = 1000
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "3389"
    source_address_prefix      = var.allowed_rdp_source
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "Allow-HTTPS-Outbound"
    priority                   = 1010
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }
}

resource "azurerm_subnet_network_security_group_association" "avd" {
  subnet_id                 = azurerm_subnet.avd.id
  network_security_group_id = azurerm_network_security_group.avd.id
}

# ============================================================================
# AVD HOST POOL
# ============================================================================

resource "azurerm_virtual_desktop_host_pool" "main" {
  name                     = "hp-${local.resource_prefix}"
  location                 = azurerm_resource_group.avd.location
  resource_group_name      = azurerm_resource_group.avd.name
  type                     = var.host_pool_type
  load_balancer_type       = var.host_pool_load_balancer_type
  friendly_name            = "${var.project_name} ${var.environment} Host Pool"
  description              = "Managed by Terraform"
  validate_environment     = false
  start_vm_on_connect      = var.start_vm_on_connect
  custom_rdp_properties    = var.custom_rdp_properties
  maximum_sessions_allowed = var.maximum_sessions_allowed
  tags                     = local.common_tags
}

# ============================================================================
# AVD WORKSPACE
# ============================================================================

resource "azurerm_virtual_desktop_workspace" "main" {
  name                = "ws-${local.resource_prefix}"
  location            = azurerm_resource_group.avd.location
  resource_group_name = azurerm_resource_group.avd.name
  friendly_name       = "${var.project_name} ${var.environment} Workspace"
  description         = "Managed by Terraform"
  tags                = local.common_tags
}

# ============================================================================
# AVD APPLICATION GROUP
# ============================================================================

resource "azurerm_virtual_desktop_application_group" "desktop" {
  name                = "ag-${local.resource_prefix}-desktop"
  location            = azurerm_resource_group.avd.location
  resource_group_name = azurerm_resource_group.avd.name
  type                = "Desktop"
  host_pool_id        = azurerm_virtual_desktop_host_pool.main.id
  friendly_name       = "Desktop Application Group"
  description         = "Managed by Terraform"
  tags                = local.common_tags
}

# ============================================================================
# WORKSPACE - APPLICATION GROUP ASSOCIATION
# ============================================================================

resource "azurerm_virtual_desktop_workspace_application_group_association" "main" {
  workspace_id         = azurerm_virtual_desktop_workspace.main.id
  application_group_id = azurerm_virtual_desktop_application_group.desktop.id
}

# ============================================================================
# AVD HOST POOL REGISTRATION TOKEN
# ============================================================================

resource "azurerm_virtual_desktop_host_pool_registration_info" "main" {
  hostpool_id     = azurerm_virtual_desktop_host_pool.main.id
  expiration_date = timeadd(timestamp(), "48h")
}

# ============================================================================
# SESSION HOST VMs
# ============================================================================

resource "azurerm_network_interface" "avd" {
  count               = var.session_host_count
  name                = "nic-${local.vm_prefix}-${count.index + 1}"
  location            = azurerm_resource_group.avd.location
  resource_group_name = azurerm_resource_group.avd.name
  tags                = local.common_tags

  ip_configuration {
    name                          = "internal"
    subnet_id                     = azurerm_subnet.avd.id
    private_ip_address_allocation = "Dynamic"
  }
}

resource "azurerm_windows_virtual_machine" "avd" {
  count               = var.session_host_count
  name                = "${local.vm_prefix}-${count.index + 1}"
  location            = azurerm_resource_group.avd.location
  resource_group_name = azurerm_resource_group.avd.name
  size                = var.vm_size
  admin_username      = var.admin_username
  admin_password      = random_password.vm_password[count.index].result
  tags                = local.common_tags

  network_interface_ids = [
    azurerm_network_interface.avd[count.index].id
  ]

  os_disk {
    name                 = "osdisk-${local.vm_prefix}-${count.index + 1}"
    caching              = "ReadWrite"
    storage_account_type = var.vm_storage_account_type
  }

  source_image_reference {
    publisher = var.vm_image_publisher
    offer     = var.vm_image_offer
    sku       = var.vm_image_sku
    version   = var.vm_image_version
  }

  identity {
    type = "SystemAssigned"
  }

  lifecycle {
    ignore_changes = [
      admin_password
    ]
  }
}

# ============================================================================
# AVD AGENT EXTENSION
# ============================================================================

resource "azurerm_virtual_machine_extension" "avd_dsc" {
  count                = var.session_host_count
  name                 = "Microsoft.PowerShell.DSC"
  virtual_machine_id   = azurerm_windows_virtual_machine.avd[count.index].id
  publisher            = "Microsoft.Powershell"
  type                 = "DSC"
  type_handler_version = "2.73"

  settings = jsonencode({
    modulesUrl = "https://wvdportalstorageblob.blob.core.windows.net/galleryartifacts/Configuration_09-08-2022.zip"
    configurationFunction = "Configuration.ps1\\AddSessionHost"
    properties = {
      hostPoolName          = azurerm_virtual_desktop_host_pool.main.name
      registrationInfoToken = azurerm_virtual_desktop_host_pool_registration_info.main.token
    }
  })

  depends_on = [
    azurerm_virtual_machine_extension.domain_join
  ]
}

# ============================================================================
# DOMAIN JOIN EXTENSION (OPTIONAL)
# ============================================================================

resource "azurerm_virtual_machine_extension" "domain_join" {
  count                = var.enable_domain_join ? var.session_host_count : 0
  name                 = "JsonADDomainExtension"
  virtual_machine_id   = azurerm_windows_virtual_machine.avd[count.index].id
  publisher            = "Microsoft.Compute"
  type                 = "JsonADDomainExtension"
  type_handler_version = "1.3"

  settings = jsonencode({
    Name    = var.domain_name
    OUPath  = var.ou_path
    User    = "${var.domain_name}\\${var.domain_join_username}"
    Restart = "true"
    Options = "3"
  })

  protected_settings = jsonencode({
    Password = var.domain_join_password
  })
}

# ============================================================================
# DIAGNOSTIC SETTINGS
# ============================================================================

resource "azurerm_monitor_diagnostic_setting" "avd_hostpool" {
  count = var.enable_diagnostics ? 1 : 0

  name                       = "diag-${azurerm_virtual_desktop_host_pool.main.name}"
  target_resource_id         = azurerm_virtual_desktop_host_pool.main.id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  enabled_log {
    category = "Checkpoint"
  }

  enabled_log {
    category = "Error"
  }

  enabled_log {
    category = "Management"
  }

  enabled_log {
    category = "Connection"
  }

  enabled_log {
    category = "HostRegistration"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

resource "azurerm_monitor_diagnostic_setting" "avd_workspace" {
  count = var.enable_diagnostics ? 1 : 0

  name                       = "diag-${azurerm_virtual_desktop_workspace.main.name}"
  target_resource_id         = azurerm_virtual_desktop_workspace.main.id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  enabled_log {
    category = "Checkpoint"
  }

  enabled_log {
    category = "Error"
  }

  enabled_log {
    category = "Management"
  }

  enabled_log {
    category = "Feed"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}
