# ============================================================================
# AZURE VIRTUAL DESKTOP (AVD) - OUTPUTS
# ============================================================================

# ============================================================================
# RESOURCE GROUP OUTPUTS
# ============================================================================

output "avd_resource_group_name" {
  description = "Name of the AVD resource group"
  value       = azurerm_resource_group.avd.name
}

output "network_resource_group_name" {
  description = "Name of the network resource group"
  value       = azurerm_resource_group.network.name
}

# ============================================================================
# NETWORK OUTPUTS
# ============================================================================

output "vnet_id" {
  description = "ID of the virtual network"
  value       = azurerm_virtual_network.avd.id
}

output "vnet_name" {
  description = "Name of the virtual network"
  value       = azurerm_virtual_network.avd.name
}

output "subnet_id" {
  description = "ID of the AVD subnet"
  value       = azurerm_subnet.avd.id
}

output "nsg_id" {
  description = "ID of the network security group"
  value       = azurerm_network_security_group.avd.id
}

# ============================================================================
# AVD HOST POOL OUTPUTS
# ============================================================================

output "host_pool_id" {
  description = "ID of the AVD host pool"
  value       = azurerm_virtual_desktop_host_pool.main.id
}

output "host_pool_name" {
  description = "Name of the AVD host pool"
  value       = azurerm_virtual_desktop_host_pool.main.name
}

output "host_pool_type" {
  description = "Type of the host pool"
  value       = azurerm_virtual_desktop_host_pool.main.type
}

output "host_pool_registration_token" {
  description = "Registration token for the host pool"
  value       = azurerm_virtual_desktop_host_pool_registration_info.main.token
  sensitive   = true
}

# ============================================================================
# AVD WORKSPACE OUTPUTS
# ============================================================================

output "workspace_id" {
  description = "ID of the AVD workspace"
  value       = azurerm_virtual_desktop_workspace.main.id
}

output "workspace_name" {
  description = "Name of the AVD workspace"
  value       = azurerm_virtual_desktop_workspace.main.name
}

# ============================================================================
# AVD APPLICATION GROUP OUTPUTS
# ============================================================================

output "application_group_id" {
  description = "ID of the desktop application group"
  value       = azurerm_virtual_desktop_application_group.desktop.id
}

output "application_group_name" {
  description = "Name of the desktop application group"
  value       = azurerm_virtual_desktop_application_group.desktop.name
}

# ============================================================================
# SESSION HOST OUTPUTS
# ============================================================================

output "session_host_names" {
  description = "Names of all session hosts"
  value       = azurerm_windows_virtual_machine.avd[*].name
}

output "session_host_ids" {
  description = "IDs of all session hosts"
  value       = azurerm_windows_virtual_machine.avd[*].id
}

output "session_host_private_ips" {
  description = "Private IP addresses of all session hosts"
  value       = azurerm_network_interface.avd[*].private_ip_address
}

output "session_host_admin_username" {
  description = "Admin username for session hosts"
  value       = var.admin_username
}

output "session_host_admin_passwords" {
  description = "Admin passwords for session hosts"
  value       = random_password.vm_password[*].result
  sensitive   = true
}

# ============================================================================
# ENVIRONMENT OUTPUTS
# ============================================================================

output "environment" {
  description = "Environment name"
  value       = var.environment
}

output "location" {
  description = "Azure region"
  value       = var.location
}

output "tags" {
  description = "Tags applied to resources"
  value       = local.common_tags
}

# ============================================================================
# SUMMARY OUTPUT
# ============================================================================

output "deployment_summary" {
  description = "Summary of the AVD deployment"
  value = {
    environment          = var.environment
    location            = var.location
    host_pool_name      = azurerm_virtual_desktop_host_pool.main.name
    workspace_name      = azurerm_virtual_desktop_workspace.main.name
    session_host_count  = var.session_host_count
    vm_size             = var.vm_size
    host_pool_type      = var.host_pool_type
    domain_joined       = var.enable_domain_join
  }
}
