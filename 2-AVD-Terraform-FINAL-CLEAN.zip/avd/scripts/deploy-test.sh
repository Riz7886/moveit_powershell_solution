#!/bin/bash
set -e
echo "avd - TEST DEPLOYMENT"
./scripts/setup-backend.sh
terraform init -reconfigure -backend-config="key=avd-test.tfstate"
terraform validate
terraform plan -var-file="environments/terraform-test.tfvars" -out="tfplan-test"
terraform apply -auto-approve "tfplan-test"
terraform output
rm -f "tfplan-test"
echo "TEST DEPLOYMENT COMPLETE"
