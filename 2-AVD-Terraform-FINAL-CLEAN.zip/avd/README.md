# AVD TERRAFORM DEPLOYMENT

## QUICK START
1. Edit environments/terraform-prod.tfvars
2. Update subscription_id, tenant_id, and other values
3. Run: ./scripts/deploy.sh prod

## FILES
- main.tf: Main configuration
- variables.tf: All variables
- outputs.tf: All outputs
- environments/: Environment configs

## COMMANDS
terraform init
terraform plan -var-file=environments/terraform-prod.tfvars
terraform apply -var-file=environments/terraform-prod.tfvars
