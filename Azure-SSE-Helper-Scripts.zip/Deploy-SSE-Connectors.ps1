# ================================================================
# AZURE SSE - CONNECTOR DEPLOYMENT SCRIPT
# Deploy Private Access Connectors for Entra Private Access
# ================================================================

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  AZURE SSE - CONNECTOR DEPLOYMENT" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "NOTE: This script deploys the CONNECTOR infrastructure." -ForegroundColor Yellow
Write-Host "You still need to:" -ForegroundColor Yellow
Write-Host "  1. Register connectors with Entra" -ForegroundColor Yellow
Write-Host "  2. Configure applications" -ForegroundColor Yellow
Write-Host "  3. Assign users" -ForegroundColor Yellow
Write-Host ""

function Write-Log {
    param([string]$Message, [string]$Color = "White")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] $Message" -ForegroundColor $Color
}

# Configuration
$config = @{
    Location = "westus"
    ResourceGroup = "rg-sse-connectors"
    VMSize = "Standard_D2s_v3"
    ConnectorCount = 2
    VNetName = "vnet-prod"
    SubnetName = "snet-connectors"
    SubnetPrefix = "10.0.10.0/24"
}

# Check Azure CLI
Write-Log "Checking Azure CLI..." "Yellow"
try {
    $azVersion = az version --output json 2>$null | ConvertFrom-Json
    Write-Log "Azure CLI version: $($azVersion.'azure-cli')" "Green"
} catch {
    Write-Log "ERROR: Azure CLI not found!" "Red"
    exit 1
}

# Login
Write-Log "Checking Azure login..." "Yellow"
$loginCheck = az account show 2>$null
if (-not $loginCheck) {
    Write-Log "Not logged in. Starting login..." "Yellow"
    az login --use-device-code
}

# Select subscription
Write-Host ""
Write-Log "============================================" "Cyan"
Write-Log "AVAILABLE SUBSCRIPTIONS" "Cyan"
Write-Log "============================================" "Cyan"

$subscriptions = az account list --output json | ConvertFrom-Json

for ($i = 0; $i -lt $subscriptions.Count; $i++) {
    $sub = $subscriptions[$i]
    Write-Host "[$($i + 1)] $($sub.name)" -ForegroundColor Cyan
}

Write-Host ""
$selection = Read-Host "Select subscription number"
$selectedSubscription = $subscriptions[[int]$selection - 1]
az account set --subscription $selectedSubscription.id
Write-Log "Active subscription: $($selectedSubscription.name)" "Green"

# Create resource group
Write-Host ""
Write-Log "Creating resource group..." "Yellow"
az group create --name $config.ResourceGroup --location $config.Location --output none
Write-Log "Resource group created" "Green"

# Find or create VNet
Write-Host ""
Write-Log "Looking for VNet..." "Yellow"
$vnet = az network vnet show --resource-group $config.ResourceGroup --name $config.VNetName 2>$null

if (-not $vnet) {
    Write-Log "VNet not found. Creating..." "Yellow"
    az network vnet create `
        --resource-group $config.ResourceGroup `
        --name $config.VNetName `
        --address-prefix "10.0.0.0/16" `
        --location $config.Location `
        --output none
    Write-Log "VNet created" "Green"
}

# Create connector subnet
Write-Host ""
Write-Log "Creating connector subnet..." "Yellow"
az network vnet subnet create `
    --resource-group $config.ResourceGroup `
    --vnet-name $config.VNetName `
    --name $config.SubnetName `
    --address-prefix $config.SubnetPrefix `
    --output none 2>$null
Write-Log "Connector subnet created" "Green"

# Deploy connector VMs
Write-Host ""
Write-Log "============================================" "Yellow"
Write-Log "DEPLOYING CONNECTOR VMS" "Yellow"
Write-Log "============================================" "Yellow"
Write-Host ""

for ($i = 1; $i -le $config.ConnectorCount; $i++) {
    $vmName = "vm-connector-$i"
    Write-Log "Creating connector VM $i of $($config.ConnectorCount)..." "Yellow"
    
    az vm create `
        --resource-group $config.ResourceGroup `
        --name $vmName `
        --image Win2022Datacenter `
        --size $config.VMSize `
        --vnet-name $config.VNetName `
        --subnet $config.SubnetName `
        --admin-username "azureuser" `
        --admin-password "P@ssw0rd123!@#" `
        --public-ip-address "" `
        --nsg "" `
        --location $config.Location `
        --output none
    
    Write-Log "VM $vmName created" "Green"
}

Write-Host ""
Write-Log "============================================" "Green"
Write-Log "CONNECTOR INFRASTRUCTURE DEPLOYED!" "Green"
Write-Log "============================================" "Green"
Write-Host ""
Write-Host "NEXT STEPS (MANUAL):" -ForegroundColor Cyan
Write-Host "1. RDP to each connector VM" -ForegroundColor Yellow
Write-Host "2. Download Entra connector installer from:" -ForegroundColor Yellow
Write-Host "   https://aka.ms/aadappproxyconnectordownload" -ForegroundColor White
Write-Host "3. Install connector on each VM" -ForegroundColor Yellow
Write-Host "4. Register connectors with Entra ID" -ForegroundColor Yellow
Write-Host "5. Create connector groups in Entra" -ForegroundColor Yellow
Write-Host "6. Configure applications" -ForegroundColor Yellow
Write-Host ""
Write-Host "Connector VMs:" -ForegroundColor Cyan
for ($i = 1; $i -le $config.ConnectorCount; $i++) {
    Write-Host "  - vm-connector-$i" -ForegroundColor White
}
Write-Host ""
Write-Host "IMPORTANT: This is only STEP 1 of SSE deployment!" -ForegroundColor Red
Write-Host "SSE requires 3 months of change management." -ForegroundColor Red
Write-Host ""
Write-Host "Press any key to exit..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
