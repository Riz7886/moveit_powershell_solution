# DATABRICKS COST CONTROL & ANALYSIS
# For Preyash - Shows costs, sets alerts, prevents surprise bills

param(
    [Parameter(Mandatory=$false)]
    [int]$MonthlyBudget = 5000,  # Set your max monthly budget in USD
    
    [Parameter(Mandatory=$false)]
    [int]$AlertThreshold = 80  # Alert at 80% of budget
)

Clear-Host
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  DATABRICKS COST CONTROL" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Monthly Budget: `$$MonthlyBudget" -ForegroundColor Yellow
Write-Host "Alert at: $AlertThreshold% (`$$($MonthlyBudget * $AlertThreshold / 100))" -ForegroundColor Yellow
Write-Host ""

# Connect
Write-Host "Connecting to Azure..." -ForegroundColor Yellow
try {
    $context = Get-AzContext
    if (-not $context) {
        Connect-AzAccount | Out-Null
    }
    Write-Host "Connected: $($context.Account.Id)" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Cannot connect to Azure" -ForegroundColor Red
    exit
}

Write-Host ""

# Get all subscriptions
$subs = Get-AzSubscription
$allDatabricks = @()
$totalCurrentCost = 0
$totalMaxCost = 0

Write-Host "Scanning for Databricks workspaces..." -ForegroundColor Yellow
Write-Host ""

# Scan all subscriptions
foreach ($sub in $subs) {
    Write-Host "Subscription: $($sub.Name)" -ForegroundColor Cyan
    
    try {
        Set-AzContext -SubscriptionId $sub.Id -ErrorAction Stop | Out-Null
    } catch {
        Write-Host "  Cannot access" -ForegroundColor Red
        continue
    }
    
    # Get all Databricks workspaces
    $workspaces = Get-AzResource -ResourceType "Microsoft.Databricks/workspaces" -ErrorAction SilentlyContinue
    
    if ($workspaces) {
        Write-Host "  Found $($workspaces.Count) Databricks workspace(s)" -ForegroundColor Green
        
        foreach ($ws in $workspaces) {
            Write-Host "    Workspace: $($ws.Name)" -ForegroundColor White
            
            # Get workspace details
            $workspace = Get-AzDatabricksWorkspace -ResourceGroupName $ws.ResourceGroupName -Name $ws.Name -ErrorAction SilentlyContinue
            
            # Get current month costs for this resource
            $startDate = (Get-Date -Day 1).ToString("yyyy-MM-dd")
            $endDate = (Get-Date).ToString("yyyy-MM-dd")
            
            try {
                $costs = Get-AzConsumptionUsageDetail -StartDate $startDate -EndDate $endDate -ErrorAction SilentlyContinue | 
                    Where-Object {$_.InstanceId -like "*$($ws.ResourceId)*"}
                
                $currentCost = ($costs | Measure-Object -Property PretaxCost -Sum).Sum
                if (-not $currentCost) { $currentCost = 0 }
                
                Write-Host "      Current month cost: `$$([math]::Round($currentCost, 2))" -ForegroundColor $(if($currentCost -gt 500){"Red"}else{"Green"})
            } catch {
                $currentCost = 0
                Write-Host "      Current cost: Unable to fetch" -ForegroundColor Yellow
            }
            
            # Estimate max cost (assumes 24/7 usage of largest cluster type)
            # Standard_DS3_v2 = ~$0.27/hour = ~$195/month per node
            # Assume worst case: 10 nodes running 24/7
            $maxMonthlyCost = 195 * 10  # $1,950 per workspace max estimate
            
            Write-Host "      MAX potential cost (if 24/7): `$$maxMonthlyCost" -ForegroundColor Red
            Write-Host ""
            
            $allDatabricks += [PSCustomObject]@{
                Subscription = $sub.Name
                ResourceGroup = $ws.ResourceGroupName
                Workspace = $ws.Name
                Location = $ws.Location
                SKU = if($workspace.Sku.Name){$workspace.Sku.Name}else{"Standard"}
                CurrentCost = [math]::Round($currentCost, 2)
                MaxCost = $maxMonthlyCost
            }
            
            $totalCurrentCost += $currentCost
            $totalMaxCost += $maxMonthlyCost
        }
    } else {
        Write-Host "  No Databricks workspaces found" -ForegroundColor Gray
    }
    
    Write-Host ""
}

# Summary
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  COST SUMMARY" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Total Databricks workspaces: $($allDatabricks.Count)" -ForegroundColor White
Write-Host "Current month cost so far: `$$([math]::Round($totalCurrentCost, 2))" -ForegroundColor $(if($totalCurrentCost -gt ($MonthlyBudget * 0.5)){"Red"}else{"Green"})
Write-Host "MAX potential cost (24/7): `$$totalMaxCost" -ForegroundColor Red
Write-Host "Your monthly budget: `$$MonthlyBudget" -ForegroundColor Yellow
Write-Host ""

# Budget status
$budgetUsed = ($totalCurrentCost / $MonthlyBudget) * 100
Write-Host "Budget used: $([math]::Round($budgetUsed, 1))%" -ForegroundColor $(if($budgetUsed -gt $AlertThreshold){"Red"}elseif($budgetUsed -gt 50){"Yellow"}else{"Green"})

if ($budgetUsed -gt $AlertThreshold) {
    Write-Host "WARNING: You are over $AlertThreshold% of your budget!" -ForegroundColor Red
    Write-Host "Current spending: `$$([math]::Round($totalCurrentCost, 2)) / `$$MonthlyBudget" -ForegroundColor Red
}

Write-Host ""

# Recommendations
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  COST SAVING RECOMMENDATIONS" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "1. AUTO-TERMINATION" -ForegroundColor Yellow
Write-Host "   Set clusters to auto-terminate after 30 minutes idle" -ForegroundColor White
Write-Host "   Potential savings: 60-80% of compute costs" -ForegroundColor Green
Write-Host ""

Write-Host "2. CLUSTER POLICIES" -ForegroundColor Yellow
Write-Host "   Limit max cluster size (e.g., max 5 workers)" -ForegroundColor White
Write-Host "   Prevent users from creating huge clusters" -ForegroundColor White
Write-Host ""

Write-Host "3. SPOT INSTANCES" -ForegroundColor Yellow
Write-Host "   Use Azure Spot VMs for non-critical workloads" -ForegroundColor White
Write-Host "   Potential savings: 60-90% on compute" -ForegroundColor Green
Write-Host ""

Write-Host "4. SCHEDULE JOBS" -ForegroundColor Yellow
Write-Host "   Run jobs during off-peak hours if possible" -ForegroundColor White
Write-Host "   Stop all clusters outside business hours" -ForegroundColor White
Write-Host ""

# Generate report
Write-Host "Generating detailed report..." -ForegroundColor Yellow

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$reportFile = "DATABRICKS-COST-REPORT-$timestamp.html"

# Build table
$tableRows = ""
foreach ($db in $allDatabricks) {
    $costColor = if($db.CurrentCost -gt 500){"red"}elseif($db.CurrentCost -gt 200){"orange"}else{"green"}
    $tableRows += "<tr>
        <td>$($db.Subscription)</td>
        <td>$($db.ResourceGroup)</td>
        <td><b>$($db.Workspace)</b></td>
        <td>$($db.Location)</td>
        <td>$($db.SKU)</td>
        <td style='color:$costColor;font-weight:bold'>`$$($db.CurrentCost)</td>
        <td style='color:red;font-weight:bold'>`$$($db.MaxCost)</td>
    </tr>"
}

$html = @"
<!DOCTYPE html>
<html>
<head>
<meta charset='UTF-8'>
<title>Databricks Cost Analysis</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:Arial,sans-serif;background:#f5f5f5;padding:20px}
.header{background:linear-gradient(135deg,#FF3621,#FF8A00);color:white;padding:50px;border-radius:12px;margin-bottom:30px;text-align:center}
h1{font-size:42px;margin-bottom:15px}
.subtitle{font-size:18px;opacity:0.95}
.container{max-width:1400px;margin:0 auto}
.summary{display:grid;grid-template-columns:repeat(3,1fr);gap:25px;margin-bottom:35px}
.box{background:white;padding:35px;border-radius:12px;text-align:center;box-shadow:0 4px 20px rgba(0,0,0,0.1)}
.val{font-size:48px;font-weight:bold;margin-bottom:12px}
.label{color:#666;font-size:15px;text-transform:uppercase;letter-spacing:1px}
.card{background:white;padding:40px;border-radius:12px;margin-bottom:30px;box-shadow:0 4px 20px rgba(0,0,0,0.1)}
h2{color:#333;font-size:28px;margin-bottom:25px;padding-bottom:15px;border-bottom:4px solid #FF3621}
table{width:100%;border-collapse:collapse;margin:25px 0}
thead{background:#FF3621}
th{color:white;padding:18px;text-align:left;font-size:13px;font-weight:600}
td{padding:15px;border-bottom:1px solid #e0e0e0;font-size:14px}
tr:hover{background:#fff5f5}
.warning{background:#dc3545;color:white;padding:25px;border-radius:10px;margin:25px 0;text-align:center;font-size:20px}
.success{background:#28a745;color:white;padding:25px;border-radius:10px;margin:25px 0;text-align:center;font-size:20px}
.recommendation{background:#fff3cd;border-left:5px solid #ffc107;padding:20px;margin:15px 0;border-radius:8px}
.rec-title{font-weight:bold;font-size:16px;margin-bottom:8px;color:#856404}
.rec-text{color:#856404;font-size:14px;line-height:1.6}
</style>
</head>
<body>
<div class='container'>

<div class='header'>
<h1>🔥 DATABRICKS COST ANALYSIS 🔥</h1>
<div class='subtitle'>For Preyash Patel | Generated: $(Get-Date -Format 'MMMM dd, yyyy HH:mm')</div>
</div>

<div class='summary'>
<div class='box'>
<div class='val' style='color:#FF3621'>$($allDatabricks.Count)</div>
<div class='label'>Databricks Workspaces</div>
</div>
<div class='box'>
<div class='val' style='color:$(if($totalCurrentCost -gt ($MonthlyBudget * 0.8)){"#dc3545"}elseif($totalCurrentCost -gt ($MonthlyBudget * 0.5)){"#ffc107"}else{"#28a745"})'>`$$([math]::Round($totalCurrentCost, 2))</div>
<div class='label'>Current Month Cost</div>
</div>
<div class='box'>
<div class='val' style='color:#dc3545'>`$$totalMaxCost</div>
<div class='label'>Max Potential (24/7)</div>
</div>
</div>

$(if($budgetUsed -gt $AlertThreshold){
"<div class='warning'>
⚠️ WARNING: $([math]::Round($budgetUsed, 1))% OF BUDGET USED!<br>
Current: `$$([math]::Round($totalCurrentCost, 2)) / Budget: `$$MonthlyBudget<br>
IMMEDIATE ACTION REQUIRED!
</div>"
}elseif($budgetUsed -gt 50){
"<div class='warning' style='background:#ffc107;color:#856404'>
⚠️ ATTENTION: $([math]::Round($budgetUsed, 1))% OF BUDGET USED<br>
Monitor spending closely
</div>"
}else{
"<div class='success'>
✅ Budget Status: HEALTHY<br>
$([math]::Round($budgetUsed, 1))% of budget used
</div>"
})

<div class='card'>
<h2>ALL DATABRICKS WORKSPACES</h2>
<table>
<thead>
<tr>
<th>Subscription</th>
<th>Resource Group</th>
<th>Workspace</th>
<th>Location</th>
<th>SKU</th>
<th>Current Cost</th>
<th>Max Cost (24/7)</th>
</tr>
</thead>
<tbody>
$tableRows
</tbody>
</table>
</div>

<div class='card'>
<h2>💰 COST SAVING RECOMMENDATIONS</h2>

<div class='recommendation'>
<div class='rec-title'>1. AUTO-TERMINATION (Highest Impact)</div>
<div class='rec-text'>
Configure all clusters to auto-terminate after 30 minutes of inactivity.<br>
<b>Potential Savings: 60-80% of compute costs</b><br>
<b>Action:</b> Set in cluster configuration → Auto Termination → 30 minutes
</div>
</div>

<div class='recommendation'>
<div class='rec-title'>2. CLUSTER SIZE POLICIES</div>
<div class='rec-text'>
Limit maximum cluster size to prevent runaway costs.<br>
<b>Action:</b> Create cluster policy limiting max workers to 5-10 nodes<br>
<b>Prevents:</b> Users accidentally creating 50-node clusters
</div>
</div>

<div class='recommendation'>
<div class='rec-title'>3. USE SPOT/PREEMPTIBLE INSTANCES</div>
<div class='rec-text'>
Use Azure Spot VMs for development and non-critical workloads.<br>
<b>Potential Savings: 60-90% on compute</b><br>
<b>Action:</b> Enable Spot instances in cluster configuration
</div>
</div>

<div class='recommendation'>
<div class='rec-title'>4. SCHEDULE-BASED SHUTDOWN</div>
<div class='rec-text'>
Stop all clusters outside business hours (e.g., 7 PM - 7 AM).<br>
<b>Potential Savings: 50% of costs</b><br>
<b>Action:</b> Use Azure Automation to stop/start clusters on schedule
</div>
</div>

<div class='recommendation'>
<div class='rec-title'>5. SET UP AZURE COST ALERTS</div>
<div class='rec-text'>
Get email alerts when spending hits 80% of budget.<br>
<b>Action:</b> Azure Portal → Cost Management → Budgets → Create Alert<br>
<b>Prevents:</b> Surprise bills at end of month
</div>
</div>

</div>

<div class='card'>
<h2>📊 COST BREAKDOWN (Estimated)</h2>
<p><b>Current Month Costs:</b></p>
<ul style='margin:15px 0;line-height:2'>
<li>Databricks Compute (VMs): ~70-80% of total</li>
<li>Databricks DBUs (processing units): ~15-20%</li>
<li>Storage (ADLS/Blob): ~5-10%</li>
</ul>

<p style='margin-top:25px'><b>To Answer Preyash's Questions:</b></p>
<ul style='margin:15px 0;line-height:2'>
<li>✅ <b>Are costs from Azure?</b> YES - Databricks runs on Azure VMs</li>
<li>✅ <b>Normal cost:</b> `$$([math]::Round($totalCurrentCost, 2)) this month so far</li>
<li>✅ <b>Max if scaled up:</b> Up to `$$totalMaxCost if all clusters run 24/7</li>
<li>✅ <b>Prevention:</b> Auto-termination + Cost alerts + Cluster policies</li>
</ul>
</div>

<div style='background:#2c3e50;color:white;padding:30px;border-radius:12px;text-align:center;margin-top:35px'>
<b>DATABRICKS COST CONTROL REPORT</b><br><br>
Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')<br>
Total Workspaces: $($allDatabricks.Count) | Current Cost: `$$([math]::Round($totalCurrentCost, 2)) | Budget: `$$MonthlyBudget<br>
Status: $(if($budgetUsed -gt $AlertThreshold){"⚠️ OVER BUDGET"}elseif($budgetUsed -gt 50){"⚠️ MONITOR CLOSELY"}else{"✅ HEALTHY"})
</div>

</div>
</body>
</html>
"@

$html | Out-File $reportFile -Encoding UTF8

Write-Host ""
Write-Host "Report generated: $reportFile" -ForegroundColor Green
Write-Host ""

# Offer to set up alerts
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  NEXT STEPS" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Send the HTML report to Preyash" -ForegroundColor White
Write-Host "2. Set up Azure Cost Management alerts (Portal)" -ForegroundColor White
Write-Host "3. Configure auto-termination on all clusters" -ForegroundColor White
Write-Host "4. Review cluster policies" -ForegroundColor White
Write-Host ""

Start-Process $reportFile

Write-Host "DONE! Report opened in browser." -ForegroundColor Green
Write-Host ""
Write-Host "ANSWER FOR PREYASH:" -ForegroundColor Cyan
Write-Host "===================" -ForegroundColor Cyan
Write-Host "Current cost: `$$([math]::Round($totalCurrentCost, 2)) this month" -ForegroundColor White
Write-Host "Max potential: `$$totalMaxCost (if running 24/7)" -ForegroundColor White
Write-Host "Recommendation: Set auto-termination to prevent high costs" -ForegroundColor White
Write-Host ""
