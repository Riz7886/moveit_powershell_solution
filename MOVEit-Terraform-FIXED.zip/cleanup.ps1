# MOVEit Cleanup Script
# Removes ONLY the NEW security resources we deployed
# DOES NOT TOUCH YOUR MOVEIT SERVER

Write-Host "========================================" -ForegroundColor Yellow
Write-Host "MOVEit Security Resources Cleanup" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Yellow

Write-Host "`n**IMPORTANT**: This script is SAFE for your MOVEit server!" -ForegroundColor Green
Write-Host "It only removes the NEW security resources we added.`n" -ForegroundColor Green

Write-Host "This will REMOVE (new resources we created):" -ForegroundColor Red
Write-Host "  - Load Balancer (NEW)" -ForegroundColor White
Write-Host "  - Public IP (NEW)" -ForegroundColor White
Write-Host "  - Azure Front Door (NEW)" -ForegroundColor White
Write-Host "  - WAF Policy (NEW)" -ForegroundColor White
Write-Host "  - Network Security Group (NEW)" -ForegroundColor White
Write-Host "  - Resource Group 'rg-moveit-security' (NEW)" -ForegroundColor White

Write-Host "`nThis will NOT TOUCH (your existing resources):" -ForegroundColor Green
Write-Host "  - Your MOVEit VM - SAFE" -ForegroundColor Cyan
Write-Host "  - Your Virtual Network - SAFE" -ForegroundColor Cyan
Write-Host "  - Your Subnet - SAFE" -ForegroundColor Cyan
Write-Host "  - Your MOVEit data and config - SAFE" -ForegroundColor Cyan
Write-Host "  - Your MOVEit resource group - SAFE" -ForegroundColor Cyan

$confirm = Read-Host "`nAre you sure? Type 'destroy' to confirm"

if ($confirm -ne "destroy") {
    Write-Host "Cleanup cancelled" -ForegroundColor Yellow
    exit 0
}

Write-Host "`nDestroying resources..." -ForegroundColor Red
terraform destroy -auto-approve

if ($LASTEXITCODE -eq 0) {
    Write-Host "`n========================================" -ForegroundColor Green
    Write-Host "CLEANUP COMPLETE" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "All security resources removed" -ForegroundColor White
    Write-Host "Your MOVEit server and network remain intact" -ForegroundColor White
} else {
    Write-Host "`nCleanup failed - check errors above" -ForegroundColor Red
}
