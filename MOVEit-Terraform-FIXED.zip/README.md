# MOVEit Terraform Auto-Deploy

## WORKS EXACTLY LIKE BULLETPROOF SCRIPT

Lists subscriptions, RGs, VNets, Subnets - you select what you want.

## BEFORE RUNNING - EDIT 2 VALUES

Open `deploy-moveit.ps1` in notepad.

At the top (lines 8-9) you'll see:

```powershell
param(
    [string]$MOVEitPrivateIP = "192.168.0.5",  # <<< CHANGE THIS TO YOUR MOVEIT IP
    [string]$Location = "westus"                # <<< CHANGE THIS TO YOUR REGION
)
```

Change these to YOUR values:
- **MOVEitPrivateIP**: Your MOVEit server private IP (e.g., "10.0.1.4")
- **Location**: Your Azure region (e.g., "eastus", "westus", "centralus")

Save the file.

## THEN RUN

```powershell
.\deploy-moveit.ps1
```

## What Gets Deployed

### Network Security
- Network Security Group with FTPS/HTTPS rules
- Denies all other inbound traffic

### Load Balancer
- Standard SKU Azure Load Balancer
- Public IP for FTPS access
- Backend pool pointing to MOVEit server
- Health probes for HTTPS (443) and FTPS (990)
- Load balancing rules for ports 990, 989

### Azure Front Door
- Standard tier Front Door
- HTTPS endpoint for MOVEit web interface
- Origin group with health probes
- HTTPS-only routing

### WAF Protection
- Prevention mode by default
- Microsoft Managed Rule Set 2.1 (OWASP)
- Bot Manager Rule Set 1.0
- Protects against:
  - SQL injection
  - Cross-site scripting
  - Remote code execution
  - DDoS attacks
  - Bot attacks

### Microsoft Defender
- Standard tier for Virtual Machines
- Real-time threat detection
- Security recommendations

## Prerequisites

1. Azure CLI installed
2. Terraform installed
3. Existing MOVEit server in Azure
4. PowerShell 5.1 or higher

## Deployment Process

The `deploy-moveit.ps1` script:

1. Checks Azure login
2. Auto-detects Virtual Network
3. Auto-detects Subnet
4. Auto-detects MOVEit VM and IP
5. Generates terraform.tfvars automatically
6. Runs terraform init
7. Runs terraform plan
8. Asks for confirmation
9. Runs terraform apply
10. Shows deployment summary with endpoints

## After Deployment

### FTPS Access
```
ftps://<public-ip>:990
```

### HTTPS Access
```
https://<frontdoor-url>.azurefd.net
```

### Verify Deployment

1. Test FTPS: Connect to public IP on port 990
2. Test HTTPS: Browse to Front Door URL
3. Check WAF logs: Azure Portal > Front Door > WAF logs
4. Review NSG rules: Azure Portal > Network Security Groups

## Cost

Estimated monthly cost: **~83 USD**

Breakdown:
- Load Balancer Standard: ~20 USD
- Public IP: ~4 USD
- Front Door Standard: ~35 USD
- WAF: ~20 USD
- NSG: Free
- Defender: ~4 USD

## Troubleshooting

### Script fails to find VNet
- Ensure you're logged into correct subscription
- Check that VNet exists: `az network vnet list`

### Script fails to find MOVEit VM
- Ensure VM exists in same resource group as VNet
- Check VM is running: `az vm list`

### Terraform init fails
- Delete `.terraform` folder
- Delete `.terraform.lock.hcl`
- Run script again

### Terraform apply fails
- Check error message
- Ensure you have permissions in subscription
- Verify no conflicting resources exist

## Manual Configuration (Optional)

If you need to customize, edit `terraform.tfvars` after script generates it:

```hcl
# Change WAF mode
waf_mode = "Detection"  # or "Prevention"

# Disable WAF
enable_waf = false

# Change resource group name
resource_group_name = "rg-custom-name"
```

Then run:
```powershell
terraform plan
terraform apply
```

## Cleanup

To remove all deployed resources:

```powershell
terraform destroy
```

This removes:
- Load Balancer
- Public IP
- Front Door
- WAF Policy
- Network Security Group
- Resource Group

**Note:** This does NOT delete your existing VNet, Subnet, or MOVEit VM.

## Support

For issues or questions:
1. Check Azure Portal for resource status
2. Review Terraform logs
3. Check NSG rules are not blocking traffic
4. Verify MOVEit server is responding on ports 443, 990, 989
