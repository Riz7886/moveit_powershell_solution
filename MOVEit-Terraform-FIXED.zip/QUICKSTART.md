# QUICKSTART - MOVEit Terraform

## ONE COMMAND TO DEPLOY EVERYTHING

```powershell
.\deploy-moveit.ps1
```

## What Happens

1. Script checks Azure login
2. Auto-finds your VNet
3. Auto-finds your Subnet
4. Auto-finds your MOVEit server IP
5. Generates terraform.tfvars
6. Runs terraform init
7. Runs terraform plan
8. Asks "Deploy now? (yes/no)"
9. Type `yes` and press Enter
10. Deploys everything
11. Shows endpoints

## After Deployment

### FTPS Endpoint
```
ftps://[public-ip]:990
```

### HTTPS Endpoint
```
https://[frontdoor-url].azurefd.net
```

### View Details
```powershell
terraform output deployment_summary
```

## That's It

No manual configuration.
No editing files.
No questions asked (except final confirmation).

Just ONE command:
```powershell
.\deploy-moveit.ps1
```

## If Something Goes Wrong

### Delete and try again:
```powershell
terraform destroy
.\deploy-moveit.ps1
```

### Check what Terraform will do:
```powershell
terraform plan
```

### See current resources:
```powershell
terraform show
```

## Cost
~83 USD per month

## Time
5-10 minutes to deploy

## Next Steps After Deployment
1. Test FTPS connection
2. Test HTTPS connection
3. Monitor WAF logs
4. Configure MOVEit settings
