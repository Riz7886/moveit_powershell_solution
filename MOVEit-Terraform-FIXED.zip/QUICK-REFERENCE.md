# QUICK REFERENCE

## Deploy Everything
```powershell
.\deploy-moveit.ps1
```

## View Deployment Details
```powershell
terraform output deployment_summary
```

## View Specific Outputs
```powershell
# Public IP for FTPS
terraform output public_ip_address

# Front Door URL for HTTPS
terraform output frontdoor_endpoint_url

# FTPS connection string
terraform output ftps_connection_string

# HTTPS connection string
terraform output https_connection_string
```

## Test Connectivity
```powershell
# Test FTPS port
Test-NetConnection -ComputerName <public-ip> -Port 990

# Test FTPS data port
Test-NetConnection -ComputerName <public-ip> -Port 989

# Test HTTPS via Front Door
Invoke-WebRequest -Uri https://<frontdoor-url>.azurefd.net
```

## Terraform Commands
```powershell
# Initialize
terraform init

# See what will be created
terraform plan

# Apply changes
terraform apply

# Show current state
terraform show

# List outputs
terraform output

# Destroy everything
terraform destroy
```

## Azure CLI Commands
```powershell
# List VNets
az network vnet list

# List VMs
az vm list --resource-group <rg-name>

# Show VM details
az vm show --name <vm-name> --resource-group <rg-name>

# List Load Balancers
az network lb list --resource-group rg-moveit-security

# Show Load Balancer health
az network lb show --name lb-moveit-prod --resource-group rg-moveit-security

# List Front Door profiles
az afd profile list --resource-group rg-moveit-security

# List NSGs
az network nsg list --resource-group rg-moveit-security

# Show NSG rules
az network nsg rule list --nsg-name nsg-moveit-prod --resource-group rg-moveit-security
```

## Cleanup
```powershell
# Remove all security resources
.\cleanup.ps1

# Or use Terraform directly
terraform destroy
```

## Reset Terraform
```powershell
# Delete cache and state
Remove-Item -Recurse -Force .terraform
Remove-Item terraform.tfstate*
Remove-Item .terraform.lock.hcl
Remove-Item tfplan

# Run deploy again
.\deploy-moveit.ps1
```

## Check Resource Status
```powershell
# Load Balancer backend health
az network lb show --name lb-moveit-prod --resource-group rg-moveit-security --query "backendAddressPools[0].backendIPConfigurations"

# Front Door health
az afd origin show --profile-name afd-moveit-prod --origin-group-name moveit-origin-group --origin-name moveit-origin --resource-group rg-moveit-security

# NSG effective rules
az network nic list-effective-nsg --resource-group <moveit-vm-rg> --name <vm-nic-name>
```

## View Logs
```powershell
# Azure activity logs
az monitor activity-log list --resource-group rg-moveit-security

# Terraform debug
$env:TF_LOG="DEBUG"
terraform apply
```

## Common File Locations
```
deploy-moveit.ps1       - Main deployment script
cleanup.ps1             - Cleanup script
provider.tf             - Terraform provider config
variables.tf            - Terraform variables
main.tf                 - Terraform resources
outputs.tf              - Terraform outputs
terraform.tfvars        - Auto-generated config (DO NOT EDIT)
README.md               - Full documentation
QUICKSTART.md           - Quick start guide
TROUBLESHOOTING.md      - Troubleshooting guide
```

## Endpoints After Deployment

### FTPS (File Transfer)
```
ftps://<public-ip>:990
```

### HTTPS (Web Interface)
```
https://<frontdoor-url>.azurefd.net
```

## What Gets Created
- Network Security Group (NSG)
- Public IP Address
- Load Balancer Standard
- Azure Front Door Standard
- WAF Policy (Prevention mode)
- Microsoft Defender for Cloud

## What Stays Untouched
- Your Virtual Network
- Your Subnet
- Your MOVEit VM
- Your MOVEit data

## Cost
~83 USD per month

## Support Resources
- Azure Portal: https://portal.azure.com
- Terraform Docs: https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs
- Azure CLI Docs: https://docs.microsoft.com/en-us/cli/azure/
