# ================================================================
# MOVEIT TERRAFORM DEPLOYMENT - EXACT BULLETPROOF MATCH
# EDIT THESE VALUES AT TOP OF FILE:
# ================================================================

param(
    [string]$MOVEitPrivateIP = "192.168.0.5",  # <<< CHANGE THIS TO YOUR MOVEIT IP
    [string]$Location = "westus"                # <<< CHANGE THIS TO YOUR AZURE REGION
)

$ErrorActionPreference = "Stop"

function Write-Log {
    param([string]$Message, [string]$Color = "White")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] $Message" -ForegroundColor $Color
}

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  MOVEIT TERRAFORM DEPLOYMENT" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# ----------------------------------------------------------------
# STEP 1: CHECK PREREQUISITES
# ----------------------------------------------------------------
Write-Log "Checking prerequisites..." "Yellow"

# Check Azure CLI
try {
    $azVersion = az version --output json 2>$null | ConvertFrom-Json
    Write-Log "Azure CLI: OK ($($azVersion.'azure-cli'))" "Green"
} catch {
    Write-Log "ERROR: Azure CLI not installed!" "Red"
    Write-Log "Download: https://aka.ms/installazurecli" "Yellow"
    exit 1
}

# Check Terraform
try {
    $tfVersion = terraform version -json 2>$null | ConvertFrom-Json
    Write-Log "Terraform: OK ($($tfVersion.terraform_version))" "Green"
} catch {
    Write-Log "ERROR: Terraform not installed!" "Red"
    Write-Log "Download: https://www.terraform.io/downloads" "Yellow"
    exit 1
}

Write-Host ""

# ----------------------------------------------------------------
# STEP 2: AZURE LOGIN
# ----------------------------------------------------------------
Write-Log "Checking Azure login..." "Yellow"
$loginCheck = az account show 2>$null
if (-not $loginCheck) {
    Write-Log "Not logged in - starting login..." "Yellow"
    az login --use-device-code
} else {
    Write-Log "Already logged in" "Green"
}

Write-Host ""

# ----------------------------------------------------------------
# STEP 3: SELECT SUBSCRIPTION (LIKE BULLETPROOF)
# ----------------------------------------------------------------
Write-Host ""
Write-Log "============================================" "Cyan"
Write-Log "AVAILABLE SUBSCRIPTIONS" "Cyan"
Write-Log "============================================" "Cyan"
Write-Host ""

$subscriptions = az account list --output json | ConvertFrom-Json

if ($subscriptions.Count -eq 0) {
    Write-Log "ERROR: No subscriptions found!" "Red"
    exit 1
}

for ($i = 0; $i -lt $subscriptions.Count; $i++) {
    $sub = $subscriptions[$i]
    $stateColor = if ($sub.state -eq "Enabled") { "Green" } else { "Yellow" }
    Write-Host "[$($i + 1)] " -NoNewline -ForegroundColor Cyan
    Write-Host "$($sub.name) " -NoNewline -ForegroundColor White
    Write-Host "($($sub.state))" -ForegroundColor $stateColor
}

Write-Host ""
$selection = Read-Host "Select subscription number (1-$($subscriptions.Count))"
$selectedSubscription = $subscriptions[[int]$selection - 1]

Write-Log "Setting subscription: $($selectedSubscription.name)" "Yellow"
az account set --subscription $selectedSubscription.id

$currentSub = az account show --output json | ConvertFrom-Json
Write-Log "Active subscription: $($currentSub.name)" "Green"
Write-Host ""

# ----------------------------------------------------------------
# STEP 4: FIND RESOURCE GROUP (LIKE BULLETPROOF)
# ----------------------------------------------------------------
Write-Log "============================================" "Cyan"
Write-Log "FINDING YOUR NETWORK RESOURCES" "Cyan"
Write-Log "============================================" "Cyan"
Write-Host ""

Write-Log "Searching for resource groups..." "Yellow"
$allRGs = az group list --output json | ConvertFrom-Json

if ($allRGs.Count -eq 0) {
    Write-Log "ERROR: No resource groups found!" "Red"
    exit 1
}

# Try to find RG with "network" in name (like bulletproof)
$networkRG = $null
foreach ($rg in $allRGs) {
    if ($rg.name -like "*network*") {
        $networkRG = $rg.name
        Write-Log "FOUND Network RG: $networkRG" "Green"
        break
    }
}

# If not found, show all RGs and let user select
if (-not $networkRG) {
    Write-Log "No RG with 'network' found. Showing all resource groups:" "Yellow"
    Write-Host ""
    
    for ($i = 0; $i -lt $allRGs.Count; $i++) {
        Write-Host "[$($i + 1)] " -NoNewline -ForegroundColor Cyan
        Write-Host "$($allRGs[$i].name)" -ForegroundColor White
    }
    
    Write-Host ""
    $rgSelection = Read-Host "Select resource group for your network (1-$($allRGs.Count))"
    $networkRG = $allRGs[[int]$rgSelection - 1].name
    Write-Log "Selected: $networkRG" "Green"
}

Write-Host ""

# ----------------------------------------------------------------
# STEP 5: FIND VNET (LIKE BULLETPROOF)
# ----------------------------------------------------------------
Write-Log "Searching for VNets in $networkRG..." "Yellow"
$allVNets = az network vnet list --resource-group $networkRG --output json 2>$null | ConvertFrom-Json

if (-not $allVNets -or $allVNets.Count -eq 0) {
    Write-Log "ERROR: No VNets found in $networkRG!" "Red"
    Write-Log "Create a VNet first or select different resource group" "Yellow"
    exit 1
}

Write-Log "FOUND VNets:" "Green"
for ($i = 0; $i -lt $allVNets.Count; $i++) {
    Write-Host "[$($i + 1)] " -NoNewline -ForegroundColor Cyan
    Write-Host "$($allVNets[$i].name)" -ForegroundColor White
}

# Auto-select if only one, or if one has "prod" in name
$selectedVNet = $null
if ($allVNets.Count -eq 1) {
    $selectedVNet = $allVNets[0].name
    Write-Log "Auto-selected (only one): $selectedVNet" "Green"
} else {
    # Try to find "prod" VNet
    foreach ($vnet in $allVNets) {
        if ($vnet.name -like "*prod*") {
            $selectedVNet = $vnet.name
            Write-Log "Auto-selected (has 'prod'): $selectedVNet" "Green"
            break
        }
    }
    
    # If still not found, ask user
    if (-not $selectedVNet) {
        Write-Host ""
        $vnetSelection = Read-Host "Select VNet (1-$($allVNets.Count))"
        $selectedVNet = $allVNets[[int]$vnetSelection - 1].name
        Write-Log "Selected: $selectedVNet" "Green"
    }
}

Write-Host ""

# ----------------------------------------------------------------
# STEP 6: FIND SUBNET (LIKE BULLETPROOF)
# ----------------------------------------------------------------
Write-Log "Searching for subnets in $selectedVNet..." "Yellow"
$vnetDetails = az network vnet show --resource-group $networkRG --name $selectedVNet --output json | ConvertFrom-Json
$allSubnets = $vnetDetails.subnets

if (-not $allSubnets -or $allSubnets.Count -eq 0) {
    Write-Log "ERROR: No subnets found in $selectedVNet!" "Red"
    exit 1
}

Write-Log "FOUND Subnets:" "Green"
for ($i = 0; $i -lt $allSubnets.Count; $i++) {
    Write-Host "[$($i + 1)] " -NoNewline -ForegroundColor Cyan
    Write-Host "$($allSubnets[$i].name)" -NoNewline -ForegroundColor White
    Write-Host " ($($allSubnets[$i].addressPrefix))" -ForegroundColor Gray
}

# Auto-select if only one, or if one has "prod" or "app" in name
$selectedSubnet = $null
if ($allSubnets.Count -eq 1) {
    $selectedSubnet = $allSubnets[0].name
    Write-Log "Auto-selected (only one): $selectedSubnet" "Green"
} else {
    # Try to find "prod" or "app" subnet
    foreach ($subnet in $allSubnets) {
        if ($subnet.name -like "*prod*" -or $subnet.name -like "*app*") {
            $selectedSubnet = $subnet.name
            Write-Log "Auto-selected: $selectedSubnet" "Green"
            break
        }
    }
    
    # If still not found, ask user
    if (-not $selectedSubnet) {
        Write-Host ""
        $subnetSelection = Read-Host "Select Subnet (1-$($allSubnets.Count))"
        $selectedSubnet = $allSubnets[[int]$subnetSelection - 1].name
        Write-Log "Selected: $selectedSubnet" "Green"
    }
}

Write-Host ""

# ----------------------------------------------------------------
# STEP 7: CONFIRM MOVEIT IP
# ----------------------------------------------------------------
Write-Log "============================================" "Cyan"
Write-Log "MOVEIT SERVER CONFIGURATION" "Cyan"
Write-Log "============================================" "Cyan"
Write-Host ""

Write-Log "MOVEit Private IP: $MOVEitPrivateIP" "Yellow"
$changeIP = Read-Host "Is this correct? (yes/no)"

if ($changeIP -eq "no") {
    $MOVEitPrivateIP = Read-Host "Enter MOVEit private IP address"
    Write-Log "Updated to: $MOVEitPrivateIP" "Green"
}

Write-Host ""

# ----------------------------------------------------------------
# STEP 8: SHOW SUMMARY
# ----------------------------------------------------------------
Write-Log "============================================" "Cyan"
Write-Log "CONFIGURATION SUMMARY" "Cyan"
Write-Log "============================================" "Cyan"
Write-Host ""
Write-Host "Subscription:  $($currentSub.name)" -ForegroundColor White
Write-Host "Location:      $Location" -ForegroundColor White
Write-Host ""
Write-Host "Network RG:    $networkRG" -ForegroundColor Cyan
Write-Host "VNet:          $selectedVNet" -ForegroundColor Cyan
Write-Host "Subnet:        $selectedSubnet" -ForegroundColor Cyan
Write-Host ""
Write-Host "MOVEit IP:     $MOVEitPrivateIP" -ForegroundColor Yellow
Write-Host ""
Write-Host "Will create NEW resource group: rg-moveit-security" -ForegroundColor Green
Write-Host "Will deploy: NSG, Load Balancer, Front Door, WAF" -ForegroundColor Green
Write-Host ""
Write-Host "Cost: ~83 USD/month" -ForegroundColor Yellow
Write-Host ""

$confirm = Read-Host "Continue with deployment? (yes/no)"
if ($confirm -ne "yes") {
    Write-Log "Deployment cancelled" "Yellow"
    exit 0
}

Write-Host ""

# ----------------------------------------------------------------
# STEP 9: GENERATE TERRAFORM.TFVARS
# ----------------------------------------------------------------
Write-Log "Generating Terraform configuration..." "Cyan"

$tfvars = @"
# Auto-generated by deploy-moveit.ps1
# Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")

subscription_id      = "$($currentSub.id)"
location            = "$Location"

# Network (Existing)
existing_vnet_name  = "$selectedVNet"
existing_vnet_rg    = "$networkRG"
existing_subnet_name = "$selectedSubnet"

# MOVEit Server
moveit_private_ip   = "$MOVEitPrivateIP"

# Deployment
resource_group_name = "rg-moveit-security"
project_name        = "moveit"
environment         = "prod"

# Security
enable_waf          = true
waf_mode            = "Prevention"
"@

$tfvars | Out-File -FilePath "terraform.tfvars" -Encoding UTF8
Write-Log "Created terraform.tfvars" "Green"
Write-Host ""

# ----------------------------------------------------------------
# STEP 10: TERRAFORM INIT
# ----------------------------------------------------------------
Write-Log "============================================" "Cyan"
Write-Log "INITIALIZING TERRAFORM" "Cyan"
Write-Log "============================================" "Cyan"
Write-Host ""

terraform init

if ($LASTEXITCODE -ne 0) {
    Write-Log "ERROR: Terraform init failed!" "Red"
    exit 1
}

Write-Host ""

# ----------------------------------------------------------------
# STEP 11: TERRAFORM PLAN
# ----------------------------------------------------------------
Write-Log "============================================" "Cyan"
Write-Log "TERRAFORM PLAN" "Cyan"
Write-Log "============================================" "Cyan"
Write-Host ""

terraform plan -out=tfplan

if ($LASTEXITCODE -ne 0) {
    Write-Log "ERROR: Terraform plan failed!" "Red"
    exit 1
}

Write-Host ""

# ----------------------------------------------------------------
# STEP 12: TERRAFORM APPLY
# ----------------------------------------------------------------
Write-Log "============================================" "Yellow"
Write-Log "READY TO DEPLOY" "Yellow"
Write-Log "============================================" "Yellow"
Write-Host ""

$finalConfirm = Read-Host "Deploy now? (yes/no)"
if ($finalConfirm -ne "yes") {
    Write-Log "Deployment cancelled" "Yellow"
    exit 0
}

Write-Host ""
Write-Log "============================================" "Cyan"
Write-Log "DEPLOYING (5-10 minutes)..." "Cyan"
Write-Log "============================================" "Cyan"
Write-Host ""

terraform apply tfplan

if ($LASTEXITCODE -ne 0) {
    Write-Log "ERROR: Terraform apply failed!" "Red"
    exit 1
}

Write-Host ""

# ----------------------------------------------------------------
# STEP 13: SHOW RESULTS
# ----------------------------------------------------------------
Write-Log "============================================" "Green"
Write-Log "DEPLOYMENT COMPLETED!" "Green"
Write-Log "============================================" "Green"
Write-Host ""

terraform output deployment_summary

Write-Host ""
Write-Log "Configuration saved: terraform.tfvars" "Cyan"
Write-Log "Terraform state saved: terraform.tfstate" "Cyan"
Write-Host ""
Write-Log "To destroy: terraform destroy" "Yellow"
Write-Host ""
