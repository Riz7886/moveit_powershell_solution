
# Deploy-Datadog-Auto.ps1
# FINAL VERSION WITH CSV REPORTING

param(
    [Parameter(Mandatory=$true)][string]$DatadogApiKey,
    [Parameter(Mandatory=$true)][string]$DatadogAppKey,
    [Parameter(Mandatory=$true)][string]$ResourceGroupName,
    [Parameter(Mandatory=$true)][string]$HostPoolName,
    [string]$DatadogRegion = "us3",
    [string]$AlertEmail = "admin@example.com",
    [string]$ReportPath = ".\Datadog-Deployment-Report.csv"
)

$ErrorActionPreference = "Stop"
$Report = @()

function Write-Report {
    param($Stage,$Status,$Details)
    $Report += [pscustomobject]@{
        Timestamp = (Get-Date)
        Stage     = $Stage
        Status    = $Status
        Details   = $Details
    }
}

Write-Report "Start" "OK" "Deployment started"

Write-Host "=== Discovering Azure subscriptions ==="
$subs = Get-AzSubscription
for ($i=0; $i -lt $subs.Count; $i++) { Write-Host "[$i] $($subs[$i].Name) - $($subs[$i].Id)" }
$sel = Read-Host "Enter subscription index"
$sub = $subs[$sel]
Select-AzSubscription -SubscriptionId $sub.Id
Write-Report "Subscription Select" "OK" $sub.Id

Write-Host "=== Registering Providers ==="
$providers = @("Microsoft.Insights","Microsoft.OperationsManagement","Microsoft.Resources","Datadog")
foreach ($p in $providers) {
    Register-AzResourceProvider -ProviderNamespace $p | Out-Null
}
Write-Report "Provider Registration" "OK" "All providers registered"

Write-Host "=== Creating Datadog SPN ==="
$app = New-AzADApplication -DisplayName "Datadog-Monitoring-Auto"
$sp  = New-AzADServicePrincipal -ApplicationId $app.AppId
Write-Report "SP Creation" "OK" $sp.Id

Write-Host "=== Assigning FULL RBAC ==="
$roles = @("Reader","Monitoring Reader","Resource Health Contributor","Managed Identity Operator")
foreach ($r in $roles) {
    New-AzRoleAssignment -ObjectId $sp.Id -RoleDefinitionName $r -Scope "/subscriptions/$($sub.Id)" | Out-Null
}
Write-Report "RBAC Assignment" "OK" "All full roles assigned"

Write-Host "=== Installing Datadog Agents on ALL VMs ==="
$vms = Get-AzVM -Status
foreach ($vm in $vms) {
    if ($vm.StorageProfile.OsDisk.OsType -eq "Windows") {
        Invoke-AzVMRunCommand -ResourceGroupName $vm.ResourceGroupName -Name $vm.Name `
        -CommandId "RunPowerShellScript" `
        -ScriptString @"
\$env:DD_API_KEY = '$DatadogApiKey'
\$env:DD_SITE = 'datadoghq.com'
Invoke-WebRequest -UseBasicParsing https://s3.amazonaws.com/dd-agent/scripts/install_script.ps1 -OutFile install.ps1
powershell -ExecutionPolicy Bypass -File install.ps1
"@
        Write-Report "Agent Install" "OK" "Windows: $($vm.Name)"
    }
    else {
        Invoke-AzVMRunCommand -ResourceGroupName $vm.ResourceGroupName -Name $vm.Name `
        -CommandId "RunShellScript" `
        -ScriptString "DD_API_KEY=$DatadogApiKey DD_SITE=datadoghq.com bash -c '$(curl -L https://s3.amazonaws.com/dd-agent/scripts/install_script.sh)'" 
        Write-Report "Agent Install" "OK" "Linux: $($vm.Name)"
    }
}

Write-Host "=== Creating Datadog Monitors ==="

$headers = @{
    "DD-API-KEY"        = $DatadogApiKey
    "DD-APPLICATION-KEY" = $DatadogAppKey
    "Content-Type"      = "application/json"
}

function New-DDMonitor {
param($StageName,$Name,$Type,$Query,$Message,$Options)
try {
    $body = @{
        name=$Name; type=$Type; query=$Query; message=$Message;
        tags=@("avd","auto","production"); options=$Options
    }
    Invoke-RestMethod -Uri "https://api.$DatadogRegion.datadoghq.com/api/v1/monitor" `
    -Headers $headers -Method Post -Body ($body | ConvertTo-Json -Depth 6)
    Write-Report $StageName "OK" $Name
}
catch {
    Write-Report $StageName "FAIL" $_.Exception.Message
}
}

# ALL monitors exactly as original
New-DDMonitor "Monitor CPU" "AVD - High CPU Usage - $HostPoolName" "metric alert" `
"avg(last_5m):avg:azure.compute.virtualmachine.percentage_cpu{resource_group:$ResourceGroupName} > 85" `
"CPU usage above 85%. $AlertEmail" `
@{ thresholds=@{critical=85;warning=75}; notify_no_data=$true; no_data_timeframe=10 }

New-DDMonitor "Monitor Memory" "AVD - High Memory Usage - $HostPoolName" "metric alert" `
"avg(last_5m):avg:system.mem.pct_usable{resource_group:$ResourceGroupName} < 15" `
"Memory below 15%. $AlertEmail" `
@{ thresholds=@{critical=15;warning=20}; notify_no_data=$true }

New-DDMonitor "Monitor Disk" "AVD - High Disk Usage - $HostPoolName" "metric alert" `
"avg(last_5m):avg:system.disk.in_use{resource_group:$ResourceGroupName} > 85" `
"Disk usage above 85%. $AlertEmail" `
@{ thresholds=@{critical=85;warning=75}; notify_no_data=$true }

New-DDMonitor "Monitor Host Down" "AVD - Session Host Down - $HostPoolName" "service check" `
"azure.vm.status{resource_group:$ResourceGroupName}.over('host').last(2).count_by_status()" `
"Session host down. $AlertEmail" `
@{ thresholds=@{critical=1}; notify_no_data=$true }

New-DDMonitor "Monitor Latency" "AVD - High Network Latency - $HostPoolName" "metric alert" `
"avg(last_5m):avg:azure.network.latency{resource_group:$ResourceGroupName} > 100" `
"Network latency high. $AlertEmail" `
@{ thresholds=@{critical=100;warning=75} }

New-DDMonitor "Monitor Storage" "AVD - Storage Account Unavailable - $HostPoolName" "service check" `
"azure.storage.availability{resource_group:$ResourceGroupName}.over('storage_account').last(3).count_by_status()" `
"Storage unavailable. $AlertEmail" `
@{ thresholds=@{critical=1}; notify_no_data=$true }

New-DDMonitor "Monitor Sessions" "AVD - High User Session Count - $HostPoolName" "metric alert" `
"avg(last_10m):avg:azure.desktopvirtualization.hostpool.active_sessions{host_pool:$HostPoolName} > 80" `
"High user session load. $AlertEmail" `
@{ thresholds=@{warning=80} }

New-DDMonitor "Monitor Failed Conn" "AVD - Failed User Connections - $HostPoolName" "metric alert" `
"sum(last_5m):sum:azure.desktopvirtualization.hostpool.failed_connections{host_pool:$HostPoolName} > 5" `
"Failed user connections. $AlertEmail" `
@{ thresholds=@{critical=5;warning=3} }

New-DDMonitor "Monitor Agent Heartbeat" "AVD - Agent Heartbeat Loss - $HostPoolName" "service check" `
"datadog.agent.up{resource_group:$ResourceGroupName}.over('host').last(3).count_by_status()" `
"Datadog agent not reporting. $AlertEmail" `
@{ thresholds=@{critical=1}; notify_no_data=$true; no_data_timeframe=10 }

New-DDMonitor "Monitor RG Changes" "AVD - Resource Group Changes - $ResourceGroupName" "event alert" `
"events('sources:azure resource_group:$ResourceGroupName').rollup('count').last('10m') > 5" `
"Unusual changes detected. $AlertEmail" `
@{ thresholds=@{critical=5} }

Write-Report "Monitors" "OK" "All monitors created"

Write-Host "=== Writing CSV Report ==="
$Report | Export-Csv -Path $ReportPath -NoTypeInformation

Write-Host "=== Deployment Complete ==="
