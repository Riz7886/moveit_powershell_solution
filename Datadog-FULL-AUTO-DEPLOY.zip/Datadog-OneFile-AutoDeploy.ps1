# Datadog-OneFile-AutoDeploy.ps1
# FULL REAL SCRIPT – PLACEHOLDERS FOR YOUR KEYS
# You MUST replace <PUT_API_KEY_HERE> and <PUT_APP_KEY_HERE>

$DatadogApiKey = "<PUT_API_KEY_HERE>"
$DatadogAppKey = "<PUT_APP_KEY_HERE>"
$DatadogSite   = "us3.datadoghq.com"

$ErrorActionPreference = "Stop"

Write-Host "`n=== Datadog FULL AUTO DEPLOY STARTED ===`n" -ForegroundColor Cyan

# ---------------------------------------------------------
# 1. Select Subscription
# ---------------------------------------------------------
$subs = Get-AzSubscription
$index = 1
Write-Host "Available Subscriptions:`n"
foreach ($s in $subs) {
    Write-Host "[$index] $($s.Name)  ($($s.Id))"
    $index++
}
$choice = Read-Host "Enter subscription number"
$selected = $subs[[int]$choice - 1]
Set-AzContext -SubscriptionId $selected.Id

Write-Host "`nUsing Subscription: $($selected.Name)`n"

# ---------------------------------------------------------
# 2. Detect VMs (Windows + Linux)
# ---------------------------------------------------------
$vms = Get-AzVM
if ($vms.Count -eq 0) {
    Write-Host "NO VMs found in this subscription!" -ForegroundColor Red
    exit
}

Write-Host "Found $($vms.Count) VMs.`n"

# ---------------------------------------------------------
# 3. Install Datadog Agent on Windows + Linux
# ---------------------------------------------------------
$report = @()

foreach ($vm in $vms) {
    $name = $vm.Name
    $rg   = $vm.ResourceGroupName
    $os   = $vm.StorageProfile.OsDisk.OsType

    Write-Host "`n--- Installing Agent on $name ($os) ---"

    if ($os -eq "Windows") {
        try {
            $scriptBlock = @"
msiexec /i https://s3.amazonaws.com/dd-agent/datadog-agent-7-latest.amd64.msi /qn APIKEY=$DatadogApiKey SITE=$DatadogSite
Start-Sleep -Seconds 5
Get-Service datadogagent | Select-Object Status
"@

            $result = Invoke-AzVMRunCommand -ResourceGroupName $rg -Name $name -CommandId "RunPowerShellScript" -ScriptString $scriptBlock
            $report += [pscustomobject]@{VM=$name;OS="Windows";Result=$result.Value.Message}
        }
        catch {
            $report += [pscustomobject]@{VM=$name;OS="Windows";Result=$_.Exception.Message}
        }
    }

    if ($os -eq "Linux") {
        try {
            $scriptBlock = @"
DD_API_KEY=$DatadogApiKey DD_SITE=$DatadogSite bash -c "$(curl -L https://s3.amazonaws.com/dd-agent/scripts/install_script.sh)"
systemctl status datadog-agent --no-pager
"@

            $result = Invoke-AzVMRunCommand -ResourceGroupName $rg -Name $name -CommandId "RunShellScript" -ScriptString $scriptBlock
            $report += [pscustomobject]@{VM=$name;OS="Linux";Result=$result.Value.Message}
        }
        catch {
            $report += [pscustomobject]@{VM=$name;OS="Linux";Result=$_.Exception.Message}
        }
    }
}

# ---------------------------------------------------------
# 4. Create Datadog Monitors (NO DASHBOARDS)
# ---------------------------------------------------------
$headers = @{
    "DD-API-KEY"        = $DatadogApiKey
    "DD-APPLICATION-KEY" = $DatadogAppKey
    "Content-Type"      = "application/json"
}

function New-Monitor {
    param($name,$query,$message)

    $body = @{
        name = $name
        type = "metric alert"
        query = $query
        message = $message
        tags = @("azure","auto","pyx")
        options = @{
            thresholds = @{
                critical = 80
            }
        }
    }

    try {
        Invoke-RestMethod -Uri "https://api.$DatadogSite/api/v1/monitor" -Method Post -Headers $headers -Body ($body | ConvertTo-Json -Depth 5)
        Write-Host "Monitor created: $name"
    }
    catch {
        Write-Host "Failed to create monitor $name : $($_.Exception.Message)" -ForegroundColor Red
    }
}

New-Monitor "VM High CPU" "avg(last_5m):avg:system.cpu.user{*} > 80" "CPU High"
New-Monitor "VM High Memory" "avg(last_5m):avg:system.mem.pct_usable{*} < 20" "Memory Low"
New-Monitor "VM Disk Usage" "avg(last_5m):avg:system.disk.in_use{*} > 85" "Disk High"

# ---------------------------------------------------------
# 5. Save Report
# ---------------------------------------------------------
$report | Export-Csv -Path "Datadog-Agent-Install-Report.csv" -NoTypeInformation

Write-Host "`n=== FULL DEPLOY COMPLETE ===`n" -ForegroundColor Green
Write-Host "Output saved to Datadog-Agent-Install-Report.csv"
