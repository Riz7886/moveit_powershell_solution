# DATABRICKS COMPLETE AUTO-SETUP
# Sets up: Cost Alerts + Auto-Termination + Cluster Policies + All Recommendations

param(
    [Parameter(Mandatory=$false)]
    [int]$MonthlyBudget = 5000,
    
    [Parameter(Mandatory=$false)]
    [string[]]$AlertEmails = @(
        "preyash.patel@pyxhealth.com",
        "tony@pyxhealth.com", 
        "john@pyxhealth.com",
        "brian.burge@pyxhealth.com"
    ),
    
    [Parameter(Mandatory=$false)]
    [int]$AutoTerminationMinutes = 30,
    
    [Parameter(Mandatory=$false)]
    [int]$MaxWorkers = 10,
    
    [Parameter(Mandatory=$false)]
    [string]$DatabricksToken = ""
)

Clear-Host
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  DATABRICKS COMPLETE AUTO-SETUP" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This script will configure:" -ForegroundColor Yellow
Write-Host "  1. Azure Cost Alerts (4 thresholds)" -ForegroundColor White
Write-Host "  2. Auto-Termination on all clusters" -ForegroundColor White
Write-Host "  3. Cluster Size Policies" -ForegroundColor White
Write-Host "  4. Databricks Cost Controls" -ForegroundColor White
Write-Host ""
Write-Host "Settings:" -ForegroundColor Cyan
Write-Host "  Monthly Budget: `$$MonthlyBudget" -ForegroundColor White
Write-Host "  Auto-Termination: $AutoTerminationMinutes minutes" -ForegroundColor White
Write-Host "  Max Cluster Size: $MaxWorkers workers" -ForegroundColor White
Write-Host "  Email Recipients: $($AlertEmails.Count)" -ForegroundColor White
Write-Host ""

$confirm = Read-Host "Continue with setup? (yes/no)"
if ($confirm -ne "yes") {
    Write-Host "Setup cancelled" -ForegroundColor Yellow
    exit
}

Write-Host ""

# Connect to Azure
Write-Host "Step 1: Connecting to Azure..." -ForegroundColor Cyan
try {
    $context = Get-AzContext
    if (-not $context) {
        Connect-AzAccount | Out-Null
    }
    Write-Host "  Connected: $($context.Account.Id)" -ForegroundColor Green
} catch {
    Write-Host "  ERROR: Cannot connect to Azure" -ForegroundColor Red
    exit
}

Write-Host ""

# Get all subscriptions
$subs = Get-AzSubscription
Write-Host "Step 2: Scanning subscriptions..." -ForegroundColor Cyan
Write-Host "  Found $($subs.Count) subscriptions" -ForegroundColor Green
Write-Host ""

$alertsCreated = 0
$clustersUpdated = 0
$policiesCreated = 0
$workspacesConfigured = 0

foreach ($sub in $subs) {
    Write-Host "Subscription: $($sub.Name)" -ForegroundColor Yellow
    
    try {
        Set-AzContext -SubscriptionId $sub.Id -ErrorAction Stop | Out-Null
    } catch {
        Write-Host "  Cannot access - skipping" -ForegroundColor Red
        continue
    }
    
    # Find Databricks workspaces
    $workspaces = Get-AzResource -ResourceType "Microsoft.Databricks/workspaces" -ErrorAction SilentlyContinue
    
    if (-not $workspaces -or $workspaces.Count -eq 0) {
        Write-Host "  No Databricks workspaces - skipping" -ForegroundColor Gray
        Write-Host ""
        continue
    }
    
    Write-Host "  Found $($workspaces.Count) Databricks workspace(s)" -ForegroundColor Green
    
    # PART 1: SET UP AZURE COST ALERTS
    Write-Host ""
    Write-Host "  [1/3] Setting up Azure Cost Alerts..." -ForegroundColor Cyan
    
    $budgetName = "Databricks-Monthly-Budget-$($sub.Name)"
    
    # Remove old budget if exists
    $existingBudget = Get-AzConsumptionBudget -Name $budgetName -ErrorAction SilentlyContinue
    if ($existingBudget) {
        Remove-AzConsumptionBudget -Name $budgetName -ErrorAction SilentlyContinue | Out-Null
    }
    
    # Create notifications
    $notifications = @{}
    
    $notifications["Alert1-50Percent"] = New-AzConsumptionBudgetNotificationObject `
        -Enabled $true `
        -Operator GreaterThan `
        -Threshold 50 `
        -ContactEmail $AlertEmails `
        -ThresholdType Actual
    
    $notifications["Alert2-80Percent"] = New-AzConsumptionBudgetNotificationObject `
        -Enabled $true `
        -Operator GreaterThan `
        -Threshold 80 `
        -ContactEmail $AlertEmails `
        -ThresholdType Actual
    
    $notifications["Alert3-100Percent"] = New-AzConsumptionBudgetNotificationObject `
        -Enabled $true `
        -Operator GreaterThan `
        -Threshold 100 `
        -ContactEmail $AlertEmails `
        -ThresholdType Actual
    
    $notifications["Alert4-120Percent"] = New-AzConsumptionBudgetNotificationObject `
        -Enabled $true `
        -Operator GreaterThan `
        -Threshold 120 `
        -ContactEmail $AlertEmails `
        -ThresholdType Actual
    
    $startDate = Get-Date -Day 1
    $timePeriod = New-AzConsumptionBudgetTimePeriodObject -StartDate $startDate
    
    try {
        New-AzConsumptionBudget `
            -Name $budgetName `
            -Amount $MonthlyBudget `
            -Category Cost `
            -TimeGrain Monthly `
            -TimePeriod $timePeriod `
            -Notification $notifications `
            -ErrorAction Stop | Out-Null
        
        Write-Host "    Cost alerts created: 50%, 80%, 100%, 120%" -ForegroundColor Green
        $alertsCreated++
        
    } catch {
        Write-Host "    ERROR: Could not create alerts" -ForegroundColor Red
    }
    
    # PART 2: CONFIGURE DATABRICKS WORKSPACES
    Write-Host ""
    Write-Host "  [2/3] Configuring Databricks Workspaces..." -ForegroundColor Cyan
    
    foreach ($ws in $workspaces) {
        Write-Host "    Workspace: $($ws.Name)" -ForegroundColor White
        
        # Get workspace details
        $workspace = Get-AzDatabricksWorkspace -ResourceGroupName $ws.ResourceGroupName -Name $ws.Name -ErrorAction SilentlyContinue
        
        if (-not $workspace) {
            Write-Host "      Cannot get workspace details" -ForegroundColor Yellow
            continue
        }
        
        # Get workspace URL
        $workspaceUrl = $workspace.Url
        if (-not $workspaceUrl) {
            $workspaceUrl = "https://$($workspace.WorkspaceUrl)"
        }
        
        Write-Host "      URL: $workspaceUrl" -ForegroundColor Gray
        
        # Check if we have Databricks token
        if ([string]::IsNullOrEmpty($DatabricksToken)) {
            Write-Host "      SKIPPING: No Databricks token provided" -ForegroundColor Yellow
            Write-Host "      To configure clusters, run with -DatabricksToken parameter" -ForegroundColor Yellow
            continue
        }
        
        # Configure Databricks via API
        $headers = @{
            "Authorization" = "Bearer $DatabricksToken"
            "Content-Type" = "application/json"
        }
        
        # Get all clusters
        try {
            $clustersUrl = "$workspaceUrl/api/2.0/clusters/list"
            $clustersResponse = Invoke-RestMethod -Uri $clustersUrl -Headers $headers -Method Get -ErrorAction Stop
            
            if ($clustersResponse.clusters) {
                Write-Host "      Found $($clustersResponse.clusters.Count) cluster(s)" -ForegroundColor Green
                
                foreach ($cluster in $clustersResponse.clusters) {
                    Write-Host "        Cluster: $($cluster.cluster_name)" -ForegroundColor Gray
                    
                    # Update cluster with auto-termination
                    $clusterConfig = @{
                        cluster_id = $cluster.cluster_id
                        autotermination_minutes = $AutoTerminationMinutes
                    }
                    
                    try {
                        $updateUrl = "$workspaceUrl/api/2.0/clusters/edit"
                        
                        # Get full cluster config
                        $getUrl = "$workspaceUrl/api/2.0/clusters/get?cluster_id=$($cluster.cluster_id)"
                        $fullCluster = Invoke-RestMethod -Uri $getUrl -Headers $headers -Method Get -ErrorAction Stop
                        
                        # Update auto-termination
                        $fullCluster.autotermination_minutes = $AutoTerminationMinutes
                        
                        # Remove read-only fields
                        $fullCluster.PSObject.Properties.Remove('cluster_id')
                        $fullCluster.PSObject.Properties.Remove('state')
                        $fullCluster.PSObject.Properties.Remove('state_message')
                        $fullCluster.PSObject.Properties.Remove('start_time')
                        $fullCluster.PSObject.Properties.Remove('terminated_time')
                        $fullCluster.PSObject.Properties.Remove('last_state_loss_time')
                        $fullCluster.PSObject.Properties.Remove('last_activity_time')
                        $fullCluster.PSObject.Properties.Remove('cluster_memory_mb')
                        $fullCluster.PSObject.Properties.Remove('cluster_cores')
                        $fullCluster.PSObject.Properties.Remove('default_tags')
                        $fullCluster.PSObject.Properties.Remove('cluster_log_status')
                        $fullCluster.PSObject.Properties.Remove('termination_reason')
                        
                        $updateBody = @{
                            cluster_id = $cluster.cluster_id
                        }
                        
                        foreach ($prop in $fullCluster.PSObject.Properties) {
                            $updateBody[$prop.Name] = $prop.Value
                        }
                        
                        $updateBody.autotermination_minutes = $AutoTerminationMinutes
                        
                        $updateJson = $updateBody | ConvertTo-Json -Depth 10
                        
                        Invoke-RestMethod -Uri $updateUrl -Headers $headers -Method Post -Body $updateJson -ErrorAction Stop | Out-Null
                        
                        Write-Host "          Auto-termination set: $AutoTerminationMinutes min" -ForegroundColor Green
                        $clustersUpdated++
                        
                    } catch {
                        Write-Host "          ERROR: $($_.Exception.Message)" -ForegroundColor Red
                    }
                }
            } else {
                Write-Host "      No clusters found" -ForegroundColor Gray
            }
            
        } catch {
            Write-Host "      ERROR: Cannot access Databricks API" -ForegroundColor Red
            Write-Host "      $($_.Exception.Message)" -ForegroundColor Red
        }
        
        # Create cluster policy
        Write-Host ""
        Write-Host "      Creating cluster policy..." -ForegroundColor Cyan
        
        $policyDefinition = @{
            "max_workers" = @{
                "type" = "fixed"
                "value" = $MaxWorkers
            }
            "autotermination_minutes" = @{
                "type" = "fixed"
                "value" = $AutoTerminationMinutes
            }
            "spark_version" = @{
                "type" = "unlimited"
            }
            "node_type_id" = @{
                "type" = "allowlist"
                "values" = @("Standard_DS3_v2", "Standard_DS4_v2", "Standard_DS5_v2")
            }
        }
        
        $policyBody = @{
            name = "Cost-Control-Policy"
            definition = ($policyDefinition | ConvertTo-Json -Depth 10)
        } | ConvertTo-Json
        
        try {
            $policyUrl = "$workspaceUrl/api/2.0/policies/clusters/create"
            Invoke-RestMethod -Uri $policyUrl -Headers $headers -Method Post -Body $policyBody -ErrorAction Stop | Out-Null
            
            Write-Host "      Cluster policy created" -ForegroundColor Green
            Write-Host "        Max workers: $MaxWorkers" -ForegroundColor Gray
            Write-Host "        Auto-termination: $AutoTerminationMinutes min" -ForegroundColor Gray
            $policiesCreated++
            
        } catch {
            if ($_.Exception.Message -like "*already exists*") {
                Write-Host "      Policy already exists - skipping" -ForegroundColor Yellow
            } else {
                Write-Host "      ERROR: Could not create policy" -ForegroundColor Red
            }
        }
        
        $workspacesConfigured++
    }
    
    Write-Host ""
}

# Summary
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  SETUP COMPLETE" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "RESULTS:" -ForegroundColor Yellow
Write-Host "  Cost Alerts Created: $alertsCreated subscriptions" -ForegroundColor White
Write-Host "  Workspaces Configured: $workspacesConfigured" -ForegroundColor White
Write-Host "  Clusters Updated: $clustersUpdated" -ForegroundColor White
Write-Host "  Policies Created: $policiesCreated" -ForegroundColor White
Write-Host ""

if ([string]::IsNullOrEmpty($DatabricksToken)) {
    Write-Host "NOTE: Databricks configuration was SKIPPED" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "To configure Databricks clusters and policies:" -ForegroundColor Cyan
    Write-Host "  1. Get Databricks Personal Access Token:" -ForegroundColor White
    Write-Host "     - Open Databricks workspace" -ForegroundColor Gray
    Write-Host "     - Click User Settings" -ForegroundColor Gray
    Write-Host "     - Generate New Token" -ForegroundColor Gray
    Write-Host "  2. Run script again with token:" -ForegroundColor White
    Write-Host "     .\DATABRICKS-COMPLETE-SETUP.ps1 -DatabricksToken 'your-token-here'" -ForegroundColor Gray
    Write-Host ""
}

Write-Host "CONFIGURATION SUMMARY:" -ForegroundColor Cyan
Write-Host "  Budget: `$$MonthlyBudget/month" -ForegroundColor White
Write-Host "  Alert Thresholds: 50%, 80%, 100%, 120%" -ForegroundColor White
Write-Host "  Auto-Termination: $AutoTerminationMinutes minutes" -ForegroundColor White
Write-Host "  Max Cluster Size: $MaxWorkers workers" -ForegroundColor White
Write-Host "  Email Recipients: $($AlertEmails.Count)" -ForegroundColor White
foreach ($email in $AlertEmails) {
    Write-Host "    - $email" -ForegroundColor Gray
}
Write-Host ""

Write-Host "To verify in Azure Portal:" -ForegroundColor Yellow
Write-Host "  Cost Management + Billing > Budgets" -ForegroundColor White
Write-Host ""

Write-Host "DONE!" -ForegroundColor Green
