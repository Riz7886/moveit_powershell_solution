#Requires -Version 5.1
<#
.SYNOPSIS
    Test Datadog API Keys - Find EXACT Problem
#>

$ErrorActionPreference = 'Stop'

# YOUR KEYS FROM THE IMAGES
$apiKey = 'e390a1103701b7aba1b0f27340620c932'
$appKey = 'c2ec7440597b571e24e9619936def1f4'
$apiUrl = 'https://api.us3.datadoghq.com/api/v1'

Write-Host ""
Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host "  TESTING YOUR DATADOG API KEYS" -ForegroundColor White
Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host ""

$headers = @{
    'DD-API-KEY' = $apiKey
    'DD-APPLICATION-KEY' = $appKey
    'Content-Type' = 'application/json'
}

# TEST 1: Validate API
Write-Host "[TEST 1] Validating API Keys..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$apiUrl/validate" -Headers $headers -Method Get -ErrorAction Stop
    Write-Host "  ✓ API Keys are VALID!" -ForegroundColor Green
    Write-Host "    Valid: $($response.valid)" -ForegroundColor Gray
}
catch {
    Write-Host "  ✗ API Keys FAILED validation!" -ForegroundColor Red
    Write-Host "    Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "    Status: $($_.Exception.Response.StatusCode.value__)" -ForegroundColor Red
    Write-Host ""
    Write-Host "PROBLEM: Keys are not valid for authentication" -ForegroundColor Red
    exit 1
}

# TEST 2: List Monitors (Read Permission)
Write-Host ""
Write-Host "[TEST 2] Testing READ permission (list monitors)..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$apiUrl/monitor" -Headers $headers -Method Get -ErrorAction Stop
    Write-Host "  ✓ Can READ monitors!" -ForegroundColor Green
    Write-Host "    Found: $($response.Count) existing monitors" -ForegroundColor Gray
}
catch {
    Write-Host "  ✗ Cannot READ monitors!" -ForegroundColor Red
    Write-Host "    Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "    Status: $($_.Exception.Response.StatusCode.value__)" -ForegroundColor Red
    Write-Host ""
    Write-Host "PROBLEM: No read permission on monitors" -ForegroundColor Red
    exit 1
}

# TEST 3: Create Test Monitor (Write Permission)
Write-Host ""
Write-Host "[TEST 3] Testing WRITE permission (create monitor)..." -ForegroundColor Yellow

$testMonitor = @{
    type = "metric alert"
    query = "avg(last_5m):avg:system.cpu.user{*} > 100"
    name = "TEST-DELETE-ME-$(Get-Random)"
    message = "Test monitor - DELETE ME"
    tags = @('test:delete-me')
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "$apiUrl/monitor" -Headers $headers -Method Post -Body $testMonitor -ErrorAction Stop
    Write-Host "  ✓ Can WRITE monitors!" -ForegroundColor Green
    Write-Host "    Created test monitor ID: $($response.id)" -ForegroundColor Gray
    
    # Delete test monitor
    Write-Host "    Cleaning up test monitor..." -ForegroundColor Gray
    Invoke-RestMethod -Uri "$apiUrl/monitor/$($response.id)" -Headers $headers -Method Delete -ErrorAction Stop
    Write-Host "    Test monitor deleted" -ForegroundColor Gray
    
    Write-Host ""
    Write-Host "=====================================================================" -ForegroundColor Green
    Write-Host "  ALL TESTS PASSED - YOUR KEYS WORK PERFECTLY!" -ForegroundColor Green
    Write-Host "=====================================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Your keys have full permissions." -ForegroundColor Green
    Write-Host "The main deployment script should work now." -ForegroundColor Green
    Write-Host ""
}
catch {
    $statusCode = $_.Exception.Response.StatusCode.value__
    $errorMessage = $_.Exception.Message
    
    Write-Host "  ✗ Cannot WRITE monitors!" -ForegroundColor Red
    Write-Host "    Error: $errorMessage" -ForegroundColor Red
    Write-Host "    Status Code: $statusCode" -ForegroundColor Red
    Write-Host ""
    
    if ($statusCode -eq 401) {
        Write-Host "=====================================================================" -ForegroundColor Red
        Write-Host "  PROBLEM FOUND: 401 UNAUTHORIZED" -ForegroundColor Red
        Write-Host "=====================================================================" -ForegroundColor Red
        Write-Host ""
        Write-Host "Your Application Key does NOT have 'monitors_write' permission!" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "FIX THIS NOW:" -ForegroundColor Cyan
        Write-Host "1. Go to: https://app.us3.datadoghq.com/organization-settings/application-keys" -ForegroundColor White
        Write-Host "2. Click: PowerShell-Automation-App-Key" -ForegroundColor White
        Write-Host "3. Check if you can EDIT it" -ForegroundColor White
        Write-Host "4. If YES: Add 'monitors_write' scope" -ForegroundColor White
        Write-Host "5. If NO: Create NEW App Key" -ForegroundColor White
        Write-Host "   - Name: Monitoring-Write-Enabled" -ForegroundColor White
        Write-Host "   - When creating, look for 'Scopes' dropdown" -ForegroundColor White
        Write-Host "   - Check: monitors_write" -ForegroundColor White
        Write-Host "   - Create and copy the NEW key" -ForegroundColor White
        Write-Host ""
        Write-Host "ALTERNATIVE: Your user role might not have permission" -ForegroundColor Yellow
        Write-Host "- Check your role at: https://app.us3.datadoghq.com/organization-settings/users" -ForegroundColor White
        Write-Host "- You need: 'Datadog Admin' or 'Datadog Standard' role" -ForegroundColor White
        Write-Host "- NOT: 'Datadog Read Only' role" -ForegroundColor White
        Write-Host ""
    }
    elseif ($statusCode -eq 403) {
        Write-Host "=====================================================================" -ForegroundColor Red
        Write-Host "  PROBLEM FOUND: 403 FORBIDDEN" -ForegroundColor Red
        Write-Host "=====================================================================" -ForegroundColor Red
        Write-Host ""
        Write-Host "Your user role does NOT have permission to create monitors!" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "FIX THIS NOW:" -ForegroundColor Cyan
        Write-Host "1. Go to: https://app.us3.datadoghq.com/organization-settings/users" -ForegroundColor White
        Write-Host "2. Find: Syed Rizvi (you)" -ForegroundColor White
        Write-Host "3. Check role - should be 'Datadog Admin' or 'Datadog Standard'" -ForegroundColor White
        Write-Host "4. If it says 'Read Only' - ask admin to change your role" -ForegroundColor White
        Write-Host ""
    }
    else {
        Write-Host "=====================================================================" -ForegroundColor Red
        Write-Host "  UNKNOWN ERROR" -ForegroundColor Red
        Write-Host "=====================================================================" -ForegroundColor Red
        Write-Host ""
        Write-Host "Status Code: $statusCode" -ForegroundColor White
        Write-Host "Message: $errorMessage" -ForegroundColor White
        Write-Host ""
    }
    
    exit 1
}

# TEST 4: Check User Info
Write-Host "[TEST 4] Checking your user information..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "https://api.us3.datadoghq.com/api/v2/current_user" -Headers $headers -Method Get -ErrorAction Stop
    Write-Host "  ✓ User info retrieved" -ForegroundColor Green
    Write-Host "    User: $($response.data.attributes.name)" -ForegroundColor Gray
    Write-Host "    Email: $($response.data.attributes.email)" -ForegroundColor Gray
}
catch {
    Write-Host "  ⚠ Could not get user info (not critical)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host "  TEST COMPLETE" -ForegroundColor White
Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host ""
