#Requires -Version 5.1

# SIMPLEST POSSIBLE TEST
$apiKey = 'e390a1103701b7aba1b0f27340620c932'
$appKey = 'c2ec7440597b571e24e9619936def1f4'

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "SIMPLE TEST - EXACT ERROR MESSAGE" -ForegroundColor White
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$headers = @{
    'DD-API-KEY' = $apiKey
    'DD-APPLICATION-KEY' = $appKey
}

Write-Host "Your keys:" -ForegroundColor Yellow
Write-Host "  API Key: $apiKey" -ForegroundColor White
Write-Host "  App Key: $appKey" -ForegroundColor White
Write-Host ""

Write-Host "Testing: https://api.us3.datadoghq.com/api/v1/monitor" -ForegroundColor Yellow
Write-Host ""

try {
    $response = Invoke-WebRequest -Uri "https://api.us3.datadoghq.com/api/v1/monitor" -Headers $headers -Method Get
    
    Write-Host "SUCCESS!" -ForegroundColor Green
    Write-Host "Status Code: $($response.StatusCode)" -ForegroundColor Green
    Write-Host "Found monitors: $(($response.Content | ConvertFrom-Json).Count)" -ForegroundColor Green
    Write-Host ""
    Write-Host "YOUR KEYS WORK! Run the main deployment script now!" -ForegroundColor Green
}
catch {
    Write-Host "FAILED!" -ForegroundColor Red
    Write-Host ""
    
    $statusCode = $_.Exception.Response.StatusCode.value__
    Write-Host "Status Code: $statusCode" -ForegroundColor Red
    
    # Get response body
    $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
    $responseBody = $reader.ReadToEnd()
    $reader.Close()
    
    Write-Host "Error Message: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host "Response from Datadog:" -ForegroundColor Yellow
    Write-Host $responseBody -ForegroundColor White
    Write-Host ""
    
    if ($statusCode -eq 403) {
        Write-Host "========================================" -ForegroundColor Red
        Write-Host "403 FORBIDDEN" -ForegroundColor Red
        Write-Host "========================================" -ForegroundColor Red
        Write-Host ""
        Write-Host "This means one of these things:" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "1. Your Datadog org has API access disabled" -ForegroundColor White
        Write-Host "   - Admin needs to enable API access" -ForegroundColor Gray
        Write-Host "   - Organization Settings > Security > API Access" -ForegroundColor Gray
        Write-Host ""
        Write-Host "2. Your IP address is blocked" -ForegroundColor White
        Write-Host "   - Organization has IP allowlist" -ForegroundColor Gray
        Write-Host "   - Your IP needs to be added" -ForegroundColor Gray
        Write-Host ""
        Write-Host "3. Application Key doesn't have correct scopes" -ForegroundColor White
        Write-Host "   - Need to create new App Key with monitors_read + monitors_write" -ForegroundColor Gray
        Write-Host ""
        Write-Host "4. Organization requires MFA for API access" -ForegroundColor White
        Write-Host "   - Check if MFA is required" -ForegroundColor Gray
        Write-Host ""
        Write-Host "TRY THIS:" -ForegroundColor Cyan
        Write-Host "1. In Datadog UI, go to: Organization Settings" -ForegroundColor White
        Write-Host "2. Click: Security" -ForegroundColor White
        Write-Host "3. Check: API Access settings" -ForegroundColor White
        Write-Host "4. Make sure API access is enabled" -ForegroundColor White
        Write-Host "5. Check if there's an IP allowlist" -ForegroundColor White
        Write-Host ""
    }
    elseif ($statusCode -eq 401) {
        Write-Host "========================================" -ForegroundColor Red
        Write-Host "401 UNAUTHORIZED" -ForegroundColor Red
        Write-Host "========================================" -ForegroundColor Red
        Write-Host ""
        Write-Host "Keys are invalid!" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Copy keys again:" -ForegroundColor White
        Write-Host "1. Go to API Keys page" -ForegroundColor Gray
        Write-Host "2. Click the key" -ForegroundColor Gray
        Write-Host "3. Click Copy button" -ForegroundColor Gray
        Write-Host "4. Paste EXACTLY here (no spaces)" -ForegroundColor Gray
        Write-Host ""
    }
    
    Write-Host ""
    Write-Host "PASTE THE FULL ERROR MESSAGE ABOVE TO THE CHAT!" -ForegroundColor Cyan
    Write-Host ""
}

Write-Host ""
