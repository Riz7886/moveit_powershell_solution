#Requires -Version 5.1
<#
.SYNOPSIS
    Advanced Datadog Diagnostic - Find EXACT Issue
#>

$ErrorActionPreference = 'Stop'

# YOUR KEYS
$apiKey = 'e390a1103701b7aba1b0f27340620c932'
$appKey = 'c2ec7440597b571e24e9619936def1f4'

Write-Host ""
Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host "  ADVANCED DATADOG DIAGNOSTIC" -ForegroundColor White
Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host ""

# Test different API endpoints
$endpoints = @(
    @{ Name = "US3"; URL = "https://api.us3.datadoghq.com/api/v1" }
    @{ Name = "US1"; URL = "https://api.datadoghq.com/api/v1" }
    @{ Name = "US5"; URL = "https://api.us5.datadoghq.com/api/v1" }
    @{ Name = "EU1"; URL = "https://api.datadoghq.eu/api/v1" }
)

Write-Host "Testing different API endpoints..." -ForegroundColor Yellow
Write-Host ""

$workingEndpoint = $null

foreach ($endpoint in $endpoints) {
    Write-Host "[$($endpoint.Name)] Testing $($endpoint.URL)..." -ForegroundColor Cyan
    
    $headers = @{
        'DD-API-KEY' = $apiKey
        'DD-APPLICATION-KEY' = $appKey
        'Content-Type' = 'application/json'
    }
    
    try {
        $response = Invoke-RestMethod -Uri "$($endpoint.URL)/validate" -Headers $headers -Method Get -TimeoutSec 10 -ErrorAction Stop
        Write-Host "  ✓ This endpoint WORKS!" -ForegroundColor Green
        Write-Host "    Valid: $($response.valid)" -ForegroundColor Gray
        $workingEndpoint = $endpoint
        break
    }
    catch {
        $statusCode = if ($_.Exception.Response) { $_.Exception.Response.StatusCode.value__ } else { "N/A" }
        Write-Host "  ✗ Failed - Status: $statusCode" -ForegroundColor Red
    }
}

if (-not $workingEndpoint) {
    Write-Host ""
    Write-Host "=====================================================================" -ForegroundColor Red
    Write-Host "  NO WORKING ENDPOINT FOUND!" -ForegroundColor Red
    Write-Host "=====================================================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "Your API keys don't work on ANY Datadog endpoint!" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "This means:" -ForegroundColor Cyan
    Write-Host "1. The keys are invalid/expired" -ForegroundColor White
    Write-Host "2. The keys are from a different Datadog account" -ForegroundColor White
    Write-Host "3. The keys were revoked" -ForegroundColor White
    Write-Host ""
    Write-Host "ACTION REQUIRED:" -ForegroundColor Yellow
    Write-Host "1. Log into YOUR Datadog account in browser" -ForegroundColor White
    Write-Host "2. Check what URL you see (app.us3.datadoghq.com? app.datadoghq.com?)" -ForegroundColor White
    Write-Host "3. Go to API Keys and CREATE NEW KEYS" -ForegroundColor White
    Write-Host "4. Make 100% sure you're in the RIGHT organization" -ForegroundColor White
    Write-Host ""
    exit 1
}

Write-Host ""
Write-Host "=====================================================================" -ForegroundColor Green
Write-Host "  FOUND WORKING ENDPOINT: $($workingEndpoint.Name)" -ForegroundColor Green
Write-Host "=====================================================================" -ForegroundColor Green
Write-Host ""

# Use working endpoint for remaining tests
$apiUrl = $workingEndpoint.URL
$headers = @{
    'DD-API-KEY' = $apiKey
    'DD-APPLICATION-KEY' = $appKey
    'Content-Type' = 'application/json'
}

# Get organization info
Write-Host "[TEST] Getting organization information..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$apiUrl/org" -Headers $headers -Method Get -ErrorAction Stop
    Write-Host "  ✓ Organization: $($response.org.name)" -ForegroundColor Green
    Write-Host "    Public ID: $($response.org.public_id)" -ForegroundColor Gray
    Write-Host "    Subscription: $($response.org.subscription.type)" -ForegroundColor Gray
}
catch {
    Write-Host "  ⚠ Could not get org info" -ForegroundColor Yellow
}

# Try to list monitors
Write-Host ""
Write-Host "[TEST] Attempting to list monitors..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$apiUrl/monitor" -Headers $headers -Method Get -ErrorAction Stop
    Write-Host "  ✓ SUCCESS! Can read monitors!" -ForegroundColor Green
    Write-Host "    Found: $($response.Count) monitors" -ForegroundColor Gray
}
catch {
    $statusCode = $_.Exception.Response.StatusCode.value__
    $errorBody = $_.ErrorDetails.Message
    
    Write-Host "  ✗ FAILED to read monitors!" -ForegroundColor Red
    Write-Host "    Status Code: $statusCode" -ForegroundColor Red
    Write-Host "    Error: $($_.Exception.Message)" -ForegroundColor Red
    
    if ($errorBody) {
        Write-Host "    Response: $errorBody" -ForegroundColor Gray
    }
    
    Write-Host ""
    Write-Host "=====================================================================" -ForegroundColor Red
    Write-Host "  PERMISSION ISSUE DETECTED" -ForegroundColor Red
    Write-Host "=====================================================================" -ForegroundColor Red
    Write-Host ""
    
    if ($statusCode -eq 403) {
        Write-Host "403 FORBIDDEN means:" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Even though you're an admin in the UI, your API keys don't have permission." -ForegroundColor White
        Write-Host ""
        Write-Host "POSSIBLE CAUSES:" -ForegroundColor Cyan
        Write-Host "1. Keys belong to a Service Account with limited role" -ForegroundColor White
        Write-Host "2. Keys are from a different user who isn't admin" -ForegroundColor White
        Write-Host "3. Organization has special restrictions" -ForegroundColor White
        Write-Host "4. Keys have scoped permissions" -ForegroundColor White
        Write-Host ""
        Write-Host "FIX OPTIONS:" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "OPTION 1: Create keys from YOUR admin account" -ForegroundColor Green
        Write-Host "  1. Go to: $($workingEndpoint.URL -replace '/api/v1','')/organization-settings/api-keys" -ForegroundColor White
        Write-Host "  2. Make sure you're logged in as Syed Rizvi (admin)" -ForegroundColor White
        Write-Host "  3. Create NEW API Key" -ForegroundColor White
        Write-Host "  4. Create NEW Application Key" -ForegroundColor White
        Write-Host "  5. Copy both keys" -ForegroundColor White
        Write-Host "  6. Update the script" -ForegroundColor White
        Write-Host ""
        Write-Host "OPTION 2: Create Service Account with Admin role" -ForegroundColor Green
        Write-Host "  1. Go to: $($workingEndpoint.URL -replace '/api/v1','')/organization-settings/service-accounts" -ForegroundColor White
        Write-Host "  2. Create new Service Account" -ForegroundColor White
        Write-Host "  3. Role: 'Datadog Admin Role'" -ForegroundColor White
        Write-Host "  4. Create API and App keys from that account" -ForegroundColor White
        Write-Host ""
    }
    elseif ($statusCode -eq 401) {
        Write-Host "401 UNAUTHORIZED means:" -ForegroundColor Yellow
        Write-Host "  Keys are invalid or expired" -ForegroundColor White
        Write-Host "  Create new keys from your admin account" -ForegroundColor White
    }
    
    exit 1
}

# Try to create monitor
Write-Host ""
Write-Host "[TEST] Attempting to create a test monitor..." -ForegroundColor Yellow

$testMonitor = @{
    type = "metric alert"
    query = "avg(last_5m):avg:system.cpu.user{*} > 100"
    name = "TEST-DELETE-ME-$(Get-Random)"
    message = "Test"
    tags = @('test:delete')
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "$apiUrl/monitor" -Headers $headers -Method Post -Body $testMonitor -ErrorAction Stop
    Write-Host "  ✓ SUCCESS! Can create monitors!" -ForegroundColor Green
    Write-Host "    Created monitor ID: $($response.id)" -ForegroundColor Gray
    
    # Delete it
    Invoke-RestMethod -Uri "$apiUrl/monitor/$($response.id)" -Headers $headers -Method Delete -ErrorAction SilentlyContinue
    Write-Host "    Cleaned up test monitor" -ForegroundColor Gray
}
catch {
    Write-Host "  ✗ FAILED to create monitor!" -ForegroundColor Red
    Write-Host "    Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host "  DIAGNOSTIC COMPLETE" -ForegroundColor White
Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Working Endpoint: $($workingEndpoint.URL)" -ForegroundColor Green
Write-Host ""
Write-Host "If you still have issues:" -ForegroundColor Yellow
Write-Host "1. Make sure you're creating keys from YOUR admin account" -ForegroundColor White
Write-Host "2. Create BRAND NEW keys (don't reuse old ones)" -ForegroundColor White
Write-Host "3. Check you're in the correct Datadog organization" -ForegroundColor White
Write-Host ""
