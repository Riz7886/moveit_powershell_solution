# QUICK INSTALL SCRIPT FOR AVD DEPLOYMENT
# Run this as Administrator in Windows PowerShell 5.1
# This will install everything you need

Write-Host ""
Write-Host "=========================================================================" -ForegroundColor Cyan
Write-Host "  AVD DEPLOYMENT - PREREQUISITE INSTALLER" -ForegroundColor White
Write-Host "  PYX HEALTH CORPORATION" -ForegroundColor Cyan
Write-Host "=========================================================================" -ForegroundColor Cyan
Write-Host ""

# Check if running as Administrator
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "ERROR: This script must be run as Administrator" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please:" -ForegroundColor Yellow
    Write-Host "1. Close this PowerShell window" -ForegroundColor White
    Write-Host "2. Right-click PowerShell" -ForegroundColor White
    Write-Host "3. Select 'Run as Administrator'" -ForegroundColor White
    Write-Host "4. Run this script again" -ForegroundColor White
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "Administrator privileges confirmed" -ForegroundColor Green
Write-Host ""

# Display current PowerShell version
Write-Host "Current PowerShell version: $($PSVersionTable.PSVersion)" -ForegroundColor White
Write-Host ""

# Ask what to install
Write-Host "What do you want to install?" -ForegroundColor Cyan
Write-Host ""
Write-Host "[1] Azure PowerShell modules only (works with current PowerShell)" -ForegroundColor White
Write-Host "[2] PowerShell 7 + Azure modules (RECOMMENDED)" -ForegroundColor Green
Write-Host "[3] Check what's already installed" -ForegroundColor Yellow
Write-Host "[4] Exit" -ForegroundColor White
Write-Host ""
$choice = Read-Host "Enter your choice (1, 2, 3, or 4)"

switch ($choice) {
    "1" {
        Write-Host ""
        Write-Host "Installing Azure PowerShell modules..." -ForegroundColor Cyan
        Write-Host "This may take 5-10 minutes..." -ForegroundColor Yellow
        Write-Host ""
        
        try {
            # Set TLS 1.2
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            
            # Install NuGet
            Write-Host "Installing NuGet provider..." -ForegroundColor Cyan
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -Scope CurrentUser | Out-Null
            Write-Host "NuGet installed" -ForegroundColor Green
            
            # Trust PSGallery
            Write-Host "Configuring PSGallery..." -ForegroundColor Cyan
            Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
            Write-Host "PSGallery configured" -ForegroundColor Green
            
            # Install Az modules
            Write-Host "Installing Azure PowerShell modules..." -ForegroundColor Cyan
            Write-Host "This is the longest step - please wait..." -ForegroundColor Yellow
            
            $modules = @(
                'Az.Accounts',
                'Az.Resources',
                'Az.Network',
                'Az.Storage',
                'Az.Compute',
                'Az.DesktopVirtualization'
            )
            
            foreach ($module in $modules) {
                Write-Host "Installing $module..." -ForegroundColor Cyan
                Install-Module -Name $module -Repository PSGallery -Scope CurrentUser -Force -AllowClobber
                Write-Host "$module installed" -ForegroundColor Green
            }
            
            Write-Host ""
            Write-Host "=========================================================================" -ForegroundColor Green
            Write-Host "  AZURE MODULES INSTALLED SUCCESSFULLY" -ForegroundColor Green
            Write-Host "=========================================================================" -ForegroundColor Green
            Write-Host ""
            Write-Host "You can now run the AVD deployment script:" -ForegroundColor White
            Write-Host ".\Deploy-AVD-Clean.ps1" -ForegroundColor Cyan
            Write-Host ""
        }
        catch {
            Write-Host ""
            Write-Host "ERROR: Installation failed" -ForegroundColor Red
            Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
            Write-Host ""
            Write-Host "Try installing manually:" -ForegroundColor Yellow
            Write-Host "Install-Module -Name Az -Repository PSGallery -Scope CurrentUser -Force" -ForegroundColor White
            Write-Host ""
        }
    }
    
    "2" {
        Write-Host ""
        Write-Host "Installing PowerShell 7 + Azure modules..." -ForegroundColor Cyan
        Write-Host ""
        
        Write-Host "STEP 1: Installing PowerShell 7" -ForegroundColor Cyan
        Write-Host "This may take 5 minutes..." -ForegroundColor Yellow
        Write-Host ""
        
        try {
            # Download and install PowerShell 7
            Write-Host "Downloading PowerShell 7 installer..." -ForegroundColor Cyan
            $url = "https://github.com/PowerShell/PowerShell/releases/download/v7.4.0/PowerShell-7.4.0-win-x64.msi"
            $output = "$env:TEMP\PowerShell-7.4.0-win-x64.msi"
            
            Invoke-WebRequest -Uri $url -OutFile $output
            Write-Host "Download complete" -ForegroundColor Green
            
            Write-Host "Installing PowerShell 7..." -ForegroundColor Cyan
            Start-Process msiexec.exe -ArgumentList "/i `"$output`" /quiet /norestart" -Wait
            Write-Host "PowerShell 7 installed" -ForegroundColor Green
            
            Write-Host ""
            Write-Host "=========================================================================" -ForegroundColor Green
            Write-Host "  POWERSHELL 7 INSTALLED SUCCESSFULLY" -ForegroundColor Green
            Write-Host "=========================================================================" -ForegroundColor Green
            Write-Host ""
            Write-Host "NEXT STEPS:" -ForegroundColor Cyan
            Write-Host "1. Close this PowerShell window" -ForegroundColor White
            Write-Host "2. Search for 'PowerShell 7' in Start Menu" -ForegroundColor White
            Write-Host "3. Right-click PowerShell 7" -ForegroundColor White
            Write-Host "4. Select 'Run as Administrator'" -ForegroundColor White
            Write-Host "5. Run this command to install Azure modules:" -ForegroundColor White
            Write-Host ""
            Write-Host "   Install-Module -Name Az -Repository PSGallery -Scope CurrentUser -Force" -ForegroundColor Cyan
            Write-Host ""
            Write-Host "6. Then run the AVD deployment script:" -ForegroundColor White
            Write-Host ""
            Write-Host "   .\Deploy-AVD-Clean.ps1" -ForegroundColor Cyan
            Write-Host ""
        }
        catch {
            Write-Host ""
            Write-Host "ERROR: PowerShell 7 installation failed" -ForegroundColor Red
            Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
            Write-Host ""
            Write-Host "Please install manually from:" -ForegroundColor Yellow
            Write-Host "https://aka.ms/powershell-release?tag=stable" -ForegroundColor White
            Write-Host ""
        }
    }
    
    "3" {
        Write-Host ""
        Write-Host "Checking installed components..." -ForegroundColor Cyan
        Write-Host ""
        
        # Check PowerShell version
        Write-Host "PowerShell Version:" -ForegroundColor Cyan
        Write-Host "  Current: $($PSVersionTable.PSVersion)" -ForegroundColor White
        if ($PSVersionTable.PSVersion.Major -ge 7) {
            Write-Host "  Status: OK - PowerShell 7+ detected" -ForegroundColor Green
        }
        elseif ($PSVersionTable.PSVersion.Major -ge 5) {
            Write-Host "  Status: WORKS - Windows PowerShell 5.1" -ForegroundColor Yellow
            Write-Host "  Recommendation: Upgrade to PowerShell 7 for best performance" -ForegroundColor Yellow
        }
        else {
            Write-Host "  Status: TOO OLD - Please upgrade" -ForegroundColor Red
        }
        Write-Host ""
        
        # Check Azure modules
        Write-Host "Azure PowerShell Modules:" -ForegroundColor Cyan
        $modules = @(
            'Az.Accounts',
            'Az.Resources',
            'Az.Network',
            'Az.Storage',
            'Az.Compute',
            'Az.DesktopVirtualization'
        )
        
        $installedCount = 0
        foreach ($module in $modules) {
            if (Get-Module -ListAvailable -Name $module) {
                Write-Host "  $module : INSTALLED" -ForegroundColor Green
                $installedCount++
            }
            else {
                Write-Host "  $module : MISSING" -ForegroundColor Red
            }
        }
        
        Write-Host ""
        if ($installedCount -eq $modules.Count) {
            Write-Host "All Azure modules are installed!" -ForegroundColor Green
            Write-Host "You can run the AVD deployment script" -ForegroundColor Green
        }
        else {
            Write-Host "Some modules are missing" -ForegroundColor Yellow
            Write-Host "Run option [1] or [2] to install" -ForegroundColor Yellow
        }
        Write-Host ""
    }
    
    "4" {
        Write-Host ""
        Write-Host "Exiting..." -ForegroundColor Yellow
        exit 0
    }
    
    default {
        Write-Host ""
        Write-Host "Invalid choice" -ForegroundColor Red
        Write-Host ""
    }
}

Write-Host ""
Read-Host "Press Enter to exit"
