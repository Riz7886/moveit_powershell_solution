# Azure SQL Database Auto-Optimizer

Automatically right-size Azure SQL databases and save money.

## What This Script Does

1. Scans all Azure SQL databases across all subscriptions
2. Analyzes 14 days of DTU metrics (average and peak usage)
3. Identifies underutilized databases (using less than 25% DTU)
4. Calculates recommended tier based on actual usage
5. ACTUALLY CHANGES the database tier to save money
6. Generates before/after report with total savings

## Quick Start

### Step 1: Preview Mode (No Changes)

```powershell
.\Optimize-AzureSQL-AutoRightSize.ps1 -WhatIf
```

This shows what WOULD be changed without making any changes.

### Step 2: Apply Changes

```powershell
.\Optimize-AzureSQL-AutoRightSize.ps1
```

The script will prompt for confirmation before each change.

### Step 3: Apply All Changes (No Prompts)

```powershell
.\Optimize-AzureSQL-AutoRightSize.ps1 -Force
```

## Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| -WhatIf | Off | Preview mode - no changes applied |
| -Force | Off | Apply all changes without prompting |
| -MinSavingsThreshold | 50 | Only optimize if savings greater than this amount per month |
| -MaxDTUThreshold | 40 | Only optimize if max DTU usage below this percent |
| -AuditCsvPath | None | Use existing audit CSV instead of fresh scan |
| -OutputPath | .\SQL-Optimization-Results | Where to save reports |

## Examples

### Preview changes for databases saving more than 100 per month

```powershell
.\Optimize-AzureSQL-AutoRightSize.ps1 -WhatIf -MinSavingsThreshold 100
```

### Use existing audit file

```powershell
.\Optimize-AzureSQL-AutoRightSize.ps1 -AuditCsvPath .\AzureSQLAuditReport_20260109.csv
```

### Apply all changes with lower threshold

```powershell
.\Optimize-AzureSQL-AutoRightSize.ps1 -Force -MinSavingsThreshold 25
```

## Safety Features

1. WhatIf mode - Preview before making changes
2. Confirmation prompts - Approve each change individually
3. 30 percent buffer - Recommended tier has 30 percent headroom above max usage
4. Threshold limits - Only optimizes databases with proven low usage
5. Full logging - Every action is logged with timestamp
6. Before/after report - Complete documentation of changes

## Output Files

After running the script:

1. SQL-Optimization-Results_[timestamp].csv - Raw data
2. SQL-Optimization-Report_[timestamp].html - Visual report (opens in browser)

## Sample Results

```
OPTIMIZATION COMPLETE

Databases Optimized:    8
Changes Failed:         0

Previous Monthly Cost:  4,850.00
New Monthly Cost:       1,920.00

MONTHLY SAVINGS:        2,930.00
ANNUAL SAVINGS:         35,160.00
```

## Rollback

If you need to scale a database back up:

```powershell
Set-AzSqlDatabase -ResourceGroupName "RG-NAME" -ServerName "SERVER-NAME" -DatabaseName "DB-NAME" -Edition "Standard" -RequestedServiceObjectiveName "S4"
```

## Tier Pricing Reference

| Tier | DTU | Monthly Cost |
|------|-----|--------------|
| Basic | 5 | 4.99 |
| S0 | 10 | 15.03 |
| S1 | 20 | 30.05 |
| S2 | 50 | 75.13 |
| S3 | 100 | 150.26 |
| S4 | 200 | 300.52 |
| S6 | 400 | 601.03 |
| S7 | 800 | 1202.06 |
| S9 | 1600 | 2404.13 |
| P1 | 125 | 465.00 |
| P2 | 250 | 930.00 |
| P4 | 500 | 1860.00 |
| P6 | 1000 | 3720.00 |

## Requirements

- PowerShell 5.1 or higher
- Az PowerShell module (script will install if missing)
- Azure subscription access (Reader for analysis, Contributor for changes)
