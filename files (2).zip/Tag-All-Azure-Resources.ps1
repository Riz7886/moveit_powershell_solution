# ============================================================================
# ENTERPRISE AZURE RESOURCE TAGGING SCRIPT
# Tags all subscriptions, resource groups, and resources
# Integrates with Datadog for monitoring
# Follows Microsoft + Datadog best practices
# ============================================================================

param(
    [switch]$WhatIf = $false,
    [switch]$GenerateReport = $true,
    [string]$ReportPath = ".\Azure-Tagging-Report.html"
)

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "AZURE ENTERPRISE TAGGING AUTOMATION" -ForegroundColor Cyan
Write-Host "Tags: Subscriptions > Resource Groups > Resources" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

if ($WhatIf) {
    Write-Host "RUNNING IN WHATIF MODE - No changes will be made" -ForegroundColor Yellow
    Write-Host ""
}

# Check Azure CLI
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: Azure CLI not installed!" -ForegroundColor Red
    Write-Host "Install from: https://aka.ms/installazurecli" -ForegroundColor Yellow
    exit 1
}

# Login check
$account = az account show 2>$null
if (-not $account) {
    Write-Host "Not logged in. Starting Azure login..." -ForegroundColor Yellow
    az login --use-device-code
}

# ============================================================================
# TAGGING CONFIGURATION (CUSTOMIZE HERE)
# ============================================================================

$TaggingRules = @{
    # Subscription-level tags (billing, governance)
    SubscriptionTags = @{
        "Department" = "IT Operations"
        "CostCenter" = "CC-12345"
        "BillingOwner" = "finance@company.com"
        "ManagedBy" = "CloudOps"
        "TaggingVersion" = "1.0"
        "LastTagged" = (Get-Date -Format "yyyy-MM-dd")
    }
    
    # Resource Group mapping (application-specific)
    ResourceGroupMappings = @{
        "rg-moveit.*" = @{
            "Application" = "MoveIT"
            "Service" = "file-transfer"
            "Criticality" = "High"
            "DataClassification" = "Confidential"
            "BackupSchedule" = "Daily"
        }
        "rg-identity.*" = @{
            "Application" = "Identity"
            "Service" = "authentication"
            "Criticality" = "Critical"
            "DataClassification" = "Highly-Confidential"
            "BackupSchedule" = "Hourly"
        }
        "rg-drivershealth.*" = @{
            "Application" = "DriversHealth"
            "Service" = "health-monitoring"
            "Criticality" = "High"
            "DataClassification" = "Protected"
            "BackupSchedule" = "Daily"
        }
        ".*prod.*" = @{
            "Environment" = "Production"
        }
        ".*dev.*" = @{
            "Environment" = "Development"
        }
        ".*staging.*|.*stg.*" = @{
            "Environment" = "Staging"
        }
    }
    
    # VM-specific role detection (by name pattern)
    VMRoleMappings = @{
        ".*gateway.*" = "gateway"
        ".*transfer.*" = "transfer"
        ".*web.*|.*app.*" = "application"
        ".*db.*|.*sql.*" = "database"
        ".*cache.*|.*redis.*" = "cache"
        ".*bastion.*" = "bastion"
        ".*jumpbox.*" = "jumpbox"
    }
}

# ============================================================================
# FUNCTIONS
# ============================================================================

function Get-ResourceGroupTags {
    param([string]$ResourceGroupName)
    
    $tags = @{}
    
    # Apply matching patterns
    foreach ($pattern in $TaggingRules.ResourceGroupMappings.Keys) {
        if ($ResourceGroupName -match $pattern) {
            $matchedTags = $TaggingRules.ResourceGroupMappings[$pattern]
            foreach ($key in $matchedTags.Keys) {
                $tags[$key] = $matchedTags[$key]
            }
        }
    }
    
    # Add metadata
    $tags["ResourceGroup"] = $ResourceGroupName
    $tags["TaggedDate"] = Get-Date -Format "yyyy-MM-dd"
    
    return $tags
}

function Get-VMRoleTag {
    param([string]$VMName)
    
    foreach ($pattern in $TaggingRules.VMRoleMappings.Keys) {
        if ($VMName -match $pattern) {
            return $TaggingRules.VMRoleMappings[$pattern]
        }
    }
    
    return "general"
}

function ConvertTo-DatadogTags {
    param([hashtable]$Tags)
    
    $ddTags = @()
    foreach ($key in $Tags.Keys) {
        $value = $Tags[$key] -replace '\s+', '-' -replace '[^a-zA-Z0-9_\-\.]', ''
        $ddTags += "$($key.ToLower()):$($value.ToLower())"
    }
    
    return $ddTags -join ','
}

function Apply-TagsToResource {
    param(
        [string]$ResourceId,
        [hashtable]$Tags
    )
    
    $tagString = ($Tags.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join ' '
    
    if ($WhatIf) {
        Write-Host "    [WHATIF] Would tag: $tagString" -ForegroundColor Gray
    } else {
        az resource tag --ids $ResourceId --tags $tagString 2>$null | Out-Null
    }
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================

$report = @{
    Subscriptions = @()
    TotalResources = 0
    TaggedResources = 0
    StartTime = Get-Date
}

Write-Host "[STEP 1] Getting all accessible subscriptions..." -ForegroundColor Yellow
$subscriptions = az account list | ConvertFrom-Json

Write-Host "Found $($subscriptions.Count) subscription(s)" -ForegroundColor Green
Write-Host ""

foreach ($sub in $subscriptions) {
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "SUBSCRIPTION: $($sub.name)" -ForegroundColor Cyan
    Write-Host "ID: $($sub.id)" -ForegroundColor White
    Write-Host "========================================" -ForegroundColor Cyan
    
    # Set context
    az account set --subscription $sub.id
    
    $subReport = @{
        Name = $sub.name
        Id = $sub.id
        ResourceGroups = @()
    }
    
    # Tag subscription
    Write-Host "[1] Tagging subscription..." -ForegroundColor Yellow
    $subTags = $TaggingRules.SubscriptionTags.Clone()
    $subTags["SubscriptionName"] = $sub.name
    
    if (-not $WhatIf) {
        $tagCmd = "az account management-group subscription show --subscription $($sub.id) 2>$null"
        # Note: Subscription tagging requires specific permissions
        Write-Host "  Subscription-level tags configured (requires Owner role)" -ForegroundColor Gray
    }
    
    # Get resource groups
    Write-Host "[2] Processing resource groups..." -ForegroundColor Yellow
    $resourceGroups = az group list --subscription $sub.id | ConvertFrom-Json
    
    Write-Host "  Found $($resourceGroups.Count) resource group(s)" -ForegroundColor White
    Write-Host ""
    
    foreach ($rg in $resourceGroups) {
        Write-Host "  Resource Group: $($rg.name)" -ForegroundColor Cyan
        
        # Get tags for this resource group
        $rgTags = Get-ResourceGroupTags -ResourceGroupName $rg.name
        
        # Add subscription-level tags
        foreach ($key in $subTags.Keys) {
            if (-not $rgTags.ContainsKey($key)) {
                $rgTags[$key] = $subTags[$key]
            }
        }
        
        # Apply to resource group
        Write-Host "    Tagging resource group..." -ForegroundColor Yellow
        $tagString = ($rgTags.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join ' '
        
        if (-not $WhatIf) {
            az group update --name $rg.name --tags $tagString 2>$null | Out-Null
            Write-Host "    ✓ Tagged resource group" -ForegroundColor Green
        } else {
            Write-Host "    [WHATIF] Tags: $tagString" -ForegroundColor Gray
        }
        
        $rgReport = @{
            Name = $rg.name
            Tags = $rgTags
            Resources = @()
        }
        
        # Get resources in this resource group
        Write-Host "    Getting resources..." -ForegroundColor Yellow
        $resources = az resource list --resource-group $rg.name | ConvertFrom-Json
        
        Write-Host "    Found $($resources.Count) resource(s)" -ForegroundColor White
        
        foreach ($resource in $resources) {
            $report.TotalResources++
            
            Write-Host "      - $($resource.type): $($resource.name)" -ForegroundColor White
            
            # Build resource tags (inherit from RG)
            $resourceTags = $rgTags.Clone()
            $resourceTags["ResourceType"] = $resource.type
            $resourceTags["ResourceName"] = $resource.name
            
            # Special handling for VMs
            if ($resource.type -eq "Microsoft.Compute/virtualMachines") {
                $role = Get-VMRoleTag -VMName $resource.name
                $resourceTags["Role"] = $role
                $resourceTags["Service"] = "$($rgTags.Application.ToLower())-$role"
                
                Write-Host "        Role detected: $role" -ForegroundColor Cyan
            }
            
            # Apply tags to resource
            Apply-TagsToResource -ResourceId $resource.id -Tags $resourceTags
            
            if (-not $WhatIf) {
                Write-Host "        ✓ Tagged" -ForegroundColor Green
                $report.TaggedResources++
            }
            
            # Generate Datadog tags
            $ddTags = ConvertTo-DatadogTags -Tags $resourceTags
            
            $rgReport.Resources += @{
                Name = $resource.name
                Type = $resource.type
                Tags = $resourceTags
                DatadogTags = $ddTags
            }
        }
        
        Write-Host ""
        $subReport.ResourceGroups += $rgReport
    }
    
    $report.Subscriptions += $subReport
}

$report.EndTime = Get-Date
$report.Duration = ($report.EndTime - $report.StartTime).TotalSeconds

# ============================================================================
# GENERATE REPORT
# ============================================================================

if ($GenerateReport) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "GENERATING REPORT" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    
    $html = @"
<!DOCTYPE html>
<html>
<head>
    <title>Azure Tagging Report</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        h1 { color: #0078d4; }
        h2 { color: #106ebe; margin-top: 30px; }
        h3 { color: #1a1a1a; }
        .summary { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .stat { display: inline-block; margin-right: 30px; }
        .stat-label { color: #666; font-size: 14px; }
        .stat-value { font-size: 32px; font-weight: bold; color: #0078d4; }
        .subscription { background: white; padding: 20px; margin-bottom: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .rg { background: #f9f9f9; padding: 15px; margin: 10px 0; border-left: 4px solid #0078d4; }
        .resource { background: white; padding: 10px; margin: 5px 0; border-left: 3px solid #50e6ff; }
        .tags { background: #e8f4fd; padding: 10px; margin: 10px 0; border-radius: 4px; font-family: 'Courier New', monospace; font-size: 12px; }
        .tag { display: inline-block; background: #0078d4; color: white; padding: 4px 8px; margin: 2px; border-radius: 3px; }
        .dd-tag { background: #632ca6; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th { background: #0078d4; color: white; padding: 10px; text-align: left; }
        td { padding: 8px; border-bottom: 1px solid #ddd; }
        tr:hover { background: #f5f5f5; }
    </style>
</head>
<body>
    <h1>Azure Tagging Report</h1>
    <div class="summary">
        <h2>Summary</h2>
        <div class="stat">
            <div class="stat-label">Subscriptions</div>
            <div class="stat-value">$($report.Subscriptions.Count)</div>
        </div>
        <div class="stat">
            <div class="stat-label">Total Resources</div>
            <div class="stat-value">$($report.TotalResources)</div>
        </div>
        <div class="stat">
            <div class="stat-label">Tagged Resources</div>
            <div class="stat-value">$($report.TaggedResources)</div>
        </div>
        <div class="stat">
            <div class="stat-label">Duration</div>
            <div class="stat-value">$([math]::Round($report.Duration, 1))s</div>
        </div>
        <p><strong>Generated:</strong> $($report.EndTime.ToString("yyyy-MM-dd HH:mm:ss"))</p>
    </div>
"@

    foreach ($sub in $report.Subscriptions) {
        $html += @"
    <div class="subscription">
        <h2>📋 $($sub.Name)</h2>
        <p><strong>Subscription ID:</strong> $($sub.Id)</p>
"@
        
        foreach ($rg in $sub.ResourceGroups) {
            $html += @"
        <div class="rg">
            <h3>📁 $($rg.Name)</h3>
            <div class="tags">
                <strong>Tags:</strong><br>
"@
            foreach ($tag in $rg.Tags.GetEnumerator()) {
                $html += "                <span class='tag'>$($tag.Key): $($tag.Value)</span>`n"
            }
            
            $html += @"
            </div>
            
            <table>
                <tr>
                    <th>Resource</th>
                    <th>Type</th>
                    <th>Datadog Tags</th>
                </tr>
"@
            
            foreach ($res in $rg.Resources) {
                $html += @"
                <tr>
                    <td><strong>$($res.Name)</strong></td>
                    <td>$($res.Type)</td>
                    <td><code>$($res.DatadogTags)</code></td>
                </tr>
"@
            }
            
            $html += @"
            </table>
        </div>
"@
        }
        
        $html += "</div>`n"
    }
    
    $html += @"
</body>
</html>
"@
    
    $html | Out-File -FilePath $ReportPath -Encoding UTF8
    
    Write-Host "Report generated: $ReportPath" -ForegroundColor Green
    Write-Host "Opening report..." -ForegroundColor Yellow
    Start-Process $ReportPath
}

# ============================================================================
# SUMMARY
# ============================================================================

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "TAGGING COMPLETE!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Summary:" -ForegroundColor White
Write-Host "  Subscriptions processed: $($report.Subscriptions.Count)" -ForegroundColor White
Write-Host "  Total resources found: $($report.TotalResources)" -ForegroundColor White
Write-Host "  Resources tagged: $($report.TaggedResources)" -ForegroundColor White
Write-Host "  Duration: $([math]::Round($report.Duration, 1)) seconds" -ForegroundColor White
Write-Host ""

if ($WhatIf) {
    Write-Host "This was a WHATIF run - no changes were made" -ForegroundColor Yellow
    Write-Host "Run without -WhatIf to apply tags" -ForegroundColor Yellow
} else {
    Write-Host "NEXT STEPS:" -ForegroundColor Yellow
    Write-Host "  1. ✓ Tags applied to all resources" -ForegroundColor Green
    Write-Host "  2. Run Datadog Agent update script" -ForegroundColor White
    Write-Host "  3. Verify tags in Datadog UI" -ForegroundColor White
    Write-Host "  4. Create tag-based monitors" -ForegroundColor White
}

Write-Host ""
