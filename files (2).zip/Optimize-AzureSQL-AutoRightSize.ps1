param(
    [string]$AuditCsvPath,
    [switch]$WhatIf,
    [switch]$Force,
    [int]$MinSavingsThreshold = 50,
    [int]$MaxDTUThreshold = 40,
    [string]$OutputPath = ".\SQL-Optimization-Results"
)

$ErrorActionPreference = "Stop"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) {
        "ERROR" { "Red" }
        "WARNING" { "Yellow" }
        "SUCCESS" { "Green" }
        "SAVINGS" { "Cyan" }
        default { "White" }
    }
    Write-Host "[$timestamp] [$Level] $Message" -ForegroundColor $color
}

function Get-DTUPricing {
    return @{
        "Basic" = @{ DTU = 5; Price = 4.99 }
        "S0" = @{ DTU = 10; Price = 15.03 }
        "S1" = @{ DTU = 20; Price = 30.05 }
        "S2" = @{ DTU = 50; Price = 75.13 }
        "S3" = @{ DTU = 100; Price = 150.26 }
        "S4" = @{ DTU = 200; Price = 300.52 }
        "S6" = @{ DTU = 400; Price = 601.03 }
        "S7" = @{ DTU = 800; Price = 1202.06 }
        "S9" = @{ DTU = 1600; Price = 2404.13 }
        "S12" = @{ DTU = 3000; Price = 4507.74 }
        "P1" = @{ DTU = 125; Price = 465.00 }
        "P2" = @{ DTU = 250; Price = 930.00 }
        "P4" = @{ DTU = 500; Price = 1860.00 }
        "P6" = @{ DTU = 1000; Price = 3720.00 }
        "P11" = @{ DTU = 1750; Price = 6510.75 }
        "P15" = @{ DTU = 4000; Price = 14880.00 }
    }
}

function Get-RecommendedTier {
    param([double]$MaxDTUPercent, [int]$CurrentDTU, [string]$CurrentTier)
    
    $pricing = Get-DTUPricing
    $neededDTU = [math]::Ceiling(($MaxDTUPercent / 100) * $CurrentDTU * 1.3)
    if ($neededDTU -lt 5) { $neededDTU = 5 }
    
    $sortedTiers = $pricing.GetEnumerator() | Sort-Object { $_.Value.DTU }
    
    foreach ($tier in $sortedTiers) {
        if ($tier.Value.DTU -ge $neededDTU) {
            return @{
                Tier = $tier.Key
                DTU = $tier.Value.DTU
                Price = $tier.Value.Price
            }
        }
    }
    
    return @{ Tier = $CurrentTier; DTU = $CurrentDTU; Price = 0 }
}

function Get-DatabaseMetrics {
    param([string]$SubscriptionId, [string]$ResourceGroup, [string]$ServerName, [string]$DatabaseName)
    
    $endTime = Get-Date
    $startTime = $endTime.AddDays(-14)
    
    try {
        $db = Get-AzSqlDatabase -ResourceGroupName $ResourceGroup -ServerName $ServerName -DatabaseName $DatabaseName -ErrorAction Stop
        
        $metrics = Get-AzMetric -ResourceId $db.ResourceId -MetricName "dtu_consumption_percent" -StartTime $startTime -EndTime $endTime -TimeGrain 01:00:00 -AggregationType Average -ErrorAction SilentlyContinue
        
        $avgDTU = 0
        $maxDTU = 0
        
        if ($metrics -and $metrics.Data) {
            $values = $metrics.Data | Where-Object { $_.Average -ne $null } | Select-Object -ExpandProperty Average
            if ($values.Count -gt 0) {
                $avgDTU = [math]::Round(($values | Measure-Object -Average).Average, 2)
                $maxDTU = [math]::Round(($values | Measure-Object -Maximum).Maximum, 2)
            }
        }
        
        return @{
            AvgDTU = $avgDTU
            MaxDTU = $maxDTU
            CurrentTier = $db.CurrentServiceObjectiveName
            Edition = $db.Edition
            Status = $db.Status
        }
    }
    catch {
        return $null
    }
}

function Invoke-DatabaseTierChange {
    param(
        [string]$SubscriptionId,
        [string]$ResourceGroup,
        [string]$ServerName,
        [string]$DatabaseName,
        [string]$NewTier,
        [switch]$WhatIfMode
    )
    
    try {
        Set-AzContext -SubscriptionId $SubscriptionId -ErrorAction Stop | Out-Null
        
        $edition = "Standard"
        if ($NewTier -like "P*") { $edition = "Premium" }
        if ($NewTier -eq "Basic") { $edition = "Basic" }
        
        if ($WhatIfMode) {
            Write-Log "WHATIF: Would change $DatabaseName from current tier to $NewTier ($edition)" "WARNING"
            return @{ Success = $true; WhatIf = $true }
        }
        
        Write-Log "Changing $DatabaseName to $NewTier ($edition)..." "INFO"
        
        Set-AzSqlDatabase -ResourceGroupName $ResourceGroup -ServerName $ServerName -DatabaseName $DatabaseName -Edition $edition -RequestedServiceObjectiveName $NewTier -ErrorAction Stop | Out-Null
        
        Write-Log "Successfully changed $DatabaseName to $NewTier" "SUCCESS"
        return @{ Success = $true; WhatIf = $false }
    }
    catch {
        Write-Log "Failed to change $DatabaseName : $($_.Exception.Message)" "ERROR"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  AZURE SQL DATABASE AUTO-OPTIMIZER" -ForegroundColor Cyan
Write-Host "  Automatically Right-Size Databases and Save Money" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

if ($WhatIf) {
    Write-Host "  MODE: PREVIEW ONLY (No changes will be made)" -ForegroundColor Yellow
    Write-Host ""
}

if (-not (Test-Path $OutputPath)) {
    New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
}

if (-not (Get-Module -ListAvailable -Name Az.Sql)) {
    Write-Log "Installing Az.Sql module..." "WARNING"
    Install-Module -Name Az.Sql -Scope CurrentUser -Force -AllowClobber
}

Import-Module Az.Sql -ErrorAction SilentlyContinue

try {
    $context = Get-AzContext
    if (-not $context) {
        Write-Log "Connecting to Azure..." "INFO"
        Connect-AzAccount | Out-Null
    }
    Write-Log "Connected as: $($context.Account.Id)" "SUCCESS"
}
catch {
    Write-Log "Failed to connect to Azure: $($_.Exception.Message)" "ERROR"
    exit 1
}

$pricing = Get-DTUPricing
$allResults = @()
$totalCurrentCost = 0
$totalNewCost = 0
$totalSavings = 0
$changesApplied = 0
$changesFailed = 0

if ($AuditCsvPath -and (Test-Path $AuditCsvPath)) {
    Write-Log "Loading audit data from: $AuditCsvPath" "INFO"
    $auditData = Import-Csv -Path $AuditCsvPath
    
    $candidates = $auditData | Where-Object { 
        [double]$_.PotentialSavings -ge $MinSavingsThreshold -and
        [double]$_.MaxDTUPercent -le $MaxDTUThreshold -and
        $_.StatusFlag -ne "OK"
    }
    
    Write-Log "Found $($candidates.Count) databases eligible for optimization" "INFO"
    
    foreach ($db in $candidates) {
        Write-Host ""
        Write-Log "Processing: $($db.DatabaseName) on $($db.ServerName)" "INFO"
        
        $subscriptions = Get-AzSubscription | Where-Object { $_.Name -eq $db.SubscriptionName -or $_.Id -eq $db.SubscriptionId }
        
        if (-not $subscriptions) {
            Write-Log "Subscription not found for $($db.DatabaseName)" "WARNING"
            continue
        }
        
        Set-AzContext -SubscriptionId $subscriptions[0].Id -ErrorAction SilentlyContinue | Out-Null
        
        $servers = Get-AzSqlServer -ErrorAction SilentlyContinue | Where-Object { $_.ServerName -eq $db.ServerName }
        
        if (-not $servers) {
            Write-Log "Server $($db.ServerName) not found" "WARNING"
            continue
        }
        
        $server = $servers[0]
        $currentTier = $db.ServiceObjective
        $recommendedTier = $db.RecommendedTier
        $currentCost = [double]$db.CurrentMonthlyCost
        $potentialSavings = [double]$db.PotentialSavings
        
        if ($pricing.ContainsKey($recommendedTier)) {
            $newCost = $pricing[$recommendedTier].Price
        } else {
            $newCost = $currentCost - $potentialSavings
        }
        
        Write-Log "  Current Tier: $currentTier (Cost: $([math]::Round($currentCost,2))/month)" "INFO"
        Write-Log "  Recommended: $recommendedTier (Cost: $([math]::Round($newCost,2))/month)" "INFO"
        Write-Log "  Potential Savings: $([math]::Round($potentialSavings,2))/month" "SAVINGS"
        
        if (-not $Force -and -not $WhatIf) {
            $confirm = Read-Host "  Apply this change? (Y/N/A for All)"
            if ($confirm -eq "A") { $Force = $true }
            if ($confirm -ne "Y" -and $confirm -ne "A") {
                Write-Log "  Skipped by user" "WARNING"
                continue
            }
        }
        
        $result = Invoke-DatabaseTierChange -SubscriptionId $subscriptions[0].Id -ResourceGroup $server.ResourceGroupName -ServerName $server.ServerName -DatabaseName $db.DatabaseName -NewTier $recommendedTier -WhatIfMode:$WhatIf
        
        if ($result.Success) {
            $changesApplied++
            $totalCurrentCost += $currentCost
            $totalNewCost += $newCost
            $totalSavings += $potentialSavings
            
            $allResults += [PSCustomObject]@{
                Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
                SubscriptionName = $db.SubscriptionName
                ServerName = $db.ServerName
                DatabaseName = $db.DatabaseName
                PreviousTier = $currentTier
                NewTier = $recommendedTier
                PreviousCost = [math]::Round($currentCost, 2)
                NewCost = [math]::Round($newCost, 2)
                MonthlySavings = [math]::Round($potentialSavings, 2)
                AnnualSavings = [math]::Round($potentialSavings * 12, 2)
                Status = if ($WhatIf) { "PREVIEW" } else { "APPLIED" }
                AvgDTU = $db.AvgDTUPercent
                MaxDTU = $db.MaxDTUPercent
            }
        } else {
            $changesFailed++
        }
    }
}
else {
    Write-Log "No audit file provided. Running fresh analysis..." "INFO"
    
    $subscriptions = Get-AzSubscription | Where-Object { $_.State -eq "Enabled" }
    Write-Log "Found $($subscriptions.Count) subscriptions to analyze" "INFO"
    
    foreach ($subscription in $subscriptions) {
        Write-Log "Scanning subscription: $($subscription.Name)" "INFO"
        
        try {
            Set-AzContext -SubscriptionId $subscription.Id -ErrorAction Stop | Out-Null
        }
        catch {
            Write-Log "Cannot access subscription: $($subscription.Name)" "WARNING"
            continue
        }
        
        $servers = Get-AzSqlServer -ErrorAction SilentlyContinue
        
        foreach ($server in $servers) {
            $databases = Get-AzSqlDatabase -ResourceGroupName $server.ResourceGroupName -ServerName $server.ServerName -ErrorAction SilentlyContinue | Where-Object { $_.DatabaseName -ne "master" }
            
            foreach ($db in $databases) {
                Write-Log "  Analyzing: $($db.DatabaseName)" "INFO"
                
                $metrics = Get-DatabaseMetrics -SubscriptionId $subscription.Id -ResourceGroup $server.ResourceGroupName -ServerName $server.ServerName -DatabaseName $db.DatabaseName
                
                if (-not $metrics) {
                    Write-Log "    Could not get metrics for $($db.DatabaseName)" "WARNING"
                    continue
                }
                
                $currentTier = $metrics.CurrentTier
                $avgDTU = $metrics.AvgDTU
                $maxDTU = $metrics.MaxDTU
                
                if (-not $pricing.ContainsKey($currentTier)) {
                    Write-Log "    Tier $currentTier not in pricing table, skipping" "WARNING"
                    continue
                }
                
                $currentCost = $pricing[$currentTier].Price
                $currentDTU = $pricing[$currentTier].DTU
                
                if ($avgDTU -lt 25 -and $maxDTU -le $MaxDTUThreshold) {
                    $recommended = Get-RecommendedTier -MaxDTUPercent $maxDTU -CurrentDTU $currentDTU -CurrentTier $currentTier
                    
                    if ($recommended.Tier -ne $currentTier -and $recommended.Price -lt $currentCost) {
                        $savings = $currentCost - $recommended.Price
                        
                        if ($savings -ge $MinSavingsThreshold) {
                            Write-Host ""
                            Write-Log "  OPTIMIZATION FOUND: $($db.DatabaseName)" "SAVINGS"
                            Write-Log "    Current: $currentTier ($currentCost/month) - Avg DTU: $avgDTU%, Max DTU: $maxDTU%" "INFO"
                            Write-Log "    Recommended: $($recommended.Tier) ($($recommended.Price)/month)" "INFO"
                            Write-Log "    Monthly Savings: $([math]::Round($savings,2))" "SAVINGS"
                            
                            if (-not $Force -and -not $WhatIf) {
                                $confirm = Read-Host "    Apply this change? (Y/N/A for All)"
                                if ($confirm -eq "A") { $Force = $true }
                                if ($confirm -ne "Y" -and $confirm -ne "A") {
                                    Write-Log "    Skipped by user" "WARNING"
                                    continue
                                }
                            }
                            
                            $result = Invoke-DatabaseTierChange -SubscriptionId $subscription.Id -ResourceGroup $server.ResourceGroupName -ServerName $server.ServerName -DatabaseName $db.DatabaseName -NewTier $recommended.Tier -WhatIfMode:$WhatIf
                            
                            if ($result.Success) {
                                $changesApplied++
                                $totalCurrentCost += $currentCost
                                $totalNewCost += $recommended.Price
                                $totalSavings += $savings
                                
                                $allResults += [PSCustomObject]@{
                                    Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
                                    SubscriptionName = $subscription.Name
                                    ServerName = $server.ServerName
                                    DatabaseName = $db.DatabaseName
                                    PreviousTier = $currentTier
                                    NewTier = $recommended.Tier
                                    PreviousCost = [math]::Round($currentCost, 2)
                                    NewCost = [math]::Round($recommended.Price, 2)
                                    MonthlySavings = [math]::Round($savings, 2)
                                    AnnualSavings = [math]::Round($savings * 12, 2)
                                    Status = if ($WhatIf) { "PREVIEW" } else { "APPLIED" }
                                    AvgDTU = $avgDTU
                                    MaxDTU = $maxDTU
                                }
                            } else {
                                $changesFailed++
                            }
                        }
                    }
                }
            }
        }
    }
}

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$csvPath = Join-Path $OutputPath "SQL-Optimization-Results_$timestamp.csv"
$allResults | Export-Csv -Path $csvPath -NoTypeInformation

$htmlPath = Join-Path $OutputPath "SQL-Optimization-Report_$timestamp.html"

$htmlContent = @"
<!DOCTYPE html>
<html>
<head>
    <title>Azure SQL Optimization Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #0078d4; border-bottom: 3px solid #0078d4; padding-bottom: 10px; }
        .summary { display: flex; gap: 20px; margin: 30px 0; flex-wrap: wrap; }
        .card { flex: 1; min-width: 200px; padding: 20px; border-radius: 8px; text-align: center; }
        .card.savings { background: linear-gradient(135deg, #107c10, #0b5c0b); color: white; }
        .card.changes { background: linear-gradient(135deg, #0078d4, #005a9e); color: white; }
        .card.cost { background: linear-gradient(135deg, #d83b01, #a62c01); color: white; }
        .card h2 { margin: 0; font-size: 2.5em; }
        .card p { margin: 10px 0 0 0; opacity: 0.9; }
        table { width: 100%; border-collapse: collapse; margin-top: 30px; }
        th { background: #0078d4; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        tr:hover { background: #f0f8ff; }
        .status-applied { color: #107c10; font-weight: bold; }
        .status-preview { color: #d83b01; font-weight: bold; }
        .footer { margin-top: 30px; text-align: center; color: #666; font-size: 0.9em; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Azure SQL Database Optimization Report</h1>
        <p>Generated: $(Get-Date -Format "MMMM dd, yyyy HH:mm:ss")</p>
        <p>Mode: $(if ($WhatIf) { "<span style='color:#d83b01;font-weight:bold;'>PREVIEW MODE - No changes applied</span>" } else { "<span style='color:#107c10;font-weight:bold;'>CHANGES APPLIED</span>" })</p>
        
        <div class="summary">
            <div class="card savings">
                <h2>$([math]::Round($totalSavings, 2))</h2>
                <p>Monthly Savings</p>
            </div>
            <div class="card savings">
                <h2>$([math]::Round($totalSavings * 12, 2))</h2>
                <p>Annual Savings</p>
            </div>
            <div class="card changes">
                <h2>$changesApplied</h2>
                <p>Databases Optimized</p>
            </div>
            <div class="card cost">
                <h2>$([math]::Round($totalCurrentCost, 2))</h2>
                <p>Previous Monthly Cost</p>
            </div>
        </div>
        
        <h2>Optimization Details</h2>
        <table>
            <tr>
                <th>Database</th>
                <th>Server</th>
                <th>Previous Tier</th>
                <th>New Tier</th>
                <th>Previous Cost</th>
                <th>New Cost</th>
                <th>Monthly Savings</th>
                <th>Annual Savings</th>
                <th>Status</th>
            </tr>
"@

foreach ($result in $allResults) {
    $statusClass = if ($result.Status -eq "APPLIED") { "status-applied" } else { "status-preview" }
    $htmlContent += @"
            <tr>
                <td>$($result.DatabaseName)</td>
                <td>$($result.ServerName)</td>
                <td>$($result.PreviousTier)</td>
                <td>$($result.NewTier)</td>
                <td>$($result.PreviousCost)</td>
                <td>$($result.NewCost)</td>
                <td>$($result.MonthlySavings)</td>
                <td>$($result.AnnualSavings)</td>
                <td class="$statusClass">$($result.Status)</td>
            </tr>
"@
}

$htmlContent += @"
        </table>
        
        <div class="footer">
            <p>Azure SQL Database Auto-Optimizer | Infrastructure Team</p>
        </div>
    </div>
</body>
</html>
"@

$htmlContent | Out-File -FilePath $htmlPath -Encoding UTF8

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  OPTIMIZATION COMPLETE" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Databases Optimized:    $changesApplied" -ForegroundColor Green
Write-Host "  Changes Failed:         $changesFailed" -ForegroundColor $(if ($changesFailed -gt 0) { "Red" } else { "Green" })
Write-Host ""
Write-Host "  Previous Monthly Cost:  $([math]::Round($totalCurrentCost, 2))" -ForegroundColor Yellow
Write-Host "  New Monthly Cost:       $([math]::Round($totalNewCost, 2))" -ForegroundColor Green
Write-Host ""
Write-Host "  MONTHLY SAVINGS:        $([math]::Round($totalSavings, 2))" -ForegroundColor Cyan
Write-Host "  ANNUAL SAVINGS:         $([math]::Round($totalSavings * 12, 2))" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Reports saved to:" -ForegroundColor White
Write-Host "    CSV:  $csvPath" -ForegroundColor Gray
Write-Host "    HTML: $htmlPath" -ForegroundColor Gray
Write-Host ""

if ($allResults.Count -gt 0) {
    Start-Process $htmlPath
}

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
