# ============================================================================
# DATADOG AGENT TAG SYNC SCRIPT
# Updates Datadog Agent on all VMs to use Azure tags
# Run AFTER tagging Azure resources
# ============================================================================

param(
    [switch]$WhatIf = $false
)

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "DATADOG AGENT - AZURE TAG SYNC" -ForegroundColor Cyan
Write-Host "Updates all VM agents with Azure tags" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# Check Azure CLI
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: Azure CLI not installed!" -ForegroundColor Red
    exit 1
}

# Login check
$account = az account show 2>$null
if (-not $account) {
    Write-Host "Not logged in. Starting Azure login..." -ForegroundColor Yellow
    az login --use-device-code
}

Write-Host "[STEP 1] Finding all VMs across subscriptions..." -ForegroundColor Yellow

$subscriptions = az account list | ConvertFrom-Json
$allVMs = @()

foreach ($sub in $subscriptions) {
    Write-Host "  Checking subscription: $($sub.name)" -ForegroundColor White
    az account set --subscription $sub.id
    
    $vms = az vm list --show-details | ConvertFrom-Json
    
    foreach ($vm in $vms) {
        $allVMs += @{
            Name = $vm.name
            ResourceGroup = $vm.resourceGroup
            Subscription = $sub.name
            SubscriptionId = $sub.id
            Tags = $vm.tags
            PowerState = $vm.powerState
        }
    }
}

Write-Host "Found $($allVMs.Count) VM(s)" -ForegroundColor Green
Write-Host ""

if ($allVMs.Count -eq 0) {
    Write-Host "No VMs found. Exiting." -ForegroundColor Yellow
    exit 0
}

Write-Host "[STEP 2] Updating Datadog Agent configuration on each VM..." -ForegroundColor Yellow
Write-Host ""

$updated = 0
$skipped = 0
$failed = 0

foreach ($vm in $allVMs) {
    Write-Host "VM: $($vm.Name) [$($vm.ResourceGroup)]" -ForegroundColor Cyan
    
    # Check if VM is running
    if ($vm.PowerState -ne "VM running") {
        Write-Host "  ⚠ VM is not running (state: $($vm.PowerState))" -ForegroundColor Yellow
        Write-Host "  Skipping..." -ForegroundColor Yellow
        $skipped++
        Write-Host ""
        continue
    }
    
    # Convert Azure tags to Datadog format
    $ddTags = @()
    if ($vm.Tags) {
        foreach ($key in $vm.Tags.PSObject.Properties.Name) {
            $value = $vm.Tags.$key -replace '\s+', '-' -replace '[^a-zA-Z0-9_\-\.]', ''
            $ddTags += "$($key.ToLower()):$($value.ToLower())"
        }
    }
    
    if ($ddTags.Count -eq 0) {
        Write-Host "  ⚠ No Azure tags found on this VM" -ForegroundColor Yellow
        $skipped++
        Write-Host ""
        continue
    }
    
    Write-Host "  Tags to apply: $($ddTags -join ', ')" -ForegroundColor White
    
    if ($WhatIf) {
        Write-Host "  [WHATIF] Would update Datadog Agent config" -ForegroundColor Gray
        $updated++
    } else {
        # Create script to run on VM
        $script = @"
# Update Datadog Agent configuration
`$configPath = "C:\ProgramData\Datadog\datadog.yaml"

if (-not (Test-Path `$configPath)) {
    Write-Host "Datadog Agent not found at `$configPath"
    exit 1
}

`$config = Get-Content `$configPath -Raw

# Remove existing tags section
`$config = `$config -replace '(?ms)^tags:.*?(?=^[a-z_]|\z)', ''

# Add new tags
`$tagSection = @"
tags:
$($ddTags | ForEach-Object { "  - $_" } | Out-String)
"@

`$config = `$tagSection + "`n`n" + `$config

# Save config
Set-Content -Path `$configPath -Value `$config -Force

# Restart Datadog Agent
Restart-Service -Name datadogagent -Force

Write-Host "Datadog Agent updated and restarted"
"@
        
        # Save script to temp file
        $scriptPath = [System.IO.Path]::GetTempFileName() + ".ps1"
        $script | Out-File -FilePath $scriptPath -Encoding UTF8
        
        try {
            # Set subscription context
            az account set --subscription $vm.SubscriptionId
            
            # Run script on VM using Run Command
            Write-Host "  Updating agent..." -ForegroundColor Yellow
            
            $result = az vm run-command invoke `
                --resource-group $vm.ResourceGroup `
                --name $vm.Name `
                --command-id RunPowerShellScript `
                --scripts "@$scriptPath" `
                2>$null | ConvertFrom-Json
            
            if ($result.value[0].message -like "*updated and restarted*") {
                Write-Host "  ✓ Successfully updated" -ForegroundColor Green
                $updated++
            } else {
                Write-Host "  ✗ Update may have failed" -ForegroundColor Red
                Write-Host "  Output: $($result.value[0].message)" -ForegroundColor Gray
                $failed++
            }
            
        } catch {
            Write-Host "  ✗ Failed to update: $_" -ForegroundColor Red
            $failed++
        } finally {
            Remove-Item -Path $scriptPath -Force -ErrorAction SilentlyContinue
        }
    }
    
    Write-Host ""
}

# ============================================================================
# SUMMARY
# ============================================================================

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "DATADOG AGENT UPDATE COMPLETE!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Summary:" -ForegroundColor White
Write-Host "  Total VMs found: $($allVMs.Count)" -ForegroundColor White
Write-Host "  Successfully updated: $updated" -ForegroundColor Green
Write-Host "  Skipped: $skipped" -ForegroundColor Yellow
Write-Host "  Failed: $failed" -ForegroundColor Red
Write-Host ""

if ($WhatIf) {
    Write-Host "This was a WHATIF run - no changes were made" -ForegroundColor Yellow
} else {
    Write-Host "NEXT STEPS:" -ForegroundColor Yellow
    Write-Host "  1. Wait 2-3 minutes for agents to report" -ForegroundColor White
    Write-Host "  2. Go to Datadog > Infrastructure > Host Map" -ForegroundColor White
    Write-Host "  3. Filter by tags (e.g., application:moveit)" -ForegroundColor White
    Write-Host "  4. Create tag-based monitors and dashboards" -ForegroundColor White
}

Write-Host ""
