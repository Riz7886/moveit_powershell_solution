param(
    [Parameter(Mandatory=$true)]
    [string]$ResultsCsvPath
)

$ErrorActionPreference = "Stop"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) {
        "ERROR" { "Red" }
        "WARNING" { "Yellow" }
        "SUCCESS" { "Green" }
        default { "White" }
    }
    Write-Host "[$timestamp] [$Level] $Message" -ForegroundColor $color
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Yellow
Write-Host "  AZURE SQL DATABASE ROLLBACK" -ForegroundColor Yellow
Write-Host "  Revert databases to previous tier" -ForegroundColor Yellow
Write-Host "============================================================" -ForegroundColor Yellow
Write-Host ""

if (-not (Test-Path $ResultsCsvPath)) {
    Write-Log "Results file not found: $ResultsCsvPath" "ERROR"
    exit 1
}

$results = Import-Csv -Path $ResultsCsvPath | Where-Object { $_.Status -eq "APPLIED" }

if ($results.Count -eq 0) {
    Write-Log "No applied changes found in the results file" "WARNING"
    exit 0
}

Write-Log "Found $($results.Count) databases to rollback" "INFO"
Write-Host ""

try {
    $context = Get-AzContext
    if (-not $context) {
        Write-Log "Connecting to Azure..." "INFO"
        Connect-AzAccount | Out-Null
    }
}
catch {
    Write-Log "Failed to connect to Azure" "ERROR"
    exit 1
}

$confirm = Read-Host "Are you sure you want to rollback $($results.Count) databases? (YES to confirm)"
if ($confirm -ne "YES") {
    Write-Log "Rollback cancelled" "WARNING"
    exit 0
}

$successCount = 0
$failCount = 0

foreach ($db in $results) {
    Write-Log "Rolling back: $($db.DatabaseName)" "INFO"
    Write-Log "  From: $($db.NewTier) back to: $($db.PreviousTier)" "INFO"
    
    try {
        $subscriptions = Get-AzSubscription | Where-Object { $_.Name -eq $db.SubscriptionName }
        if (-not $subscriptions) {
            Write-Log "  Subscription not found" "ERROR"
            $failCount++
            continue
        }
        
        Set-AzContext -SubscriptionId $subscriptions[0].Id | Out-Null
        
        $servers = Get-AzSqlServer | Where-Object { $_.ServerName -eq $db.ServerName }
        if (-not $servers) {
            Write-Log "  Server not found" "ERROR"
            $failCount++
            continue
        }
        
        $edition = "Standard"
        if ($db.PreviousTier -like "P*") { $edition = "Premium" }
        if ($db.PreviousTier -eq "Basic") { $edition = "Basic" }
        
        Set-AzSqlDatabase -ResourceGroupName $servers[0].ResourceGroupName -ServerName $db.ServerName -DatabaseName $db.DatabaseName -Edition $edition -RequestedServiceObjectiveName $db.PreviousTier | Out-Null
        
        Write-Log "  Rolled back successfully" "SUCCESS"
        $successCount++
    }
    catch {
        Write-Log "  Failed: $($_.Exception.Message)" "ERROR"
        $failCount++
    }
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Yellow
Write-Host "  ROLLBACK COMPLETE" -ForegroundColor Yellow
Write-Host "============================================================" -ForegroundColor Yellow
Write-Host ""
Write-Host "  Successfully rolled back: $successCount" -ForegroundColor Green
Write-Host "  Failed:                   $failCount" -ForegroundColor $(if ($failCount -gt 0) { "Red" } else { "Green" })
Write-Host ""
