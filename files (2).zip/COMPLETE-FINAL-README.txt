# COMPLETE ENTERPRISE CLOUD AUDIT SUITE

## DOWNLOAD NOW

[ENTERPRISE-CLOUD-AUDIT-COMPLETE.zip](computer:///mnt/user-data/outputs/ENTERPRISE-CLOUD-AUDIT-COMPLETE.zip) (16KB)

---

## WHAT WAS ADDED - NSG ENHANCEMENTS

### DETAILED NSG PORT ANALYSIS

Now shows EVERY NSG rule with COMPLETE details:

#### For Each NSG Shows:
- NSG Name
- Resource Group
- Location
- Total number of rules

#### For Each Inbound Rule Shows:
- Rule Name
- Priority
- Direction (Inbound/Outbound)
- Access (Allow/Deny)
- Protocol (TCP/UDP/Any)
- Source Address
- Source Port
- Destination Address
- Destination Port
- Description

#### For Each Outbound Rule Shows:
- Rule Name
- Priority
- Access
- Protocol
- Destination Address
- Destination Port

#### Detects 20+ Dangerous Ports:
- 3389 - RDP
- 22 - SSH
- 1433 - SQL Server
- 3306 - MySQL
- 5432 - PostgreSQL
- 21 - FTP
- 23 - Telnet
- 445 - SMB
- 139 - NetBIOS
- 135 - RPC
- 1521 - Oracle
- 5900 - VNC
- 5984 - CouchDB
- 6379 - Redis
- 7001 - Cassandra
- 8020 - Hadoop
- 8086 - InfluxDB
- 9042 - Cassandra
- 9200 - Elasticsearch
- 11211 - Memcached
- 27017 - MongoDB

---

## EXAMPLE OUTPUT

```
================================================================
  DETAILED NSG ANALYSIS
================================================================

Total NSGs: 12

NSG: nsg-prod-web
  Resource Group: rg-prod-web
  Location: eastus
  Total Rules: 8

  Inbound Rules:

    [100] AllowVnetInBound
      Direction: Inbound
      Access: Allow
      Protocol: *
      Source: VirtualNetwork
      Source Port: *
      Destination: VirtualNetwork
      Destination Port: *

    [110] AllowHTTP
      Direction: Inbound
      Access: Allow
      Protocol: TCP
      Source: *
      Source Port: *
      Destination: *
      Destination Port: 80

      WARNING: Port 80 open but not in dangerous list

    [120] AllowHTTPS
      Direction: Inbound
      Access: Allow
      Protocol: TCP
      Source: *
      Source Port: *
      Destination: *
      Destination Port: 443

    [200] AllowSSH
      Direction: Inbound
      Access: Allow
      Protocol: TCP
      Source: *
      Source Port: *
      Destination: *
      Destination Port: 22

      CRITICAL: Port 22 (SSH) open to internet

    [300] AllowRDP
      Direction: Inbound
      Access: Allow
      Protocol: TCP
      Source: *
      Source Port: *
      Destination: *
      Destination Port: 3389

      CRITICAL: Port 3389 (RDP) open to internet

  Outbound Rules:

    [100] AllowVnetOutBound
      Access: Allow
      Protocol: *
      Destination: VirtualNetwork
      Destination Port: *

    [110] AllowInternetOutBound
      Access: Allow
      Protocol: *
      Destination: Internet
      Destination Port: *
```

---

## NEW REPORTS GENERATED

### 1. NSG_Analysis_timestamp.csv

Complete CSV with ALL NSG rules:
- Subscription
- NSG
- ResourceGroup
- RuleName
- Priority
- Direction
- Access
- Protocol
- SourceAddress
- SourcePort
- DestinationAddress
- DestinationPort
- Description

### 2. NSG_DangerousRules_timestamp.txt

Text report highlighting dangerous rules:

```
================================================================
  DANGEROUS NSG RULES DETECTED
================================================================

Total Dangerous Rules: 15

WARNING: These rules allow traffic from ANY source (internet)

================================================================

NSG: nsg-prod-web
  Rule: AllowSSH (Priority: 200)
  Protocol: TCP
  Source: * (INTERNET)
  Destination Port: 22
  Resource Group: rg-prod-web
  Subscription: Production-Sub-01
  RISK: HIGH - Exposed to internet attacks

NSG: nsg-prod-db
  Rule: AllowSQLServer (Priority: 300)
  Protocol: TCP
  Source: * (INTERNET)
  Destination Port: 1433
  Resource Group: rg-prod-db
  Subscription: Production-Sub-01
  RISK: HIGH - Database exposed to internet
```

### 3. CostAnalysis_timestamp.csv

Stopped VM details with costs:
- Subscription
- ResourceType
- ResourceName
- ResourceGroup
- Status
- Size
- MonthlyCost
- DaysStopped
- StopDate
- MonthlySavings
- YearlySavings

### 4. CostSummary_timestamp.txt

Cost savings summary:
```
================================================================
  COST SAVINGS ANALYSIS
================================================================

Total Stopped Resources: 10

Potential Monthly Savings: $1,245.67
Potential Yearly Savings: $14,948.04

================================================================
  TOP 10 COST SAVINGS OPPORTUNITIES
================================================================

[1] prod-web-01 (Virtual Machine)
    Resource Group: rg-prod-web
    Subscription: Production-Sub-01
    Size: Standard_D4s_v3
    Monthly Cost: $192.72
    Monthly Savings: $192.72
    Yearly Savings: $2,312.64
    Stopped For: 45 days
    Stop Date: 2024-10-25
```

---

## COMPLETE SCAN OUTPUT

```
================================================================
  ENTERPRISE CLOUD AUDIT SUITE V6
================================================================

Available Subscriptions:

[1] Production-Sub-01
[2] Development-Sub-02
[3] Test-Sub-03

[A] All Subscriptions

Select subscriptions: A

Selected Subscriptions: 3

================================================================
  ACTIVE DIRECTORY AUDIT
================================================================

Checking Active Directory module...
ActiveDirectory module loaded

Connecting to Active Directory...
SUCCESS: Connected to domain

Domain: company.local
Forest: company.local

FSMO Roles:
  Schema Master: DC01.company.local
  Domain Naming Master: DC01.company.local
  PDC Emulator: DC01.company.local
  RID Master: DC01.company.local
  Infrastructure Master: DC01.company.local

Domain Controllers: 2
  DC01.company.local
    IP: 10.0.0.10
    Site: Default-First-Site-Name
    OS: Windows Server 2019

Found 15 inactive accounts
Found 5 accounts with password never expires

AD Issues Found: 33
  Critical: 5
  High: 23

================================================================
  AZURE ENVIRONMENT AUDIT
================================================================

Scanning Subscription: Production-Sub-01

Scanning VMs...
  Total VMs: 25
  Running: 15
  Stopped: 10

================================================================
  DETAILED NSG ANALYSIS
================================================================

Total NSGs: 12

NSG: nsg-prod-web
  Resource Group: rg-prod-web
  Location: eastus
  Total Rules: 8

  Inbound Rules:

    [200] AllowSSH
      Direction: Inbound
      Access: Allow
      Protocol: TCP
      Source: *
      Destination Port: 22

      CRITICAL: Port 22 (SSH) open to internet

Scanning VNets and Subnets...
  Total VNets: 3
    vnet-prod
      Subnets: 5
        subnet-db: 82% full

Scanning Storage Accounts...
  Total Storage Accounts: 8
    storage01: Public access enabled

Scanning Resource Groups...
  Total Resource Groups: 18
    rg-prod-web: 25 resources

Scanning RBAC Assignments...
  Total Role Assignments: 145
    Owners: 3
    Contributors: 15

Azure Issues Found: 45

================================================================
  AUDIT SUMMARY
================================================================

Total Issues: 78

Auto-Fixable: 52

================================================================
  COST SAVINGS SUMMARY
================================================================

Stopped Resources: 10
Monthly Savings: $1,245.67
Yearly Savings: $14,948.04

Cost Report: Reports\CostAnalysis_20241209.csv
Cost Summary: Reports\CostSummary_20241209.txt

================================================================
  WARNING: DANGEROUS NSG RULES FOUND
================================================================

Dangerous Rules: 15
Dangerous Rules Report: Reports\NSG_DangerousRules_20241209.txt

NSG Report: Reports\NSG_Analysis_20241209.csv

Report: Reports\AuditReport_20241209.csv
Dashboard: Reports\Dashboard.html
PowerBI Data: Reports\PowerBI_Data.json

================================================================
  AUDIT COMPLETE
================================================================
```

---

## ALL REPORTS GENERATED

1. **AuditReport_timestamp.csv** - All issues
2. **CostAnalysis_timestamp.csv** - Cost breakdown
3. **CostSummary_timestamp.txt** - Cost summary
4. **NSG_Analysis_timestamp.csv** - All NSG rules
5. **NSG_DangerousRules_timestamp.txt** - Dangerous rules only
6. **Dashboard.html** - Interactive dashboard
7. **PowerBI_Data.json** - PowerBI export
8. **RemediationLog_timestamp.csv** - Remediation actions

---

## WHAT IT SCANS

### ACTIVE DIRECTORY
- FSMO roles with server names
- Domain controllers with IPs
- Inactive accounts (90+ days)
- Password never expires
- Old passwords
- Disabled accounts in groups
- Locked accounts

### AZURE VMs
- VM status (running/stopped)
- VM size
- Monthly cost
- Days stopped
- Stop date
- Cost savings

### AZURE NSGs
- All NSG rules (inbound/outbound)
- Rule priorities
- Protocols
- Source/destination addresses
- Source/destination ports
- Dangerous ports detection
- Internet-facing rules

### AZURE VNETs
- Address spaces
- Subnets
- IP utilization
- Subnet capacity warnings

### AZURE STORAGE
- Public blob access
- HTTPS enforcement
- Security configuration

### AZURE RESOURCE GROUPS
- Resource counts
- Empty groups

### AZURE RBAC
- Total role assignments
- Owner counts
- Contributor counts

---

## DANGEROUS PORTS DETECTED

The script now detects 20+ dangerous ports:
- Database ports (SQL, MySQL, PostgreSQL, Oracle, MongoDB, etc)
- Remote access ports (RDP, SSH, VNC)
- Legacy protocols (FTP, Telnet)
- File sharing (SMB, NetBIOS)
- Big data (Hadoop, Cassandra, Elasticsearch)
- Cache servers (Redis, Memcached)

---

## USAGE

```powershell
.\Enterprise-Cloud-Audit-v6.ps1
```

That is it. Run and get everything.

---

THIS IS THE COMPLETE SCRIPT - READY NOW
