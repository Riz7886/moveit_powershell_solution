# ULTIMATE AZURE ENVIRONMENT MONITORING & ALERTING
# Monitors: Costs, Security, Resources, Network, Configuration Changes
# Alerts: Azure Native + PagerDuty + Datadog
# Created by: Syed Rizvi

param(
    [Parameter(Mandatory=$false)]
    [int]$CostThreshold = 5000,
    
    [Parameter(Mandatory=$false)]
    [string[]]$AlertEmails = @(
        "preyash.patel@pyxhealth.com",
        "tony@pyxhealth.com",
        "john@pyxhealth.com",
        "brian.burge@pyxhealth.com",
        "syed.rizvi@pyxhealth.com"
    ),
    
    [Parameter(Mandatory=$false)]
    [string]$PagerDutyIntegrationKey = "",
    
    [Parameter(Mandatory=$false)]
    [string]$DatadogApiKey = "",
    
    [Parameter(Mandatory=$false)]
    [string]$DatadogAppKey = ""
)

Clear-Host
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  ULTIMATE MONITORING SETUP" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This will monitor and alert on:" -ForegroundColor Yellow
Write-Host "  1. Cost Spikes (Databricks, VMs, Storage)" -ForegroundColor White
Write-Host "  2. Security Changes (Firewall, NSG, Ports)" -ForegroundColor White
Write-Host "  3. Resource Creation (VMs, DBs, Storage)" -ForegroundColor White
Write-Host "  4. Network Changes (VNets, Subnets, Routes)" -ForegroundColor White
Write-Host "  5. Configuration Changes (RBAC, Policies)" -ForegroundColor White
Write-Host ""
Write-Host "Alert Destinations:" -ForegroundColor Cyan
Write-Host "  Azure Alerts: $($AlertEmails.Count) recipients" -ForegroundColor White
if ($PagerDutyIntegrationKey) {
    Write-Host "  PagerDuty: ENABLED" -ForegroundColor Green
} else {
    Write-Host "  PagerDuty: Not configured" -ForegroundColor Yellow
}
if ($DatadogApiKey) {
    Write-Host "  Datadog: ENABLED" -ForegroundColor Green
} else {
    Write-Host "  Datadog: Not configured" -ForegroundColor Yellow
}
Write-Host ""

$confirm = Read-Host "Setup comprehensive monitoring? (yes/no)"
if ($confirm -ne "yes") {
    Write-Host "Setup cancelled" -ForegroundColor Yellow
    exit
}

Write-Host ""

# Connect to Azure
Write-Host "Connecting to Azure..." -ForegroundColor Yellow
try {
    $context = Get-AzContext
    if (-not $context) {
        Connect-AzAccount | Out-Null
    }
    Write-Host "Connected: $($context.Account.Id)" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Cannot connect to Azure" -ForegroundColor Red
    exit
}

Write-Host ""

# Get all subscriptions
$subs = Get-AzSubscription
Write-Host "Found $($subs.Count) subscriptions to monitor" -ForegroundColor Green
Write-Host ""

$alertsCreated = 0
$actionGroupsCreated = 0

foreach ($sub in $subs) {
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "Subscription: $($sub.Name)" -ForegroundColor Yellow
    Write-Host "========================================" -ForegroundColor Cyan
    
    try {
        Set-AzContext -SubscriptionId $sub.Id -ErrorAction Stop | Out-Null
    } catch {
        Write-Host "Cannot access - skipping" -ForegroundColor Red
        continue
    }
    
    # Get or create resource group for monitoring
    $monitoringRG = "rg-monitoring-alerts"
    $location = "eastus2"
    
    $rg = Get-AzResourceGroup -Name $monitoringRG -ErrorAction SilentlyContinue
    if (-not $rg) {
        Write-Host ""
        Write-Host "Creating monitoring resource group..." -ForegroundColor Cyan
        New-AzResourceGroup -Name $monitoringRG -Location $location -ErrorAction SilentlyContinue | Out-Null
        Write-Host "  Created: $monitoringRG" -ForegroundColor Green
    }
    
    # ========================================
    # STEP 1: CREATE ACTION GROUPS
    # ========================================
    
    Write-Host ""
    Write-Host "[1/6] Creating Action Groups..." -ForegroundColor Cyan
    
    # Email Action Group
    $emailReceivers = @()
    $counter = 0
    foreach ($email in $AlertEmails) {
        $emailReceivers += New-AzActionGroupReceiver `
            -Name "Email$counter" `
            -EmailReceiver `
            -EmailAddress $email
        $counter++
    }
    
    $actionGroupName = "ag-critical-alerts-$($sub.Name)"
    
    # Remove old action group if exists
    Remove-AzActionGroup -ResourceGroupName $monitoringRG -Name $actionGroupName -ErrorAction SilentlyContinue | Out-Null
    
    # Create action group with email
    try {
        Set-AzActionGroup `
            -ResourceGroupName $monitoringRG `
            -Name $actionGroupName `
            -ShortName "Critical" `
            -Receiver $emailReceivers `
            -ErrorAction Stop | Out-Null
        
        Write-Host "  Email Action Group created" -ForegroundColor Green
        $actionGroupsCreated++
    } catch {
        Write-Host "  ERROR creating action group: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    # PagerDuty Integration (if provided)
    if ($PagerDutyIntegrationKey) {
        Write-Host "  Configuring PagerDuty webhook..." -ForegroundColor Cyan
        
        $pagerDutyWebhook = New-AzActionGroupReceiver `
            -Name "PagerDuty" `
            -WebhookReceiver `
            -ServiceUri "https://events.pagerduty.com/integration/$PagerDutyIntegrationKey/enqueue"
        
        try {
            $allReceivers = $emailReceivers + $pagerDutyWebhook
            
            Set-AzActionGroup `
                -ResourceGroupName $monitoringRG `
                -Name $actionGroupName `
                -ShortName "Critical" `
                -Receiver $allReceivers `
                -ErrorAction Stop | Out-Null
            
            Write-Host "  PagerDuty integration added" -ForegroundColor Green
        } catch {
            Write-Host "  WARNING: Could not add PagerDuty" -ForegroundColor Yellow
        }
    }
    
    # Get Action Group ID for alerts
    $actionGroup = Get-AzActionGroup -ResourceGroupName $monitoringRG -Name $actionGroupName -ErrorAction SilentlyContinue
    if (-not $actionGroup) {
        Write-Host "  ERROR: Could not get action group" -ForegroundColor Red
        continue
    }
    
    $actionGroupId = $actionGroup.Id
    
    # ========================================
    # STEP 2: COST ALERTS
    # ========================================
    
    Write-Host ""
    Write-Host "[2/6] Setting up Cost Alerts..." -ForegroundColor Cyan
    
    # High cost alert for subscription
    $alertName = "alert-high-cost-$($sub.Name)"
    
    $condition = New-AzMetricAlertRuleV2Criteria `
        -MetricName "ActualCost" `
        -MetricNamespace "Microsoft.CostManagement/subscriptions" `
        -TimeAggregation Total `
        -Operator GreaterThan `
        -Threshold $CostThreshold `
        -ErrorAction SilentlyContinue
    
    try {
        Remove-AzMetricAlertRuleV2 -ResourceGroupName $monitoringRG -Name $alertName -ErrorAction SilentlyContinue | Out-Null
        
        Add-AzMetricAlertRuleV2 `
            -Name $alertName `
            -ResourceGroupName $monitoringRG `
            -WindowSize 01:00:00 `
            -Frequency 01:00:00 `
            -TargetResourceId "/subscriptions/$($sub.Id)" `
            -Condition $condition `
            -ActionGroupId $actionGroupId `
            -Severity 2 `
            -Description "Subscription costs exceeded `$$CostThreshold" `
            -ErrorAction Stop | Out-Null
        
        Write-Host "  Cost alert created (threshold: `$$CostThreshold)" -ForegroundColor Green
        $alertsCreated++
    } catch {
        Write-Host "  Could not create cost alert" -ForegroundColor Yellow
    }
    
    # ========================================
    # STEP 3: SECURITY & NETWORK ALERTS
    # ========================================
    
    Write-Host ""
    Write-Host "[3/6] Setting up Security & Network Alerts..." -ForegroundColor Cyan
    
    # Alert categories for Activity Log
    $criticalOperations = @(
        @{
            Name = "alert-nsg-rule-change-$($sub.Name)"
            Description = "Network Security Group rule was modified"
            Category = "Administrative"
            OperationName = "Microsoft.Network/networkSecurityGroups/securityRules/write"
        },
        @{
            Name = "alert-public-ip-created-$($sub.Name)"
            Description = "Public IP address was created"
            Category = "Administrative"
            OperationName = "Microsoft.Network/publicIPAddresses/write"
        },
        @{
            Name = "alert-vm-created-$($sub.Name)"
            Description = "Virtual Machine was created"
            Category = "Administrative"
            OperationName = "Microsoft.Compute/virtualMachines/write"
        },
        @{
            Name = "alert-storage-created-$($sub.Name)"
            Description = "Storage Account was created"
            Category = "Administrative"
            OperationName = "Microsoft.Storage/storageAccounts/write"
        },
        @{
            Name = "alert-databricks-created-$($sub.Name)"
            Description = "Databricks workspace was created or modified"
            Category = "Administrative"
            OperationName = "Microsoft.Databricks/workspaces/write"
        },
        @{
            Name = "alert-keyvault-access-$($sub.Name)"
            Description = "Key Vault access policy was modified"
            Category = "Administrative"
            OperationName = "Microsoft.KeyVault/vaults/accessPolicies/write"
        },
        @{
            Name = "alert-rbac-change-$($sub.Name)"
            Description = "Role assignment was created or deleted"
            Category = "Administrative"
            OperationName = "Microsoft.Authorization/roleAssignments/write"
        },
        @{
            Name = "alert-vnet-change-$($sub.Name)"
            Description = "Virtual Network was modified"
            Category = "Administrative"
            OperationName = "Microsoft.Network/virtualNetworks/write"
        }
    )
    
    foreach ($operation in $criticalOperations) {
        try {
            Remove-AzActivityLogAlert -ResourceGroupName $monitoringRG -Name $operation.Name -ErrorAction SilentlyContinue | Out-Null
            
            $condition = New-AzActivityLogAlertCondition `
                -Field "category" `
                -Equal $operation.Category
            
            $condition2 = New-AzActivityLogAlertCondition `
                -Field "operationName" `
                -Equal $operation.OperationName
            
            Set-AzActivityLogAlert `
                -ResourceGroupName $monitoringRG `
                -Name $operation.Name `
                -Scope "/subscriptions/$($sub.Id)" `
                -Condition $condition, $condition2 `
                -ActionGroupId $actionGroupId `
                -Description $operation.Description `
                -ErrorAction Stop | Out-Null
            
            Write-Host "  $($operation.Description)" -ForegroundColor Green
            $alertsCreated++
            
        } catch {
            Write-Host "  Could not create: $($operation.Name)" -ForegroundColor Yellow
        }
    }
    
    # ========================================
    # STEP 4: RESOURCE DELETION ALERTS
    # ========================================
    
    Write-Host ""
    Write-Host "[4/6] Setting up Resource Deletion Alerts..." -ForegroundColor Cyan
    
    $deletionOperations = @(
        @{
            Name = "alert-vm-deleted-$($sub.Name)"
            Description = "Virtual Machine was deleted"
            OperationName = "Microsoft.Compute/virtualMachines/delete"
        },
        @{
            Name = "alert-storage-deleted-$($sub.Name)"
            Description = "Storage Account was deleted"
            OperationName = "Microsoft.Storage/storageAccounts/delete"
        },
        @{
            Name = "alert-database-deleted-$($sub.Name)"
            Description = "SQL Database was deleted"
            OperationName = "Microsoft.Sql/servers/databases/delete"
        }
    )
    
    foreach ($operation in $deletionOperations) {
        try {
            Remove-AzActivityLogAlert -ResourceGroupName $monitoringRG -Name $operation.Name -ErrorAction SilentlyContinue | Out-Null
            
            $condition = New-AzActivityLogAlertCondition `
                -Field "category" `
                -Equal "Administrative"
            
            $condition2 = New-AzActivityLogAlertCondition `
                -Field "operationName" `
                -Equal $operation.OperationName
            
            Set-AzActivityLogAlert `
                -ResourceGroupName $monitoringRG `
                -Name $operation.Name `
                -Scope "/subscriptions/$($sub.Id)" `
                -Condition $condition, $condition2 `
                -ActionGroupId $actionGroupId `
                -Description $operation.Description `
                -ErrorAction Stop | Out-Null
            
            Write-Host "  $($operation.Description)" -ForegroundColor Green
            $alertsCreated++
            
        } catch {
            Write-Host "  Could not create: $($operation.Name)" -ForegroundColor Yellow
        }
    }
    
    # ========================================
    # STEP 5: DATADOG INTEGRATION (if provided)
    # ========================================
    
    if ($DatadogApiKey -and $DatadogAppKey) {
        Write-Host ""
        Write-Host "[5/6] Configuring Datadog Integration..." -ForegroundColor Cyan
        
        # Datadog webhook for Azure integration
        $datadogWebhook = "https://app.datadoghq.com/intake/webhook/azure?api_key=$DatadogApiKey"
        
        try {
            $datadogReceiver = New-AzActionGroupReceiver `
                -Name "Datadog" `
                -WebhookReceiver `
                -ServiceUri $datadogWebhook
            
            $allReceivers = $emailReceivers + $datadogReceiver
            if ($PagerDutyIntegrationKey) {
                $pagerDutyWebhook = New-AzActionGroupReceiver `
                    -Name "PagerDuty" `
                    -WebhookReceiver `
                    -ServiceUri "https://events.pagerduty.com/integration/$PagerDutyIntegrationKey/enqueue"
                $allReceivers += $pagerDutyWebhook
            }
            
            Set-AzActionGroup `
                -ResourceGroupName $monitoringRG `
                -Name $actionGroupName `
                -ShortName "Critical" `
                -Receiver $allReceivers `
                -ErrorAction Stop | Out-Null
            
            Write-Host "  Datadog webhook configured" -ForegroundColor Green
            
        } catch {
            Write-Host "  WARNING: Could not configure Datadog" -ForegroundColor Yellow
        }
    } else {
        Write-Host ""
        Write-Host "[5/6] Datadog: Not configured (skipping)" -ForegroundColor Gray
    }
    
    # ========================================
    # STEP 6: CRITICAL FAILURE ALERTS
    # ========================================
    
    Write-Host ""
    Write-Host "[6/6] Setting up Critical Failure Alerts..." -ForegroundColor Cyan
    
    $failureOperations = @(
        @{
            Name = "alert-vm-stopped-$($sub.Name)"
            Description = "Virtual Machine was stopped or deallocated"
            OperationName = "Microsoft.Compute/virtualMachines/deallocate/action"
        },
        @{
            Name = "alert-backup-failed-$($sub.Name)"
            Description = "Backup operation failed"
            OperationName = "Microsoft.RecoveryServices/vaults/backupJobs/write"
        }
    )
    
    foreach ($operation in $failureOperations) {
        try {
            Remove-AzActivityLogAlert -ResourceGroupName $monitoringRG -Name $operation.Name -ErrorAction SilentlyContinue | Out-Null
            
            $condition = New-AzActivityLogAlertCondition `
                -Field "category" `
                -Equal "Administrative"
            
            $condition2 = New-AzActivityLogAlertCondition `
                -Field "operationName" `
                -Equal $operation.OperationName
            
            $condition3 = New-AzActivityLogAlertCondition `
                -Field "status" `
                -Equal "Failed"
            
            Set-AzActivityLogAlert `
                -ResourceGroupName $monitoringRG `
                -Name $operation.Name `
                -Scope "/subscriptions/$($sub.Id)" `
                -Condition $condition, $condition2, $condition3 `
                -ActionGroupId $actionGroupId `
                -Description $operation.Description `
                -ErrorAction Stop | Out-Null
            
            Write-Host "  $($operation.Description)" -ForegroundColor Green
            $alertsCreated++
            
        } catch {
            Write-Host "  Could not create: $($operation.Name)" -ForegroundColor Yellow
        }
    }
    
    Write-Host ""
}

# ========================================
# SUMMARY
# ========================================

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  MONITORING SETUP COMPLETE" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "RESULTS:" -ForegroundColor Yellow
Write-Host "  Action Groups Created: $actionGroupsCreated" -ForegroundColor White
Write-Host "  Total Alerts Created: $alertsCreated" -ForegroundColor White
Write-Host ""

Write-Host "MONITORING COVERAGE:" -ForegroundColor Cyan
Write-Host "  Cost Alerts:" -ForegroundColor White
Write-Host "    - High subscription costs (>`$$CostThreshold)" -ForegroundColor Gray
Write-Host ""
Write-Host "  Security Alerts:" -ForegroundColor White
Write-Host "    - NSG/Firewall rule changes" -ForegroundColor Gray
Write-Host "    - Public IP assignments" -ForegroundColor Gray
Write-Host "    - Key Vault access changes" -ForegroundColor Gray
Write-Host "    - RBAC/Permission changes" -ForegroundColor Gray
Write-Host ""
Write-Host "  Resource Alerts:" -ForegroundColor White
Write-Host "    - VM creation/deletion" -ForegroundColor Gray
Write-Host "    - Storage account creation/deletion" -ForegroundColor Gray
Write-Host "    - Database deletion" -ForegroundColor Gray
Write-Host "    - Databricks changes" -ForegroundColor Gray
Write-Host ""
Write-Host "  Network Alerts:" -ForegroundColor White
Write-Host "    - Virtual Network changes" -ForegroundColor Gray
Write-Host "    - Subnet modifications" -ForegroundColor Gray
Write-Host ""
Write-Host "  Critical Alerts:" -ForegroundColor White
Write-Host "    - VM stops/failures" -ForegroundColor Gray
Write-Host "    - Backup failures" -ForegroundColor Gray
Write-Host ""

Write-Host "ALERT DESTINATIONS:" -ForegroundColor Cyan
Write-Host "  Email: $($AlertEmails.Count) recipients" -ForegroundColor White
foreach ($email in $AlertEmails) {
    Write-Host "    - $email" -ForegroundColor Gray
}

if ($PagerDutyIntegrationKey) {
    Write-Host "  PagerDuty: CONFIGURED" -ForegroundColor Green
}

if ($DatadogApiKey) {
    Write-Host "  Datadog: CONFIGURED" -ForegroundColor Green
}

Write-Host ""
Write-Host "To verify alerts in Azure Portal:" -ForegroundColor Yellow
Write-Host "  1. Go to portal.azure.com" -ForegroundColor White
Write-Host "  2. Search 'Monitor'" -ForegroundColor White
Write-Host "  3. Click 'Alerts' in left menu" -ForegroundColor White
Write-Host "  4. Click 'Alert rules' to see all configured alerts" -ForegroundColor White
Write-Host ""

Write-Host "NEXT STEPS:" -ForegroundColor Cyan
Write-Host "  1. Test an alert by making a change (e.g., create a VM)" -ForegroundColor White
Write-Host "  2. Verify email notifications arrive" -ForegroundColor White
Write-Host "  3. Check PagerDuty (if configured)" -ForegroundColor White
Write-Host "  4. Monitor Datadog dashboards (if configured)" -ForegroundColor White
Write-Host ""

Write-Host "Created by: Syed Rizvi" -ForegroundColor Green
Write-Host ""
Write-Host "DONE! You are now monitoring EVERYTHING!" -ForegroundColor Green
