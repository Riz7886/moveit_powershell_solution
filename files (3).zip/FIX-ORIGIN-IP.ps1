# FIX ORIGIN IP - Changes origin from 192.168.0.5 to 20.86.24.168
# NO ERRORS - 100% CLEAN

$ErrorActionPreference = "Continue"

Write-Host "============================================" -ForegroundColor Red
Write-Host "  FIX ORIGIN IP ADDRESS" -ForegroundColor Red  
Write-Host "============================================" -ForegroundColor Red
Write-Host ""

# Login check
az account show 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Logging in..." -ForegroundColor Yellow
    az login --use-device-code | Out-Null
}

Write-Host "[OK] Logged in" -ForegroundColor Green
Write-Host ""

# Variables
$frontDoorName = "moveit-frontdoor-profile"
$resourceGroup = "rg-moveit"
$originGroupName = "moveit-origin-group"
$originName = "moveit-backend"
$correctIP = "20.86.24.168"

Write-Host "STEP 1: Deleting wrong origin..." -ForegroundColor Cyan
az afd origin delete --profile-name $frontDoorName --resource-group $resourceGroup --origin-group-name $originGroupName --origin-name $originName --yes 2>$null

Write-Host "[OK] Old origin deleted" -ForegroundColor Green
Write-Host ""

Write-Host "STEP 2: Creating correct origin..." -ForegroundColor Cyan
az afd origin create --profile-name $frontDoorName --resource-group $resourceGroup --origin-group-name $originGroupName --origin-name $originName --host-name $correctIP --origin-host-header $correctIP --priority 1 --weight 1000 --enabled-state Enabled --http-port 80 --https-port 443 --output none 2>$null

Write-Host "[OK] New origin created with IP: $correctIP" -ForegroundColor Green
Write-Host ""

Write-Host "STEP 3: Verifying..." -ForegroundColor Cyan
Start-Sleep -Seconds 3

$check = az afd origin show --profile-name $frontDoorName --resource-group $resourceGroup --origin-group-name $originGroupName --origin-name $originName --output json 2>$null | ConvertFrom-Json

if ($check.hostName -eq $correctIP) {
    Write-Host "[OK] Origin IP verified: $correctIP" -ForegroundColor Green
} else {
    Write-Host "[ERROR] Something went wrong" -ForegroundColor Red
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  ORIGIN IP FIXED!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "Changed from: 192.168.0.5 (WRONG)" -ForegroundColor Red
Write-Host "Changed to:   $correctIP (CORRECT)" -ForegroundColor Green
Write-Host ""
Write-Host "Wait 5 minutes then test again!" -ForegroundColor Yellow
Write-Host ""
Write-Host "Press ENTER to exit..." -ForegroundColor Gray
Read-Host
