# DATABRICKS COMPLETE HEALTH CHECK + COST ANALYSIS + FIX
# Real-world solution balancing cost and performance

$workspace = "https://adb-324884819348686.6.azuredatabricks.net"
$token = "dapi9abaad71d0865d1a32a08cba05a318b7"

$headers = @{
    "Authorization" = "Bearer $token"
}

Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  DATABRICKS COMPLETE ANALYSIS - ALL CLUSTERS + WAREHOUSES" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

$allData = @()
$totalMonthlyCost = 0
$potentialSavings = 0
$recommendations = @()

# ANALYZE CLUSTERS
Write-Host "[1/2] Analyzing Compute Clusters..." -ForegroundColor Yellow
try {
    $cl = Invoke-RestMethod -Uri "$workspace/api/2.0/clusters/list" -Headers $headers
    
    if ($cl.clusters) {
        Write-Host "  Found: $($cl.clusters.Count) clusters" -ForegroundColor Green
        
        foreach ($c in $cl.clusters) {
            $name = $c.cluster_name
            $state = $c.state
            
            # Get config
            $minW = if ($c.autoscale) { $c.autoscale.min_workers } elseif ($c.num_workers) { $c.num_workers } else { 0 }
            $maxW = if ($c.autoscale) { $c.autoscale.max_workers } elseif ($c.num_workers) { $c.num_workers } else { 0 }
            $autoTerm = if ($c.autotermination_minutes) { $c.autotermination_minutes } else { 0 }
            
            # Calculate costs (16 vCPUs per worker, $0.15/vCPU/hour)
            $minCost = [math]::Round($minW * 16 * 0.15 * 730, 2)
            $maxCost = [math]::Round($maxW * 16 * 0.15 * 730, 2)
            
            # Identify issues
            $issue = "OK"
            $recommendation = ""
            
            if ($name -like "*Processing*") {
                if ($minW -eq 1 -and $autoTerm -lt 30) {
                    $issue = "SLOW STARTUP + FREQUENT RESTARTS"
                    $recommendation = "CHANGE: min=2, max=8, auto-term=30min (balance cost+performance)"
                    $potentialSavings += 0  # Slight cost increase but worth it
                }
            }
            
            if ($autoTerm -eq 0) {
                $issue = "RUNS FOREVER"
                $recommendation = "ENABLE auto-termination (30 minutes)"
                $potentialSavings += 1000
            }
            
            if ($minW -eq 0 -and $maxW -eq 0) {
                $issue = "NO WORKERS CONFIGURED"
            }
            
            Write-Host "    - $name [$state] Min=$minW Max=$maxW AutoTerm=${autoTerm}min" -ForegroundColor White
            
            $allData += [PSCustomObject]@{
                Type = "Cluster"
                Name = $name
                State = $state
                MinWorkers = $minW
                MaxWorkers = $maxW
                AutoTerm = "${autoTerm} min"
                MonthlyCost = "`$$minCost - `$$maxCost"
                Issue = $issue
                Recommendation = $recommendation
            }
            
            $totalMonthlyCost += $minCost
            if ($recommendation) { $recommendations += "$name : $recommendation" }
        }
    }
} catch {
    Write-Host "  ERROR: $($_.Exception.Message)" -ForegroundColor Red
}

# ANALYZE SQL WAREHOUSES
Write-Host ""
Write-Host "[2/2] Analyzing SQL Warehouses..." -ForegroundColor Yellow
try {
    $wh = Invoke-RestMethod -Uri "$workspace/api/2.0/sql/warehouses" -Headers $headers
    
    if ($wh.warehouses) {
        Write-Host "  Found: $($wh.warehouses.Count) warehouses" -ForegroundColor Green
        
        foreach ($w in $wh.warehouses) {
            $whName = $w.name
            $whState = $w.state
            $whSize = $w.cluster_size
            $whAutoStop = $w.auto_stop_mins
            
            # Cost estimate (2X-Small = ~$0.22/hour)
            $whCost = [math]::Round(0.22 * 730, 2)
            
            $whIssue = "OK"
            $whRec = ""
            
            if ($whAutoStop -eq 0) {
                $whIssue = "NO AUTO-STOP"
                $whRec = "ENABLE auto-stop (30 minutes)"
                $potentialSavings += 150
            }
            
            Write-Host "    - $whName [$whState] Size=$whSize AutoStop=${whAutoStop}min" -ForegroundColor White
            
            $allData += [PSCustomObject]@{
                Type = "SQL Warehouse"
                Name = $whName
                State = $whState
                MinWorkers = "-"
                MaxWorkers = "-"
                AutoTerm = "${whAutoStop} min"
                MonthlyCost = "`$$whCost"
                Issue = $whIssue
                Recommendation = $whRec
            }
            
            $totalMonthlyCost += $whCost
            if ($whRec) { $recommendations += "$whName : $whRec" }
        }
    }
} catch {
    Write-Host "  ERROR: $($_.Exception.Message)" -ForegroundColor Red
}

# GENERATE HTML REPORT
Write-Host ""
Write-Host "Generating Complete HTML Report..." -ForegroundColor Yellow

$reportFile = "Databricks-Complete-Analysis-$(Get-Date -Format 'yyyyMMdd-HHmmss').html"

$tableRows = ""
foreach ($item in $allData) {
    $issueColor = if ($item.Issue -eq "OK") { "green" } else { "red" }
    $tableRows += "<tr>"
    $tableRows += "<td>$($item.Type)</td>"
    $tableRows += "<td><strong>$($item.Name)</strong></td>"
    $tableRows += "<td>$($item.State)</td>"
    $tableRows += "<td>$($item.MinWorkers)</td>"
    $tableRows += "<td>$($item.MaxWorkers)</td>"
    $tableRows += "<td>$($item.AutoTerm)</td>"
    $tableRows += "<td>$($item.MonthlyCost)</td>"
    $tableRows += "<td style='color:$issueColor;font-weight:bold;'>$($item.Issue)</td>"
    $tableRows += "<td>$($item.Recommendation)</td>"
    $tableRows += "</tr>"
}

$recList = ""
if ($recommendations.Count -eq 0) {
    $recList = "<p style='color:green;font-weight:bold;'>All configurations are optimal!</p>"
} else {
    $recList = "<ul style='color:blue;'>"
    foreach ($rec in $recommendations) {
        $recList += "<li>$rec</li>"
    }
    $recList += "</ul>"
}

$html = @"
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Databricks Complete Analysis</title>
<style>
body{font-family:Arial;margin:20px;background:#f5f5f5;}
.container{max-width:1600px;margin:0 auto;background:white;padding:40px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);}
h1{color:#FF3621;font-size:32px;margin-bottom:10px;}
h2{color:#1B3139;border-bottom:3px solid #FF3621;padding-bottom:10px;margin-top:35px;}
.summary{background:#f8f9fa;padding:25px;border-left:4px solid #FF3621;margin:25px 0;}
.fix{background:#d4edda;border-left:5px solid #28a745;padding:20px;margin:20px 0;}
table{width:100%;border-collapse:collapse;margin:25px 0;box-shadow:0 1px 3px rgba(0,0,0,0.1);}
th{background:#1B3139;color:white;padding:15px;text-align:left;}
td{padding:12px;border-bottom:1px solid #ddd;}
tr:hover{background:#f5f5f5;}
.metric{display:inline-block;background:#e3f2fd;padding:20px 30px;margin:10px;border-radius:5px;min-width:200px;text-align:center;}
.metric strong{display:block;font-size:32px;color:#1976d2;margin-bottom:5px;}
</style>
</head>
<body>
<div class="container">

<h1>Databricks Complete Health Check</h1>
<p>Generated: $(Get-Date -Format 'MMMM dd, yyyy HH:mm:ss')</p>
<p>Workspace: $workspace</p>

<div class="summary">
<h2 style="margin-top:0;border:none;">Executive Summary</h2>
<div style="text-align:center;">
<div class="metric">
<strong>$($allData.Count)</strong>
<span>Total Resources</span>
</div>
<div class="metric">
<strong>`$$([math]::Round($totalMonthlyCost,2))</strong>
<span>Monthly Cost</span>
</div>
<div class="metric">
<strong>`$$([math]::Round($potentialSavings,2))</strong>
<span>Potential Savings</span>
</div>
<div class="metric">
<strong>$($recommendations.Count)</strong>
<span>Recommendations</span>
</div>
</div>
</div>

<div class="fix">
<h2 style="margin-top:0;border:none;">The Problem (From Teams Chat)</h2>
<p><strong>Issue 1:</strong> Cluster keeps shutting down due to being idle (10min auto-termination too aggressive)</p>
<p><strong>Issue 2:</strong> Cluster takes too long to start (min=1 worker causes slow startup for Tableau)</p>
<p><strong>Solution:</strong> Increase min workers to 2 + increase auto-termination to 30 minutes</p>
<p style="color:#28a745;font-weight:bold;">This balances cost savings with performance!</p>
</div>

<h2>Recommended Actions</h2>
$recList

<h2>Complete Resource Analysis</h2>
<table>
<tr>
<th>Type</th>
<th>Name</th>
<th>State</th>
<th>Min Workers</th>
<th>Max Workers</th>
<th>Auto-Terminate</th>
<th>Monthly Cost</th>
<th>Status</th>
<th>Recommendation</th>
</tr>
$tableRows
</table>

<h2>Next Steps</h2>
<ol>
<li><strong>Processing Cluster:</strong> Change to min=2, max=8, auto-terminate=30min</li>
<li><strong>SQL Warehouses:</strong> Verify auto-stop enabled (30 minutes)</li>
<li><strong>Monitor:</strong> Check Tableau connection performance after changes</li>
<li><strong>Reply to Teams:</strong> Confirm fixes applied</li>
</ol>

<p style="margin-top:40px;"><strong>Prepared by:</strong> Syed Rizvi</p>
<p><strong>Date:</strong> $(Get-Date -Format 'yyyy-MM-dd')</p>

</div>
</body>
</html>
"@

$html | Out-File $reportFile -Encoding UTF8
Write-Host "  Report saved: $reportFile" -ForegroundColor Green
Start-Process $reportFile

# SUMMARY
Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  ANALYSIS COMPLETE" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "Total Resources: $($allData.Count)" -ForegroundColor White
Write-Host "Monthly Cost: `$$([math]::Round($totalMonthlyCost,2))" -ForegroundColor White
Write-Host "Potential Savings: `$$([math]::Round($potentialSavings,2))" -ForegroundColor Yellow
Write-Host "Recommendations: $($recommendations.Count)" -ForegroundColor $(if ($recommendations.Count -eq 0) {"Green"} else {"Yellow"})
Write-Host ""
Write-Host "Report: $reportFile" -ForegroundColor Green
Write-Host ""
