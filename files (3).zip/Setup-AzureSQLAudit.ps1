<#
.SYNOPSIS
    ONE-TIME SETUP - Run this ONCE, then AzureSQLDatabaseAudit.ps1 runs forever on its own.
.DESCRIPTION
    This script does everything in one shot:
      1. Fixes the token cache error you're hitting
      2. Creates a Service Principal for automated auth
      3. Saves encrypted credentials locally
      4. Schedules the audit to run daily
    
    After this, you never touch it again.

.NOTES
    Run as Administrator in PowerShell
    Usage: .\Setup-AzureSQLAudit.ps1
           .\Setup-AzureSQLAudit.ps1 -ScheduleTime "07:00" -Frequency Weekly
#>

[CmdletBinding()]
param(
    [string]$AuditScriptPath = ".\AzureSQLDatabaseAudit.ps1",
    [string]$ReportFolder = "C:\AzureSQLAuditReports",
    [string]$ScheduleTime = "06:00",
    [ValidateSet("Daily", "Weekly")]
    [string]$Frequency = "Daily",
    [string]$ServicePrincipalName = "SQLAuditAutomation"
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  AZURE SQL AUDIT - ONE-TIME AUTOMATED SETUP" -ForegroundColor Cyan
Write-Host "  Run this once. Never think about it again." -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

# --- Step 1: Verify audit script exists ---
Write-Host "[1/7] Checking audit script..." -ForegroundColor Yellow
if (-not (Test-Path $AuditScriptPath)) {
    Write-Host "  ERROR: Can't find $AuditScriptPath" -ForegroundColor Red
    Write-Host "  Put AzureSQLDatabaseAudit.ps1 in the same folder as this setup script." -ForegroundColor Red
    exit 1
}
$AuditScriptPath = (Resolve-Path $AuditScriptPath).Path
Write-Host "  Found: $AuditScriptPath" -ForegroundColor Green

# --- Step 2: Create report folder ---
Write-Host "[2/7] Creating report folder..." -ForegroundColor Yellow
if (-not (Test-Path $ReportFolder)) {
    New-Item -ItemType Directory -Path $ReportFolder -Force | Out-Null
}
Write-Host "  Reports will save to: $ReportFolder" -ForegroundColor Green

# --- Step 3: Fix token cache and login ---
Write-Host "[3/7] Fixing Azure authentication..." -ForegroundColor Yellow
try {
    # Clear broken token cache
    Clear-AzContext -Force -ErrorAction SilentlyContinue | Out-Null
    
    # Try existing login first
    $context = $null
    try {
        Connect-AzAccount -WarningAction SilentlyContinue -ErrorAction Stop | Out-Null
        $context = Get-AzContext
    }
    catch {
        Write-Host "  Using device authentication (browser will open)..." -ForegroundColor Cyan
        Connect-AzAccount -UseDeviceAuthentication -WarningAction SilentlyContinue | Out-Null
        $context = Get-AzContext
    }
    Write-Host "  Logged in as: $($context.Account.Id)" -ForegroundColor Green
}
catch {
    Write-Host "  ERROR: Could not authenticate. Error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# --- Step 4: Pick subscription ---
Write-Host "[4/7] Finding subscriptions..." -ForegroundColor Yellow
$subs = @(Get-AzSubscription -WarningAction SilentlyContinue | Where-Object { $_.State -eq "Enabled" })

if ($subs.Count -eq 0) {
    Write-Host "  ERROR: No enabled subscriptions found!" -ForegroundColor Red
    exit 1
}

$selectedSub = $null
if ($subs.Count -eq 1) {
    $selectedSub = $subs[0]
    Write-Host "  Using subscription: $($selectedSub.Name)" -ForegroundColor Green
}
else {
    Write-Host "  Found $($subs.Count) subscriptions:" -ForegroundColor Cyan
    for ($i = 0; $i -lt $subs.Count; $i++) {
        Write-Host "    [$($i+1)] $($subs[$i].Name) ($($subs[$i].Id))" -ForegroundColor White
    }
    Write-Host "    [A] All subscriptions" -ForegroundColor White
    $choice = Read-Host "  Select (number or A)"
    if ($choice -eq 'A' -or $choice -eq 'a') {
        $selectedSub = $subs  # All
        Write-Host "  Will scan ALL subscriptions" -ForegroundColor Green
    }
    else {
        $idx = [int]$choice - 1
        $selectedSub = $subs[$idx]
        Write-Host "  Selected: $($selectedSub.Name)" -ForegroundColor Green
    }
}

# --- Step 5: Create Service Principal ---
Write-Host "[5/7] Creating Service Principal for automation..." -ForegroundColor Yellow

$sp = $null
$spSecret = $null
$tenantId = (Get-AzContext).Tenant.Id

try {
    # Check if SP already exists
    $existingSp = Get-AzADServicePrincipal -DisplayName $ServicePrincipalName -ErrorAction SilentlyContinue
    
    if ($existingSp) {
        Write-Host "  Service Principal '$ServicePrincipalName' already exists." -ForegroundColor Cyan
        $resetCreds = Read-Host "  Reset its credentials? (y/n)"
        if ($resetCreds -eq 'y') {
            $newCred = New-AzADSpCredential -ObjectId $existingSp.Id
            $sp = $existingSp
            $spSecret = $newCred.SecretText
            $spClientId = $existingSp.AppId
        }
        else {
            Write-Host "  Enter the existing Client Secret:" -ForegroundColor Cyan
            $spSecret = Read-Host "  Client Secret"
            $spClientId = $existingSp.AppId
        }
    }
    else {
        # Create new SP with Reader role on selected subscription(s)
        if ($selectedSub -is [array]) {
            # Multiple subscriptions - assign to first, then add others
            $sp = New-AzADServicePrincipal -DisplayName $ServicePrincipalName -ErrorAction Stop
            $spSecret = $sp.PasswordCredentials.SecretText
            $spClientId = $sp.AppId
            
            Start-Sleep -Seconds 15  # Wait for AD propagation
            
            foreach ($sub in $selectedSub) {
                New-AzRoleAssignment -ApplicationId $spClientId `
                    -RoleDefinitionName "Reader" `
                    -Scope "/subscriptions/$($sub.Id)" `
                    -ErrorAction SilentlyContinue | Out-Null
                
                # Also need Monitoring Reader for metrics
                New-AzRoleAssignment -ApplicationId $spClientId `
                    -RoleDefinitionName "Monitoring Reader" `
                    -Scope "/subscriptions/$($sub.Id)" `
                    -ErrorAction SilentlyContinue | Out-Null
                    
                Write-Host "    Assigned Reader + Monitoring Reader on: $($sub.Name)" -ForegroundColor Gray
            }
        }
        else {
            $scope = "/subscriptions/$($selectedSub.Id)"
            $sp = New-AzADServicePrincipal -DisplayName $ServicePrincipalName -Role "Reader" -Scope $scope -ErrorAction Stop
            $spSecret = $sp.PasswordCredentials.SecretText
            $spClientId = $sp.AppId
            
            Start-Sleep -Seconds 10
            
            # Add Monitoring Reader for metrics access
            New-AzRoleAssignment -ApplicationId $spClientId `
                -RoleDefinitionName "Monitoring Reader" `
                -Scope $scope `
                -ErrorAction SilentlyContinue | Out-Null
        }
        
        Write-Host "  Service Principal created: $ServicePrincipalName" -ForegroundColor Green
        Write-Host "  Client ID: $spClientId" -ForegroundColor Gray
    }
}
catch {
    Write-Host "  ERROR creating Service Principal: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host "  MANUAL ALTERNATIVE: Run this in Azure CLI:" -ForegroundColor Yellow
    Write-Host "    az ad sp create-for-rbac --name `"$ServicePrincipalName`" --role Reader --scopes /subscriptions/$($selectedSub.Id)" -ForegroundColor White
    Write-Host ""
    Write-Host "  Then re-run this setup with:" -ForegroundColor Yellow
    Write-Host "    .\Setup-AzureSQLAudit.ps1" -ForegroundColor White
    exit 1
}

# --- Step 6: Save credentials ---
Write-Host "[6/7] Saving encrypted credentials..." -ForegroundColor Yellow

$credentialPath = Join-Path $env:USERPROFILE ".azure_sql_audit_creds.xml"

$credsToSave = @{
    TenantId     = $tenantId
    ClientId     = $spClientId
    ClientSecret = $spSecret | ConvertTo-SecureString -AsPlainText -Force | ConvertFrom-SecureString
}
$credsToSave | Export-Clixml -Path $credentialPath -Force

Write-Host "  Credentials encrypted and saved to: $credentialPath" -ForegroundColor Green
Write-Host "  (Only YOUR user account on THIS machine can decrypt them)" -ForegroundColor Gray

# --- Step 7: Create Scheduled Task ---
Write-Host "[7/7] Creating scheduled task..." -ForegroundColor Yellow

try {
    $action = New-ScheduledTaskAction `
        -Execute "powershell.exe" `
        -Argument "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$AuditScriptPath`" -ExportPath `"$ReportFolder`""

    $trigger = switch ($Frequency) {
        "Daily"  { New-ScheduledTaskTrigger -Daily -At $ScheduleTime }
        "Weekly" { New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday -At $ScheduleTime }
    }

    $settings = New-ScheduledTaskSettingsSet `
        -AllowStartIfOnBatteries `
        -DontStopIfGoingOnBatteries `
        -StartWhenAvailable `
        -RunOnlyIfNetworkAvailable

    $taskName = "AzureSQLDatabaseAudit"

    Register-ScheduledTask `
        -TaskName $taskName `
        -Action $action `
        -Trigger $trigger `
        -Settings $settings `
        -Description "Automated Azure SQL Database audit - runs $Frequency at $ScheduleTime" `
        -RunLevel Highest `
        -Force | Out-Null

    Write-Host "  Scheduled task created: $taskName" -ForegroundColor Green
    Write-Host "  Runs: $Frequency at $ScheduleTime" -ForegroundColor Gray
}
catch {
    Write-Host "  WARNING: Could not create scheduled task (need Admin?): $($_.Exception.Message)" -ForegroundColor Yellow
    Write-Host "  You can create it manually later with:" -ForegroundColor Yellow
    Write-Host "    .\AzureSQLDatabaseAudit.ps1 -CreateScheduledTask -ScheduleFrequency $Frequency" -ForegroundColor White
}

# --- Done ---
Write-Host ""
Write-Host "========================================================" -ForegroundColor Green
Write-Host "  SETUP COMPLETE!" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  What happens now:" -ForegroundColor Cyan
Write-Host "    - Audit runs automatically $Frequency at $ScheduleTime" -ForegroundColor White
Write-Host "    - Reports saved to: $ReportFolder" -ForegroundColor White
Write-Host "    - CSV + HTML + LOG files generated each run" -ForegroundColor White
Write-Host "    - No passwords, no prompts, no manual work" -ForegroundColor White
Write-Host ""
Write-Host "  To test it right now:" -ForegroundColor Cyan
Write-Host "    .\AzureSQLDatabaseAudit.ps1 -ExportPath `"$ReportFolder`"" -ForegroundColor White
Write-Host ""
Write-Host "  To add email reports later:" -ForegroundColor Cyan
Write-Host "    .\AzureSQLDatabaseAudit.ps1 -EmailReport -EmailFrom you@company.com -EmailTo tony@company.com" -ForegroundColor White
Write-Host ""
