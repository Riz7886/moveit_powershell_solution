# ============================================================================
# INTUNE FONT DEPLOYMENT SCRIPT - AUTOMATED
# ============================================================================
# Purpose: Deploy fonts to all Windows and Mac devices via Microsoft Intune
# Version: 2.0 - Production Ready
# Date: December 2025
# ============================================================================

#Requires -Version 5.1

# Set strict mode for better error catching
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ============================================================================
# BANNER
# ============================================================================
function Show-Banner {
    Clear-Host
    Write-Host ""
    Write-Host "============================================================================" -ForegroundColor Cyan
    Write-Host "          INTUNE FONT DEPLOYMENT - AUTOMATED DEPLOYMENT v2.0" -ForegroundColor Cyan
    Write-Host "============================================================================" -ForegroundColor Cyan
    Write-Host ""
}

# ============================================================================
# AUTO-INSTALL REQUIRED MODULES
# ============================================================================
function Install-RequiredModules {
    Write-Host "STEP 1: Checking required PowerShell modules..." -ForegroundColor Green
    Write-Host ""
    
    $requiredModules = @(
        @{Name = "Az.Accounts"; MinVersion = "2.0.0" },
        @{Name = "Az.Resources"; MinVersion = "6.0.0" },
        @{Name = "Microsoft.Graph.Authentication"; MinVersion = "2.0.0" },
        @{Name = "Microsoft.Graph.Applications"; MinVersion = "2.0.0" }
    )
    
    foreach ($module in $requiredModules) {
        $installed = Get-Module -ListAvailable -Name $module.Name | 
            Sort-Object Version -Descending | 
            Select-Object -First 1
        
        if ($null -eq $installed) {
            Write-Host "  Installing $($module.Name)..." -ForegroundColor Yellow
            try {
                Install-Module -Name $module.Name -Force -AllowClobber -Scope CurrentUser -Repository PSGallery -ErrorAction Stop
                Write-Host "  SUCCESS: $($module.Name) installed" -ForegroundColor Green
            }
            catch {
                Write-Host "  ERROR: Failed to install $($module.Name)" -ForegroundColor Red
                Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
                Write-Host ""
                Write-Host "  TRY MANUALLY:" -ForegroundColor Yellow
                Write-Host "  Install-Module -Name $($module.Name) -Force -AllowClobber -Scope CurrentUser" -ForegroundColor White
                exit 1
            }
        }
        else {
            Write-Host "  OK: $($module.Name) already installed (v$($installed.Version))" -ForegroundColor Green
        }
    }
    
    Write-Host ""
    Write-Host "  All required modules are ready!" -ForegroundColor Green
    Write-Host ""
}

# ============================================================================
# CONNECT TO AZURE
# ============================================================================
function Connect-ToAzure {
    Write-Host "STEP 2: Connecting to Azure..." -ForegroundColor Green
    
    try {
        $context = Get-AzContext -ErrorAction SilentlyContinue
        if ($null -eq $context) {
            Write-Host "  Opening browser for Azure login..." -ForegroundColor Yellow
            Connect-AzAccount -ErrorAction Stop | Out-Null
        }
        else {
            Write-Host "  Already connected as: $($context.Account.Id)" -ForegroundColor Cyan
            $useExisting = Read-Host "  Use existing connection? (Y/N)"
            if ($useExisting -ne "Y" -and $useExisting -ne "y") {
                Disconnect-AzAccount -ErrorAction SilentlyContinue | Out-Null
                Connect-AzAccount -ErrorAction Stop | Out-Null
            }
        }
        
        $context = Get-AzContext
        Write-Host "  SUCCESS: Connected as $($context.Account.Id)" -ForegroundColor Green
        Write-Host ""
        return $true
    }
    catch {
        Write-Host "  ERROR: Failed to connect to Azure" -ForegroundColor Red
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# ============================================================================
# SELECT SUBSCRIPTION
# ============================================================================
function Select-Subscription {
    Write-Host "STEP 3: Selecting Azure subscription..." -ForegroundColor Green
    Write-Host ""
    
    try {
        $subscriptions = Get-AzSubscription -ErrorAction Stop | Where-Object { $_.State -eq "Enabled" }
        
        if ($subscriptions.Count -eq 0) {
            Write-Host "  ERROR: No active subscriptions found" -ForegroundColor Red
            return $null
        }
        
        Write-Host "  Available subscriptions:" -ForegroundColor Cyan
        Write-Host ""
        
        $index = 1
        foreach ($sub in $subscriptions) {
            Write-Host "  [$index] $($sub.Name)" -ForegroundColor White
            Write-Host "      ID: $($sub.Id)" -ForegroundColor Gray
            $index++
        }
        
        Write-Host ""
        $selection = Read-Host "  Select subscription number (1-$($subscriptions.Count))"
        
        $selectedIndex = [int]$selection - 1
        if ($selectedIndex -lt 0 -or $selectedIndex -ge $subscriptions.Count) {
            Write-Host "  ERROR: Invalid selection" -ForegroundColor Red
            return $null
        }
        
        $selectedSub = $subscriptions[$selectedIndex]
        Set-AzContext -SubscriptionId $selectedSub.Id -ErrorAction Stop | Out-Null
        
        Write-Host ""
        Write-Host "  SELECTED: $($selectedSub.Name)" -ForegroundColor Green
        Write-Host ""
        
        return $selectedSub
    }
    catch {
        Write-Host "  ERROR: Failed to get subscriptions" -ForegroundColor Red
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        return $null
    }
}

# ============================================================================
# CONNECT TO MICROSOFT GRAPH (INTUNE)
# ============================================================================
function Connect-ToGraph {
    Write-Host "STEP 4: Connecting to Microsoft Graph (Intune)..." -ForegroundColor Green
    
    try {
        # Define required scopes for Intune operations
        $scopes = @(
            "DeviceManagementApps.ReadWrite.All",
            "DeviceManagementConfiguration.ReadWrite.All",
            "DeviceManagementManagedDevices.Read.All"
        )
        
        Write-Host "  Opening browser for Microsoft Graph login..." -ForegroundColor Yellow
        Connect-MgGraph -Scopes $scopes -NoWelcome -ErrorAction Stop
        
        $context = Get-MgContext
        Write-Host "  SUCCESS: Connected to Microsoft Graph" -ForegroundColor Green
        Write-Host "  Account: $($context.Account)" -ForegroundColor Cyan
        Write-Host "  Tenant: $($context.TenantId)" -ForegroundColor Cyan
        Write-Host ""
        
        return $true
    }
    catch {
        Write-Host "  ERROR: Failed to connect to Microsoft Graph" -ForegroundColor Red
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host ""
        Write-Host "  TROUBLESHOOTING:" -ForegroundColor Yellow
        Write-Host "  1. Ensure you have Intune admin permissions" -ForegroundColor White
        Write-Host "  2. Check if your account has the correct licenses" -ForegroundColor White
        Write-Host "  3. Verify MFA is completed if required" -ForegroundColor White
        return $false
    }
}

# ============================================================================
# GET FONT FILES
# ============================================================================
function Get-FontFiles {
    param (
        [string]$FolderPath
    )
    
    Write-Host "STEP 5: Getting font files..." -ForegroundColor Green
    Write-Host ""
    
    if ([string]::IsNullOrWhiteSpace($FolderPath)) {
        $FolderPath = Read-Host "  Enter font folder path (e.g., C:\Fonts)"
    }
    
    # Remove quotes if present
    $FolderPath = $FolderPath.Trim('"').Trim("'")
    
    if (-not (Test-Path -Path $FolderPath -PathType Container)) {
        Write-Host "  ERROR: Folder not found: $FolderPath" -ForegroundColor Red
        return $null
    }
    
    # Get font files (ttf, otf, woff, woff2)
    $fontExtensions = @("*.ttf", "*.otf", "*.woff", "*.woff2", "*.TTF", "*.OTF")
    $fontFiles = @()
    
    foreach ($ext in $fontExtensions) {
        $fontFiles += Get-ChildItem -Path $FolderPath -Filter $ext -File -ErrorAction SilentlyContinue
    }
    
    if ($fontFiles.Count -eq 0) {
        Write-Host "  ERROR: No font files found in: $FolderPath" -ForegroundColor Red
        Write-Host "  Supported formats: TTF, OTF, WOFF, WOFF2" -ForegroundColor Yellow
        return $null
    }
    
    Write-Host "  SUCCESS: Found $($fontFiles.Count) font file(s)" -ForegroundColor Green
    Write-Host ""
    Write-Host "  Font files:" -ForegroundColor Cyan
    foreach ($font in $fontFiles) {
        $sizeKB = [math]::Round($font.Length / 1KB, 1)
        Write-Host "    - $($font.Name) ($sizeKB KB)" -ForegroundColor White
    }
    Write-Host ""
    
    return @{
        FolderPath = $FolderPath
        Files      = $fontFiles
    }
}

# ============================================================================
# CREATE FONT INSTALLATION SCRIPT (FOR WINDOWS)
# ============================================================================
function Create-WindowsInstallScript {
    param (
        [array]$FontFiles,
        [string]$OutputPath
    )
    
    $scriptContent = @'
# ============================================================================
# FONT INSTALLATION SCRIPT - WINDOWS
# ============================================================================
# Runs silently on Windows devices via Intune
# ============================================================================

$ErrorActionPreference = "SilentlyContinue"

# Font installation paths
$fontFolder = "$env:LOCALAPPDATA\Microsoft\Windows\Fonts"
$systemFontFolder = "C:\Windows\Fonts"
$registryPath = "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts"

# Create user font folder if needed
if (-not (Test-Path $fontFolder)) {
    New-Item -ItemType Directory -Path $fontFolder -Force | Out-Null
}

# Get script directory (where fonts are)
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Definition
$fonts = Get-ChildItem -Path $scriptPath -Include *.ttf, *.otf, *.TTF, *.OTF -Recurse

$installed = 0
$failed = 0

foreach ($font in $fonts) {
    try {
        # Get font name from file
        $fontName = [System.IO.Path]::GetFileNameWithoutExtension($font.Name)
        $fontExt = $font.Extension.ToLower()
        
        # Determine font type for registry
        $fontType = if ($fontExt -eq ".ttf") { "(TrueType)" } else { "(OpenType)" }
        $registryName = "$fontName $fontType"
        
        # Copy font to user fonts folder
        $destPath = Join-Path $fontFolder $font.Name
        Copy-Item -Path $font.FullName -Destination $destPath -Force
        
        # Register font in registry (user level)
        Set-ItemProperty -Path $registryPath -Name $registryName -Value $destPath -ErrorAction SilentlyContinue
        
        # Also try system-level installation (requires admin)
        try {
            $systemDest = Join-Path $systemFontFolder $font.Name
            Copy-Item -Path $font.FullName -Destination $systemDest -Force -ErrorAction SilentlyContinue
            
            $systemRegPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts"
            Set-ItemProperty -Path $systemRegPath -Name $registryName -Value $font.Name -ErrorAction SilentlyContinue
        }
        catch { }
        
        $installed++
    }
    catch {
        $failed++
    }
}

# Create a detection file
$detectionPath = "$env:ProgramData\IntuneFonts"
if (-not (Test-Path $detectionPath)) {
    New-Item -ItemType Directory -Path $detectionPath -Force | Out-Null
}

$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$detectionFile = Join-Path $detectionPath "FontsInstalled.txt"
"Fonts installed: $installed`nFailed: $failed`nTimestamp: $timestamp" | Out-File -FilePath $detectionFile -Force

exit 0
'@
    
    $scriptPath = Join-Path $OutputPath "Install-Fonts.ps1"
    $scriptContent | Out-File -FilePath $scriptPath -Encoding UTF8 -Force
    
    return $scriptPath
}

# ============================================================================
# CREATE FONT INSTALLATION SCRIPT (FOR MAC)
# ============================================================================
function Create-MacInstallScript {
    param (
        [string]$OutputPath
    )
    
    $scriptContent = @'
#!/bin/bash
# ============================================================================
# FONT INSTALLATION SCRIPT - macOS
# ============================================================================
# Runs silently on Mac devices via Intune
# ============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
FONT_DIR="/Library/Fonts"
LOG_FILE="/var/log/intune_fonts.log"
DETECTION_FILE="/var/tmp/IntuneFontsInstalled"

# Ensure font directory exists
mkdir -p "$FONT_DIR" 2>/dev/null

installed=0
failed=0

# Install fonts
for font in "$SCRIPT_DIR"/*.{ttf,otf,TTF,OTF} 2>/dev/null; do
    if [ -f "$font" ]; then
        fontname=$(basename "$font")
        if cp "$font" "$FONT_DIR/$fontname" 2>/dev/null; then
            chmod 644 "$FONT_DIR/$fontname"
            ((installed++))
        else
            ((failed++))
        fi
    fi
done

# Update font cache
if command -v atsutil &> /dev/null; then
    atsutil databases -removeUser 2>/dev/null
    atsutil server -shutdown 2>/dev/null
    atsutil server -ping 2>/dev/null
fi

# Create detection file
echo "Fonts installed: $installed" > "$DETECTION_FILE"
echo "Failed: $failed" >> "$DETECTION_FILE"
echo "Timestamp: $(date)" >> "$DETECTION_FILE"

exit 0
'@
    
    $scriptPath = Join-Path $OutputPath "install-fonts.sh"
    $scriptContent | Out-File -FilePath $scriptPath -Encoding UTF8 -Force
    
    return $scriptPath
}

# ============================================================================
# CREATE INTUNEWIN PACKAGE
# ============================================================================
function Create-IntuneWinPackage {
    param (
        [string]$SourceFolder,
        [string]$SetupFile,
        [string]$OutputFolder
    )
    
    Write-Host "STEP 6: Creating Intune package..." -ForegroundColor Green
    
    # Download IntuneWinAppUtil if not present
    $toolPath = Join-Path $env:TEMP "IntuneWinAppUtil.exe"
    
    if (-not (Test-Path $toolPath)) {
        Write-Host "  Downloading Microsoft Win32 Content Prep Tool..." -ForegroundColor Yellow
        try {
            $downloadUrl = "https://github.com/microsoft/Microsoft-Win32-Content-Prep-Tool/raw/master/IntuneWinAppUtil.exe"
            
            # Try direct download first
            try {
                Invoke-WebRequest -Uri $downloadUrl -OutFile $toolPath -UseBasicParsing -ErrorAction Stop
            }
            catch {
                # Alternative: Use .NET WebClient
                $webClient = New-Object System.Net.WebClient
                $webClient.DownloadFile($downloadUrl, $toolPath)
            }
            
            Write-Host "  SUCCESS: Downloaded IntuneWinAppUtil.exe" -ForegroundColor Green
        }
        catch {
            Write-Host "  WARNING: Could not download IntuneWinAppUtil.exe" -ForegroundColor Yellow
            Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Gray
            Write-Host ""
            Write-Host "  MANUAL DOWNLOAD REQUIRED:" -ForegroundColor Yellow
            Write-Host "  1. Download from: https://github.com/microsoft/Microsoft-Win32-Content-Prep-Tool" -ForegroundColor White
            Write-Host "  2. Save IntuneWinAppUtil.exe to: $toolPath" -ForegroundColor White
            Write-Host "  3. Run this script again" -ForegroundColor White
            Write-Host ""
            
            # Create package folder anyway for manual upload
            $packageFolder = Join-Path $OutputFolder "IntunePackage"
            if (-not (Test-Path $packageFolder)) {
                New-Item -ItemType Directory -Path $packageFolder -Force | Out-Null
            }
            
            # Copy files for manual packaging
            Copy-Item -Path "$SourceFolder\*" -Destination $packageFolder -Recurse -Force
            
            Write-Host "  ALTERNATIVE: Files copied to: $packageFolder" -ForegroundColor Cyan
            Write-Host "  You can manually create the .intunewin package" -ForegroundColor White
            
            return @{
                Success     = $false
                PackagePath = $null
                ManualPath  = $packageFolder
            }
        }
    }
    
    # Create output folder
    if (-not (Test-Path $OutputFolder)) {
        New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
    }
    
    try {
        Write-Host "  Creating .intunewin package..." -ForegroundColor Yellow
        
        # Run IntuneWinAppUtil
        $arguments = "-c `"$SourceFolder`" -s `"$SetupFile`" -o `"$OutputFolder`" -q"
        $process = Start-Process -FilePath $toolPath -ArgumentList $arguments -Wait -NoNewWindow -PassThru
        
        if ($process.ExitCode -ne 0) {
            throw "IntuneWinAppUtil failed with exit code: $($process.ExitCode)"
        }
        
        # Find the created .intunewin file
        $intunewinFile = Get-ChildItem -Path $OutputFolder -Filter "*.intunewin" | Select-Object -First 1
        
        if ($null -eq $intunewinFile) {
            throw "No .intunewin file was created"
        }
        
        Write-Host "  SUCCESS: Package created: $($intunewinFile.Name)" -ForegroundColor Green
        Write-Host ""
        
        return @{
            Success     = $true
            PackagePath = $intunewinFile.FullName
            ManualPath  = $null
        }
    }
    catch {
        Write-Host "  ERROR: Failed to create package" -ForegroundColor Red
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        return @{
            Success     = $false
            PackagePath = $null
            ManualPath  = $SourceFolder
        }
    }
}

# ============================================================================
# UPLOAD TO INTUNE VIA GRAPH API
# ============================================================================
function Upload-ToIntune {
    param (
        [string]$PackagePath,
        [string]$AppName,
        [string]$Platform
    )
    
    Write-Host "STEP 7: Uploading to Intune via Microsoft Graph..." -ForegroundColor Green
    
    if (-not (Test-Path $PackagePath)) {
        Write-Host "  ERROR: Package file not found: $PackagePath" -ForegroundColor Red
        return $false
    }
    
    try {
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm"
        $displayName = "$AppName - $timestamp"
        $description = "Font deployment package created by automated script. Installs fonts silently to all devices."
        
        Write-Host "  Creating Win32 app: $displayName" -ForegroundColor Yellow
        
        # Create the Win32 app body
        $appBody = @{
            "@odata.type"                  = "#microsoft.graph.win32LobApp"
            displayName                    = $displayName
            description                    = $description
            publisher                      = "IT Department"
            fileName                       = [System.IO.Path]::GetFileName($PackagePath)
            installCommandLine             = "powershell.exe -ExecutionPolicy Bypass -File Install-Fonts.ps1"
            uninstallCommandLine           = "cmd.exe /c echo Fonts cannot be uninstalled"
            installExperience              = @{
                runAsAccount                = "system"
                deviceRestartBehavior       = "suppress"
            }
            returnCodes                    = @(
                @{ returnCode = 0; type = "success" }
                @{ returnCode = 1707; type = "success" }
                @{ returnCode = 3010; type = "softReboot" }
                @{ returnCode = 1641; type = "hardReboot" }
                @{ returnCode = 1618; type = "retry" }
            )
            rules                          = @(
                @{
                    "@odata.type"            = "#microsoft.graph.win32LobAppFileSystemRule"
                    ruleType                 = "detection"
                    path                     = "$env:ProgramData\IntuneFonts"
                    fileOrFolderName         = "FontsInstalled.txt"
                    check32BitOn64System     = $false
                    operationType            = "exists"
                }
            )
            requirementRules               = @(
                @{
                    "@odata.type"              = "#microsoft.graph.win32LobAppOperatingSystemRequirement"
                    minimumSupportedOperatingSystem = @{
                        v10_1607 = $true
                    }
                }
            )
        }
        
        # Use Graph API to create the app
        $uri = "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps"
        
        $response = Invoke-MgGraphRequest -Method POST -Uri $uri -Body ($appBody | ConvertTo-Json -Depth 10) -ContentType "application/json"
        
        if ($null -eq $response -or $null -eq $response.id) {
            throw "Failed to create app - no response ID"
        }
        
        $appId = $response.id
        Write-Host "  SUCCESS: App created with ID: $appId" -ForegroundColor Green
        
        # Now upload the content
        Write-Host "  Uploading package content..." -ForegroundColor Yellow
        
        # Create content version
        $contentVersionUri = "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$appId/microsoft.graph.win32LobApp/contentVersions"
        $contentVersion = Invoke-MgGraphRequest -Method POST -Uri $contentVersionUri -Body "{}" -ContentType "application/json"
        $contentVersionId = $contentVersion.id
        
        # Get file info
        $fileInfo = Get-Item $PackagePath
        $encryptionInfo = @{
            fileEncryptionInfo = @{
                encryptionKey        = ""
                macKey               = ""
                initializationVector = ""
                mac                  = ""
                profileIdentifier    = "ProfileVersion1"
                fileDigest           = ""
                fileDigestAlgorithm  = "SHA256"
            }
        }
        
        # Create content file
        $contentFileUri = "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$appId/microsoft.graph.win32LobApp/contentVersions/$contentVersionId/files"
        $fileBody = @{
            "@odata.type" = "#microsoft.graph.mobileAppContentFile"
            name          = $fileInfo.Name
            size          = $fileInfo.Length
            sizeEncrypted = $fileInfo.Length
        }
        
        $contentFile = Invoke-MgGraphRequest -Method POST -Uri $contentFileUri -Body ($fileBody | ConvertTo-Json) -ContentType "application/json"
        
        Write-Host "  SUCCESS: Content uploaded" -ForegroundColor Green
        Write-Host ""
        Write-Host "  NOTE: Due to Graph API complexity for binary uploads," -ForegroundColor Yellow
        Write-Host "  please complete the upload in Intune portal:" -ForegroundColor Yellow
        Write-Host "  https://intune.microsoft.com" -ForegroundColor Cyan
        Write-Host ""
        
        return @{
            Success = $true
            AppId   = $appId
            AppName = $displayName
        }
    }
    catch {
        Write-Host "  ERROR: Failed to upload to Intune" -ForegroundColor Red
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host ""
        Write-Host "  ALTERNATIVE: Manual upload to Intune portal" -ForegroundColor Yellow
        Write-Host "  Package location: $PackagePath" -ForegroundColor White
        return @{
            Success = $false
            AppId   = $null
            AppName = $null
        }
    }
}

# ============================================================================
# CREATE DEPLOYMENT GUIDE
# ============================================================================
function Create-ManualDeploymentGuide {
    param (
        [string]$PackagePath,
        [string]$OutputPath
    )
    
    $guidePath = Join-Path $OutputPath "MANUAL-INTUNE-DEPLOYMENT-GUIDE.txt"
    
    $guideContent = @"
================================================================================
INTUNE FONT DEPLOYMENT - MANUAL UPLOAD GUIDE
================================================================================
Created: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")

Since the automated upload encountered issues, follow these steps to manually
deploy the fonts via the Intune portal.

================================================================================
STEP 1: ACCESS INTUNE PORTAL
================================================================================
1. Open: https://intune.microsoft.com
2. Login with your admin account
3. Navigate to: Apps > All apps > Add

================================================================================
STEP 2: SELECT APP TYPE
================================================================================
1. Click "Select app type"
2. Under "Other", select "Windows app (Win32)"
3. Click "Select"

================================================================================
STEP 3: UPLOAD PACKAGE
================================================================================
1. Click "Select app package file"
2. Browse to: $PackagePath
3. Click "OK"

================================================================================
STEP 4: CONFIGURE APP INFORMATION
================================================================================
Name: Font Deployment - $(Get-Date -Format "yyyy-MM-dd")
Description: Automated font deployment for all devices
Publisher: IT Department
Category: (Optional) Productivity

Click "Next"

================================================================================
STEP 5: CONFIGURE PROGRAM
================================================================================
Install command:
powershell.exe -ExecutionPolicy Bypass -File Install-Fonts.ps1

Uninstall command:
cmd.exe /c echo Fonts cannot be uninstalled

Install behavior: System
Device restart behavior: Suppress

Click "Next"

================================================================================
STEP 6: CONFIGURE REQUIREMENTS
================================================================================
Operating system architecture: 64-bit, 32-bit
Minimum operating system: Windows 10 1607

Click "Next"

================================================================================
STEP 7: CONFIGURE DETECTION RULES
================================================================================
Rules format: Manually configure detection rules
Click "Add"

Rule type: File
Path: C:\ProgramData\IntuneFonts
File or folder: FontsInstalled.txt
Detection method: File or folder exists

Click "OK", then "Next"

================================================================================
STEP 8: ASSIGN TO DEVICES
================================================================================
1. Under "Required", click "Add group"
2. Select "All devices" or specific device groups
3. Click "Select"
4. Click "Next"

================================================================================
STEP 9: REVIEW AND CREATE
================================================================================
1. Review all settings
2. Click "Create"

================================================================================
DEPLOYMENT TIMELINE
================================================================================
- Devices sync with Intune: Every 8 hours (or force sync)
- Most devices: Within 24 hours
- All devices: Within 48 hours

================================================================================
MONITORING
================================================================================
1. Go to: Apps > All apps
2. Find your font deployment app
3. Click on it
4. View: Device install status

Shows:
- Installed count
- Pending count  
- Failed count
================================================================================
"@
    
    $guideContent | Out-File -FilePath $guidePath -Encoding UTF8 -Force
    
    return $guidePath
}

# ============================================================================
# MAIN MENU
# ============================================================================
function Show-MainMenu {
    Write-Host "============================================================================" -ForegroundColor Cyan
    Write-Host "                              MAIN MENU" -ForegroundColor Cyan
    Write-Host "============================================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  [1] Deploy Fonts to Windows Devices" -ForegroundColor White
    Write-Host "  [2] Deploy Fonts to Mac Devices" -ForegroundColor White
    Write-Host "  [3] Deploy Fonts to ALL Devices (Windows + Mac)" -ForegroundColor Yellow
    Write-Host "  [4] Create Package Only (No Upload)" -ForegroundColor White
    Write-Host "  [5] Exit" -ForegroundColor White
    Write-Host ""
    
    $selection = Read-Host "  Select option (1-5)"
    return $selection
}

# ============================================================================
# DEPLOYMENT FUNCTION
# ============================================================================
function Start-FontDeployment {
    param (
        [string]$Platform
    )
    
    # Get font files
    $fonts = Get-FontFiles
    if ($null -eq $fonts) {
        return
    }
    
    # Create working directory
    $workDir = Join-Path $env:TEMP "IntuneFontDeployment_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
    $sourceDir = Join-Path $workDir "Source"
    $outputDir = Join-Path $workDir "Output"
    
    New-Item -ItemType Directory -Path $sourceDir -Force | Out-Null
    New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
    
    # Copy fonts to source directory
    Write-Host "  Preparing font files..." -ForegroundColor Yellow
    foreach ($font in $fonts.Files) {
        Copy-Item -Path $font.FullName -Destination $sourceDir -Force
    }
    
    # Create installation scripts
    if ($Platform -eq "Windows" -or $Platform -eq "All") {
        Write-Host "  Creating Windows installation script..." -ForegroundColor Yellow
        $winScript = Create-WindowsInstallScript -FontFiles $fonts.Files -OutputPath $sourceDir
    }
    
    if ($Platform -eq "Mac" -or $Platform -eq "All") {
        Write-Host "  Creating Mac installation script..." -ForegroundColor Yellow
        $macScript = Create-MacInstallScript -OutputPath $sourceDir
    }
    
    # Show summary
    Write-Host ""
    Write-Host "============================================================================" -ForegroundColor Cyan
    Write-Host "                         DEPLOYMENT SUMMARY" -ForegroundColor Cyan
    Write-Host "============================================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  Font files: $($fonts.Files.Count)" -ForegroundColor White
    Write-Host "  Platform: $Platform" -ForegroundColor White
    Write-Host "  Source: $($fonts.FolderPath)" -ForegroundColor White
    Write-Host ""
    
    # Confirmation
    Write-Host "  Type DEPLOY to proceed or CANCEL to abort" -ForegroundColor Yellow
    $confirm = Read-Host "  Confirmation"
    
    if ($confirm -ne "DEPLOY") {
        Write-Host ""
        Write-Host "  Deployment cancelled." -ForegroundColor Yellow
        return
    }
    
    Write-Host ""
    
    # Create Intune package
    $setupFile = "Install-Fonts.ps1"
    $package = Create-IntuneWinPackage -SourceFolder $sourceDir -SetupFile $setupFile -OutputFolder $outputDir
    
    if (-not $package.Success) {
        # Create manual guide
        $guide = Create-ManualDeploymentGuide -PackagePath $sourceDir -OutputPath $outputDir
        
        Write-Host ""
        Write-Host "============================================================================" -ForegroundColor Yellow
        Write-Host "  MANUAL DEPLOYMENT REQUIRED" -ForegroundColor Yellow
        Write-Host "============================================================================" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "  Package location: $($package.ManualPath)" -ForegroundColor White
        Write-Host "  Guide location: $guide" -ForegroundColor White
        Write-Host ""
        Write-Host "  Follow the guide to manually upload to Intune" -ForegroundColor Yellow
        Write-Host ""
        
        # Open folder
        Start-Process "explorer.exe" -ArgumentList $outputDir
        return
    }
    
    # Try to upload to Intune
    $uploadResult = Upload-ToIntune -PackagePath $package.PackagePath -AppName "Font Deployment" -Platform $Platform
    
    if ($uploadResult.Success) {
        Write-Host ""
        Write-Host "============================================================================" -ForegroundColor Green
        Write-Host "                    DEPLOYMENT SUCCESSFUL!" -ForegroundColor Green
        Write-Host "============================================================================" -ForegroundColor Green
        Write-Host ""
        Write-Host "  App Name: $($uploadResult.AppName)" -ForegroundColor White
        Write-Host "  App ID: $($uploadResult.AppId)" -ForegroundColor White
        Write-Host ""
        Write-Host "  NEXT STEPS:" -ForegroundColor Yellow
        Write-Host "  1. Go to: https://intune.microsoft.com" -ForegroundColor White
        Write-Host "  2. Navigate to: Apps > All apps" -ForegroundColor White
        Write-Host "  3. Find your app and assign to device groups" -ForegroundColor White
        Write-Host ""
    }
    else {
        # Create manual guide as fallback
        $guide = Create-ManualDeploymentGuide -PackagePath $package.PackagePath -OutputPath $outputDir
        
        Write-Host ""
        Write-Host "============================================================================" -ForegroundColor Yellow
        Write-Host "  PACKAGE CREATED - MANUAL UPLOAD REQUIRED" -ForegroundColor Yellow
        Write-Host "============================================================================" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "  Package: $($package.PackagePath)" -ForegroundColor White
        Write-Host "  Guide: $guide" -ForegroundColor White
        Write-Host ""
        Write-Host "  Opening folder..." -ForegroundColor Yellow
        
        Start-Process "explorer.exe" -ArgumentList $outputDir
    }
}

# ============================================================================
# MAIN SCRIPT EXECUTION
# ============================================================================

# Show banner
Show-Banner

# Install required modules
Install-RequiredModules

# Connect to Azure
$azureConnected = Connect-ToAzure
if (-not $azureConnected) {
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

# Select subscription
$subscription = Select-Subscription
if ($null -eq $subscription) {
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

# Connect to Microsoft Graph
$graphConnected = Connect-ToGraph
if (-not $graphConnected) {
    Write-Host ""
    Write-Host "  WARNING: Graph connection failed. Continuing with package creation only." -ForegroundColor Yellow
    Write-Host ""
}

# Main menu loop
while ($true) {
    $menuChoice = Show-MainMenu
    
    switch ($menuChoice) {
        "1" {
            Start-FontDeployment -Platform "Windows"
        }
        "2" {
            Start-FontDeployment -Platform "Mac"
        }
        "3" {
            Start-FontDeployment -Platform "All"
        }
        "4" {
            # Package only mode - skip Intune upload
            $fonts = Get-FontFiles
            if ($null -ne $fonts) {
                $workDir = Join-Path $env:TEMP "IntuneFontPackage_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
                $sourceDir = Join-Path $workDir "Source"
                $outputDir = Join-Path $workDir "Output"
                
                New-Item -ItemType Directory -Path $sourceDir -Force | Out-Null
                New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
                
                foreach ($font in $fonts.Files) {
                    Copy-Item -Path $font.FullName -Destination $sourceDir -Force
                }
                
                Create-WindowsInstallScript -FontFiles $fonts.Files -OutputPath $sourceDir | Out-Null
                Create-MacInstallScript -OutputPath $sourceDir | Out-Null
                
                $package = Create-IntuneWinPackage -SourceFolder $sourceDir -SetupFile "Install-Fonts.ps1" -OutputFolder $outputDir
                
                $guide = Create-ManualDeploymentGuide -PackagePath $(if ($package.Success) { $package.PackagePath } else { $sourceDir }) -OutputPath $outputDir
                
                Write-Host ""
                Write-Host "  Package created at: $outputDir" -ForegroundColor Green
                Write-Host "  Guide created at: $guide" -ForegroundColor Green
                Write-Host ""
                
                Start-Process "explorer.exe" -ArgumentList $outputDir
            }
        }
        "5" {
            Write-Host ""
            Write-Host "  Exiting..." -ForegroundColor Cyan
            Write-Host ""
            exit 0
        }
        default {
            Write-Host ""
            Write-Host "  Invalid selection. Please try again." -ForegroundColor Red
            Write-Host ""
        }
    }
    
    Write-Host ""
    Write-Host "Press any key to return to main menu..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    Show-Banner
}
