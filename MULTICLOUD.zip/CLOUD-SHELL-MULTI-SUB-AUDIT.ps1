# CLOUD SHELL VERSION - NO LOGIN NEEDED
# Use this in Azure Portal Cloud Shell

Clear-Host
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  MULTI-SUBSCRIPTION AUDIT (Cloud Shell)" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Get ALL subscriptions (already logged in via Cloud Shell)
Write-Host "Loading all subscriptions..." -ForegroundColor Yellow
$allSubs = Get-AzSubscription
Write-Host "Found: $($allSubs.Count) subscriptions" -ForegroundColor Green
Write-Host ""

# Show menu
Write-Host "SELECT SUBSCRIPTION TO AUDIT:" -ForegroundColor Cyan
Write-Host ""

for ($i = 0; $i -lt $allSubs.Count; $i++) {
    $sub = $allSubs[$i]
    $state = $sub.State
    $color = if ($state -eq "Enabled") {"Green"} else {"Yellow"}
    
    Write-Host "  [$($i+1)] $($sub.Name) ($state)" -ForegroundColor $color
}

Write-Host ""
Write-Host "  [A] Audit ALL subscriptions" -ForegroundColor White
Write-Host ""

$choice = Read-Host "Select number or A for all"

$subsToAudit = @()

if ($choice -eq "A" -or $choice -eq "a") {
    $subsToAudit = $allSubs
    Write-Host ""
    Write-Host "Auditing ALL $($allSubs.Count) subscriptions..." -ForegroundColor Yellow
} else {
    $index = [int]$choice - 1
    if ($index -ge 0 -and $index -lt $allSubs.Count) {
        $subsToAudit = @($allSubs[$index])
        Write-Host ""
        Write-Host "Auditing: $($subsToAudit[0].Name)" -ForegroundColor Yellow
    } else {
        Write-Host "Invalid selection" -ForegroundColor Red
        exit
    }
}

Write-Host ""

# Audit
$allIssues = @()

foreach ($sub in $subsToAudit) {
    Write-Host "Subscription: $($sub.Name)" -ForegroundColor Cyan
    
    Set-AzContext -Subscription $sub.Id | Out-Null
    
    $rgs = Get-AzResourceGroup
    Write-Host "  Resource Groups: $($rgs.Count)" -ForegroundColor Green
    
    foreach ($rg in $rgs) {
        Write-Host "    Checking: $($rg.ResourceGroupName)" -ForegroundColor Gray
        
        $res = Get-AzResource -ResourceGroupName $rg.ResourceGroupName -ErrorAction SilentlyContinue
        $dbWS = $res | Where-Object {$_.ResourceType -eq "Microsoft.Databricks/workspaces"}
        
        $env = "Unknown"
        if ($rg.ResourceGroupName -match "prod" -and $rg.ResourceGroupName -notmatch "preprod") { $env = "Production" }
        elseif ($rg.ResourceGroupName -match "preprod") { $env = "PreProd" }
        elseif ($rg.ResourceGroupName -match "poc") { $env = "POC" }
        
        $problems = @()
        
        if ($env -eq "POC") {
            foreach ($r in $res) {
                if ($r.Name -match "prod" -and $r.Name -notmatch "preprod") {
                    $problems += "POC contains: $($r.Name)"
                }
            }
        }
        
        if ($env -eq "PreProd") {
            foreach ($r in $res) {
                if ($r.Name -match "-prod$") {
                    $problems += "PreProd contains: $($r.Name)"
                }
            }
        }
        
        if ($problems.Count -gt 0) {
            $allIssues += [PSCustomObject]@{
                Subscription = $sub.Name
                ResourceGroup = $rg.ResourceGroupName
                Environment = $env
                Location = $rg.Location
                Count = $res.Count
                Databricks = if ($dbWS) {($dbWS.Name -join ", ")} else {"-"}
                Issues = ($problems -join " | ")
            }
        }
    }
    
    Write-Host ""
}

# Results
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  RESULTS" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Subscriptions Scanned: $($subsToAudit.Count)" -ForegroundColor White
Write-Host "Issues Found: $($allIssues.Count)" -ForegroundColor $(if ($allIssues.Count -gt 0) {"Red"} else {"Green"})
Write-Host ""

if ($allIssues.Count -gt 0) {
    Write-Host "NAMING ISSUES FOUND:" -ForegroundColor Yellow
    Write-Host ""
    $allIssues | Format-Table Subscription, ResourceGroup, Environment, Issues -AutoSize
} else {
    Write-Host "No naming issues found!" -ForegroundColor Green
}

Write-Host ""
Write-Host "Done!" -ForegroundColor Green
