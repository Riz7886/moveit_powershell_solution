# AZURE MULTI-SUBSCRIPTION NAMING AUDIT
# Shows ALL subscriptions and lets you choose which to audit

Clear-Host
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  AZURE MULTI-SUBSCRIPTION AUDIT" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Force fresh login
Write-Host "Connecting to Azure..." -ForegroundColor Yellow
Disconnect-AzAccount -ErrorAction SilentlyContinue | Out-Null
Connect-AzAccount

Write-Host ""

# Get ALL subscriptions
Write-Host "Loading all subscriptions..." -ForegroundColor Yellow
$allSubs = Get-AzSubscription
Write-Host "Found: $($allSubs.Count) subscriptions" -ForegroundColor Green
Write-Host ""

# Show menu
Write-Host "SELECT SUBSCRIPTION TO AUDIT:" -ForegroundColor Cyan
Write-Host ""

for ($i = 0; $i -lt $allSubs.Count; $i++) {
    $sub = $allSubs[$i]
    $state = $sub.State
    $color = if ($state -eq "Enabled") {"Green"} else {"Yellow"}
    
    Write-Host "  [$($i+1)] " -NoNewline -ForegroundColor White
    Write-Host "$($sub.Name)" -NoNewline -ForegroundColor $color
    Write-Host " ($state)" -ForegroundColor Gray
}

Write-Host ""
Write-Host "  [A] Audit ALL subscriptions" -ForegroundColor White
Write-Host "  [X] Exit" -ForegroundColor White
Write-Host ""

$choice = Read-Host "Select subscription number or option"

if ($choice -eq "X" -or $choice -eq "x") {
    Write-Host "Exiting..." -ForegroundColor Yellow
    exit
}

$subsToAudit = @()

if ($choice -eq "A" -or $choice -eq "a") {
    Write-Host ""
    Write-Host "Auditing ALL subscriptions..." -ForegroundColor Yellow
    $subsToAudit = $allSubs
} else {
    $index = [int]$choice - 1
    if ($index -ge 0 -and $index -lt $allSubs.Count) {
        $subsToAudit = @($allSubs[$index])
        Write-Host ""
        Write-Host "Auditing: $($subsToAudit[0].Name)" -ForegroundColor Yellow
    } else {
        Write-Host "Invalid selection" -ForegroundColor Red
        exit
    }
}

Write-Host ""

# Run audit on selected subscriptions
$allIssues = @()

foreach ($sub in $subsToAudit) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  SUBSCRIPTION: $($sub.Name)" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    
    # Switch to subscription
    Set-AzContext -Subscription $sub.Id | Out-Null
    
    # Get resource groups
    Write-Host "Scanning resource groups..." -ForegroundColor Yellow
    $rgs = Get-AzResourceGroup
    Write-Host "Found: $($rgs.Count) resource groups" -ForegroundColor Green
    Write-Host ""
    
    foreach ($rg in $rgs) {
        Write-Host "  Checking: $($rg.ResourceGroupName)" -ForegroundColor Gray
        
        $res = Get-AzResource -ResourceGroupName $rg.ResourceGroupName -ErrorAction SilentlyContinue
        $dbWS = $res | Where-Object {$_.ResourceType -eq "Microsoft.Databricks/workspaces"}
        
        $env = "Unknown"
        if ($rg.ResourceGroupName -match "prod" -and $rg.ResourceGroupName -notmatch "preprod") { $env = "Production" }
        elseif ($rg.ResourceGroupName -match "preprod") { $env = "PreProd" }
        elseif ($rg.ResourceGroupName -match "poc") { $env = "POC" }
        elseif ($rg.ResourceGroupName -match "dev") { $env = "Dev" }
        
        $problems = @()
        
        if ($env -eq "POC") {
            foreach ($r in $res) {
                if ($r.Name -match "prod" -and $r.Name -notmatch "preprod") {
                    $problems += "POC has prod resource: $($r.Name)"
                }
            }
        }
        
        if ($env -eq "PreProd") {
            foreach ($r in $res) {
                if ($r.Name -match "-prod$") {
                    $problems += "PreProd has prod resource: $($r.Name)"
                }
            }
        }
        
        if ($problems.Count -gt 0) {
            $allIssues += [PSCustomObject]@{
                Subscription = $sub.Name
                ResourceGroup = $rg.ResourceGroupName
                Environment = $env
                Location = $rg.Location
                Resources = $res.Count
                Databricks = if ($dbWS) {($dbWS.Name -join ", ")} else {"None"}
                Issues = ($problems -join " | ")
            }
        }
    }
}

# Generate HTML report
Write-Host ""
Write-Host "Generating HTML report..." -ForegroundColor Yellow

$reportFile = "Multi-Sub-Naming-Audit-$(Get-Date -Format 'yyyyMMdd-HHmmss').html"

$rows = ""
foreach ($issue in $allIssues) {
    $rows += "<tr><td><strong>$($issue.Subscription)</strong></td><td><strong>$($issue.ResourceGroup)</strong></td><td>$($issue.Environment)</td><td>$($issue.Location)</td><td>$($issue.Resources)</td><td>$($issue.Databricks)</td><td style='color:red'>$($issue.Issues)</td></tr>"
}

$html = @"
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Azure Multi-Subscription Naming Audit</title>
<style>
body{font-family:Arial;margin:20px;background:#f5f5f5}
.box{max-width:1800px;margin:0 auto;background:white;padding:30px;border-radius:8px}
h1{color:#FF3621;font-size:28px}
table{width:100%;border-collapse:collapse;margin:20px 0}
th{background:#1B3139;color:white;padding:12px;text-align:left}
td{padding:10px;border-bottom:1px solid #ddd;font-size:13px}
tr:hover{background:#f5f5f5}
.summary{background:#f8f9fa;padding:20px;border-left:4px solid #FF3621;margin:20px 0}
.warn{background:#fff3cd;padding:15px;border-left:4px solid #ffc107;margin:15px 0}
</style>
</head>
<body>
<div class="box">
<h1>Azure Multi-Subscription Naming Audit</h1>
<p><strong>Date:</strong> $(Get-Date -Format 'yyyy-MM-dd HH:mm')</p>
<p><strong>Subscriptions Audited:</strong> $($subsToAudit.Count)</p>

<div class="summary">
<h3>Summary</h3>
<p><strong>Total Issues Found:</strong> $($allIssues.Count)</p>
<p><strong>Subscriptions Scanned:</strong> $(($allIssues.Subscription | Select-Object -Unique).Count)</p>
</div>

<div class="warn">
<h3>Issues Detected</h3>
<p>Resource groups with naming mismatches between RG name and resources inside.</p>
</div>

<table>
<tr>
<th>Subscription</th>
<th>Resource Group</th>
<th>Environment</th>
<th>Location</th>
<th>Resources</th>
<th>Databricks</th>
<th>Issues</th>
</tr>
$rows
</table>

<h2>Next Steps</h2>
<ol>
<li>Review with Brian/Team to verify true environments</li>
<li>Identify which RGs need renaming</li>
<li>Plan maintenance window for renames</li>
<li>Update documentation</li>
</ol>

<p style="margin-top:40px;border-top:2px solid #ddd;padding-top:20px">
<strong>Generated:</strong> $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')<br>
<strong>Total Subscriptions:</strong> $($subsToAudit.Count)<br>
<strong>Total Issues:</strong> $($allIssues.Count)
</p>

</div>
</body>
</html>
"@

$html | Out-File $reportFile -Encoding UTF8

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  AUDIT COMPLETE" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total Subscriptions: $($subsToAudit.Count)" -ForegroundColor White
Write-Host "Total Issues Found: $($allIssues.Count)" -ForegroundColor $(if ($allIssues.Count -gt 0) {"Red"} else {"Green"})
Write-Host "Report: $reportFile" -ForegroundColor Green
Write-Host ""

if ($allIssues.Count -gt 0) {
    Write-Host "ISSUES BY SUBSCRIPTION:" -ForegroundColor Yellow
    Write-Host ""
    $allIssues | Format-Table Subscription, ResourceGroup, Environment, Issues -AutoSize
}

Write-Host ""
Write-Host "Opening report..." -ForegroundColor Yellow
Start-Process $reportFile

Write-Host "Done!" -ForegroundColor Green
