# DATABRICKS QUOTA ANALYZER - USING YOUR EXACT WORKSPACE
# Workspace from your screenshot: https://adb-324884819348686.6.azuredatabricks.net

$workspace = "https://adb-324884819348686.6.azuredatabricks.net"

# PUT YOUR NEW TOKEN HERE (the one you created today)
$token = "dapi9abaad71d0865d1a32a08cba05a318b7"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "DATABRICKS QUOTA ANALYZER" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Workspace: $workspace" -ForegroundColor White
Write-Host ""

$headers = @{
    "Authorization" = "Bearer $token"
}

$rootCauses = @()
$allData = @()

# TEST 1: SQL Warehouses
Write-Host "[1/2] Getting SQL Warehouses..." -ForegroundColor Yellow

try {
    $whResponse = Invoke-RestMethod -Uri "$workspace/api/2.0/sql/warehouses" -Headers $headers -Method Get
    
    if ($whResponse.warehouses -and $whResponse.warehouses.Count -gt 0) {
        Write-Host "  SUCCESS: Found $($whResponse.warehouses.Count) warehouses" -ForegroundColor Green
        
        foreach ($wh in $whResponse.warehouses) {
            Write-Host "    - $($wh.name) [$($wh.state)] Size: $($wh.cluster_size)" -ForegroundColor White
            
            $allData += [PSCustomObject]@{
                Type = "SQL Warehouse"
                Name = $wh.name
                State = $wh.state
                Size = $wh.cluster_size
                AutoStop = "$($wh.auto_stop_mins) min"
                NumClusters = $wh.num_clusters
            }
            
            if ($wh.num_clusters -gt 3) {
                $rootCauses += "SQL Warehouse '$($wh.name)' running $($wh.num_clusters) clusters (high resource usage)"
            }
        }
    } else {
        Write-Host "  WARNING: No warehouses returned" -ForegroundColor Red
        Write-Host "  This means token has no 'sql_access' permission" -ForegroundColor Red
    }
    
} catch {
    Write-Host "  ERROR: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.ErrorDetails) {
        Write-Host "  Details: $($_.ErrorDetails.Message)" -ForegroundColor Red
    }
}

# TEST 2: Compute Clusters
Write-Host ""
Write-Host "[2/2] Getting Compute Clusters..." -ForegroundColor Yellow

try {
    $clResponse = Invoke-RestMethod -Uri "$workspace/api/2.0/clusters/list" -Headers $headers -Method Get
    
    if ($clResponse.clusters -and $clResponse.clusters.Count -gt 0) {
        Write-Host "  SUCCESS: Found $($clResponse.clusters.Count) clusters" -ForegroundColor Green
        
        foreach ($cl in $clResponse.clusters) {
            Write-Host "    - $($cl.cluster_name) [$($cl.state)]" -ForegroundColor White
            
            $autoscale = "NO"
            $autoterm = "NO"
            
            if ($cl.autoscale) {
                $autoscale = "YES ($($cl.autoscale.min_workers)-$($cl.autoscale.max_workers) workers)"
                if ($cl.autoscale.max_workers -gt 20) {
                    $rootCauses += "Cluster '$($cl.cluster_name)' max_workers=$($cl.autoscale.max_workers) (QUOTA RISK)"
                }
            } else {
                $rootCauses += "Cluster '$($cl.cluster_name)' has NO autoscaling"
            }
            
            if ($cl.autotermination_minutes) {
                $autoterm = "YES ($($cl.autotermination_minutes) min)"
            } else {
                $rootCauses += "Cluster '$($cl.cluster_name)' has NO auto-termination"
            }
            
            $allData += [PSCustomObject]@{
                Type = "Compute Cluster"
                Name = $cl.cluster_name
                State = $cl.state
                Autoscale = $autoscale
                AutoTerminate = $autoterm
                NodeType = $cl.node_type_id
            }
        }
    } else {
        Write-Host "  No compute clusters found (this is normal if you only use SQL warehouses)" -ForegroundColor Yellow
    }
    
} catch {
    Write-Host "  ERROR: $($_.Exception.Message)" -ForegroundColor Red
}

# GENERATE REPORT
Write-Host ""
Write-Host "Generating HTML Report..." -ForegroundColor Yellow

$reportFile = "DatabricksReport_$(Get-Date -Format 'yyyyMMdd_HHmmss').html"

$dataRows = ""
if ($allData.Count -gt 0) {
    foreach ($item in $allData) {
        if ($item.Type -eq "SQL Warehouse") {
            $dataRows += "<tr><td>$($item.Type)</td><td>$($item.Name)</td><td>$($item.State)</td><td>$($item.Size)</td><td>$($item.AutoStop)</td><td>$($item.NumClusters)</td></tr>"
        } else {
            $dataRows += "<tr><td>$($item.Type)</td><td>$($item.Name)</td><td>$($item.State)</td><td>$($item.Autoscale)</td><td>$($item.AutoTerminate)</td><td>-</td></tr>"
        }
    }
} else {
    $dataRows = "<tr><td colspan='6' style='text-align:center;color:red;padding:20px;'><strong>NO DATA FOUND</strong><br>Token may lack permissions or is for different workspace</td></tr>"
}

$rootCauseHTML = ""
if ($rootCauses.Count -eq 0) {
    if ($allData.Count -eq 0) {
        $rootCauseHTML = "<p style='color:red;font-weight:bold;'>Cannot analyze - no data retrieved. Check token permissions.</p>"
    } else {
        $rootCauseHTML = "<p style='color:green;font-weight:bold;'>✓ No critical issues found</p>"
    }
} else {
    $rootCauseHTML = "<ul style='color:red;'>"
    foreach ($rc in $rootCauses) {
        $rootCauseHTML += "<li>$rc</li>"
    }
    $rootCauseHTML += "</ul>"
}

$html = @"
<!DOCTYPE html>
<html>
<head>
<title>Databricks Quota Report</title>
<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
h1 { color: #FF3621; margin-bottom: 10px; }
h2 { color: #1B3139; border-bottom: 3px solid #FF3621; padding-bottom: 8px; margin-top: 30px; }
.info { background: #f8f9fa; padding: 15px; border-left: 4px solid #FF3621; margin: 20px 0; }
table { width: 100%; border-collapse: collapse; margin: 20px 0; }
th { background: #1B3139; color: white; padding: 12px; text-align: left; }
td { padding: 10px; border-bottom: 1px solid #ddd; }
tr:hover { background: #f5f5f5; }
.summary-box { display: inline-block; background: #e3f2fd; padding: 15px 25px; margin: 10px; border-radius: 5px; min-width: 200px; }
.summary-box strong { display: block; font-size: 24px; color: #1976d2; }
</style>
</head>
<body>
<div class="container">
<h1>🔍 Databricks Quota Analysis Report</h1>
<p><strong>Generated:</strong> $(Get-Date -Format 'MMMM dd, yyyy HH:mm:ss')</p>
<p><strong>Workspace:</strong> $workspace</p>

<h2>📊 Summary</h2>
<div style="text-align:center;">
<div class="summary-box">
<strong>$($allData.Count)</strong>
Total Resources
</div>
<div class="summary-box">
<strong>$($rootCauses.Count)</strong>
Root Causes
</div>
<div class="summary-box">
<strong>$(($allData | Where-Object {$_.Type -eq 'SQL Warehouse'}).Count)</strong>
SQL Warehouses
</div>
<div class="summary-box">
<strong>$(($allData | Where-Object {$_.Type -eq 'Compute Cluster'}).Count)</strong>
Compute Clusters
</div>
</div>

<h2>🚨 Root Causes Identified</h2>
$rootCauseHTML

<h2>📋 All Resources</h2>
<table>
<tr>
<th>Type</th>
<th>Name</th>
<th>State</th>
<th>Config 1</th>
<th>Config 2</th>
<th>Clusters</th>
</tr>
$dataRows
</table>

<h2>✅ Recommendations</h2>
<ul>
<li>Enable autoscaling on all compute clusters (prevents over-provisioning)</li>
<li>Enable auto-termination 30-60 min on clusters (prevents resource waste)</li>
<li>Monitor SQL warehouse usage - reduce size if under-utilized</li>
<li>Set auto-stop on SQL warehouses to 15-30 minutes</li>
<li>Cap max workers at 12 per cluster (prevents quota spikes)</li>
<li>Set up Azure quota alerts at 80% threshold</li>
</ul>

<h2>🔧 Troubleshooting</h2>
<div class="info">
<p><strong>If no data appears above:</strong></p>
<ol>
<li>Open Databricks workspace in browser</li>
<li>Click user icon (top right) → <strong>User Settings</strong></li>
<li>Go to <strong>Developer</strong> → <strong>Access Tokens</strong></li>
<li>Click <strong>Generate New Token</strong></li>
<li>Lifetime: 90 days, Comment: "Full Access Quota Script"</li>
<li>Copy the new token</li>
<li>Update line 6 in the PowerShell script</li>
<li>Re-run the script</li>
</ol>
</div>

</div>
</body>
</html>
"@

Set-Content -Path $reportFile -Value $html -Encoding UTF8
Write-Host "  Report saved: $reportFile" -ForegroundColor Green

Start-Process $reportFile

# CONSOLE SUMMARY
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "RESULTS" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total Resources: $($allData.Count)" -ForegroundColor White
Write-Host "Root Causes: $($rootCauses.Count)" -ForegroundColor $(if ($rootCauses.Count -eq 0) { "Green" } else { "Red" })
Write-Host ""

if ($allData.Count -eq 0) {
    Write-Host "⚠️  NO DATA RETRIEVED" -ForegroundColor Red
    Write-Host ""
    Write-Host "PROBLEM: Token authenticated but returned no resources" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "SOLUTION:" -ForegroundColor Cyan
    Write-Host "1. Go to: $workspace" -ForegroundColor White
    Write-Host "2. User Settings → Developer → Access Tokens" -ForegroundColor White  
    Write-Host "3. Generate new token with full permissions" -ForegroundColor White
    Write-Host "4. Update line 6 in script with new token" -ForegroundColor White
    Write-Host "5. Re-run script" -ForegroundColor White
    Write-Host ""
} else {
    Write-Host "✓ Report generated successfully" -ForegroundColor Green
    
    if ($rootCauses.Count -gt 0) {
        Write-Host ""
        Write-Host "ROOT CAUSES:" -ForegroundColor Red
        foreach ($rc in $rootCauses) {
            Write-Host "  • $rc" -ForegroundColor Red
        }
    }
}

Write-Host ""
