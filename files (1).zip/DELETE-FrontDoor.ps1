# ================================================================
# DELETE BROKEN FRONT DOOR - CLEAN SLATE
# ================================================================

Write-Host "============================================" -ForegroundColor Red
Write-Host "  DELETING BROKEN FRONT DOOR" -ForegroundColor Red
Write-Host "============================================" -ForegroundColor Red
Write-Host ""

function Write-Log {
    param([string]$Message, [string]$Color = "White")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] $Message" -ForegroundColor $Color
}

# ----------------------------------------------------------------
# CONFIGURATION
# ----------------------------------------------------------------
$resourceGroup = "rg-moveit"
$frontDoorProfile = "moveit-frontdoor-profile"
$wafPolicy = "moveitWAFPolicy"

Write-Host "This will DELETE:" -ForegroundColor Yellow
Write-Host "  - Front Door Profile: $frontDoorProfile" -ForegroundColor White
Write-Host "  - WAF Policy: $wafPolicy" -ForegroundColor White
Write-Host "  - All endpoints, routes, origins, origin groups" -ForegroundColor White
Write-Host ""
Write-Host "This will NOT affect:" -ForegroundColor Green
Write-Host "  ✓ NSG (Network Security Group)" -ForegroundColor Green
Write-Host "  ✓ Load Balancer" -ForegroundColor Green
Write-Host "  ✓ Public IP" -ForegroundColor Green
Write-Host "  ✓ VNet and subnet" -ForegroundColor Green
Write-Host "  ✓ MOVEit server" -ForegroundColor Green
Write-Host ""

$confirm = Read-Host "Are you sure you want to delete? (yes/no)"
if ($confirm -ne "yes") {
    Write-Log "Deletion cancelled." "Yellow"
    exit 0
}

Write-Host ""

# ----------------------------------------------------------------
# DELETE FRONT DOOR PROFILE
# ----------------------------------------------------------------
Write-Log "Deleting Front Door profile..." "Cyan"

$fdExists = az afd profile show --resource-group $resourceGroup --profile-name $frontDoorProfile 2>$null
if ($fdExists) {
    az afd profile delete `
        --resource-group $resourceGroup `
        --profile-name $frontDoorProfile `
        --yes `
        --output none
    
    Write-Log "Front Door profile deleted" "Green"
    
    # Wait for deletion to complete
    Write-Log "Waiting for deletion to complete..." "Yellow"
    Start-Sleep -Seconds 30
    
    # Verify deletion
    $stillExists = az afd profile show --resource-group $resourceGroup --profile-name $frontDoorProfile 2>$null
    if (-not $stillExists) {
        Write-Log "✓ Deletion confirmed" "Green"
    } else {
        Write-Log "⚠ Still deleting... (this is normal)" "Yellow"
    }
} else {
    Write-Log "Front Door profile already deleted" "Yellow"
}

Write-Host ""

# ----------------------------------------------------------------
# DELETE WAF POLICY
# ----------------------------------------------------------------
Write-Log "Deleting WAF policy..." "Cyan"

$wafExists = az network front-door waf-policy show --resource-group $resourceGroup --name $wafPolicy 2>$null
if ($wafExists) {
    az network front-door waf-policy delete `
        --resource-group $resourceGroup `
        --name $wafPolicy `
        --yes `
        --output none
    
    Write-Log "WAF policy deleted" "Green"
} else {
    Write-Log "WAF policy already deleted" "Yellow"
}

Write-Host ""

# ----------------------------------------------------------------
# VERIFICATION
# ----------------------------------------------------------------
Write-Log "Verifying deletion..." "Yellow"
Write-Host ""

$fdCheck = az afd profile show --resource-group $resourceGroup --profile-name $frontDoorProfile 2>$null
$wafCheck = az network front-door waf-policy show --resource-group $resourceGroup --name $wafPolicy 2>$null

if (-not $fdCheck -and -not $wafCheck) {
    Write-Host "============================================" -ForegroundColor Green
    Write-Host "  DELETION COMPLETE!" -ForegroundColor Green
    Write-Host "============================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "✓ Front Door profile removed" -ForegroundColor Green
    Write-Host "✓ WAF policy removed" -ForegroundColor Green
    Write-Host ""
    Write-Host "NEXT STEPS:" -ForegroundColor Cyan
    Write-Host "  1. Run: .\4-WAF-FrontDoor.ps1" -ForegroundColor White
    Write-Host "  2. Run: .\5-Defender.ps1" -ForegroundColor White
    Write-Host "  3. (Optional) Run: .\6-Custom-Domain.ps1" -ForegroundColor White
    Write-Host "  4. (Optional) Run: .\7-Testing-Verification.ps1" -ForegroundColor White
    Write-Host ""
    Write-Host "This will create a FRESH, WORKING Front Door!" -ForegroundColor Green
    Write-Host ""
} else {
    Write-Host "============================================" -ForegroundColor Yellow
    Write-Host "  DELETION IN PROGRESS" -ForegroundColor Yellow
    Write-Host "============================================" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "⚠ Azure is still deleting resources" -ForegroundColor Yellow
    Write-Host "  Wait 2-3 minutes, then run Script 4" -ForegroundColor White
    Write-Host ""
}

# ----------------------------------------------------------------
# SHOW REMAINING RESOURCES
# ----------------------------------------------------------------
Write-Host "REMAINING RESOURCES (should still exist):" -ForegroundColor Cyan
Write-Host ""

$nsg = az network nsg show --resource-group $resourceGroup --name nsg-moveit 2>$null
if ($nsg) {
    Write-Host "  ✓ NSG (nsg-moveit)" -ForegroundColor Green
} else {
    Write-Host "  ✗ NSG missing - run Script 2" -ForegroundColor Red
}

$lb = az network lb show --resource-group $resourceGroup --name lb-moveit-sftp 2>$null
if ($lb) {
    Write-Host "  ✓ Load Balancer (lb-moveit-sftp)" -ForegroundColor Green
} else {
    Write-Host "  ✗ Load Balancer missing - run Script 3" -ForegroundColor Red
}

$pip = az network public-ip show --resource-group $resourceGroup --name pip-moveit-lb 2>$null
if ($pip) {
    $pipObj = $pip | ConvertFrom-Json
    Write-Host "  ✓ Public IP ($($pipObj.ipAddress))" -ForegroundColor Green
} else {
    Write-Host "  ✗ Public IP missing - run Script 3" -ForegroundColor Red
}

Write-Host ""
Write-Host "Ready to deploy fresh Front Door!" -ForegroundColor Green
Write-Host ""
