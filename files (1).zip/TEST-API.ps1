# SIMPLE TEST - Shows exact API response

$workspace = "https://adb-324884819348686.6.azuredatabricks.net"
$token = "dapi9abaad71d0865d1a32a08cba05a318b7"

Write-Host "Testing SQL Warehouses API..." -ForegroundColor Yellow
Write-Host ""

try {
    $response = Invoke-WebRequest -Uri "$workspace/api/2.0/sql/warehouses" -Headers @{"Authorization"="Bearer $token"} -Method Get
    
    Write-Host "STATUS: $($response.StatusCode)" -ForegroundColor Green
    Write-Host ""
    Write-Host "RESPONSE:" -ForegroundColor Cyan
    $response.Content | ConvertFrom-Json | ConvertTo-Json -Depth 10
    
} catch {
    Write-Host "ERROR:" -ForegroundColor Red
    Write-Host $_.Exception.Message
    Write-Host ""
    Write-Host "RESPONSE BODY:" -ForegroundColor Yellow
    $_.ErrorDetails.Message
}

Write-Host ""
Write-Host "If you see 'warehouses': [] that means token has no permission" -ForegroundColor Yellow
Write-Host "If you see 3 warehouses, then my script had a bug" -ForegroundColor Yellow
