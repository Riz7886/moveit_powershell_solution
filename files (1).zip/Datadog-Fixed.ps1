param(
    [string]$DD_API_KEY = "38ff813dd7d46538706378cc3bd68e94",
    [string]$DD_APP_KEY = "438d47ab7dbc503fb3f44439a20ad21761e78bbc"
)

$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "DATADOG MONITOR DEPLOYMENT" -ForegroundColor Cyan
Write-Host ""

$BaseUrl = "https://api.us3.datadoghq.com/api/v1/monitor"
$Headers = @{
    "DD-API-KEY" = $DD_API_KEY
    "DD-APPLICATION-KEY" = $DD_APP_KEY
    "Content-Type" = "application/json"
}

Write-Host "Connecting to Azure..." -ForegroundColor Cyan
$context = Get-AzContext -ErrorAction SilentlyContinue
if (-not $context) {
    Connect-AzAccount | Out-Null
    $context = Get-AzContext
}
Write-Host "Connected as: $($context.Account.Id)" -ForegroundColor Green
Write-Host ""

Write-Host "Loading subscriptions..." -ForegroundColor Cyan
$allSubs = Get-AzSubscription
if ($allSubs.Count -eq 0) {
    Write-Host "No subscriptions found" -ForegroundColor Red
    exit 1
}

Write-Host ""
for ($i = 0; $i -lt $allSubs.Count; $i++) {
    Write-Host "[$($i + 1)] $($allSubs[$i].Name)"
}
Write-Host ""

$choice = Read-Host "Select subscription (1-$($allSubs.Count))"
$selectedIndex = [int]$choice - 1
if ($selectedIndex -lt 0 -or $selectedIndex -ge $allSubs.Count) {
    Write-Host "Invalid selection" -ForegroundColor Red
    exit 1
}

$selectedSub = $allSubs[$selectedIndex]
Set-AzContext -SubscriptionId $selectedSub.Id | Out-Null
Write-Host ""
Write-Host "Using: $($selectedSub.Name)" -ForegroundColor Green
Write-Host ""

Write-Host "Creating monitors..." -ForegroundColor Cyan
Write-Host ""

function New-Monitor {
    param([string]$Name, [string]$Query, [string]$Message)
    
    $body = @{
        name = $Name
        type = "metric alert"
        query = $Query
        message = $Message
        tags = @("env:production")
        options = @{
            thresholds = @{ critical = 1 }
            notify_no_data = $true
            no_data_timeframe = 10
        }
    } | ConvertTo-Json -Depth 5
    
    try {
        Invoke-RestMethod -Uri $BaseUrl -Method Post -Headers $Headers -Body $body -ErrorAction Stop | Out-Null
        Write-Host "[OK] $Name" -ForegroundColor Green
    }
    catch {
        Write-Host "[FAIL] $Name" -ForegroundColor Red
    }
}

New-Monitor -Name "VM CPU High" -Query "avg(last_5m):avg:azure.vm.percentage_cpu{*} > 85" -Message "VM CPU above 85 percent"
New-Monitor -Name "VM Network In High" -Query "avg(last_5m):avg:azure.vm.network_in_total{*} > 100000000" -Message "VM network in high"
New-Monitor -Name "VM Network Out High" -Query "avg(last_5m):avg:azure.vm.network_out_total{*} > 100000000" -Message "VM network out high"
New-Monitor -Name "VM Disk Read High" -Query "avg(last_5m):avg:azure.vm.disk_read_bytes{*} > 100000000" -Message "VM disk read high"
New-Monitor -Name "VM Disk Write High" -Query "avg(last_5m):avg:azure.vm.disk_write_bytes{*} > 100000000" -Message "VM disk write high"
New-Monitor -Name "VM Disk Operations High" -Query "avg(last_5m):avg:azure.vm.disk_read_operations_persec{*} > 500" -Message "VM disk operations high"
New-Monitor -Name "SQL Database DTU High" -Query "avg(last_5m):avg:azure.sql_servers_databases.dtu_consumption_percent{*} > 80" -Message "SQL DTU above 80 percent"
New-Monitor -Name "SQL Database Storage High" -Query "avg(last_5m):avg:azure.sql_servers_databases.storage_percent{*} > 85" -Message "SQL storage above 85 percent"
New-Monitor -Name "SQL Connection Failed" -Query "avg(last_5m):avg:azure.sql_servers_databases.connection_failed{*} > 5" -Message "SQL connection failures"
New-Monitor -Name "SQL Deadlocks" -Query "avg(last_5m):avg:azure.sql_servers_databases.deadlock{*} > 0" -Message "SQL deadlocks detected"
New-Monitor -Name "Storage Availability Low" -Query "avg(last_5m):avg:azure.storage_storageaccounts.availability{*} < 99" -Message "Storage availability below 99 percent"
New-Monitor -Name "Storage Latency High" -Query "avg(last_5m):avg:azure.storage_storageaccounts.success_e2_e_latency{*} > 1000" -Message "Storage latency high"
New-Monitor -Name "App Service CPU High" -Query "avg(last_5m):avg:azure.web_sites.cpu_time{*} > 80" -Message "App Service CPU above 80 percent"
New-Monitor -Name "App Service Response Time High" -Query "avg(last_5m):avg:azure.web_sites.average_response_time{*} > 3" -Message "App Service response time above 3 seconds"
New-Monitor -Name "App Service HTTP 5xx" -Query "avg(last_5m):avg:azure.web_sites.http_server_errors{*} > 10" -Message "App Service 5xx errors"
New-Monitor -Name "Load Balancer Health Low" -Query "avg(last_5m):avg:azure.network_loadbalancers.health_probe_status{*} < 50" -Message "Load balancer health below 50 percent"

Write-Host ""
Write-Host "COMPLETE" -ForegroundColor Green
Write-Host ""
Write-Host "Go to Datadog portal to verify monitors" -ForegroundColor Yellow
Write-Host "URL: https://us3.datadoghq.com/monitors/manage" -ForegroundColor Cyan
Write-Host ""
