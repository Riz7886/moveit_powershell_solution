function Invoke-ADScan {
    $issues = @()
    
    Write-Host "Checking Active Directory module..." -ForegroundColor Cyan
    
    if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
        Write-Host "ERROR: ActiveDirectory module NOT installed" -ForegroundColor Red
        Write-Host "Install with: Add-WindowsCapability -Online -Name Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0" -ForegroundColor Yellow
        return @()
    }
    
    try {
        Import-Module ActiveDirectory -ErrorAction Stop
        Write-Host "ActiveDirectory module loaded" -ForegroundColor Green
        Write-Host ""
    }
    catch {
        Write-Host "ERROR: Cannot load ActiveDirectory module" -ForegroundColor Red
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
        return @()
    }
    
    Write-Host "Connecting to Active Directory..." -ForegroundColor Cyan
    
    try {
        $domain = Get-ADDomain -ErrorAction Stop
        $forest = Get-ADForest -ErrorAction Stop
        
        Write-Host "SUCCESS: Connected to domain" -ForegroundColor Green
        Write-Host ""
        Write-Host "Domain: $($domain.DNSRoot)" -ForegroundColor White
        Write-Host "Forest: $($forest.Name)" -ForegroundColor White
        Write-Host "Domain Functional Level: $($domain.DomainMode)" -ForegroundColor White
        Write-Host "Forest Functional Level: $($forest.ForestMode)" -ForegroundColor White
        Write-Host ""
        
        Write-Host "FSMO Roles:" -ForegroundColor Cyan
        Write-Host "  Schema Master: $($forest.SchemaMaster)" -ForegroundColor White
        Write-Host "  Domain Naming Master: $($forest.DomainNamingMaster)" -ForegroundColor White
        Write-Host "  PDC Emulator: $($domain.PDCEmulator)" -ForegroundColor White
        Write-Host "  RID Master: $($domain.RIDMaster)" -ForegroundColor White
        Write-Host "  Infrastructure Master: $($domain.InfrastructureMaster)" -ForegroundColor White
        Write-Host ""
        
        $dcs = Get-ADDomainController -Filter * -ErrorAction Stop
        Write-Host "Domain Controllers: $($dcs.Count)" -ForegroundColor Cyan
        foreach ($dc in $dcs) {
            $dcIP = [System.Net.Dns]::GetHostAddresses($dc.HostName)[0].IPAddressToString
            Write-Host "  $($dc.HostName)" -ForegroundColor White
            Write-Host "    IP: $dcIP" -ForegroundColor Gray
            Write-Host "    Site: $($dc.Site)" -ForegroundColor Gray
            Write-Host "    OS: $($dc.OperatingSystem)" -ForegroundColor Gray
        }
        Write-Host ""
        
    }
    catch {
        Write-Host "ERROR: Cannot connect to Active Directory" -ForegroundColor Red
        Write-Host "Reason: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host ""
        Write-Host "Possible causes:" -ForegroundColor Yellow
        Write-Host "  - Machine not joined to AD domain" -ForegroundColor White
        Write-Host "  - Not connected to domain network" -ForegroundColor White
        Write-Host "  - Domain controller unreachable" -ForegroundColor White
        Write-Host "  - VPN/network connectivity issue" -ForegroundColor White
        return @()
    }
    
    Write-Host "Scanning for issues..." -ForegroundColor Cyan
    Write-Host ""
    
    $inactiveUsers = Search-ADAccount -UsersOnly -AccountInactive -TimeSpan 90 -ErrorAction SilentlyContinue | Where-Object { $_.Enabled -eq $true }
    Write-Host "Found $($inactiveUsers.Count) inactive accounts" -ForegroundColor Yellow
    
    foreach ($user in $inactiveUsers) {
        $issues += [PSCustomObject]@{
            Type = 'AD'
            Category = 'Security'
            Severity = 'High'
            Resource = $user.SamAccountName
            Issue = 'Inactive Account'
            Remediation = 'Disable-Account'
            AutoFixable = $true
            DistinguishedName = $user.DistinguishedName
            LastLogon = $user.LastLogonDate
        }
    }
    
    $neverExpire = Get-ADUser -Filter {Enabled -eq $true -and PasswordNeverExpires -eq $true} -Properties PasswordNeverExpires -ErrorAction SilentlyContinue
    Write-Host "Found $($neverExpire.Count) accounts with password never expires" -ForegroundColor Yellow
    
    foreach ($user in $neverExpire) {
        $issues += [PSCustomObject]@{
            Type = 'AD'
            Category = 'Security'
            Severity = 'Critical'
            Resource = $user.SamAccountName
            Issue = 'Password Never Expires'
            Remediation = 'Fix-PasswordPolicy'
            AutoFixable = $true
            DistinguishedName = $user.DistinguishedName
        }
    }
    
    $oldPasswords = Get-ADUser -Filter {Enabled -eq $true} -Properties PasswordLastSet -ErrorAction SilentlyContinue | 
        Where-Object { $_.PasswordLastSet -lt (Get-Date).AddDays(-90) }
    Write-Host "Found $($oldPasswords.Count) accounts with old passwords" -ForegroundColor Yellow
    
    foreach ($user in $oldPasswords) {
        $issues += [PSCustomObject]@{
            Type = 'AD'
            Category = 'Security'
            Severity = 'High'
            Resource = $user.SamAccountName
            Issue = 'Old Password'
            Remediation = 'Force-PasswordChange'
            AutoFixable = $true
            DistinguishedName = $user.DistinguishedName
        }
    }
    
    $disabledInGroups = Get-ADUser -Filter {Enabled -eq $false} -Properties MemberOf -ErrorAction SilentlyContinue | 
        Where-Object { $_.MemberOf.Count -gt 0 }
    Write-Host "Found $($disabledInGroups.Count) disabled accounts in groups" -ForegroundColor Yellow
    
    foreach ($user in $disabledInGroups) {
        $issues += [PSCustomObject]@{
            Type = 'AD'
            Category = 'Cleanup'
            Severity = 'Medium'
            Resource = $user.SamAccountName
            Issue = 'Disabled Account in Groups'
            Remediation = 'Remove-FromGroups'
            AutoFixable = $true
            DistinguishedName = $user.DistinguishedName
        }
    }
    
    $lockedAccounts = Search-ADAccount -LockedOut -ErrorAction SilentlyContinue
    Write-Host "Found $($lockedAccounts.Count) locked accounts" -ForegroundColor Yellow
    
    foreach ($locked in $lockedAccounts) {
        $issues += [PSCustomObject]@{
            Type = 'AD'
            Category = 'Operations'
            Severity = 'Medium'
            Resource = $locked.SamAccountName
            Issue = 'Account Locked'
            Remediation = 'Unlock-Account'
            AutoFixable = $true
            DistinguishedName = $locked.DistinguishedName
        }
    }
    
    Write-Host ""
    Write-Host "AD Scan Complete" -ForegroundColor Green
    Write-Host "Total Issues: $($issues.Count)" -ForegroundColor Yellow
    Write-Host ""
    
    return $issues
}

function Invoke-ADRemediation {
    param($Issue)
    
    try {
        switch ($Issue.Remediation) {
            'Disable-Account' {
                $confirm = Read-Host "Disable $($Issue.Resource)? (Y/N)"
                if ($confirm -ne 'Y') {
                    return @{Success=$false; Action="Skipped"; Details="User declined"}
                }
                Disable-ADAccount -Identity $Issue.DistinguishedName
                return @{Success=$true; Action="Disabled"; Details="Account disabled"}
            }
            'Fix-PasswordPolicy' {
                $confirm = Read-Host "Fix password policy for $($Issue.Resource)? (Y/N)"
                if ($confirm -ne 'Y') {
                    return @{Success=$false; Action="Skipped"; Details="User declined"}
                }
                Set-ADUser -Identity $Issue.DistinguishedName -PasswordNeverExpires $false
                return @{Success=$true; Action="Fixed"; Details="Password expiration enabled"}
            }
            'Force-PasswordChange' {
                Set-ADUser -Identity $Issue.DistinguishedName -ChangePasswordAtLogon $true
                return @{Success=$true; Action="Fixed"; Details="Password change required"}
            }
            'Remove-FromGroups' {
                $confirm = Read-Host "Remove $($Issue.Resource) from groups? (Y/N)"
                if ($confirm -ne 'Y') {
                    return @{Success=$false; Action="Skipped"; Details="User declined"}
                }
                $user = Get-ADUser -Identity $Issue.DistinguishedName -Properties MemberOf
                foreach ($group in $user.MemberOf) {
                    Remove-ADGroupMember -Identity $group -Members $user -Confirm:$false
                }
                return @{Success=$true; Action="Fixed"; Details="Removed from groups"}
            }
            'Unlock-Account' {
                Unlock-ADAccount -Identity $Issue.DistinguishedName
                return @{Success=$true; Action="Fixed"; Details="Account unlocked"}
            }
            default {
                return @{Success=$false; Action="NotSupported"; Details="No fix available"}
            }
        }
    }
    catch {
        return @{Success=$false; Action="Failed"; Details=$_.Exception.Message}
    }
}

Export-ModuleMember -Function Invoke-ADScan, Invoke-ADRemediation
