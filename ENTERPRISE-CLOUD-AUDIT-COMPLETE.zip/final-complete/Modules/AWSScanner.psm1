function Invoke-AWSScanner {
    return @()
}
Export-ModuleMember -Function Invoke-AWSScanner
