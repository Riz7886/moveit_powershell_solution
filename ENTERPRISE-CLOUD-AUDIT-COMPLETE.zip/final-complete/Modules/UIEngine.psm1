function Start-UI {
    param($Issues, $OutputPath)
    
    $htmlPath = Join-Path $OutputPath "Dashboard.html"
    
    $critical = ($Issues | Where-Object { $_.Severity -eq 'Critical' }).Count
    $high = ($Issues | Where-Object { $_.Severity -eq 'High' }).Count
    $medium = ($Issues | Where-Object { $_.Severity -eq 'Medium' }).Count
    $low = ($Issues | Where-Object { $_.Severity -eq 'Low' }).Count
    
    $html = @"
<!DOCTYPE html>
<html>
<head>
<title>Enterprise Cloud Audit Dashboard</title>
<style>
body{font-family:Arial;margin:20px;background:#f5f5f5}
h1{color:#333}
.summary{background:white;padding:20px;border-radius:5px;margin:20px 0}
.critical{color:#d32f2f;font-weight:bold}
.high{color:#f57c00;font-weight:bold}
.medium{color:#fbc02d;font-weight:bold}
.low{color:#388e3c;font-weight:bold}
table{width:100%;border-collapse:collapse;background:white}
th,td{padding:12px;text-align:left;border-bottom:1px solid #ddd}
th{background-color:#1976d2;color:white}
tr:hover{background-color:#f5f5f5}
</style>
</head>
<body>
<h1>Enterprise Cloud Audit Dashboard</h1>
<div class="summary">
<h2>Audit Summary</h2>
<p>Total Issues: $($Issues.Count)</p>
<p><span class="critical">Critical: $critical</span></p>
<p><span class="high">High: $high</span></p>
<p><span class="medium">Medium: $medium</span></p>
<p><span class="low">Low: $low</span></p>
</div>
<table>
<tr><th>Resource</th><th>Issue</th><th>Severity</th><th>Category</th></tr>
"@
    
    foreach ($issue in $Issues | Select-Object -First 100) {
        $html += "<tr><td>$($issue.Resource)</td><td>$($issue.Issue)</td><td class='$($issue.Severity.ToLower())'>$($issue.Severity)</td><td>$($issue.Category)</td></tr>"
    }
    
    $html += "</table></body></html>"
    
    $html | Out-File -FilePath $htmlPath -Encoding UTF8
    Write-Host "Dashboard: $htmlPath" -ForegroundColor Green
}

Export-ModuleMember -Function Start-UI
