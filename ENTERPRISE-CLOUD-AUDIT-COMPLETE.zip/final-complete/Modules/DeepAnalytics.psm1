function Invoke-DeepAnalytics {
    return @()
}
Export-ModuleMember -Function Invoke-DeepAnalytics
