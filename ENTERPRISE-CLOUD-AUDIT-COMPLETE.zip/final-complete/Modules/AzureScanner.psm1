function Invoke-AzureScan {
    param([array]$Subscriptions)
    
    $issues = @()
    $Global:CostReport = @()
    $Global:NSGReport = @()
    
    foreach ($sub in $Subscriptions) {
        Write-Host ""
        Write-Host "================================================================" -ForegroundColor Cyan
        Write-Host "Scanning Subscription: $($sub.Name)" -ForegroundColor White
        Write-Host "================================================================" -ForegroundColor Cyan
        Write-Host ""
        
        Set-AzContext -SubscriptionId $sub.Id | Out-Null
        
        Write-Host "Scanning VMs..." -ForegroundColor Cyan
        $vms = Get-AzVM -Status
        $stoppedVMs = $vms | Where-Object { $_.PowerState -eq 'VM deallocated' -or $_.PowerState -eq 'VM stopped' }
        Write-Host "  Total VMs: $($vms.Count)" -ForegroundColor White
        Write-Host "  Running: $(($vms | Where-Object { $_.PowerState -eq 'VM running' }).Count)" -ForegroundColor Green
        Write-Host "  Stopped: $($stoppedVMs.Count)" -ForegroundColor Yellow
        
        foreach ($vm in $stoppedVMs) {
            $vmDetail = Get-AzVM -ResourceGroupName $vm.ResourceGroupName -Name $vm.Name
            $vmSize = $vmDetail.HardwareProfile.VmSize
            
            $monthlyCost = switch -Wildcard ($vmSize) {
                '*B1s*' { 7.59 }
                '*B1ms*' { 15.18 }
                '*B2s*' { 30.37 }
                '*B2ms*' { 60.74 }
                '*D2s*' { 96.36 }
                '*D4s*' { 192.72 }
                '*D8s*' { 385.44 }
                '*D16s*' { 770.88 }
                '*E2s*' { 121.68 }
                '*E4s*' { 243.36 }
                '*E8s*' { 486.72 }
                '*F2s*' { 84.00 }
                '*F4s*' { 168.00 }
                default { 100.00 }
            }
            
            $diskCost = 0
            foreach ($disk in $vmDetail.StorageProfile.DataDisks) {
                $diskObj = Get-AzDisk -ResourceGroupName $vm.ResourceGroupName -DiskName $disk.Name -ErrorAction SilentlyContinue
                if ($diskObj) {
                    $diskSize = $diskObj.DiskSizeGB
                    $diskCost += [math]::Round($diskSize * 0.05, 2)
                }
            }
            
            $totalMonthlyCost = $monthlyCost + $diskCost
            
            try {
                $logs = Get-AzActivityLog -ResourceId $vmDetail.Id -MaxRecord 100 -ErrorAction SilentlyContinue | 
                    Where-Object { $_.OperationName.Value -like '*deallocate*' -or $_.OperationName.Value -like '*powerOff*' } | 
                    Sort-Object EventTimestamp -Descending | 
                    Select-Object -First 1
                
                $stopDate = if ($logs) { $logs.EventTimestamp } else { Get-Date }
                $daysStopped = ((Get-Date) - $stopDate).Days
            }
            catch {
                $stopDate = "Unknown"
                $daysStopped = 0
            }
            
            $issues += [PSCustomObject]@{
                Type = 'Azure'
                Category = 'Compute'
                Severity = 'Medium'
                Resource = $vm.Name
                Issue = 'VM Stopped'
                Remediation = 'Start-VM'
                AutoFixable = $true
                ResourceGroup = $vm.ResourceGroupName
                SubscriptionId = $sub.Id
                SubscriptionName = $sub.Name
                VMSize = $vmSize
                MonthlyCost = $totalMonthlyCost
                DaysStopped = $daysStopped
                StopDate = $stopDate
                CostSaving = [math]::Round(($daysStopped / 30) * $totalMonthlyCost, 2)
            }
            
            $Global:CostReport += [PSCustomObject]@{
                Subscription = $sub.Name
                ResourceType = 'Virtual Machine'
                ResourceName = $vm.Name
                ResourceGroup = $vm.ResourceGroupName
                Status = 'Stopped'
                Size = $vmSize
                MonthlyCost = $totalMonthlyCost
                DaysStopped = $daysStopped
                StopDate = $stopDate
                MonthlySavings = $totalMonthlyCost
                YearlySavings = $totalMonthlyCost * 12
            }
        }
        
        Write-Host ""
        Write-Host "================================================================" -ForegroundColor Cyan
        Write-Host "DETAILED NSG ANALYSIS" -ForegroundColor White
        Write-Host "================================================================" -ForegroundColor Cyan
        Write-Host ""
        
        $nsgs = Get-AzNetworkSecurityGroup
        Write-Host "Total NSGs: $($nsgs.Count)" -ForegroundColor White
        Write-Host ""
        
        foreach ($nsg in $nsgs) {
            Write-Host "NSG: $($nsg.Name)" -ForegroundColor Cyan
            Write-Host "  Resource Group: $($nsg.ResourceGroupName)" -ForegroundColor Gray
            Write-Host "  Location: $($nsg.Location)" -ForegroundColor Gray
            Write-Host "  Total Rules: $($nsg.SecurityRules.Count)" -ForegroundColor White
            Write-Host ""
            
            Write-Host "  Inbound Rules:" -ForegroundColor Yellow
            
            foreach ($rule in $nsg.SecurityRules | Where-Object { $_.Direction -eq 'Inbound' }) {
                $ruleColor = if ($rule.Access -eq 'Allow') { 'Green' } else { 'Red' }
                $priority = $rule.Priority
                
                Write-Host "    [$priority] $($rule.Name)" -ForegroundColor $ruleColor
                Write-Host "      Direction: $($rule.Direction)" -ForegroundColor Gray
                Write-Host "      Access: $($rule.Access)" -ForegroundColor Gray
                Write-Host "      Protocol: $($rule.Protocol)" -ForegroundColor Gray
                Write-Host "      Source: $($rule.SourceAddressPrefix)" -ForegroundColor Gray
                Write-Host "      Source Port: $($rule.SourcePortRange)" -ForegroundColor Gray
                Write-Host "      Destination: $($rule.DestinationAddressPrefix)" -ForegroundColor Gray
                Write-Host "      Destination Port: $($rule.DestinationPortRange)" -ForegroundColor Gray
                Write-Host ""
                
                $Global:NSGReport += [PSCustomObject]@{
                    Subscription = $sub.Name
                    NSG = $nsg.Name
                    ResourceGroup = $nsg.ResourceGroupName
                    RuleName = $rule.Name
                    Priority = $rule.Priority
                    Direction = $rule.Direction
                    Access = $rule.Access
                    Protocol = $rule.Protocol
                    SourceAddress = $rule.SourceAddressPrefix
                    SourcePort = $rule.SourcePortRange
                    DestinationAddress = $rule.DestinationAddressPrefix
                    DestinationPort = $rule.DestinationPortRange
                    Description = $rule.Description
                }
                
                if ($rule.Access -eq 'Allow' -and 
                    $rule.SourceAddressPrefix -eq '*' -and 
                    $rule.DestinationAddressPrefix -eq '*') {
                    
                    $issues += [PSCustomObject]@{
                        Type = 'Azure'
                        Category = 'Security'
                        Severity = 'Critical'
                        Resource = "$($nsg.Name) - Rule: $($rule.Name)"
                        Issue = 'NSG Allow Any-to-Any Rule'
                        Remediation = 'Remove-DangerousRule'
                        AutoFixable = $true
                        ResourceGroup = $nsg.ResourceGroupName
                        SubscriptionId = $sub.Id
                        SubscriptionName = $sub.Name
                        NSGName = $nsg.Name
                        RuleName = $rule.Name
                        Priority = $rule.Priority
                        SourcePort = $rule.SourcePortRange
                        DestinationPort = $rule.DestinationPortRange
                    }
                    
                    Write-Host "      WARNING: Any-to-Any rule detected" -ForegroundColor Red
                    Write-Host ""
                }
                
                $dangerousPorts = @{
                    '3389' = 'RDP'
                    '22' = 'SSH'
                    '1433' = 'SQL Server'
                    '3306' = 'MySQL'
                    '5432' = 'PostgreSQL'
                    '21' = 'FTP'
                    '23' = 'Telnet'
                    '445' = 'SMB'
                    '139' = 'NetBIOS'
                    '135' = 'RPC'
                    '1521' = 'Oracle'
                    '5900' = 'VNC'
                    '5984' = 'CouchDB'
                    '6379' = 'Redis'
                    '7001' = 'Cassandra'
                    '8020' = 'Hadoop'
                    '8086' = 'InfluxDB'
                    '9042' = 'Cassandra'
                    '9200' = 'Elasticsearch'
                    '11211' = 'Memcached'
                    '27017' = 'MongoDB'
                }
                
                foreach ($port in $dangerousPorts.Keys) {
                    if ($rule.Access -eq 'Allow' -and 
                        $rule.DestinationPortRange -contains $port -and
                        $rule.SourceAddressPrefix -eq '*') {
                        
                        $issues += [PSCustomObject]@{
                            Type = 'Azure'
                            Category = 'Security'
                            Severity = 'Critical'
                            Resource = "$($nsg.Name) - Rule: $($rule.Name)"
                            Issue = "$($dangerousPorts[$port]) Port $port Open to Internet"
                            Remediation = 'Restrict-Source'
                            AutoFixable = $true
                            ResourceGroup = $nsg.ResourceGroupName
                            SubscriptionId = $sub.Id
                            SubscriptionName = $sub.Name
                            NSGName = $nsg.Name
                            RuleName = $rule.Name
                            Port = $port
                            Protocol = $rule.Protocol
                        }
                        
                        Write-Host "      CRITICAL: Port $port ($($dangerousPorts[$port])) open to internet" -ForegroundColor Red
                        Write-Host ""
                    }
                }
            }
            
            Write-Host "  Outbound Rules:" -ForegroundColor Yellow
            
            foreach ($rule in $nsg.SecurityRules | Where-Object { $_.Direction -eq 'Outbound' }) {
                $ruleColor = if ($rule.Access -eq 'Allow') { 'Green' } else { 'Red' }
                
                Write-Host "    [$($rule.Priority)] $($rule.Name)" -ForegroundColor $ruleColor
                Write-Host "      Access: $($rule.Access)" -ForegroundColor Gray
                Write-Host "      Protocol: $($rule.Protocol)" -ForegroundColor Gray
                Write-Host "      Destination: $($rule.DestinationAddressPrefix)" -ForegroundColor Gray
                Write-Host "      Destination Port: $($rule.DestinationPortRange)" -ForegroundColor Gray
                Write-Host ""
                
                $Global:NSGReport += [PSCustomObject]@{
                    Subscription = $sub.Name
                    NSG = $nsg.Name
                    ResourceGroup = $nsg.ResourceGroupName
                    RuleName = $rule.Name
                    Priority = $rule.Priority
                    Direction = $rule.Direction
                    Access = $rule.Access
                    Protocol = $rule.Protocol
                    SourceAddress = $rule.SourceAddressPrefix
                    SourcePort = $rule.SourcePortRange
                    DestinationAddress = $rule.DestinationAddressPrefix
                    DestinationPort = $rule.DestinationPortRange
                    Description = $rule.Description
                }
            }
            
            Write-Host ""
        }
        
        Write-Host "Scanning VNets and Subnets..." -ForegroundColor Cyan
        $vnets = Get-AzVirtualNetwork
        Write-Host "  Total VNets: $($vnets.Count)" -ForegroundColor White
        
        foreach ($vnet in $vnets) {
            Write-Host "    $($vnet.Name)" -ForegroundColor White
            Write-Host "      Address Space: $($vnet.AddressSpace.AddressPrefixes -join ', ')" -ForegroundColor Gray
            Write-Host "      Subnets: $($vnet.Subnets.Count)" -ForegroundColor Gray
            
            foreach ($subnet in $vnet.Subnets) {
                $subnetUsage = $subnet.IpConfigurations.Count
                $subnetSize = [math]::Pow(2, (32 - [int]$subnet.AddressPrefix.Split('/')[1])) - 5
                $subnetUtilization = if ($subnetSize -gt 0) { [math]::Round(($subnetUsage / $subnetSize) * 100, 2) } else { 0 }
                
                $utilizationColor = if ($subnetUtilization -gt 80) { 'Red' } elseif ($subnetUtilization -gt 60) { 'Yellow' } else { 'Green' }
                
                Write-Host "        $($subnet.Name): $($subnet.AddressPrefix)" -ForegroundColor Gray
                Write-Host "          IPs Used: $subnetUsage / $subnetSize ($subnetUtilization%)" -ForegroundColor $utilizationColor
                
                if ($subnetUtilization -gt 80) {
                    $issues += [PSCustomObject]@{
                        Type = 'Azure'
                        Category = 'Networking'
                        Severity = 'High'
                        Resource = "$($vnet.Name)/$($subnet.Name)"
                        Issue = "Subnet $subnetUtilization% Full"
                        Remediation = 'Expand-Subnet'
                        AutoFixable = $false
                        ResourceGroup = $vnet.ResourceGroupName
                        SubscriptionId = $sub.Id
                        SubscriptionName = $sub.Name
                    }
                }
            }
            Write-Host ""
        }
        
        Write-Host "Scanning Storage Accounts..." -ForegroundColor Cyan
        $storageAccounts = Get-AzStorageAccount
        Write-Host "  Total Storage Accounts: $($storageAccounts.Count)" -ForegroundColor White
        
        foreach ($sa in $storageAccounts) {
            Write-Host "    $($sa.StorageAccountName)" -ForegroundColor White
            Write-Host "      SKU: $($sa.Sku.Name)" -ForegroundColor Gray
            Write-Host "      Kind: $($sa.Kind)" -ForegroundColor Gray
            Write-Host "      Location: $($sa.Location)" -ForegroundColor Gray
            
            if ($sa.AllowBlobPublicAccess) {
                Write-Host "      WARNING: Public Blob Access Enabled" -ForegroundColor Red
                $issues += [PSCustomObject]@{
                    Type = 'Azure'
                    Category = 'Security'
                    Severity = 'High'
                    Resource = $sa.StorageAccountName
                    Issue = 'Public Blob Access Enabled'
                    Remediation = 'Disable-PublicAccess'
                    AutoFixable = $true
                    ResourceGroup = $sa.ResourceGroupName
                    SubscriptionId = $sub.Id
                    SubscriptionName = $sub.Name
                }
            }
            
            if (-not $sa.EnableHttpsTrafficOnly) {
                Write-Host "      WARNING: HTTPS Not Enforced" -ForegroundColor Red
                $issues += [PSCustomObject]@{
                    Type = 'Azure'
                    Category = 'Security'
                    Severity = 'High'
                    Resource = $sa.StorageAccountName
                    Issue = 'HTTPS Not Enforced'
                    Remediation = 'Enable-HTTPS'
                    AutoFixable = $true
                    ResourceGroup = $sa.ResourceGroupName
                    SubscriptionId = $sub.Id
                    SubscriptionName = $sub.Name
                }
            }
            
            if ($sa.AllowBlobPublicAccess -eq $false -and $sa.EnableHttpsTrafficOnly) {
                Write-Host "      OK: Secure Configuration" -ForegroundColor Green
            }
            Write-Host ""
        }
        
        Write-Host "Scanning Resource Groups..." -ForegroundColor Cyan
        $resourceGroups = Get-AzResourceGroup
        Write-Host "  Total Resource Groups: $($resourceGroups.Count)" -ForegroundColor White
        
        foreach ($rg in $resourceGroups) {
            $resources = Get-AzResource -ResourceGroupName $rg.ResourceGroupName
            Write-Host "    $($rg.ResourceGroupName): $($resources.Count) resources" -ForegroundColor White
            
            if ($resources.Count -eq 0) {
                $issues += [PSCustomObject]@{
                    Type = 'Azure'
                    Category = 'Cleanup'
                    Severity = 'Low'
                    Resource = $rg.ResourceGroupName
                    Issue = 'Empty Resource Group'
                    Remediation = 'Delete-ResourceGroup'
                    AutoFixable = $false
                    SubscriptionId = $sub.Id
                    SubscriptionName = $sub.Name
                }
            }
        }
        Write-Host ""
        
        Write-Host "Scanning RBAC Assignments..." -ForegroundColor Cyan
        $roleAssignments = Get-AzRoleAssignment
        $ownerAssignments = $roleAssignments | Where-Object { $_.RoleDefinitionName -eq 'Owner' }
        $contributorAssignments = $roleAssignments | Where-Object { $_.RoleDefinitionName -eq 'Contributor' }
        
        Write-Host "  Total Role Assignments: $($roleAssignments.Count)" -ForegroundColor White
        Write-Host "    Owners: $($ownerAssignments.Count)" -ForegroundColor Yellow
        Write-Host "    Contributors: $($contributorAssignments.Count)" -ForegroundColor White
        
        if ($ownerAssignments.Count -gt 5) {
            $issues += [PSCustomObject]@{
                Type = 'Azure'
                Category = 'Security'
                Severity = 'High'
                Resource = 'Subscription'
                Issue = "Too Many Owners ($($ownerAssignments.Count))"
                Remediation = 'Review-RBAC'
                AutoFixable = $false
                SubscriptionId = $sub.Id
                SubscriptionName = $sub.Name
            }
        }
        Write-Host ""
    }
    
    Write-Host ""
    Write-Host "Azure Scan Complete" -ForegroundColor Green
    Write-Host "Total Issues: $($issues.Count)" -ForegroundColor Yellow
    Write-Host ""
    
    return $issues
}

function Invoke-AzureRemediation {
    param($Issue)
    
    try {
        Set-AzContext -SubscriptionId $Issue.SubscriptionId | Out-Null
        
        switch ($Issue.Remediation) {
            'Start-VM' {
                $confirm = Read-Host "Start VM $($Issue.Resource)? (Y/N)"
                if ($confirm -ne 'Y') {
                    return @{Success=$false; Action="Skipped"; Details="User declined"}
                }
                Start-AzVM -ResourceGroupName $Issue.ResourceGroup -Name $Issue.Resource -NoWait
                return @{Success=$true; Action="Started"; Details="VM start initiated"}
            }
            'Remove-DangerousRule' {
                $confirm = Read-Host "Remove dangerous NSG rule $($Issue.RuleName)? (Y/N)"
                if ($confirm -ne 'Y') {
                    return @{Success=$false; Action="Skipped"; Details="User declined"}
                }
                $nsg = Get-AzNetworkSecurityGroup -ResourceGroupName $Issue.ResourceGroup -Name $Issue.NSGName
                Remove-AzNetworkSecurityRuleConfig -Name $Issue.RuleName -NetworkSecurityGroup $nsg
                Set-AzNetworkSecurityGroup -NetworkSecurityGroup $nsg
                return @{Success=$true; Action="Fixed"; Details="Dangerous rule removed"}
            }
            'Disable-PublicAccess' {
                $confirm = Read-Host "Disable public blob access on $($Issue.Resource)? (Y/N)"
                if ($confirm -ne 'Y') {
                    return @{Success=$false; Action="Skipped"; Details="User declined"}
                }
                Set-AzStorageAccount -ResourceGroupName $Issue.ResourceGroup -Name $Issue.Resource -AllowBlobPublicAccess $false
                return @{Success=$true; Action="Fixed"; Details="Public access disabled"}
            }
            'Enable-HTTPS' {
                Set-AzStorageAccount -ResourceGroupName $Issue.ResourceGroup -Name $Issue.Resource -EnableHttpsTrafficOnly $true
                return @{Success=$true; Action="Fixed"; Details="HTTPS enforced"}
            }
            default {
                return @{Success=$false; Action="NotSupported"; Details="No fix available"}
            }
        }
    }
    catch {
        return @{Success=$false; Action="Failed"; Details=$_.Exception.Message}
    }
}

Export-ModuleMember -Function Invoke-AzureScan, Invoke-AzureRemediation
