function Invoke-AutoAuditor {
    return @()
}
Export-ModuleMember -Function Invoke-AutoAuditor
