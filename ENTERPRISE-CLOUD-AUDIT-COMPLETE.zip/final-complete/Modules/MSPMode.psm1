function Invoke-MSPMode {
    return @()
}
Export-ModuleMember -Function Invoke-MSPMode
