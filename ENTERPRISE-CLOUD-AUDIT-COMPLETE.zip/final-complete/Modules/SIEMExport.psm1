function Build-SIEMExport {
    return $true
}
Export-ModuleMember -Function Build-SIEMExport
