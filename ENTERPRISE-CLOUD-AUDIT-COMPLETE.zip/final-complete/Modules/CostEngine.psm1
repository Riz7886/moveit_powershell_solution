function Invoke-CostEngine {
    param($ScanResults)
    Write-Host "Cost Engine: Analyzing cost optimization..." -ForegroundColor Cyan
    return $ScanResults
}

function Export-CostReport {
    param($CostData, $OutputPath)
    
    if ($CostData.Count -eq 0) {
        return
    }
    
    $timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $costReport = Join-Path $OutputPath "CostAnalysis_$timestamp.csv"
    $CostData | Export-Csv -Path $costReport -NoTypeInformation
    
    $totalMonthlySavings = ($CostData | Measure-Object -Property MonthlySavings -Sum).Sum
    $totalYearlySavings = ($CostData | Measure-Object -Property YearlySavings -Sum).Sum
    
    $summaryPath = Join-Path $OutputPath "CostSummary_$timestamp.txt"
    
    $summary = @"
================================================================
  COST SAVINGS ANALYSIS
================================================================

Total Stopped Resources: $($CostData.Count)

Potential Monthly Savings: `$$([math]::Round($totalMonthlySavings, 2))
Potential Yearly Savings: `$$([math]::Round($totalYearlySavings, 2))

================================================================
  TOP 10 COST SAVINGS OPPORTUNITIES
================================================================

"@
    
    $top10 = $CostData | Sort-Object MonthlySavings -Descending | Select-Object -First 10
    
    $count = 1
    foreach ($item in $top10) {
        $summary += "`n[$count] $($item.ResourceName) ($($item.ResourceType))`n"
        $summary += "    Resource Group: $($item.ResourceGroup)`n"
        $summary += "    Subscription: $($item.Subscription)`n"
        $summary += "    Size: $($item.Size)`n"
        $summary += "    Monthly Cost: `$$($item.MonthlyCost)`n"
        $summary += "    Monthly Savings: `$$($item.MonthlySavings)`n"
        $summary += "    Yearly Savings: `$$($item.YearlySavings)`n"
        $summary += "    Stopped For: $($item.DaysStopped) days`n"
        $summary += "    Stop Date: $($item.StopDate)`n"
        $count++
    }
    
    $summary | Out-File -FilePath $summaryPath -Encoding UTF8
    
    Write-Host ""
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host "  COST SAVINGS SUMMARY" -ForegroundColor White
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Stopped Resources: $($CostData.Count)" -ForegroundColor Yellow
    Write-Host "Monthly Savings: `$$([math]::Round($totalMonthlySavings, 2))" -ForegroundColor Green
    Write-Host "Yearly Savings: `$$([math]::Round($totalYearlySavings, 2))" -ForegroundColor Green
    Write-Host ""
    Write-Host "Cost Report: $costReport" -ForegroundColor Green
    Write-Host "Cost Summary: $summaryPath" -ForegroundColor Green
    Write-Host ""
}

function Export-NSGReport {
    param($NSGData, $OutputPath)
    
    if ($NSGData.Count -eq 0) {
        return
    }
    
    $timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $nsgReport = Join-Path $OutputPath "NSG_Analysis_$timestamp.csv"
    $NSGData | Export-Csv -Path $nsgReport -NoTypeInformation
    
    Write-Host "NSG Report: $nsgReport" -ForegroundColor Green
    
    $dangerousRules = $NSGData | Where-Object { $_.SourceAddress -eq '*' -and $_.Access -eq 'Allow' -and $_.Direction -eq 'Inbound' }
    
    if ($dangerousRules.Count -gt 0) {
        $dangerousPath = Join-Path $OutputPath "NSG_DangerousRules_$timestamp.txt"
        
        $dangerousReport = @"
================================================================
  DANGEROUS NSG RULES DETECTED
================================================================

Total Dangerous Rules: $($dangerousRules.Count)

WARNING: These rules allow traffic from ANY source (internet)

================================================================

"@
        
        foreach ($rule in $dangerousRules) {
            $dangerousReport += "`nNSG: $($rule.NSG)`n"
            $dangerousReport += "  Rule: $($rule.RuleName) (Priority: $($rule.Priority))`n"
            $dangerousReport += "  Protocol: $($rule.Protocol)`n"
            $dangerousReport += "  Source: $($rule.SourceAddress) (INTERNET)`n"
            $dangerousReport += "  Destination Port: $($rule.DestinationPort)`n"
            $dangerousReport += "  Resource Group: $($rule.ResourceGroup)`n"
            $dangerousReport += "  Subscription: $($rule.Subscription)`n"
            $dangerousReport += "  RISK: HIGH - Exposed to internet attacks`n"
        }
        
        $dangerousReport | Out-File -FilePath $dangerousPath -Encoding UTF8
        
        Write-Host ""
        Write-Host "================================================================" -ForegroundColor Red
        Write-Host "  WARNING: DANGEROUS NSG RULES FOUND" -ForegroundColor White
        Write-Host "================================================================" -ForegroundColor Red
        Write-Host ""
        Write-Host "Dangerous Rules: $($dangerousRules.Count)" -ForegroundColor Red
        Write-Host "Dangerous Rules Report: $dangerousPath" -ForegroundColor Yellow
        Write-Host ""
    }
}

Export-ModuleMember -Function Invoke-CostEngine, Export-CostReport, Export-NSGReport
