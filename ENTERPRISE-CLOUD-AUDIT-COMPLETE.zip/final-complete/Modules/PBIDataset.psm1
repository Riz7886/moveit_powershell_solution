function Export-PBIDataset {
    param($Issues, $OutputPath)
    
    $jsonPath = Join-Path $OutputPath "PowerBI_Data.json"
    $Issues | ConvertTo-Json -Depth 10 | Out-File -FilePath $jsonPath -Encoding UTF8
    Write-Host "PowerBI Data: $jsonPath" -ForegroundColor Green
}

Export-ModuleMember -Function Export-PBIDataset
