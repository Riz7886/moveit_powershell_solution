#Requires -Version 5.1

param(
    [Parameter(Mandatory=$false)]
    [ValidateSet('Audit','Remediate')]
    [string]$Mode = 'Audit',
    
    [Parameter(Mandatory=$false)]
    [string]$ReportPath = ".\Reports"
)

$ErrorActionPreference = 'Stop'
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$ModulePath = Join-Path $ScriptPath "Modules"

$Global:AllIssues = @()
$Global:RemediationLog = @()
$Global:SelectedSubscriptions = @()
$Global:CostReport = @()
$Global:NSGReport = @()

function Write-Header {
    param([string]$Text)
    Write-Host ""
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host "  $Text" -ForegroundColor White
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Install-Modules {
    $modules = @('Az.Accounts', 'Az.Resources', 'Az.Compute', 'Az.Network', 'Az.Storage')
    foreach ($m in $modules) {
        if (-not (Get-Module -ListAvailable -Name $m)) {
            Write-Host "Installing $m..." -ForegroundColor Yellow
            Install-Module -Name $m -Repository PSGallery -Force -AllowClobber -Scope CurrentUser -ErrorAction SilentlyContinue
        }
    }
}

function Select-Subscriptions {
    try {
        $context = Get-AzContext -ErrorAction SilentlyContinue
        if (-not $context) {
            Connect-AzAccount
        }
        
        $allSubs = Get-AzSubscription
        
        if ($allSubs.Count -eq 0) {
            Write-Host "No subscriptions found" -ForegroundColor Red
            return @()
        }
        
        Write-Host ""
        Write-Host "Available Subscriptions:" -ForegroundColor Cyan
        Write-Host ""
        
        for ($i = 0; $i -lt $allSubs.Count; $i++) {
            Write-Host "[$($i + 1)] $($allSubs[$i].Name)" -ForegroundColor White
        }
        
        Write-Host ""
        Write-Host "[A] All Subscriptions" -ForegroundColor Green
        Write-Host ""
        
        $choice = Read-Host "Select subscriptions (1-$($allSubs.Count), A for all, or comma-separated)"
        
        if ($choice -eq 'A' -or $choice -eq 'a') {
            return $allSubs
        }
        
        $selected = @()
        $choices = $choice.Split(',').Trim()
        
        foreach ($c in $choices) {
            $index = [int]$c - 1
            if ($index -ge 0 -and $index -lt $allSubs.Count) {
                $selected += $allSubs[$index]
            }
        }
        
        return $selected
    }
    catch {
        Write-Host "Azure connection failed" -ForegroundColor Yellow
        return @()
    }
}

function Load-Modules {
    $moduleFiles = Get-ChildItem -Path $ModulePath -Filter "*.psm1"
    foreach ($module in $moduleFiles) {
        Import-Module $module.FullName -Force -ErrorAction SilentlyContinue
    }
}

Write-Header "ENTERPRISE CLOUD AUDIT SUITE V6"

if (-not (Test-Path $ReportPath)) {
    New-Item -ItemType Directory -Path $ReportPath -Force | Out-Null
}

Install-Modules
Load-Modules

$Global:SelectedSubscriptions = Select-Subscriptions

if ($Global:SelectedSubscriptions.Count -gt 0) {
    Write-Host ""
    Write-Host "Selected Subscriptions: $($Global:SelectedSubscriptions.Count)" -ForegroundColor Green
    Write-Host ""
}

Write-Header "ACTIVE DIRECTORY AUDIT"

try {
    $adIssues = Invoke-ADScan
    $Global:AllIssues += $adIssues
    
    Write-Host "AD Issues Found: $($adIssues.Count)" -ForegroundColor Yellow
    
    $critical = ($adIssues | Where-Object { $_.Severity -eq 'Critical' }).Count
    $high = ($adIssues | Where-Object { $_.Severity -eq 'High' }).Count
    Write-Host "  Critical: $critical" -ForegroundColor Red
    Write-Host "  High: $high" -ForegroundColor Magenta
    Write-Host ""
}
catch {
    Write-Host "AD scan failed: $($_.Exception.Message)" -ForegroundColor Red
}

if ($Global:SelectedSubscriptions.Count -gt 0) {
    Write-Header "AZURE ENVIRONMENT AUDIT"
    
    try {
        $azureIssues = Invoke-AzureScan -Subscriptions $Global:SelectedSubscriptions
        $Global:AllIssues += $azureIssues
        
        Write-Host "Azure Issues Found: $($azureIssues.Count)" -ForegroundColor Yellow
    }
    catch {
        Write-Host "Azure scan failed: $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Header "AUDIT SUMMARY"

Write-Host "Total Issues: $($Global:AllIssues.Count)" -ForegroundColor Yellow
Write-Host ""

$fixable = ($Global:AllIssues | Where-Object { $_.AutoFixable -eq $true }).Count
Write-Host "Auto-Fixable: $fixable" -ForegroundColor Green
Write-Host ""

if ($Mode -eq 'Remediate' -and $fixable -gt 0) {
    Write-Header "REMEDIATION MODE"
    
    $confirm = Read-Host "Proceed with remediation? (Y/N)"
    
    if ($confirm -eq 'Y') {
        $fixableIssues = $Global:AllIssues | Where-Object { $_.AutoFixable -eq $true }
        
        foreach ($issue in $fixableIssues) {
            $result = $null
            
            switch ($issue.Type) {
                'AD' {
                    $result = Invoke-ADRemediation -Issue $issue
                }
                'Azure' {
                    $result = Invoke-AzureRemediation -Issue $issue
                }
            }
            
            if ($result) {
                $logEntry = [PSCustomObject]@{
                    Timestamp = Get-Date
                    Environment = $issue.Type
                    Resource = $issue.Resource
                    Issue = $issue.Issue
                    Action = $result.Action
                    Success = $result.Success
                    Details = $result.Details
                }
                
                $Global:RemediationLog += $logEntry
                
                $color = if ($result.Success) { 'Green' } else { 'Red' }
                Write-Host "[$($result.Action)] $($issue.Resource)" -ForegroundColor $color
            }
        }
        
        Write-Host ""
        Write-Header "REMEDIATION SUMMARY"
        
        $fixed = ($Global:RemediationLog | Where-Object { $_.Success -eq $true }).Count
        Write-Host "Issues Fixed: $fixed" -ForegroundColor Green
    }
}

$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'

$auditReport = Join-Path $ReportPath "AuditReport_$timestamp.csv"
$Global:AllIssues | Export-Csv -Path $auditReport -NoTypeInformation

Write-Host ""
Write-Host "Report: $auditReport" -ForegroundColor Green

if ($Global:RemediationLog.Count -gt 0) {
    $remLog = Join-Path $ReportPath "RemediationLog_$timestamp.csv"
    $Global:RemediationLog | Export-Csv -Path $remLog -NoTypeInformation
    Write-Host "Remediation Log: $remLog" -ForegroundColor Green
}

try {
    Export-CostReport -CostData $Global:CostReport -OutputPath $ReportPath
}
catch {}

try {
    Export-NSGReport -NSGData $Global:NSGReport -OutputPath $ReportPath
}
catch {}

try {
    Start-UI -Issues $Global:AllIssues -OutputPath $ReportPath
}
catch {}

try {
    Export-PBIDataset -Issues $Global:AllIssues -OutputPath $ReportPath
}
catch {}

Write-Host ""
Write-Header "AUDIT COMPLETE"
