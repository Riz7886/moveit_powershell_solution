param(
    [Parameter(Mandatory=$false)]
    [string]$ResourceGroupName = "rg-url-redirects",
    
    [Parameter(Mandatory=$false)]
    [string]$AppServiceName = "pyxhealth-redirects",
    
    [Parameter(Mandatory=$false)]
    [string]$Location = "eastus"
)

$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  PYXHEALTH URL REDIRECT DEPLOYMENT" -ForegroundColor White
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "Checking Azure connection..." -ForegroundColor Cyan
$context = Get-AzContext -ErrorAction SilentlyContinue

if (-not $context) {
    Write-Host "Connecting to Azure..." -ForegroundColor Yellow
    Connect-AzAccount | Out-Null
    $context = Get-AzContext
}

Write-Host "Connected as: $($context.Account.Id)" -ForegroundColor Green
Write-Host ""

Write-Host "Loading subscriptions..." -ForegroundColor Cyan
$allSubs = Get-AzSubscription

if ($allSubs.Count -eq 0) {
    Write-Host "No subscriptions found" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Available Subscriptions:" -ForegroundColor Cyan
Write-Host ""

for ($i = 0; $i -lt $allSubs.Count; $i++) {
    Write-Host "[$($i + 1)] $($allSubs[$i].Name)" -ForegroundColor White
}

Write-Host ""
$choice = Read-Host "Select subscription (1-$($allSubs.Count))"

$selectedIndex = [int]$choice - 1
if ($selectedIndex -lt 0 -or $selectedIndex -ge $allSubs.Count) {
    Write-Host "Invalid selection" -ForegroundColor Red
    exit 1
}

$selectedSub = $allSubs[$selectedIndex]
Set-AzContext -SubscriptionId $selectedSub.Id | Out-Null

Write-Host ""
Write-Host "Selected: $($selectedSub.Name)" -ForegroundColor Green
Write-Host ""

Write-Host "Step 1: Creating Resource Group..." -ForegroundColor Cyan
$rg = Get-AzResourceGroup -Name $ResourceGroupName -ErrorAction SilentlyContinue

if (-not $rg) {
    New-AzResourceGroup -Name $ResourceGroupName -Location $Location | Out-Null
    Write-Host "Resource Group created: $ResourceGroupName" -ForegroundColor Green
}
else {
    Write-Host "Resource Group exists: $ResourceGroupName" -ForegroundColor Yellow
}
Write-Host ""

Write-Host "Step 2: Creating App Service Plan..." -ForegroundColor Cyan
$appServicePlan = Get-AzAppServicePlan -ResourceGroupName $ResourceGroupName -Name "$AppServiceName-plan" -ErrorAction SilentlyContinue

if (-not $appServicePlan) {
    New-AzAppServicePlan -ResourceGroupName $ResourceGroupName `
        -Name "$AppServiceName-plan" `
        -Location $Location `
        -Tier "Basic" `
        -WorkerSize "Small" | Out-Null
    
    Write-Host "App Service Plan created (Basic B1)" -ForegroundColor Green
}
else {
    Write-Host "App Service Plan exists" -ForegroundColor Yellow
}
Write-Host ""

Write-Host "Step 3: Creating Web App..." -ForegroundColor Cyan
$webApp = Get-AzWebApp -ResourceGroupName $ResourceGroupName -Name $AppServiceName -ErrorAction SilentlyContinue

if (-not $webApp) {
    New-AzWebApp -ResourceGroupName $ResourceGroupName `
        -Name $AppServiceName `
        -Location $Location `
        -AppServicePlan "$AppServiceName-plan" | Out-Null
    
    Write-Host "Web App created: $AppServiceName" -ForegroundColor Green
}
else {
    Write-Host "Web App exists: $AppServiceName" -ForegroundColor Yellow
}
Write-Host ""

Write-Host "Step 4: Configuring security..." -ForegroundColor Cyan

Set-AzWebApp -ResourceGroupName $ResourceGroupName `
    -Name $AppServiceName `
    -HttpsOnly $true `
    -MinTlsVersion "1.2" | Out-Null

Write-Host "HTTPS-only mode: ENABLED" -ForegroundColor Green
Write-Host "Minimum TLS version: 1.2" -ForegroundColor Green

$webApp = Get-AzWebApp -ResourceGroupName $ResourceGroupName -Name $AppServiceName
$webApp.SiteConfig.FtpsState = "Disabled"
$webApp.SiteConfig.Http20Enabled = $true
$webApp.SiteConfig.AlwaysOn = $true
Set-AzWebApp -ResourceGroupName $ResourceGroupName -Name $AppServiceName -SiteConfig $webApp.SiteConfig | Out-Null

Write-Host "FTP access: DISABLED" -ForegroundColor Green
Write-Host "HTTP/2: ENABLED" -ForegroundColor Green
Write-Host "Always On: ENABLED" -ForegroundColor Green
Write-Host ""

Write-Host "Step 5: Deploying configuration..." -ForegroundColor Cyan

$tempZip = "$env:TEMP\redirect-deploy.zip"

if (Test-Path $tempZip) {
    Remove-Item $tempZip -Force
}

$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path

if (Test-Path "$scriptPath\web.config") {
    $filesToZip = @("$scriptPath\web.config")
    
    if (Test-Path "$scriptPath\index.html") {
        $filesToZip += "$scriptPath\index.html"
    }
    if (Test-Path "$scriptPath\403.html") {
        $filesToZip += "$scriptPath\403.html"
    }
    if (Test-Path "$scriptPath\404.html") {
        $filesToZip += "$scriptPath\404.html"
    }
    if (Test-Path "$scriptPath\500.html") {
        $filesToZip += "$scriptPath\500.html"
    }
    
    Compress-Archive -Path $filesToZip -DestinationPath $tempZip -Force
    
    Publish-AzWebApp -ResourceGroupName $ResourceGroupName `
        -Name $AppServiceName `
        -ArchivePath $tempZip `
        -Force | Out-Null
    
    Write-Host "Configuration deployed" -ForegroundColor Green
}
else {
    Write-Host "Warning: web.config not found in script directory" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Step 6: Enabling diagnostic logging..." -ForegroundColor Cyan

Set-AzWebApp -ResourceGroupName $ResourceGroupName `
    -Name $AppServiceName `
    -DetailedErrorLoggingEnabled $true `
    -HttpLoggingEnabled $true `
    -RequestTracingEnabled $true | Out-Null

Write-Host "Diagnostic logging: ENABLED" -ForegroundColor Green
Write-Host ""

Write-Host "================================================================" -ForegroundColor Green
Write-Host "  DEPLOYMENT COMPLETE" -ForegroundColor White
Write-Host "================================================================" -ForegroundColor Green
Write-Host ""

Write-Host "Default URL: https://$AppServiceName.azurewebsites.net" -ForegroundColor Cyan
Write-Host ""

Write-Host "NEXT STEPS:" -ForegroundColor Yellow
Write-Host ""
Write-Host "1. Go to GoDaddy DNS settings for pyxhealth.com" -ForegroundColor White
Write-Host ""
Write-Host "2. Add these CNAME records:" -ForegroundColor White
Write-Host "   softwareintake  ->  $AppServiceName.azurewebsites.net" -ForegroundColor Cyan
Write-Host "   outage          ->  $AppServiceName.azurewebsites.net" -ForegroundColor Cyan
Write-Host "   foodbox         ->  $AppServiceName.azurewebsites.net" -ForegroundColor Cyan
Write-Host ""
Write-Host "3. Wait 5-10 minutes for DNS propagation" -ForegroundColor White
Write-Host ""
Write-Host "4. In Azure Portal, add SSL bindings:" -ForegroundColor White
Write-Host "   Go to: Custom domains -> Add binding -> SNI SSL" -ForegroundColor Cyan
Write-Host ""
Write-Host "5. Test the URLs:" -ForegroundColor White
Write-Host "   https://softwareintake.pyxhealth.com" -ForegroundColor Cyan
Write-Host "   https://outage.pyxhealth.com" -ForegroundColor Cyan
Write-Host "   https://foodbox.pyxhealth.com" -ForegroundColor Cyan
Write-Host ""
