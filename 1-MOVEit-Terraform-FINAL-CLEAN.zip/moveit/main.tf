# MOVEit Transfer Terraform - Main Configuration
terraform {
  required_version = ">= 1.5.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.80.0"
    }
  }
  backend "azurerm" {
    resource_group_name  = "rg-terraform-state"
    storage_account_name = "stterraformstate"
    container_name       = "tfstate"
    key                  = "moveit.terraform.tfstate"
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
}

locals {
  common_tags = merge(var.tags, {
    Environment = var.environment
    ManagedBy   = "Terraform"
    Project     = "MOVEit"
  })
}

resource "azurerm_resource_group" "moveit" {
  name     = "rg-${var.project_name}-${var.environment}-moveit"
  location = var.location
  tags     = local.common_tags
}

resource "azurerm_virtual_network" "moveit" {
  name                = "vnet-${var.project_name}-${var.environment}"
  location            = azurerm_resource_group.moveit.location
  resource_group_name = azurerm_resource_group.moveit.name
  address_space       = var.vnet_address_space
  tags                = local.common_tags
}

resource "azurerm_subnet" "moveit" {
  name                 = "snet-moveit"
  resource_group_name  = azurerm_resource_group.moveit.name
  virtual_network_name = azurerm_virtual_network.moveit.name
  address_prefixes     = var.subnet_address_prefixes
}

resource "azurerm_network_security_group" "moveit" {
  name                = "nsg-moveit"
  location            = azurerm_resource_group.moveit.location
  resource_group_name = azurerm_resource_group.moveit.name
  tags                = local.common_tags

  security_rule {
    name                       = "Allow-HTTPS"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "Allow-SFTP"
    priority                   = 110
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "22"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }
}
