subscription_id = "YOUR-TEST-SUBSCRIPTION-ID"
tenant_id       = "YOUR-TENANT-ID"
environment     = "test"
location        = "eastus"
project_name    = "moveit"

vnet_address_space      = ["10.1.0.0/16"]
subnet_address_prefixes = ["10.1.1.0/24"]

tags = {
  Application        = "MOVEit"
  BusinessUnit       = "IT"
  CriticalityTier    = "Tier3"
  DataClassification = "Internal"
}
