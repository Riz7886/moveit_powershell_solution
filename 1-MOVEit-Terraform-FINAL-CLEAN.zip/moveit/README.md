# MOVEit Transfer - Terraform Deployment

## Overview
Deploy MOVEit Transfer infrastructure on Azure using Terraform.

## Files
- `main.tf` - Main infrastructure configuration
- `variables.tf` - Variable definitions
- `outputs.tf` - Output values
- `environments/` - Environment-specific configurations

## Quick Start

### 1. Update Configuration
Edit `environments/terraform-prod.tfvars`:
```hcl
subscription_id = "your-subscription-id"
tenant_id       = "your-tenant-id"
```

### 2. Initialize
```bash
terraform init
```

### 3. Plan
```bash
terraform plan -var-file=environments/terraform-prod.tfvars
```

### 4. Apply
```bash
terraform apply -var-file=environments/terraform-prod.tfvars
```

## Environments
- **prod** - Production environment
- **dev** - Development environment  
- **test** - Test environment

## Outputs
- `resource_group_name` - Resource group name
- `vnet_id` - Virtual network ID
- `subnet_id` - Subnet ID

## Resources Created
- Resource Group
- Virtual Network
- Subnet
- Network Security Group
- NSG Rules (HTTPS, SFTP)

## Troubleshooting
See `TROUBLESHOOTING.md` for common issues and solutions.

## Requirements
- Terraform >= 1.5.0
- Azure CLI
- Azure subscription with appropriate permissions
