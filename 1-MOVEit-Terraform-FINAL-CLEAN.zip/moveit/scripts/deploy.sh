#!/bin/bash
set -e

echo "============================================"
echo "MOVEIT AUTOMATED DEPLOYMENT"
echo "============================================"

ENV=${1:-dev}

# Step 1: Setup backend (auto-creates if needed)
echo ""
echo "Step 1: Setting up backend storage..."
./scripts/setup-backend.sh

# Step 2: Initialize Terraform
echo ""
echo "Step 2: Initializing Terraform..."
terraform init -reconfigure -backend-config="key=moveit-${ENV}.tfstate"

# Step 3: Validate
echo ""
echo "Step 3: Validating configuration..."
terraform validate

# Step 4: Plan
echo ""
echo "Step 4: Creating deployment plan..."
terraform plan -var-file="environments/terraform-${ENV}.tfvars" -out="tfplan-${ENV}"

# Step 5: Apply
echo ""
echo "Step 5: Applying deployment..."
terraform apply -auto-approve "tfplan-${ENV}"

# Step 6: Show outputs
echo ""
echo "Step 6: Deployment outputs..."
terraform output

rm -f "tfplan-${ENV}"

echo ""
echo "============================================"
echo "DEPLOYMENT COMPLETE"
echo "============================================"
