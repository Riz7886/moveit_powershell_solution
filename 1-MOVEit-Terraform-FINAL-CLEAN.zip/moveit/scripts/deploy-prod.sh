#!/bin/bash
set -e

echo "============================================"
echo "MOVEIT - PRODUCTION DEPLOYMENT"
echo "============================================"
echo ""

ENV="prod"

# Step 1: Setup backend
echo "Step 1: Setting up backend storage..."
./scripts/setup-backend.sh

# Step 2: Initialize
echo ""
echo "Step 2: Initializing Terraform..."
terraform init -reconfigure -backend-config="key=moveit-${ENV}.tfstate"

# Step 3: Validate
echo ""
echo "Step 3: Validating..."
terraform validate

# Step 4: Plan
echo ""
echo "Step 4: Creating plan..."
terraform plan -var-file="environments/terraform-${ENV}.tfvars" -out="tfplan-${ENV}"

# Step 5: Manual approval
echo ""
read -p "Deploy to PRODUCTION? (yes/no): " approval

if [ "$approval" != "yes" ]; then
    echo "Deployment cancelled"
    exit 0
fi

# Step 6: Apply
echo ""
echo "Step 6: Applying..."
terraform apply "tfplan-${ENV}"

# Step 7: Outputs
echo ""
terraform output

rm -f "tfplan-${ENV}"

echo ""
echo "============================================"
echo "PRODUCTION DEPLOYMENT COMPLETE"
echo "============================================"
