output "resource_group_name" {
  value = azurerm_resource_group.moveit.name
}
output "vnet_id" {
  value = azurerm_virtual_network.moveit.id
}
output "subnet_id" {
  value = azurerm_subnet.moveit.id
}
