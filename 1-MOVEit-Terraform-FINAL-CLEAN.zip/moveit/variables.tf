variable "subscription_id" {
  type = string
}
variable "tenant_id" {
  type = string
}
variable "environment" {
  type = string
}
variable "location" {
  type    = string
  default = "eastus"
}
variable "project_name" {
  type    = string
  default = "moveit"
}
variable "vnet_address_space" {
  type    = list(string)
  default = ["10.1.0.0/16"]
}
variable "subnet_address_prefixes" {
  type    = list(string)
  default = ["10.1.1.0/24"]
}
variable "tags" {
  type    = map(string)
  default = {}
}
