# Datadog-OneFile-AutoDeploy.ps1
# FULL AUTOMATED DEPLOYMENT - SINGLE FILE (FIXED PROVIDERS)
# Requires only: Datadog API Key + Datadog APP Key

param(
    [Parameter(Mandatory=$true)][string]$DatadogApiKey,
    [Parameter(Mandatory=$true)][string]$DatadogAppKey,
    [string]$DatadogRegion = "us3",
    [string]$CsvReportPath = ".\Datadog-AutoReport.csv"
)

$ErrorActionPreference = "Stop"
$Report = @()

function Log {
    param($Stage,$Status,$Details)
    $Report += [pscustomobject]@{
        Timestamp = (Get-Date)
        Stage     = $Stage
        Status    = $Status
        Details   = $Details
    }
}

function Get-DatadogSiteFromRegion {
    param([string]$Region)
    switch ($Region.ToLower()) {
        "us1" { "datadoghq.com" }
        "us3" { "us3.datadoghq.com" }
        "us5" { "us5.datadoghq.com" }
        "eu"  { "datadoghq.eu" }
        "ap1" { "ap1.datadoghq.com" }
        default { "datadoghq.com" }
    }
}

$ddSite = Get-DatadogSiteFromRegion -Region $DatadogRegion
Log "START" "OK" "Datadog Automation Script Started (Region=$DatadogRegion, Site=$ddSite)"

Write-Host "`n=== Detecting Azure Subscriptions ==="
$subs = Get-AzSubscription
if (-not $subs -or $subs.Count -eq 0) {
    Write-Host "No subscriptions found."; 
    Log "Subscription Discovery" "FAIL" "No subscriptions found"
    exit 1
}

for ($i=0; $i -lt $subs.Count; $i++) {
    Write-Host "[$i] $($subs[$i].Name) - $($subs[$i].Id)"
}

$sel = Read-Host "Enter subscription index"
if (-not $sel -or $sel -notmatch '^\d+$' -or [int]$sel -ge $subs.Count) {
    Write-Host "Invalid selection."; 
    Log "Subscription Select" "FAIL" "Invalid index $sel"
    exit 1
}

$sub = $subs[[int]$sel]
Select-AzSubscription -SubscriptionId $sub.Id | Out-Null
Log "Subscription Selected" "OK" $sub.Id

Write-Host "`n=== Registering Resource Providers ==="
# Note: Correct Azure namespaces include 'Microsoft.Datadog', not 'Datadog'
$providers = @(
    "Microsoft.Insights",
    "Microsoft.OperationsManagement",
    "Microsoft.Resources",
    "Microsoft.Datadog"
)

foreach ($p in $providers) {
    try {
        $prov = Get-AzResourceProvider -ProviderNamespace $p -ErrorAction Stop
        if ($prov.RegistrationState -ne "Registered") {
            Write-Host " Registering $p ..."
            Register-AzResourceProvider -ProviderNamespace $p | Out-Null
        }
        else {
            Write-Host " $p already registered."
        }
        Log "Provider $p" "OK" "State=$($prov.RegistrationState)"
    }
    catch {
        Write-Host " Skipping provider $p (not available in this subscription)" -ForegroundColor Yellow
        Log "Provider $p" "WARN" "Not available: $($_.Exception.Message)"
    }
}

Write-Host "`n=== Creating Datadog SPN ==="
$app = New-AzADApplication -DisplayName "Datadog-Auto-Monitoring"
$sp  = New-AzADServicePrincipal -ApplicationId $app.AppId
Log "SPN Created" "OK" "ObjectId: $($sp.Id)"

Write-Host "`n=== Assigning FULL RBAC ==="
$roles = @(
    "Reader",
    "Monitoring Reader",
    "Resource Health Contributor",
    "Managed Identity Operator"
)

foreach ($r in $roles) {
    try {
        New-AzRoleAssignment -ObjectId $sp.Id -RoleDefinitionName $r -Scope "/subscriptions/$($sub.Id)" | Out-Null
        Log "RBAC $r" "OK" "Assigned on subscription"
    }
    catch {
        Log "RBAC $r" "FAIL" $_.Exception.Message
    }
}

Write-Host "`n=== Installing Datadog Agent on ALL VMs ==="
$vms = Get-AzVM -Status
if (-not $vms -or $vms.Count -eq 0) {
    Write-Host "No VMs found in this subscription."
    Log "Agent Install" "WARN" "No VMs found"
}
else {
    foreach ($vm in $vms) {
        if ($vm.StorageProfile.OsDisk.OsType -eq "Windows") {
            Write-Host " Installing agent on Windows VM $($vm.Name)..."
            Invoke-AzVMRunCommand -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName `
            -CommandId "RunPowerShellScript" `
            -ScriptString @"
`$env:DD_API_KEY = '$DatadogApiKey'
`$env:DD_SITE    = '$ddSite'
Invoke-WebRequest -UseBasicParsing https://s3.amazonaws.com/dd-agent/scripts/install_script.ps1 -OutFile install.ps1
powershell -ExecutionPolicy Bypass -File install.ps1
"@ | Out-Null
            Log "Agent Install" "OK" "Windows VM $($vm.Name)"
        }
        else {
            Write-Host " Installing agent on Linux VM $($vm.Name)..."
            Invoke-AzVMRunCommand -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName `
            -CommandId "RunShellScript" `
            -ScriptString "DD_API_KEY=$DatadogApiKey DD_SITE=$ddSite bash -c '$(curl -L https://s3.amazonaws.com/dd-agent/scripts/install_script.sh)'" | Out-Null
            Log "Agent Install" "OK" "Linux VM $($vm.Name)"
        }
    }
}

Write-Host "`n=== Creating Subscription-Wide Datadog Monitors ==="

$headers = @{
    "DD-API-KEY"        = $DatadogApiKey
    "DD-APPLICATION-KEY" = $DatadogAppKey
    "Content-Type"      = "application/json"
}

function New-DDMonitor {
    param($Title,$Type,$Query,$Msg,$Options)

    $body = @{
        name    = $Title
        type    = $Type
        query   = $Query
        message = $Msg
        tags    = @("auto","subscription-wide","avd","monitoring")
        options = $Options
    }

    try {
        Invoke-RestMethod -Uri "https://api.$DatadogRegion.datadoghq.com/api/v1/monitor" `
            -Method Post -Headers $headers -Body ($body | ConvertTo-Json -Depth 10)
        Log "Monitor Created" "OK" $Title
    }
    catch {
        Log "Monitor Created" "FAIL" "$Title : $($_.Exception.Message)"
    }
}

# Global monitors (Option B - no RG or hostpool filters)
New-DDMonitor "AVD - CPU High" "metric alert" `
"avg(last_5m):avg:azure.compute.virtualmachine.percentage_cpu > 85" `
"CPU over 85%" `
@{ thresholds=@{critical=85;warning=75}; notify_no_data=$true }

New-DDMonitor "AVD - Memory Low" "metric alert" `
"avg(last_5m):avg:system.mem.pct_usable < 15" `
"Memory below 15%" `
@{ thresholds=@{critical=15;warning=20}; notify_no_data=$true }

New-DDMonitor "AVD - Disk High" "metric alert" `
"avg(last_5m):avg:system.disk.in_use > 85" `
"Disk usage over 85%" `
@{ thresholds=@{critical=85;warning=75}; notify_no_data=$true }

New-DDMonitor "AVD - VM Down" "service check" `
"azure.vm.status.over('host').last(2).count_by_status()" `
"VM Down Alert" `
@{ thresholds=@{critical=1}; notify_no_data=$true }

New-DDMonitor "AVD - Network Latency High" "metric alert" `
"avg(last_5m):avg:azure.network.latency > 100" `
"Network latency high" `
@{ thresholds=@{critical=100;warning=75} }

New-DDMonitor "AVD - Storage Unavailable" "service check" `
"azure.storage.availability.over('storage_account').last(3).count_by_status()" `
"Storage Unavailable" `
@{ thresholds=@{critical=1}; notify_no_data=$true }

New-DDMonitor "AVD - High User Sessions" "metric alert" `
"avg(last_10m):avg:azure.desktopvirtualization.hostpool.active_sessions > 80" `
"High user load" `
@{ thresholds=@{warning=80} }

New-DDMonitor "AVD - Failed User Connections" "metric alert" `
"sum(last_5m):sum:azure.desktopvirtualization.hostpool.failed_connections > 5" `
"Failed connection spikes" `
@{ thresholds=@{critical=5;warning=3} }

New-DDMonitor "AVD - Datadog Agent Loss" "service check" `
"datadog.agent.up.over('host').last(3).count_by_status()" `
"Datadog agent heartbeat lost" `
@{ thresholds=@{critical=1}; notify_no_data=$true }

New-DDMonitor "AVD - Subscription Events Surge" "event alert" `
"events('sources:azure').rollup('count').last('10m') > 5" `
"Unusual activity detected" `
@{ thresholds=@{critical=5} }

Write-Host "`n=== Exporting CSV Report ==="
$Report | Export-Csv -NoTypeInformation -Path $CsvReportPath

Write-Host "`n=== DONE ==="
Write-Host "Report saved to: $CsvReportPath"
