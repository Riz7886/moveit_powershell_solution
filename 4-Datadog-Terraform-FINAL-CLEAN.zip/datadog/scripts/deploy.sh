#!/bin/bash
set -e
ENV=${1:-dev}
echo "datadog AUTOMATED DEPLOYMENT"
./scripts/setup-backend.sh
terraform init -reconfigure -backend-config="key=datadog-${ENV}.tfstate"
terraform validate
terraform plan -var-file="environments/terraform-${ENV}.tfvars" -out="tfplan-${ENV}"
terraform apply -auto-approve "tfplan-${ENV}"
terraform output
rm -f "tfplan-${ENV}"
echo "DEPLOYMENT COMPLETE"
