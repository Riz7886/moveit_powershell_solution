# DATADOG MONITORING TERRAFORM

Complete automated Terraform deployment for Datadog monitoring infrastructure.

## QUICK START

### 1. UPDATE CONFIGURATION
Edit `environments/terraform-prod.tfvars`:
- Update subscription_id
- Update tenant_id
- Update datadog_api_key
- Update datadog_app_key
- Update alert_email

### 2. DEPLOY
```bash
terraform init
terraform plan -var-file=environments/terraform-prod.tfvars
terraform apply -var-file=environments/terraform-prod.tfvars
```

## WHAT IT DEPLOYS

- Resource Group for Datadog resources
- Log Analytics Workspace (optional)
- Storage Account for logs
- Diagnostic settings

## ENVIRONMENTS

- Production: Full monitoring, 90-day retention
- Development: Basic monitoring, 30-day retention
- Test: Minimal monitoring

## FILES

- main.tf: Main configuration
- variables.tf: All variables
- outputs.tf: All outputs
- environments/: Environment configs

## REQUIREMENTS

- Terraform >= 1.5.0
- Azure CLI >= 2.50.0
- Datadog account with API access

## CONFIGURATION

### Datadog API Keys
Get your API keys from: https://app.datadoghq.com/organization-settings/api-keys

### Alert Configuration
- alert_email: Email for notifications
- pagerduty_key: PagerDuty integration key
- slack_webhook_url: Slack webhook URL

### Monitoring Thresholds
- CPU: 85% critical, 75% warning (prod)
- Memory: 85% critical, 75% warning (prod)
- Disk: 85% critical, 75% warning (prod)

## DEPLOYMENT OPTIONS

### Deploy Production
```bash
terraform apply -var-file=environments/terraform-prod.tfvars
```

### Deploy Development
```bash
terraform apply -var-file=environments/terraform-dev.tfvars
```

### Deploy Test
```bash
terraform apply -var-file=environments/terraform-test.tfvars
```

## OUTPUTS

After deployment:
- resource_group_name
- log_analytics_workspace_id
- storage_account_name
- datadog_site

## TROUBLESHOOTING

See TROUBLESHOOTING.md for complete guide.

## TAGS

All resources tagged with:
- Environment
- ManagedBy: Terraform
- Project: Datadog
- CostCenter
- Owner
