# ============================================================================
# TEST ENVIRONMENT - DATADOG TERRAFORM
# ============================================================================

subscription_id = "YOUR-TEST-SUBSCRIPTION-ID"
tenant_id       = "YOUR-TENANT-ID"

environment  = "test"
location     = "eastus"
project_name = "datadog"
cost_center  = "IT-Test"
owner        = "devops-team@company.com"

# Datadog Configuration
datadog_api_key = "YOUR-DATADOG-API-KEY"
datadog_app_key = "YOUR-DATADOG-APP-KEY"
datadog_site    = "us3.datadoghq.com"

# Log Analytics
enable_log_analytics        = false
log_analytics_sku           = "PerGB2018"
log_analytics_retention_days = 30

# Alerts
alert_email        = "devops-team@company.com"
pagerduty_key      = ""
slack_webhook_url  = ""

# Monitoring
enable_monitoring          = false
cpu_threshold_critical     = 95
cpu_threshold_warning      = 85
memory_threshold_critical  = 95
memory_threshold_warning   = 85
disk_threshold_critical    = 95
disk_threshold_warning     = 85

# Tags
tags = {
  Application        = "Datadog"
  BusinessUnit       = "IT"
  CriticalityTier    = "Tier4"
  DataClassification = "Internal"
}
