# ============================================================================
# DEVELOPMENT ENVIRONMENT - DATADOG TERRAFORM
# ============================================================================

subscription_id = "YOUR-DEV-SUBSCRIPTION-ID"
tenant_id       = "YOUR-TENANT-ID"

environment  = "dev"
location     = "eastus"
project_name = "datadog"
cost_center  = "IT-Development"
owner        = "devops-team@company.com"

# Datadog Configuration
datadog_api_key = "YOUR-DATADOG-API-KEY"
datadog_app_key = "YOUR-DATADOG-APP-KEY"
datadog_site    = "us3.datadoghq.com"

# Log Analytics
enable_log_analytics        = true
log_analytics_sku           = "PerGB2018"
log_analytics_retention_days = 30

# Alerts
alert_email        = "devops-team@company.com"
pagerduty_key      = ""
slack_webhook_url  = "YOUR-SLACK-WEBHOOK-URL"

# Monitoring
enable_monitoring          = true
cpu_threshold_critical     = 90
cpu_threshold_warning      = 80
memory_threshold_critical  = 90
memory_threshold_warning   = 80
disk_threshold_critical    = 90
disk_threshold_warning     = 80

# Tags
tags = {
  Application        = "Datadog"
  BusinessUnit       = "IT"
  CriticalityTier    = "Tier3"
  DataClassification = "Internal"
}
