# ============================================================================
# PRODUCTION ENVIRONMENT - DATADOG TERRAFORM
# ============================================================================

subscription_id = "YOUR-PROD-SUBSCRIPTION-ID"
tenant_id       = "YOUR-TENANT-ID"

environment  = "prod"
location     = "eastus"
project_name = "datadog"
cost_center  = "IT-Production"
owner        = "devops-team@company.com"

# Datadog Configuration
datadog_api_key = "YOUR-DATADOG-API-KEY"
datadog_app_key = "YOUR-DATADOG-APP-KEY"
datadog_site    = "us3.datadoghq.com"

# Log Analytics
enable_log_analytics        = true
log_analytics_sku           = "PerGB2018"
log_analytics_retention_days = 90

# Alerts
alert_email        = "devops-team@company.com"
pagerduty_key      = "YOUR-PAGERDUTY-KEY"
slack_webhook_url  = "YOUR-SLACK-WEBHOOK-URL"

# Monitoring
enable_monitoring          = true
cpu_threshold_critical     = 85
cpu_threshold_warning      = 75
memory_threshold_critical  = 85
memory_threshold_warning   = 75
disk_threshold_critical    = 85
disk_threshold_warning     = 75

# Tags
tags = {
  Application        = "Datadog"
  BusinessUnit       = "IT"
  CriticalityTier    = "Tier1"
  DataClassification = "Confidential"
}
