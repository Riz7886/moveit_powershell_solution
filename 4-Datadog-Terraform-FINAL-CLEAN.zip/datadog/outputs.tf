# ============================================================================
# DATADOG MONITORING - OUTPUTS
# ============================================================================

output "resource_group_id" {
  description = "ID of the Datadog resource group"
  value       = azurerm_resource_group.datadog.id
}

output "resource_group_name" {
  description = "Name of the Datadog resource group"
  value       = azurerm_resource_group.datadog.name
}

output "resource_group_location" {
  description = "Location of the Datadog resource group"
  value       = azurerm_resource_group.datadog.location
}

output "log_analytics_workspace_id" {
  description = "ID of the Log Analytics Workspace"
  value       = var.enable_log_analytics ? azurerm_log_analytics_workspace.datadog[0].id : null
}

output "log_analytics_workspace_name" {
  description = "Name of the Log Analytics Workspace"
  value       = var.enable_log_analytics ? azurerm_log_analytics_workspace.datadog[0].name : null
}

output "storage_account_id" {
  description = "ID of the storage account"
  value       = azurerm_storage_account.datadog.id
}

output "storage_account_name" {
  description = "Name of the storage account"
  value       = azurerm_storage_account.datadog.name
}

output "storage_container_name" {
  description = "Name of the storage container"
  value       = azurerm_storage_container.logs.name
}

output "environment" {
  description = "Environment name"
  value       = var.environment
}

output "tags" {
  description = "Tags applied to resources"
  value       = local.common_tags
}

output "datadog_site" {
  description = "Datadog site URL"
  value       = var.datadog_site
}
