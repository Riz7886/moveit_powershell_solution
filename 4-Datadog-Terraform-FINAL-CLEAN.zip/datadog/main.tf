# ============================================================================
# DATADOG MONITORING - MAIN CONFIGURATION
# ============================================================================
# Purpose: Deploy Datadog monitoring infrastructure for Azure VMs
# Version: 1.0
# Terraform: >= 1.5.0
# ============================================================================

terraform {
  required_version = ">= 1.5.0"
  
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.80.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.5.0"
    }
  }
  
  backend "azurerm" {
    resource_group_name  = "rg-terraform-state"
    storage_account_name = "stterraformstate"
    container_name       = "tfstate"
    key                  = "datadog.terraform.tfstate"
  }
}

provider "azurerm" {
  features {
    resource_group {
      prevent_deletion_if_contains_resources = false
    }
  }
  
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
}

# ============================================================================
# LOCAL VARIABLES
# ============================================================================

locals {
  common_tags = merge(
    var.tags,
    {
      Environment    = var.environment
      ManagedBy      = "Terraform"
      Project        = "Datadog"
      DeploymentDate = timestamp()
      CostCenter     = var.cost_center
      Owner          = var.owner
    }
  )

  resource_prefix = "${var.project_name}-${var.environment}"
  
  # Storage account name
  storage_name = lower("stdd${var.environment}${random_string.unique.result}")
}

# ============================================================================
# RANDOM STRING
# ============================================================================

resource "random_string" "unique" {
  length  = 6
  special = false
  upper   = false
}

# ============================================================================
# RESOURCE GROUP
# ============================================================================

resource "azurerm_resource_group" "datadog" {
  name     = "rg-${local.resource_prefix}-datadog"
  location = var.location
  tags     = local.common_tags
}

# ============================================================================
# LOG ANALYTICS WORKSPACE
# ============================================================================

resource "azurerm_log_analytics_workspace" "datadog" {
  count = var.enable_log_analytics ? 1 : 0

  name                = "law-${local.resource_prefix}-${random_string.unique.result}"
  location            = azurerm_resource_group.datadog.location
  resource_group_name = azurerm_resource_group.datadog.name
  sku                 = var.log_analytics_sku
  retention_in_days   = var.log_analytics_retention_days
  tags                = local.common_tags
}

# ============================================================================
# STORAGE ACCOUNT
# ============================================================================

resource "azurerm_storage_account" "datadog" {
  name                     = local.storage_name
  resource_group_name      = azurerm_resource_group.datadog.name
  location                 = azurerm_resource_group.datadog.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  tags                     = local.common_tags
}

resource "azurerm_storage_container" "logs" {
  name                  = "datadog-logs"
  storage_account_name  = azurerm_storage_account.datadog.name
  container_access_type = "private"
}
