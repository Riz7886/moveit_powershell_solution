# ============================================================================
# DATADOG MONITORING - VARIABLES
# ============================================================================

# ============================================================================
# AZURE AUTHENTICATION
# ============================================================================

variable "subscription_id" {
  description = "Azure Subscription ID"
  type        = string
}

variable "tenant_id" {
  description = "Azure Tenant ID"
  type        = string
}

# ============================================================================
# GENERAL CONFIGURATION
# ============================================================================

variable "environment" {
  description = "Environment name (prod, dev, test)"
  type        = string
  validation {
    condition     = contains(["prod", "dev", "test"], var.environment)
    error_message = "Environment must be prod, dev, or test"
  }
}

variable "location" {
  description = "Azure region for resources"
  type        = string
  default     = "eastus"
}

variable "project_name" {
  description = "Project name for resource naming"
  type        = string
  default     = "datadog"
}

variable "cost_center" {
  description = "Cost center for billing"
  type        = string
  default     = "IT"
}

variable "owner" {
  description = "Owner email or team name"
  type        = string
  default     = "devops-team"
}

# ============================================================================
# DATADOG CONFIGURATION
# ============================================================================

variable "datadog_api_key" {
  description = "Datadog API Key"
  type        = string
  sensitive   = true
  default     = ""
}

variable "datadog_app_key" {
  description = "Datadog Application Key"
  type        = string
  sensitive   = true
  default     = ""
}

variable "datadog_site" {
  description = "Datadog site (us1, us3, us5, eu, ap1)"
  type        = string
  default     = "us3.datadoghq.com"
  validation {
    condition     = contains(["us1.datadoghq.com", "us3.datadoghq.com", "us5.datadoghq.com", "eu.datadoghq.com", "ap1.datadoghq.com"], var.datadog_site)
    error_message = "Datadog site must be one of: us1, us3, us5, eu, ap1"
  }
}

# ============================================================================
# LOG ANALYTICS CONFIGURATION
# ============================================================================

variable "enable_log_analytics" {
  description = "Enable Log Analytics Workspace"
  type        = bool
  default     = true
}

variable "log_analytics_sku" {
  description = "Log Analytics Workspace SKU"
  type        = string
  default     = "PerGB2018"
  validation {
    condition     = contains(["Free", "Standard", "Premium", "PerNode", "PerGB2018", "Standalone"], var.log_analytics_sku)
    error_message = "Invalid Log Analytics SKU"
  }
}

variable "log_analytics_retention_days" {
  description = "Log Analytics retention in days"
  type        = number
  default     = 30
  validation {
    condition     = var.log_analytics_retention_days >= 30 && var.log_analytics_retention_days <= 730
    error_message = "Retention must be between 30 and 730 days"
  }
}

# ============================================================================
# ALERT CONFIGURATION
# ============================================================================

variable "alert_email" {
  description = "Email address for alerts"
  type        = string
  default     = ""
}

variable "pagerduty_key" {
  description = "PagerDuty integration key"
  type        = string
  sensitive   = true
  default     = ""
}

variable "slack_webhook_url" {
  description = "Slack webhook URL for alerts"
  type        = string
  sensitive   = true
  default     = ""
}

# ============================================================================
# MONITORING CONFIGURATION
# ============================================================================

variable "enable_monitoring" {
  description = "Enable Datadog monitoring"
  type        = bool
  default     = true
}

variable "cpu_threshold_critical" {
  description = "CPU usage critical threshold (percentage)"
  type        = number
  default     = 85
}

variable "cpu_threshold_warning" {
  description = "CPU usage warning threshold (percentage)"
  type        = number
  default     = 75
}

variable "memory_threshold_critical" {
  description = "Memory usage critical threshold (percentage)"
  type        = number
  default     = 85
}

variable "memory_threshold_warning" {
  description = "Memory usage warning threshold (percentage)"
  type        = number
  default     = 75
}

variable "disk_threshold_critical" {
  description = "Disk usage critical threshold (percentage)"
  type        = number
  default     = 85
}

variable "disk_threshold_warning" {
  description = "Disk usage warning threshold (percentage)"
  type        = number
  default     = 75
}

# ============================================================================
# TAGS
# ============================================================================

variable "tags" {
  description = "Additional tags to apply to resources"
  type        = map(string)
  default     = {}
}
